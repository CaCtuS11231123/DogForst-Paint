"""Per-document recovery lifecycle. Workers receive snapshots, never widgets."""
import logging
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

from PySide6.QtCore import QObject, QRunnable, QThreadPool, QTimer, Signal, QLockFile, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QProgressBar, QToolButton, QMessageBox, QDialog
from diagnostics import application_data_directory
from recovery import DocumentSnapshot, RecoveryStore, RecoveryRecord
from safety_dialogs import SafetySettingsDialog, ProjectCopiesDialog, SaveProgressDialog
from storage import OperationCancelled, list_versions
from project_manager import read_project, save_project

LOG = logging.getLogger('dogforst')


class SaveSignals(QObject):
    progress = Signal(int, str)
    finished = Signal(object, str, bool)


class RecoveryWriteJob(QRunnable):
    def __init__(self, store, snapshot, session, revision, source):
        super().__init__()
        self.store, self.snapshot = store, snapshot
        self.session, self.revision, self.source = session, revision, source
        self.cancelled = threading.Event()
        self.signals = SaveSignals()

    def run(self):
        try:
            record = self.store.write(self.snapshot, self.session, self.revision, self.source,
                self.cancelled, self.signals.progress.emit)
            self.signals.finished.emit(record, '', self.cancelled.is_set())
        except OperationCancelled:
            self.signals.finished.emit(None, '', True)
        except Exception as error:
            LOG.exception('Recovery write failed')
            self.signals.finished.emit(None, str(error), False)


class ManualSignals(QObject):
    progress = Signal(int, str)
    finished = Signal(object, object)


class ManualWriteJob(QRunnable):
    def __init__(self, snapshot, filename, options):
        super().__init__()
        self.snapshot, self.filename, self.options = snapshot, filename, options
        self.cancelled = threading.Event()
        self.signals = ManualSignals()

    def run(self):
        try:
            result = save_project(self.filename, self.snapshot.size, self.snapshot.layers,
                self.snapshot.active_layer, list(self.snapshot.texts), cancelled=self.cancelled,
                progress=self.signals.progress.emit, groups=list(self.snapshot.groups),
                layer_stack=list(self.snapshot.layer_stack) or None,masks=dict(self.snapshot.masks),
                disabled_masks=self.snapshot.disabled_masks,raster_objects=dict(self.snapshot.raster_objects), **self.options)
            self.signals.finished.emit(result, None)
        except OperationCancelled as error:
            self.signals.finished.emit(None, error)
        except Exception as error:
            LOG.exception('Manual project write failed')
            self.signals.finished.emit(None, error)


class SafetyController(QObject):
    def __init__(self, window):
        super().__init__(window)
        self.window, self.settings = window, window.settings
        self.root = application_data_directory()
        self.store = RecoveryStore(self.root / 'recovery')
        self.pool = QThreadPool(self)
        self.pool.setMaxThreadCount(1)
        self.job = None
        self.manual_job = None
        self.last_manual_snapshot = None
        self.session = None
        self.revision = 0
        self.clean_revision = 0
        self.last_autosaved = -1
        self.source_session = None
        self.closing = False
        self.closed = False
        self.locks = {}
        self.enabled = self.settings.value('safety/enabled', True, type=bool)
        self.minutes = self._number('safety/minutes', 2, 1, 60)
        self.backup_limit = self._number('safety/backups', 10, 1, 50)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.request_autosave)
        self.timer.setInterval(self.minutes * 60_000)
        self.retry = QTimer(self)
        self.retry.setSingleShot(True)
        self.retry.timeout.connect(lambda: self.request_autosave(force=True))
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setFixedWidth(185)
        self.progress.setFormat('Автосохранение %p%')
        self.cancel_button = QToolButton()
        self.cancel_button.setText('Отмена')
        self.cancel_button.setToolTip('Отменить создание копии восстановления')
        self.cancel_button.clicked.connect(self.cancel)
        self.window.statusBar().addPermanentWidget(self.progress)
        self.window.statusBar().addPermanentWidget(self.cancel_button)
        self.progress.hide()
        self.cancel_button.hide()
        self.new_document()
        if self.enabled:
            self.timer.start()

    def _number(self, key, default, minimum, maximum):
        try:
            return max(minimum, min(maximum, int(self.settings.value(key, default))))
        except (ValueError, TypeError):
            return default

    def new_document(self):
        old = self.session
        if old:
            self._discard(old)
            if not self.job or self.job.session != old:
                self._unlock(old)
        if self.source_session:
            self._discard(self.source_session)
        self.session = uuid.uuid4().hex
        directory = self.store.session_directory(self.session)
        directory.mkdir(parents=True, exist_ok=True)
        lock = QLockFile(str(directory / '.lock'))
        lock.setStaleLockTime(0)
        if not lock.tryLock(0):
            raise OSError('Не удалось заблокировать сеанс восстановления.')
        self.locks[self.session] = lock
        self.revision, self.clean_revision, self.last_autosaved = 0, 0, -1
        self.source_session = None

    def modified(self):
        self.revision += 1

    def saved(self, revision=None):
        self.clean_revision = self.revision if revision is None else revision
        self._discard(self.session)
        if self.source_session:
            self._discard(self.source_session)
            self.source_session = None

    def _discard(self, session):
        try:
            self.store.discard_session(session)
        except (OSError, ValueError):
            LOG.exception('Could not clean recovery session')

    def _unlock(self, session):
        lock = self.locks.pop(session, None)
        if lock:
            lock.unlock()
        try:
            self.store.session_directory(session).rmdir()
        except OSError:
            pass

    def request_autosave(self, force=False):
        if self.closed:
            return False
        if self.job or self.manual_job:
            if force:
                self.window.statusBar().showMessage('Сохранение уже выполняется.', 5000)
            return False
        if not self.window.dirty:
            if force:
                self.window.statusBar().showMessage('Нет несохранённых изменений для копии восстановления.', 6000)
            return False
        if not force and (not self.enabled or self.revision == self.last_autosaved):
            return False
        canvas = self.window.canvas
        if canvas.drawing or canvas.fill_job is not None or canvas._opacity_edit or getattr(self.window,"_color_picker_active",False):
            if force:
                self.window.statusBar().showMessage("Копия будет создана после завершения текущего действия.", 5000)
                self.retry.start(500)
            return False
        try:
            snapshot = DocumentSnapshot.capture(canvas)
        except Exception as error:
            LOG.exception('Could not capture document for recovery')
            self.window.statusBar().showMessage('Автосохранение не выполнено: ' + str(error), 10000)
            return False
        self.job = RecoveryWriteJob(self.store, snapshot, self.session, self.revision,
                                   str(self.window.current_file) if self.window.current_file else None)
        self.job.signals.progress.connect(self._progress)
        self.job.signals.finished.connect(self._finished)
        self.progress.setValue(0)
        self.progress.show()
        self.cancel_button.show()
        self.pool.start(self.job)
        return True

    def _progress(self, percent, description):
        self.progress.setValue(percent)
        self.progress.setToolTip(description)

    def cancel(self):
        if self.job:
            self.job.cancelled.set()
            self.window.statusBar().showMessage('Отмена автосохранения…')

    def _finished(self, record, error, cancelled):
        job = self.job
        if job is None:
            return
        self.job = None
        self.progress.hide()
        self.cancel_button.hide()
        stale = (job.session != self.session or job.revision <= self.clean_revision)
        if record and (stale or cancelled):
            try:
                self.store.remove(record)
            except OSError:
                LOG.exception('Could not remove obsolete recovery generation')
        elif record:
            self.last_autosaved = job.revision
            self.window.statusBar().showMessage('Копия восстановления сохранена. Основной проект не изменён.', 6000)
        if error:
            self.window.statusBar().showMessage('Автосохранение не выполнено: ' + error, 15000)
        elif cancelled:
            self.window.statusBar().showMessage('Автосохранение отменено. Имеющиеся полные копии не изменены.', 6000)
        if job.session != self.session:
            self._discard(job.session)
            self._unlock(job.session)
        if self.closing and self.manual_job is None:
            self.closing = False
            QTimer.singleShot(0, self.window.close)

    def prepare_close(self):
        if self.manual_job:
            self.closing = True
            self.manual_job.cancelled.set()
            return False
        if self.job:
            self.closing = True
            self.cancel()
            return False
        return True

    def write_project(self, filename, **options):
        if self.manual_job:
            raise OSError('Сохранение проекта уже выполняется.')
        if self.job:
            self.job.cancelled.set()
        session, revision = self.session, self.revision
        snapshot = DocumentSnapshot.capture(self.window.canvas)
        # Even Save As must detect a file changed while the dialog/worker was open.
        from storage import project_fingerprint
        options.setdefault('expected_fingerprint', project_fingerprint(filename))
        self.manual_job = ManualWriteJob(snapshot, filename, options)
        dialog = SaveProgressDialog(filename, self.manual_job.cancelled.set, self.window)
        self.manual_job.signals.progress.connect(dialog.update_progress)
        self.manual_job.signals.finished.connect(dialog.finish)
        self.pool.start(self.manual_job)
        try:
            result, error = dialog.run()
        finally:
            self.manual_job = None
            dialog.deleteLater()
        if self.closing:
            self.closing = False
            QTimer.singleShot(0, self.window.close)
        if error:
            raise error
        if session != self.session:
            raise OSError('Снимок сохранён, но текущий документ уже сменился. Откройте сохранённый файл отдельно.')
        self.last_manual_snapshot = (session, revision)
        return result

    def finish_close(self):
        self.closed = True
        self.timer.stop()
        self.retry.stop()
        self._discard(self.session)
        if self.source_session:
            self._discard(self.source_session)
        for session in list(self.locks):
            self._unlock(session)

    def show_settings(self):
        dialog = SafetySettingsDialog(self.enabled, self.minutes, self.backup_limit,
                                      self.root, self.window)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        self.enabled = dialog.enabled.isChecked()
        self.minutes = dialog.minutes.value()
        self.backup_limit = dialog.backups.value()
        self.settings.setValue('safety/enabled', self.enabled)
        self.settings.setValue('safety/minutes', self.minutes)
        self.settings.setValue('safety/backups', self.backup_limit)
        self.settings.sync()
        self.timer.setInterval(self.minutes * 60_000)
        self.timer.start() if self.enabled else self.timer.stop()

    def offer_recovery(self, quiet=False):
        records = self.store.candidates()
        if not records:
            if not quiet:
                self.window.statusBar().showMessage('Копии для восстановления не найдены.', 5000)
            return
        dialog = ProjectCopiesDialog(records, self.window)
        if dialog.exec() == QDialog.DialogCode.Accepted and dialog.selected_record:
            self.restore(dialog.selected_record, recovery=True)

    def show_versions(self):
        source = self.window.current_file
        if not source:
            self.window.statusBar().showMessage('Сначала сохраните проект, чтобы появилась история версий.', 6000)
            return
        records = [RecoveryRecord(p, '', -1, source,
            datetime.fromtimestamp(p.stat().st_mtime, timezone.utc).isoformat())
            for p in list_versions(source)]
        if not records:
            self.window.statusBar().showMessage('Предыдущих версий ещё нет: они создаются при повторном сохранении.', 7000)
            return
        dialog = ProjectCopiesDialog(records, self.window, 'Предыдущие версии проекта')
        if dialog.exec() == QDialog.DialogCode.Accepted and dialog.selected_record:
            self.restore(dialog.selected_record, recovery=False)

    def restore(self, record, recovery=True):
        try:
            # Load first: saving the current document may prune the selected old backup.
            project = read_project(str(record.path))
        except Exception as error:
            LOG.exception('Recovery project validation failed')
            QMessageBox.warning(self.window, 'Восстановление', str(error))
            return False
        if not self.window.confirm_document_change():
            return False
        self.window.canvas.apply_loaded_project(project)
        self.new_document()
        self.source_session = record.session if recovery else None
        self.window.current_file = None
        self.window._file_token = self.window._file_token_path = None
        self.window.canvas.history.clear()
        self.window.canvas.future.clear()
        self.window.mark_dirty()
        self.window.refresh_layers()
        self.window.statusBar().showMessage('Восстановлена несохранённая копия. Сохраните её под выбранным именем.', 10000)
        return True

    def open_logs(self):
        directory = self.root / 'logs'
        directory.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(directory)))
