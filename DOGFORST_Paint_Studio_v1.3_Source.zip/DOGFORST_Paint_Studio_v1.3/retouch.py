"""Six real local tools, processed as bounded patches in sequential background jobs.

The document stays unchanged during a stroke. Only copied local patches enter a
worker; preview has one full-size work image, not a fresh canvas per mouse event.
"""
import math,threading,uuid,copy
from collections import deque
from dataclasses import dataclass
import numpy as np
from scipy.ndimage import gaussian_filter
from PySide6.QtCore import Qt,QPointF,QRectF,QRect,QObject,Signal,QRunnable,QThreadPool
from PySide6.QtGui import QColor,QImage,QPainter,QPen
from layers import Layer
from ink_stroke import clip_segment

RETOUCH_TOOLS=('Палец','Размытие','Резкость','Штамп','Осветление','Затемнение')
DEFAULT_RETOUCH=dict(strength=35,hardness=65,aligned=True)

def array(image):
    image=image.convertToFormat(QImage.Format.Format_RGBA8888)
    data=np.frombuffer(image.constBits(),np.uint8).reshape(image.height(),image.bytesPerLine())[:,:image.width()*4].reshape(image.height(),image.width(),4).astype(np.float32)/255
    return data

def rgba_image(values):
    values=np.ascontiguousarray(np.round(np.clip(values,0,1)*255).astype(np.uint8))
    return QImage(values.data,values.shape[1],values.shape[0],values.shape[1]*4,QImage.Format.Format_RGBA8888).copy().convertToFormat(QImage.Format.Format_ARGB32)

def blend_pixels(before,after,weight,alpha_locked=False,mask_only=False):
    a=before[:,:,3:4];b=after[:,:,3:4];alpha=a*(1-weight)+b*weight
    premult=before[:,:,:3]*a*(1-weight)+after[:,:,:3]*b*weight
    rgb=np.divide(premult,np.maximum(alpha,1e-8),out=np.zeros_like(premult),where=alpha>1e-8)
    if alpha_locked:alpha=a
    if mask_only:
        gray=rgb[:,:,0:1]*.299+rgb[:,:,1:2]*.587+rgb[:,:,2:3]*.114;rgb=np.repeat(gray,3,axis=2);alpha=np.ones_like(alpha)
    return np.concatenate((rgb,alpha),axis=2)

@dataclass(frozen=True)
class RetouchInput:
    image:object
    target:object
    point:object
    diameter:int
    strength:int
    opacity:int
    hardness:int
    tool:str
    coverage:object=None
    sample:object=None
    alpha_locked:bool=False
    mask_only:bool=False

def process_patch(data,cancelled):
    if data.tool not in RETOUCH_TOOLS:raise ValueError('Неизвестный инструмент ретуши.')
    if not 1<=data.diameter<=512 or not 0<=data.strength<=100 or not 0<=data.opacity<=100 or not 0<=data.hardness<=100:raise ValueError('Некорректные параметры ретуши.')
    if cancelled.is_set():return None
    pixels=array(data.image);processed=pixels.copy();sigma=max(.5,min(12.,data.diameter*.035))
    if data.tool in ('Размытие','Резкость'):
        alpha=pixels[:,:,3:4];premult=pixels[:,:,:3]*alpha
        blurred=np.empty_like(premult)
        for channel in range(3):
            if cancelled.is_set():return None
            blurred[:,:,channel]=gaussian_filter(premult[:,:,channel],sigma=sigma,mode='nearest',truncate=3)
        blurred_alpha=gaussian_filter(alpha[:,:,0],sigma=sigma,mode='nearest',truncate=3)[:,:,None]
        rgb=np.divide(blurred,np.maximum(blurred_alpha,1e-8),out=np.zeros_like(blurred),where=blurred_alpha>1e-8)
        if data.tool=='Размытие':processed=np.concatenate((rgb,blurred_alpha),axis=2)
        else:processed[:,:,:3]=np.clip(pixels[:,:,:3]+1.5*(pixels[:,:,:3]-rgb),0,1)
    elif data.tool=='Осветление':processed[:,:,:3]=1-(1-pixels[:,:,:3])*.72
    elif data.tool=='Затемнение':processed[:,:,:3]=pixels[:,:,:3]*.72
    elif data.sample is not None:processed=array(data.sample)
    else:return QImage(data.image.copy(data.target))
    r=data.target;before=pixels[r.y():r.y()+r.height(),r.x():r.x()+r.width()];after=processed[r.y():r.y()+r.height(),r.x():r.x()+r.width()]
    yy,xx=np.mgrid[0:r.height(),0:r.width()];cx,cy=data.point.x(),data.point.y();radius=max(.5,data.diameter/2)
    distance=np.sqrt((xx+.5-cx)**2+(yy+.5-cy)**2)/radius;hard=data.hardness/100
    falloff=(distance<=1).astype(np.float32) if hard>=.999 else np.clip((1-distance)/max(.001,1-hard),0,1)
    weight=falloff[:,:,None]*(data.strength/100)*(data.opacity/100)
    if data.coverage is not None:weight*=array(data.coverage)[:,:,0:1]
    if data.tool=='Штамп':
        # Clone paints sampled pixels over target, rather than erasing with transparent source.
        source_alpha=after[:,:,3:4];out_alpha=source_alpha+before[:,:,3:4]*(1-source_alpha)
        rgb=(after[:,:,:3]*source_alpha+before[:,:,:3]*before[:,:,3:4]*(1-source_alpha))/np.maximum(out_alpha,1e-8)
        after=np.concatenate((rgb,out_alpha),axis=2)
    output=rgba_image(blend_pixels(before,after,weight,data.alpha_locked,data.mask_only))
    # Preserve exact RGBA bytes for zero coverage; no resampling of unselected pixels.
    untouched=falloff==0
    if data.alpha_locked:untouched|=before[:,:,3]==0
    if data.coverage is not None:untouched|=array(data.coverage)[:,:,0]==0
    if untouched.any():
        original=data.image.copy(r).convertToFormat(QImage.Format.Format_ARGB32)
        a=np.frombuffer(original.constBits(),np.uint32).reshape(r.height(),original.bytesPerLine()//4)[:,:r.width()]
        b=np.frombuffer(output.bits(),np.uint32).reshape(r.height(),output.bytesPerLine()//4)[:,:r.width()];b[untouched]=a[untouched]
    return None if cancelled.is_set() else output

class RetouchSignals(QObject):done=Signal(object,object,str)
class RetouchJob(QRunnable):
    def __init__(self,uid,rect,data):
        super().__init__();self.uid=uid;self.rect=rect;self.data=data;self.cancelled=threading.Event();self.signals=RetouchSignals()
    def run(self):
        try:self.signals.done.emit(self,process_patch(self.data,self.cancelled),'')
        except Exception as e:self.signals.done.emit(self,None,'Недостаточно памяти для ретуши.' if isinstance(e,MemoryError) else str(e))

class RetouchSession:
    def __init__(self,node_id,mask_id,stamp,raw,coverage,tool,settings,diameter,opacity,alpha_locked,clone_delta):
        self.uid=uuid.uuid4().hex;self.node_id=node_id;self.mask_id=mask_id;self.stamp=stamp;self.raw=raw;self.work=QImage(raw);self.coverage=coverage
        self.tool=tool;self.settings=copy.deepcopy(settings);self.diameter=diameter;self.opacity=opacity;self.alpha_locked=alpha_locked;self.clone_delta=clone_delta
        self.points=deque();self.last_input=None;self.last_processed=None;self.remaining=0.;self.released=False;self.changes=0;self.processed=0

class RetouchMixin:
    def init_retouch(self):
        self.retouch_session=None;self._retouch_job=None;self.retouch_options=dict(DEFAULT_RETOUCH);self.clone_anchor=None;self.clone_delta=None
    def retouch_target(self):return ('mask',self.editing_mask) if self.editing_mask in self.masks else ('layer',self.active.id)
    def set_clone_source(self,pos):
        if not QRectF(0,0,*self.doc_size).contains(pos):return False
        self.clone_anchor=(self.retouch_target(),QPointF(pos));self.clone_delta=None;self.retouchChanged.emit();self.update();self.status.emit('Источник штампа выбран. Проведите кистью в месте копирования.');return True
    def start_retouch(self,pos):
        if self.retouch_session is not None:return False
        if self.adjustment_session is not None or self.fill_job is not None or self.wand_job is not None or self.gradient_session is not None or self.selection_transform is not None:return False
        if self.tool not in RETOUCH_TOOLS or self.retouch_options['strength']==0 or self.brush_opacity==0:return False
        mask_id=self.editing_mask if self.editing_mask in self.masks else None
        if mask_id is None and (len(self.selected_node_ids())!=1 or self.control_node().kind=='group'):
            self.status.emit('Выберите один слой для ретуши.');return False
        if not (self.can_edit_mask(mask_id) if mask_id else self.can_edit()):return False
        delta=None
        if self.tool=='Штамп':
            if self.clone_anchor is None or self.clone_anchor[0]!=self.retouch_target():self.status.emit('Штамп: сначала Alt+нажатие по источнику на выбранном слое/маске.');return False
            delta=self.clone_delta if self.retouch_options['aligned'] and self.clone_delta is not None else self.clone_anchor[1]-pos
            if self.retouch_options['aligned']:self.clone_delta=QPointF(delta)
        raw=QImage(self.masks[mask_id]) if mask_id else self.raw_pixels(self.active)
        node=self.node(mask_id) if mask_id else self.active
        self.retouch_session=RetouchSession(node.id,mask_id,self.selection_stamp(),raw,self.selection_coverage() if self.selection else None,self.tool,self.retouch_options,self.brush_size,self.brush_opacity,bool(node.alpha_locked) if not mask_id else False,delta)
        self.drawing=True;self._interaction='retouch';self.retouchChanged.emit();self.queue_retouch(pos);self.update();return True
    def queue_retouch(self,pos):
        s=self.retouch_session
        if s is None or s.released or not all(math.isfinite(v) and abs(v)<=100000 for v in (pos.x(),pos.y())):return
        a=s.last_input;pos=QPointF(pos);s.last_input=pos
        if a is None:s.points.append(pos);s.remaining=max(1.,s.diameter*.18)
        else:
            spacing=max(1.,s.diameter*.18);length=math.hypot(pos.x()-a.x(),pos.y()-a.y());radius=s.diameter/2+1
            clip=clip_segment(a,pos,QRectF(0,0,*self.doc_size).adjusted(-radius,-radius,radius,radius))
            if length and clip:
                d=s.remaining+max(0,math.ceil((clip[0]*length-s.remaining)/spacing))*spacing
                while d<=min(length,clip[1]*length)+1e-8:
                    if len(s.points)>=8192:self.cancel_retouch();self.status.emit('Слишком длинная очередь ретуши. Повторите более коротким штрихом.');return
                    s.points.append(a+(pos-a)*(d/length));d+=spacing
            if length:s.remaining=(s.remaining-length)%spacing
        self.launch_retouch_job()
    def finish_retouch(self):
        s=self.retouch_session
        if s is None:return False
        s.released=True;self.drawing=False;self.retouchChanged.emit();self.launch_retouch_job();return True
    def launch_retouch_job(self):
        s=self.retouch_session
        if s is None or self._retouch_job is not None:return
        while s.points:
            point=s.points.popleft();previous=s.last_processed;s.last_processed=point
            if s.tool=='Палец' and previous is None:continue
            radius=s.diameter/2+1;target=QRectF(point.x()-radius,point.y()-radius,radius*2,radius*2).toAlignedRect().intersected(s.work.rect())
            if target.isEmpty():continue
            halo=math.ceil(3*max(.5,min(12.,s.diameter*.035)))+2 if s.tool in ('Размытие','Резкость') else 0
            expanded=target.adjusted(-halo,-halo,halo,halo).intersected(s.work.rect());sample=None
            if s.tool=='Штамп':sample=s.raw.copy(expanded.translated(round(s.clone_delta.x()),round(s.clone_delta.y())))
            elif s.tool=='Палец':sample=s.work.copy(expanded.translated(round(previous.x()-point.x()),round(previous.y()-point.y())))
            local=target.translated(-expanded.topLeft());coverage=s.coverage.copy(target) if s.coverage is not None else None
            data=RetouchInput(s.work.copy(expanded),local,point-QPointF(target.topLeft()),s.diameter,s.settings['strength'],s.opacity,s.settings['hardness'],s.tool,coverage,sample,s.alpha_locked,bool(s.mask_id))
            job=RetouchJob(s.uid,target,data);self._retouch_job=job;job.signals.done.connect(self.finish_retouch_job);QThreadPool.globalInstance().start(job);return
        if s.released:self.apply_retouch()
    def finish_retouch_job(self,job,patch,error):
        if job is not self._retouch_job:return
        self._retouch_job=None;s=self.retouch_session
        if s is None:return
        if s.uid!=job.uid:self.launch_retouch_job();return
        if self.selection_stamp()!=s.stamp:self.cancel_retouch();self.status.emit('Документ изменился: ретушь отменена.');return
        if error:self.cancel_retouch();self.status.emit(error);return
        if patch is not None and patch!=s.work.copy(job.rect):
            p=QPainter(s.work);p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Source);p.drawImage(job.rect.topLeft(),patch);p.end();s.changes+=1;self.update()
        s.processed+=1;self.retouchChanged.emit();self.launch_retouch_job()
    def apply_retouch(self):
        s=self.retouch_session
        if s is None:return False
        if self.selection_stamp()!=s.stamp or self.control_node().id!=s.node_id or self.editing_mask!=s.mask_id:self.cancel_retouch();return False
        if s.changes==0 or s.work==s.raw:self.cancel_retouch();return True
        self.retouch_session=None;self.drawing=False;self._interaction='';self.push_history()
        if s.mask_id:self.masks[s.mask_id]=s.work
        else:
            self.active.image=s.work;self.active.kind='raster';self.text_objects=[t for t in self.text_objects if t.get('layer_id')!=s.node_id];self.selected_text=-1;self.textSelected.emit(-1)
        self.changed.emit();self.retouchChanged.emit();self.update();self.status.emit(s.tool+': применено · Ctrl+Z — отменить');return True
    def cancel_retouch(self):
        if self.retouch_session is None:return False
        self.retouch_session=None;self.drawing=False;self._interaction=''
        if self._retouch_job is not None:self._retouch_job.cancelled.set()
        self.retouchChanged.emit();self.update();self.status.emit('Ретушь отменена. Исходник сохранён.');return True
    def retouch_context(self):
        s=self.retouch_session
        if s is None:return self.layers,self.text_objects,self.masks
        if s.mask_id:
            masks=dict(self.masks);masks[s.mask_id]=s.work;return self.layers,self.text_objects,masks
        layers=[Layer(l.name,s.work,l.visible,l.opacity,l.id,'raster',**l.flags()) if l.id==s.node_id else l for l in self.layers]
        return layers,[t for t in self.text_objects if t.get('layer_id')!=s.node_id],self.masks
    def paint_retouch_overlay(self,p):
        if self.tool=='Штамп' and self.clone_anchor is not None and self.clone_anchor[0]==self.retouch_target():
            point=self.screen_point(self.clone_anchor[1]);p.save()
            for color,width in [('#101827',4),('#b8f2ff',1.4)]:
                p.setPen(QPen(QColor(color),width));p.drawEllipse(point,8,8);p.drawLine(point-QPointF(12,0),point+QPointF(12,0));p.drawLine(point-QPointF(0,12),point+QPointF(0,12))
            p.restore()
