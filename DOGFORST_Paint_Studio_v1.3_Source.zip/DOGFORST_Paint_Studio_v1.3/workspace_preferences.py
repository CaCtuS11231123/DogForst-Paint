"""Persistent presentation, layout and shortcut controls for the workspace."""

import json
from PySide6.QtCore import Qt
from PySide6.QtGui import QKeySequence
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDockWidget,
    QFormLayout, QHBoxLayout, QHeaderView, QKeySequenceEdit, QLabel,
    QListWidget, QPushButton, QTabWidget, QTableWidget, QTableWidgetItem,
    QToolBar, QVBoxLayout, QWidget,
)

STYLES = {
    'text': Qt.ToolButtonStyle.ToolButtonTextOnly,
    'icons': Qt.ToolButtonStyle.ToolButtonIconOnly,
    'both': Qt.ToolButtonStyle.ToolButtonTextBesideIcon,
}
PORTABLE = QKeySequence.SequenceFormat.PortableText


def shortcut_conflict(bindings):
    used = {}
    reserved = {'Esc', 'Escape', 'Return', 'Enter', 'Tab', 'Backtab', 'Backspace', 'Del', 'Delete', 'Space'}
    for default, key in bindings.items():
        if not key:
            continue
        sequence = QKeySequence.fromString(key, PORTABLE)
        if sequence.isEmpty() or sequence.count() != 1 or (key in reserved and key != default):
            return f'Сочетание «{key}» зарезервировано или недоступно.'
        normalized = sequence.toString(PORTABLE)
        if normalized in used:
            return f'Сочетание «{normalized}» назначено двум командам.'
        used[normalized] = default
    return ''


class WorkspacePreferencesDialog(QDialog):
    def __init__(self, owner, shortcuts=False):
        super().__init__(owner)
        self.owner = owner
        self.setWindowTitle('Интерфейс и управление')
        self.resize(620, 560)
        root = QVBoxLayout(self)
        tabs = QTabWidget()
        root.addWidget(tabs)
        appearance = QWidget()
        layout = QVBoxLayout(appearance)
        form = QFormLayout()
        layout.addLayout(form)
        self.style = QComboBox()
        for title, key in [('Текст', 'text'), ('Иконки', 'icons'), ('Текст и иконки', 'both')]:
            self.style.addItem(title, key)
        self.style.setCurrentIndex(self.style.findData(owner.command_style))
        form.addRow('Кнопки верхней панели', self.style)
        self.movable = QCheckBox('Разрешить перетаскивать панели и откреплять окна')
        self.movable.setChecked(owner.panels_movable)
        layout.addWidget(self.movable)
        hint = QLabel('Перетащите заголовок боковой панели или дважды щёлкните по нему, чтобы открепить окно.')
        hint.setWordWrap(True)
        layout.addWidget(hint)
        layout.addWidget(QLabel('Порядок кнопок верхней панели'))
        self.order = QListWidget()
        for key in owner.command_order:
            self.order.addItem(owner.command_buttons[key].text())
            self.order.item(self.order.count() - 1).setData(Qt.ItemDataRole.UserRole, key)
        layout.addWidget(self.order)
        row = QHBoxLayout()
        for title, direction in [('Выше', -1), ('Ниже', 1)]:
            button = QPushButton(title)
            button.clicked.connect(lambda checked=False, offset=direction: self.move_button(offset))
            row.addWidget(button)
        layout.addLayout(row)
        tabs.addTab(appearance, 'Панели и кнопки')

        actions = list(owner.shortcut_actions.items())
        table = QTableWidget(len(actions), 2)
        table.setHorizontalHeaderLabels(['Команда', 'Сочетание'])
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        table.setColumnWidth(1, 150)
        table.verticalHeader().hide()
        self.shortcuts = {}
        for row_index, (default, action) in enumerate(actions):
            item = QTableWidgetItem(action.text())
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            table.setItem(row_index, 0, item)
            field = QKeySequenceEdit(action.shortcut())
            field.setMaximumSequenceLength(1)
            field.setClearButtonEnabled(True)
            self.shortcuts[default] = field
            table.setCellWidget(row_index, 1, field)
        tabs.addTab(table, 'Горячие клавиши')
        if shortcuts:
            tabs.setCurrentIndex(1)

        self.error = QLabel()
        self.error.setWordWrap(True)
        root.addWidget(self.error)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
            | QDialogButtonBox.StandardButton.RestoreDefaults)
        buttons.button(QDialogButtonBox.StandardButton.RestoreDefaults).clicked.connect(self.reset)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

    def move_button(self, offset):
        row = self.order.currentRow()
        target = row + offset
        if row >= 0 and 0 <= target < self.order.count():
            self.order.insertItem(target, self.order.takeItem(row))
            self.order.setCurrentRow(target)

    def reset(self):
        self.style.setCurrentIndex(0)
        self.movable.setChecked(True)
        items = {self.order.item(i).data(Qt.ItemDataRole.UserRole): self.order.item(i)
                 for i in range(self.order.count())}
        for row, key in enumerate(self.owner.command_buttons):
            item = self.order.takeItem(self.order.row(items[key]))
            self.order.insertItem(row, item)
        for default, field in self.shortcuts.items():
            field.setKeySequence(QKeySequence.fromString(default, PORTABLE))

    def accept(self):
        bindings = {default: field.keySequence().toString(PORTABLE)
                    for default, field in self.shortcuts.items()}
        error = shortcut_conflict(bindings)
        if error:
            self.error.setText(error)
            return
        order = [self.order.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.order.count())]
        self.owner.apply_workspace_preferences(
            self.style.currentData(), order, self.movable.isChecked(), bindings)
        super().accept()


def load_workspace_preferences(owner):
    style = owner.settings.value('workspace/command_style', 'text')
    movable = owner.settings.value('workspace/movable', True, type=bool)
    try:
        order = json.loads(owner.settings.value('workspace/command_order', '[]'))
        bindings = json.loads(owner.settings.value('workspace/shortcuts', '{}'))
    except (TypeError, ValueError):
        order, bindings = [], {}
    if not isinstance(order, list):
        order = []
    if not isinstance(bindings, dict):
        bindings = {}
    owner.apply_workspace_preferences(style, order, movable, bindings, persist=False)


def apply_workspace_preferences(owner, style, order, movable, bindings, persist=True):
    owner.command_style = style if style in STYLES else 'text'
    owner.command_order = list(dict.fromkeys(
        [key for key in order if isinstance(key, str) and key in owner.command_buttons]
        + list(owner.command_buttons)))
    owner.panels_movable = movable
    for key in owner.command_order:
        action = owner.command_widget_actions[key]
        owner.command_toolbar.removeAction(action)
        owner.command_toolbar.addAction(action)
        owner.command_buttons[key].setToolButtonStyle(STYLES[owner.command_style])
    for toolbar in owner.findChildren(QToolBar):
        toolbar.setMovable(movable)
    for dock in owner.findChildren(QDockWidget):
        features = QDockWidget.DockWidgetFeature.DockWidgetClosable
        if movable:
            features |= (QDockWidget.DockWidgetFeature.DockWidgetMovable |
                         QDockWidget.DockWidgetFeature.DockWidgetFloatable)
        dock.setFeatures(features)
    effective = {
        default: bindings.get(default, default) if isinstance(bindings.get(default, default), str) else default
        for default in owner.shortcut_actions
    }
    if shortcut_conflict(effective):
        effective = {default: default for default in owner.shortcut_actions}
    for default, action in owner.shortcut_actions.items():
        action.setShortcut(QKeySequence.fromString(effective[default], PORTABLE))
    if persist:
        owner.settings.setValue('workspace/command_style', owner.command_style)
        owner.settings.setValue('workspace/command_order', json.dumps(owner.command_order))
        owner.settings.setValue('workspace/movable', movable)
        owner.settings.setValue('workspace/shortcuts', json.dumps(effective))
        owner.settings.sync()
