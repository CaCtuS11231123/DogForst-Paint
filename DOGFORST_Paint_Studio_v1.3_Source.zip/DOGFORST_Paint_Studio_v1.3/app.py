import sys
import json
import zipfile
import io
import logging
from pathlib import Path

from PySide6.QtCore import Qt, QPointF, QRectF, Signal, QByteArray, QBuffer, QIODevice
from PySide6.QtGui import (
    QAction, QColor, QImage, QPainter, QPen, QBrush, QFont, QFontDatabase, QKeySequence, QPixmap
)
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFileDialog, QColorDialog,
    QInputDialog, QMessageBox, QToolBar, QSpinBox, QLabel, QComboBox, QLineEdit, QFontDialog,
    QListWidget, QListWidgetItem, QDockWidget, QSlider, QPushButton,
    QHBoxLayout, QVBoxLayout, QFormLayout, QDoubleSpinBox, QCheckBox,
    QToolButton, QDialog, QTextEdit, QDialogButtonBox, QFontComboBox, QGridLayout, QButtonGroup, QScrollArea, QMenu, QStyle
)

from workspace import WorkspaceMixin
from workspace_preferences import (
    WorkspacePreferencesDialog, apply_workspace_preferences, load_workspace_preferences,
)
from retouch import RETOUCH_TOOLS
from canvas import PaintCanvas
from layers import Layer, transparent_image
from themes import THEMES, ThemeDialog, theme_stylesheet
from tools import tool_icon, tool_cursor
from widgets import AnimatedToolButton, ColorSwatch, AnimatedSlider
from PySide6.QtCore import QSettings, QTimer, QSize, QSignalBlocker, QVariantAnimation, QEasingCurve, QStandardPaths
from PySide6.QtGui import QIcon
from dialogs import ShapePicker, ShapeDialog, ExportDialog, TextControls
from shapes import SHAPES
from safety import SafetyController
from storage import project_fingerprint, OperationCancelled
from release_notes import UpdatesDialog, CURRENT_VERSION
from pearl import PearlAnimator
from history_dialog import HistorySettingsDialog, setting_integer
from layer_list import LayerList
from group_icon import group_icon
from blending import MODES
from readability import readable_colors,THEME_NOTICE
from mask_panel import MaskPanel
from layer_actions import LABELS
from PySide6.QtCore import QItemSelectionModel

APP_NAME = "DOGFORST Paint Studio"
APP_VERSION = CURRENT_VERSION
RELEASE_DATE = "Тестовая версия"

class BrandBadge(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent);self.setFixedSize(240,58)
        self.mark=QPixmap(str(Path(__file__).parent/'assets'/'DOGFORST_Handdrawn.png'))
        self.setToolTip('DOGFORST · нарисовано для творчества')
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        if not self.mark.isNull():p.drawPixmap(3,3,52,52,self.mark)
        else:
            p.setPen(QPen(QColor('#70cfff'),5));p.drawLine(9,41,33,8);p.drawLine(17,47,44,15)
        p.setPen(self.palette().windowText().color());p.setFont(QFont('Segoe UI',15,QFont.Weight.Bold));p.drawText(62,28,'DOGFORST')
        p.setFont(QFont('Segoe UI',8));p.drawText(63,46,f'PAINT STUDIO · {APP_VERSION}');p.end()


class MainWindow(WorkspaceMixin,QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME}  ·  v{APP_VERSION}")
        self.resize(1540, 940)
        self.setMinimumSize(1050, 680)
        self._safety = None
        self.canvas = PaintCanvas()
        self.canvas.shapeCreated.connect(self.on_shape_created)
        self.canvas.objectEditRequested.connect(lambda:self.edit_placement(whole_layer=True))
        self.setCentralWidget(self.canvas)
        self.setAcceptDrops(True)
        self.canvas.status.connect(self.statusBar().showMessage)
        self.canvas.changed.connect(self.refresh_layers)
        self.canvas.historyChanged.connect(self.refresh_history_status)
        self.canvas.colorChanged.connect(self.update_color_button)
        self.current_file = None
        self._file_token = None
        self._file_token_path = None
        self.dirty = False
        self.settings = QSettings("DOGFORST", "Paint Studio")
        self.font_files = self.settings.value('text/font_files', [], type=list)
        for filename in self.font_files:
            if isinstance(filename, str) and Path(filename).is_file():
                QFontDatabase.addApplicationFont(filename)
        self.canvas.last_fill_color = QColor(self.settings.value('fill/color', ''))
        self.canvas.fillColorUsed.connect(self.remember_fill_color)
        self.reduce_motion=self.settings.value("readability/reduce_motion",False,type=bool)
        self.large_text=self.settings.value("readability/large_text",False,type=bool)
        self.high_contrast=self.settings.value("readability/contrast",False,type=bool)
        self.ui_scale=1.2 if self.large_text else 1.
        self.theme_name = self.settings.value("theme", "Dark")
        if self.theme_name not in THEMES:
            self.theme_name = "Dark"
        self._theme_colors = THEMES[self.theme_name]
        self.canvas.checker_style=self.settings.value('canvas/checker','light')
        if self.canvas.checker_style not in ('light','dark'):self.canvas.checker_style='light'
        self.canvas.brush_shape=self.settings.value('brush/shape','round')
        if self.canvas.brush_shape not in ('round','square'):self.canvas.brush_shape='round'
        self.canvas.brush_outline=setting_integer(self.settings,'brush/outline',0,0,30)
        self.canvas.brush_outline_color=QColor(self.settings.value('brush/outline_color','#17263f'))
        if not self.canvas.brush_outline_color.isValid():self.canvas.brush_outline_color=QColor('#17263f')
        self.canvas.brush_hardness=setting_integer(self.settings,'brush/hardness',100,0,100)
        self.canvas.brush_spacing=setting_integer(self.settings,'brush/spacing',12,1,50)
        self.canvas.brush_flow=setting_integer(self.settings,'brush/flow',100,1,100)
        self.canvas.brush_stabilizer=setting_integer(self.settings,'brush/stabilizer',18,0,100)
        self.canvas.retouch_options['strength']=setting_integer(self.settings,'retouch/strength',35,0,100)
        self.canvas.retouch_options['hardness']=setting_integer(self.settings,'retouch/hardness',65,0,100)
        self.canvas.retouch_options['aligned']=self.settings.value('retouch/aligned',True,type=bool)
        self._shape_drafts={}
        try:
            saved=json.loads(self.settings.value('shapes/style_056','{}'))
            if isinstance(saved,dict):
                for key in ('stroke','fill'):
                    if isinstance(saved.get(key),str) and QColor(saved[key]).isValid():self.canvas.shape_options[key]=saved[key]
                if type(saved.get('filled')) is bool:self.canvas.shape_options['filled']=saved['filled']
        except (ValueError,TypeError):pass
        self.canvas.max_history = setting_integer(self.settings,'history/steps',35,5,200)
        self.canvas.history_engine.max_steps = self.canvas.max_history
        self.canvas.history_engine.budget = setting_integer(self.settings,'history/mib',256,32,1024)*1024*1024
        self._pearl = PearlAnimator(self)
        self._theme_animation = QVariantAnimation(self)
        self._theme_animation.setDuration(320)
        self._theme_animation.setEasingCurve(QEasingCurve.Type.InOutCubic)
        self._theme_animation.valueChanged.connect(self._theme_frame)
        self.setWindowIcon(QIcon(str(Path(__file__).parent / "assets" / "DOGFORST_Icon.ico")))
        self.canvas.modified.connect(self.mark_dirty)
        self.shortcut_actions = {}
        self._make_actions()
        self._make_toolbar()
        self._make_tools_dock()
        self._make_layers_dock()
        self._make_color_dock()
        self._make_history_dock()
        self._make_palette_dock()
        self._make_text_dock()
        self._make_mask_dock()
        self._make_selection_dock()
        self._make_selection_transform_dock()
        self._make_gradient_dock()
        self._make_retouch_dock()
        self.tabifyDockWidget(self.color_dock, self.palette_dock)
        self.color_dock.raise_()
        self.configure_workspace()
        load_workspace_preferences(self)
        self.statusBar().showMessage("Готово. Ctrl + колесо мыши — масштаб, средняя кнопка — перемещение холста.")
        self.refresh_layers()
        self.canvas.fit_canvas()
        self.apply_theme(self.theme_name, animate=False)
        self.set_tool("Кисть")
        self.mark_clean()
        self.resizeDocks([self.color_dock], [370], Qt.Orientation.Horizontal)
        QTimer.singleShot(0, lambda:self.resizeDocks([self.layers_dock,self.color_dock],[410,300],Qt.Orientation.Vertical))
        QTimer.singleShot(0, self.canvas.fit_canvas)
        try:
            self._safety = SafetyController(self)
        except (OSError, ValueError) as error:
            logging.getLogger('dogforst').exception('Recovery storage unavailable')
            self.statusBar().showMessage('Автосохранение недоступно: ' + str(error))

    def _action(self, text, shortcut, callback):
        action = QAction(text, self)
        if shortcut:
            action.setShortcut(QKeySequence(shortcut))
        action.triggered.connect(callback)
        self.addAction(action)
        return action

    def _make_actions(self):
        file_menu = self.menuBar().addMenu("Файл")
        edit_menu = self.menuBar().addMenu("Правка")
        image_menu = self.menuBar().addMenu("Холст")
        view_menu = self.menuBar().addMenu("Вид")
        help_menu = self.menuBar().addMenu("Справка")
        self._add_menu_action(file_menu, "Стартовый экран…", "", self.show_start_screen)
        self._add_menu_action(file_menu, "Новый документ", "Ctrl+N", self.new_document)
        self._add_menu_action(file_menu, "Открыть изображение…", "Ctrl+O", self.open_image)
        self._add_menu_action(file_menu, "Открыть проект DOGFORST…", "Ctrl+Shift+O", self.open_project)
        self._add_menu_action(file_menu, "Сохранить проект", "Ctrl+S", self.save_project)
        self._add_menu_action(file_menu, "Сохранить проект как…", "Ctrl+Shift+S", self.save_project_as)
        self._add_menu_action(file_menu, "Экспорт изображения…", "Ctrl+E", self.export_image)
        file_menu.addSeparator()
        self._add_menu_action(file_menu, "Выход", "Alt+F4", self.close)
        self._add_menu_action(edit_menu, "Отменить", "Ctrl+Z", self.undo)
        self._add_menu_action(edit_menu, "Повторить", "Ctrl+Y", self.redo)
        self._add_menu_action(edit_menu, "Снять выделение", "Escape", self.deselect)
        self._add_menu_action(edit_menu, "Снять выделение (Ctrl+D)", "Ctrl+D", self.deselect)
        self._add_menu_action(edit_menu, "Вернуть последнее выделение", "Ctrl+Shift+D", self.canvas.reselect)
        self._add_menu_action(image_menu, "Настроить размер холста…", "Ctrl+Alt+C", self.resize_canvas)
        self._add_menu_action(image_menu, "Размер документа / параметры проекта…", "", self.resize_canvas)
        self._add_menu_action(image_menu, "Подогнать холст", "F", self.canvas.fit_canvas)
        self._add_menu_action(image_menu, "Увеличить", "Ctrl++", lambda: self.set_zoom(self.canvas.zoom * 1.2))
        self._add_menu_action(image_menu, "Уменьшить", "Ctrl+-", lambda: self.set_zoom(self.canvas.zoom / 1.2))
        self._add_menu_action(image_menu, "Фактический размер 100%", "Ctrl+0", lambda: self.set_zoom(1.0))
        self._add_menu_action(edit_menu, "Пипетка — взять цвет с холста", "I", lambda: self.set_tool("Пипетка"))
        self._add_menu_action(edit_menu, "Кисть", "B", lambda: self.set_tool("Кисть"))
        self._add_menu_action(edit_menu, "Ластик", "E", lambda: self.set_tool("Ластик"))
        self._add_menu_action(edit_menu, "Текст", "T", lambda: self.set_tool("Текст"))
        self._add_menu_action(edit_menu, "Заливка", "G", lambda: self.set_tool("Заливка"))
        self._add_menu_action(edit_menu,"Градиент","Shift+G",lambda:self.set_tool("Градиент"))
        retouch_menu=edit_menu.addMenu('Ретушь и локальные инструменты')
        for name,key in zip(RETOUCH_TOOLS,('U','Shift+U','Shift+R','S','O','Shift+O')):self._add_menu_action(retouch_menu,name,key,lambda checked=False,t=name:self.set_tool(t))
        self._add_menu_action(edit_menu,'Полигональное лассо','L',lambda:self.set_tool('Лассо'))
        self._add_menu_action(edit_menu,'Волшебная палочка','W',lambda:self.set_tool('Волшебная палочка'))
        self._add_menu_action(edit_menu,'Инвертировать выделение','Ctrl+Alt+I',self.canvas.invert_selection)
        self._add_menu_action(edit_menu,'Параметры выделения…','',self.show_selection_panel)
        self._add_menu_action(edit_menu,'Трансформировать выбранные пиксели…','',lambda:self.run_canvas_action(self.canvas.start_selection_transform))
        correction_menu=self.menuBar().addMenu("Коррекция")
        self._add_menu_action(correction_menu,"Коррекция и фильтры…","Ctrl+Shift+F",self.show_adjustment_dialog)
        settings_menu = self.menuBar().addMenu("Настройки")
        self._add_menu_action(settings_menu, "Выбрать тему…", "", self.choose_theme)
        self._add_menu_action(settings_menu, "Интерфейс и управление…", "", self.show_workspace_preferences)
        self._add_menu_action(settings_menu, 'Добавить шрифт…', '', self.add_font)
        self._add_menu_action(settings_menu, 'Память и история действий…', '', self.show_history_settings)
        self._add_menu_action(settings_menu, 'Автосохранение и резервные копии…', '', lambda:self.safety_action('show_settings'))
        self._add_menu_action(file_menu, 'Создать копию восстановления сейчас', 'Ctrl+Alt+S', lambda:self.safety_action('request_autosave', force=True))
        self._add_menu_action(file_menu, 'Восстановление после сбоя…', '', lambda:self.safety_action('offer_recovery'))
        self._add_menu_action(file_menu, 'Предыдущие версии проекта…', '', lambda:self.safety_action('show_versions'))
        self._add_menu_action(help_menu, 'Открыть папку журналов', '', lambda:self.safety_action('open_logs'))
        self._add_menu_action(view_menu, "Выбрать тему…", "", self.choose_theme)
        self.view_menu = view_menu
        self.panels_menu=view_menu.addMenu("Панели")
        self._add_menu_action(view_menu,"Вернуть панели на места","Ctrl+Shift+0",self.restore_default_layout)
        self._add_menu_action(edit_menu,'Выделить всё','Ctrl+A',self.canvas.select_all)
        self._add_menu_action(edit_menu,'Копировать слой / выделение','Ctrl+C',self.canvas.copy_selection)
        self._add_menu_action(edit_menu,'Вырезать','Ctrl+X',self.canvas.cut_selection)
        self._add_menu_action(edit_menu,'Вставить изображение','Ctrl+V',lambda:self.run_canvas_action(self.canvas.paste_image,QApplication.clipboard().image()))
        layers_menu=self.menuBar().addMenu('Слои')
        self._add_menu_action(layers_menu,'Маска слоя / папки…','',self.show_mask_panel)
        self._add_menu_action(layers_menu,'Включить / выключить обтравку','Ctrl+Alt+G',lambda:self.change_clipping(not self.canvas.active.clipped))
        self._add_menu_action(layers_menu,'Выбрать все слои','Ctrl+Alt+A',self.select_all_layers_ui)
        self._add_menu_action(layers_menu,'Сгруппировать выбранные','Ctrl+G',lambda:self.run_canvas_action(self.canvas.create_group,True))
        self._add_menu_action(layers_menu,'Новая пустая группа','',lambda:self.run_canvas_action(self.canvas.create_group,False))
        self._add_menu_action(layers_menu,'Разгруппировать (снять свойства группы)','Ctrl+Shift+G',self.canvas.ungroup_selected)
        self._add_menu_action(layers_menu,"Объединить выбранные слои","Ctrl+E",lambda:self.run_canvas_action(self.canvas.merge_selected))
        self._add_menu_action(layers_menu,'Дублировать выбранные слои','Ctrl+J',lambda:self.run_canvas_action(self.canvas.duplicate_layer))
        self._add_menu_action(layers_menu,'Объединить с нижним (растрировать текст)','Ctrl+Shift+E',lambda:self.run_canvas_action(self.canvas.merge_down))
        self._add_menu_action(layers_menu,'Удалить выбранные слои','',self.canvas.delete_layer)
        self._add_menu_action(layers_menu,'Изображение отдельным слоем…','Ctrl+Shift+I',self.import_layer)
        self._add_menu_action(layers_menu,'Своя текстура…','',self.import_texture)
        self._add_menu_action(layers_menu,'Удалить выбранное фото / изображение','',self.remove_photo)
        self._add_menu_action(layers_menu,'Внешнее свечение…','',self.edit_glow)
        self._add_menu_action(layers_menu,'Трансформировать выделение / изображение…','Ctrl+T',self.edit_placement)
        self._add_menu_action(layers_menu,'Параметры всего слоя…','',lambda:self.edit_placement(whole_layer=True))
        self._add_menu_action(image_menu,'Обрезать по выделению','',self.canvas.crop_selection)
        self._add_menu_action(image_menu,'Вырезать фон…','',self.remove_background)
        self._add_menu_action(image_menu,'Инвертировать цвета активного слоя','',lambda:self.canvas.apply_filter('invert'))
        self._add_menu_action(image_menu,'Обесцветить активный слой','',lambda:self.canvas.apply_filter('grayscale'))
        self._add_menu_action(image_menu,'Параметры фигуры…','',self.shape_settings)
        self._add_menu_action(view_menu,'Показать / скрыть шахматный фон','',self.toggle_checkerboard)
        background_menu=view_menu.addMenu('Фон прозрачности')
        from PySide6.QtGui import QActionGroup
        self.checker_group=QActionGroup(self);self.checker_group.setExclusive(True)
        for name,key in [('Светлая шахматная подложка','light'),('Тёмная шахматная подложка','dark')]:
            action=background_menu.addAction(name);action.setCheckable(True);action.setChecked(self.canvas.checker_style==key)
            self.checker_group.addAction(action);action.triggered.connect(lambda checked=False,k=key:self.set_checker_style(k))
        self._add_menu_action(image_menu,'Выбрать кисть и настройки…','',self.choose_brush)

        self._add_menu_action(help_menu,"Проверить целостность файлов…","",self.show_integrity)
        self._add_menu_action(help_menu, "Обновления", "", self.show_updates)
        self._add_menu_action(help_menu, "Горячие клавиши", "F1", self.show_shortcuts)
        self._add_menu_action(help_menu, "О программе DOGFORST Paint", "", self.show_about)

    def choose_theme(self):
        dialog = ThemeDialog(self.theme_name, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.settings.setValue('theme/motion',dialog.motion.isChecked())
            for key,control in [('reduce_motion',dialog.reduce_check),('large_text',dialog.large_check),('contrast',dialog.contrast_check)]:self.settings.setValue('readability/'+key,control.isChecked())
            self.reduce_motion=dialog.reduce_check.isChecked();self.large_text=dialog.large_check.isChecked();self.high_contrast=dialog.contrast_check.isChecked();self.ui_scale=1.2 if self.large_text else 1.
            self.apply_theme(dialog.selected)

    def apply_theme(self, name, animate=True):
        if name not in THEMES:
            return
        self._pearl.set_theme(name,self.settings.value('theme/motion',True,type=bool) and not self.reduce_motion)
        animate=animate and not self.reduce_motion
        if self.reduce_motion:self.canvas._marquee_timer.stop()
        elif not self.canvas._marquee_timer.isActive():self.canvas._marquee_timer.start()
        for button in getattr(self,'tool_buttons',{}).values():
            button.setFixedSize(round(118*self.ui_scale),round(72*self.ui_scale));button.setIconSize(QSize(round(27*self.ui_scale),round(27*self.ui_scale)));button._animate()
        for control in self.findChildren(AnimatedSlider):
            if self.reduce_motion:control.animation.stop();control.visual_value=float(control.value());control.update()
        if getattr(self,'_last_ui_large',None)!=self.large_text:
            self._last_ui_large=self.large_text
            QTimer.singleShot(0,self.resize_readable_panels)
        self._theme_animation.stop()
        self._theme_start = self._theme_colors
        self._theme_end = readable_colors(THEMES[name],self.high_contrast)
        self.theme_name = name
        self.settings.setValue("theme", name)
        self.settings.sync()
        if animate:
            self._theme_animation.setStartValue(0.)
            self._theme_animation.setEndValue(1.)
            self._theme_animation.start()
        else:
            self._theme_frame(1.)
        self.statusBar().showMessage(f"Тема: {name}", 2500)

    def resize_readable_panels(self):
        right=min(500,max(330,self.width()-890)) if self.large_text else 370
        self.resizeDocks([self.tools_dock,self.color_dock],[330 if self.large_text else 293,right],Qt.Orientation.Horizontal)

    def _theme_frame(self, value):
        colors = []
        for old, new in zip(self._theme_start, self._theme_end):
            a,b = QColor(old),QColor(new)
            colors.append(QColor(*[round(x+(y-x)*float(value)) for x,y in zip(a.getRgb()[:3],b.getRgb()[:3])]).name())
        self._theme_colors = tuple(colors)
        self.setStyleSheet(theme_stylesheet(colors,12 if self.large_text else 10))
        self.canvas.workspace_color = QColor(colors[6])
        for tool,button in self.tool_buttons.items():
            button.accent = QColor(colors[5])
            button.setIcon(tool_icon(tool, colors[5]))
        for button in self.findChildren(ColorSwatch):
            button.accent = QColor(colors[5]);button.update()
        if self._pearl.selected:self._pearl.paint_frame()
        self.canvas.update()

    def mark_dirty(self):
        self.dirty = True
        if self._safety:
            self._safety.modified()
        self.update_title()

    def update_title(self):
        name = Path(self.current_file).name if self.current_file else "Без названия"
        self.setWindowTitle(f"{'● ' if self.dirty else ''}{name} — {APP_NAME} · v{APP_VERSION}")

    def mark_clean(self):
        self.dirty = False
        if self._safety:
            self._safety.saved()
        self.update_title()

    def confirm_document_change(self):
        if self._safety and self._safety.manual_job:
            return False
        if self.canvas.fill_job is not None:
            return False
        if not self.dirty:
            return True
        answer = QMessageBox.warning(self, APP_NAME, "Сохранить изменения текущего проекта?",
            QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Save)
        if answer == QMessageBox.StandardButton.Save:
            return self.save_project() and not self.dirty
        return answer == QMessageBox.StandardButton.Discard

    def show_updates(self):
        UpdatesDialog(APP_VERSION,self).exec()

    def show_history_settings(self):
        self.end_text_history_group()
        self.canvas.commit_history(force=True)
        engine=self.canvas.history_engine
        dialog=HistorySettingsDialog(self.canvas.max_history,engine.budget//(1024*1024),self)
        if dialog.exec()!=QDialog.DialogCode.Accepted:return
        self.canvas.max_history=dialog.steps.value();engine.max_steps=dialog.steps.value()
        engine.budget=dialog.memory.value()*1024*1024;engine.trim()
        self.settings.setValue('history/steps',dialog.steps.value());self.settings.setValue('history/mib',dialog.memory.value());self.settings.sync()
        self.refresh_history_status()

    def refresh_history_status(self):
        if not hasattr(self,'history_label'):return
        info=self.canvas.history_engine.statistics()
        self.history_label.setText(f"Отмен: {info['undo']} · Повторов: {info['redo']}\n"
            f"История: примерно {info['estimated_bytes']/(1024*1024):.2f} МиБ / {info['budget_bytes']//(1024*1024)} МиБ\n"
            + ('Текущее действие ещё записывается.\n' if info['pending'] else '')
            + 'Ctrl+Z — отмена, Ctrl+Y — повтор.')

    def add_font(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, 'Добавить шрифт', '', 'Шрифты (*.ttf *.otf)')
        if not filename:
            return
        filename = str(Path(filename).resolve())
        if filename in self.font_files:
            self.statusBar().showMessage('Шрифт уже добавлен.', 4000)
            return
        identifier = QFontDatabase.addApplicationFont(filename)
        if identifier < 0:
            QMessageBox.warning(self, APP_NAME, 'Не удалось прочитать файл шрифта.')
            return
        self.font_files.append(filename)
        self.settings.setValue('text/font_files', self.font_files)
        families = ', '.join(QFontDatabase.applicationFontFamilies(identifier))
        self.statusBar().showMessage(f'Шрифт доступен в инструменте «Текст» · {families}', 6000)

    def show_workspace_preferences(self, shortcuts=False):
        dialog = WorkspacePreferencesDialog(self, shortcuts=shortcuts)
        dialog.exec()
        dialog.deleteLater()

    def show_shortcuts(self):
        self.show_workspace_preferences(shortcuts=True)

    def apply_workspace_preferences(self, style, order, movable, bindings, persist=True):
        apply_workspace_preferences(self, style, order, movable, bindings, persist)

    def show_integrity(self):
        from security_dialog import SecurityDialog
        dialog=SecurityDialog(self);dialog.exec()

    def show_about(self):
        QMessageBox.about(self, "О программе", "DOGFORST Paint Studio\nГрафический редактор со слоями, редактируемым текстом, градиентами и экспортом.\n\nПроект находится в разработке.\n\n"+THEME_NOTICE)

    def _add_menu_action(self, menu, text, shortcut, callback):
        action = QAction(text, self)
        if shortcut:
            action.setShortcut(QKeySequence(shortcut))
        action.triggered.connect(callback)
        menu.addAction(action)
        if shortcut and shortcut != 'Escape':
            key = action.shortcut().toString(QKeySequence.SequenceFormat.PortableText)
            self.shortcut_actions[key] = action

    def _make_toolbar(self):
        commands = QToolBar("Файл и действия", self)
        commands.addWidget(BrandBadge())
        self.addToolBar(commands)
        self.command_toolbar = commands
        self.command_buttons = {}
        self.command_widget_actions = {}
        standard = QStyle.StandardPixmap
        for key, title, callback, icon in (
            ('theme', 'Тема', self.choose_theme, standard.SP_DesktopIcon),
            ('new', 'Новый', self.new_document, standard.SP_FileIcon),
            ('open', 'Открыть', self.open_project, standard.SP_DialogOpenButton),
            ('photo', 'Добавить фото', self.import_layer, standard.SP_DirOpenIcon),
            ('remove_photo', 'Удалить фото', self.remove_photo, standard.SP_TrashIcon),
            ('glow', 'Свечение…', self.edit_glow, standard.SP_DialogApplyButton),
            ('save', 'Сохранить', self.save_project, standard.SP_DialogSaveButton),
            ('undo', 'Отмена', self.undo, standard.SP_ArrowBack),
            ('redo', 'Повтор', self.redo, standard.SP_ArrowForward),
            ('layer', 'Слой +', self.canvas.add_layer, standard.SP_FileDialogNewFolder),
            ('export', 'Экспорт', self.export_image, standard.SP_DialogSaveButton),
        ):
            button = QToolButton()
            button.setText(title)
            button.setAccessibleName(title)
            button.setToolTip(title)
            button.setIcon(self.style().standardIcon(icon))
            button.clicked.connect(callback)
            self.command_buttons[key] = button
            self.command_widget_actions[key] = commands.addWidget(button)
        self.photo_add_button = self.command_buttons['photo']
        self.photo_add_button.setToolTip('Добавить фотографию отдельным слоем с подгонкой под холст.')
        self.photo_remove_button = self.command_buttons['remove_photo']
        self.photo_remove_button.setToolTip('Удалить выбранный слой изображения. Ctrl+Z — вернуть.')
        self.glow_button = self.command_buttons['glow']
        self.glow_button.setToolTip('Настроить внешнее свечение выбранного слоя.')
        self.addToolBarBreak()
        toolbar = QToolBar("Параметры инструмента",self);toolbar.setMovable(False);self.addToolBar(toolbar)
        self.tool_combo = QComboBox();self.tool_combo.addItems([t for t in PaintCanvas.TOOLS if t not in SHAPES]+["Фигуры"])
        for i in range(self.tool_combo.count()):self.tool_combo.setItemIcon(i,tool_icon(self.tool_combo.itemText(i)))
        self.tool_combo.currentTextChanged.connect(self.set_tool);toolbar.addWidget(self.tool_combo)
        toolbar.addWidget(QLabel(" Размер кисти "))
        self.size_spin=QSpinBox();self.size_spin.setRange(1,512);self.size_spin.setValue(8);self.size_spin.setSuffix(" px")
        self.size_spin.valueChanged.connect(self.set_brush_size);toolbar.addWidget(self.size_spin)
        self.size_slider=AnimatedSlider(Qt.Orientation.Horizontal);self.size_slider.setRange(1,512);self.size_slider.setValue(8)
        self.size_slider.setFixedWidth(95);self.size_slider.valueChanged.connect(self.size_spin.setValue)
        self.size_spin.valueChanged.connect(self.size_slider.setValue);toolbar.addWidget(self.size_slider)
        toolbar.addWidget(QLabel(" Непрозрачность "))
        self.opacity_slider=AnimatedSlider(Qt.Orientation.Horizontal);self.opacity_slider.setRange(0,100)
        self.opacity_slider.setValue(100);self.opacity_slider.setFixedWidth(90)
        self.opacity_slider.valueChanged.connect(self.set_brush_opacity);toolbar.addWidget(self.opacity_slider)
        self.opacity_spin=QSpinBox();self.opacity_spin.setRange(0,100);self.opacity_spin.setValue(100);self.opacity_spin.setSuffix(" %")
        self.opacity_spin.valueChanged.connect(self.opacity_slider.setValue)
        self.opacity_slider.valueChanged.connect(self.opacity_spin.setValue);toolbar.addWidget(self.opacity_spin)
        toolbar.addWidget(QLabel(" Допуск "))
        self.fill_tolerance_spin=QSpinBox();self.fill_tolerance_spin.setRange(0,255);self.fill_tolerance_spin.setValue(24)
        self.fill_tolerance_spin.setToolTip("Допуск заливки: 0 — точный цвет, 255 — любой цвет, включая альфа-канал")
        self.fill_tolerance_spin.valueChanged.connect(lambda value:setattr(self.canvas,"fill_tolerance",value))
        toolbar.addWidget(self.fill_tolerance_spin)
        self.color_button=QPushButton("Цвет");self.color_button.clicked.connect(self.choose_color);toolbar.addWidget(self.color_button)
        toolbar.addWidget(QLabel(" Масштаб "))
        self.zoom_spin=QSpinBox();self.zoom_spin.setRange(10,500);self.zoom_spin.setSuffix(" %");self.zoom_spin.setValue(80)
        self.zoom_spin.valueChanged.connect(lambda v:self.canvas.set_zoom(v/100));toolbar.addWidget(self.zoom_spin)
        self.canvas.status.connect(self.sync_zoom)
        self.addToolBarBreak()
        context=QToolBar('Контекст и перемещение',self);context.setMovable(False);self.addToolBar(context)
        self.auto_select_check=QCheckBox('Автовыбор слоя');self.auto_select_check.setChecked(False)
        self.auto_select_check.toggled.connect(lambda value:setattr(self.canvas,'auto_select_layer',value));context.addWidget(self.auto_select_check)
        self.move_scope=QComboBox();self.move_scope.addItems(['Выбранные слои','Весь видимый рисунок','Все слои рисунка'])
        self.move_scope.setToolTip('Для всего рисунка выберите все слои. Рамка не ограничивает этот перенос; защита положения сохраняется.')
        self.move_scope.currentIndexChanged.connect(self.change_move_scope);context.addWidget(self.move_scope)
        self.move_all_check=QCheckBox('Двигать все видимые слои')
        self.move_all_check.toggled.connect(lambda value:self.move_scope.setCurrentIndex(1 if value else 0))
        select_all=QPushButton('Выбрать все слои');select_all.clicked.connect(self.select_all_layers_ui);context.addWidget(select_all)
        for text,callback in [('Параметры фигуры…',self.shape_settings),('Редактор текста…',self.edit_selected_text),('Снять выделение',self.deselect)]:
            button=QPushButton(text);button.clicked.connect(callback);context.addWidget(button)
        transform=QPushButton('Размер / поворот…');transform.clicked.connect(self.edit_placement);context.addWidget(transform)
        context.addWidget(QLabel('  Space: рука · Shift: ровно / 10 px · стрелки: сдвиг'))

    def change_move_scope(self,index):
        self.canvas.move_all_visible=index==1;self.canvas.move_all_layers=index==2
        self.auto_select_check.setEnabled(index==0)
        with QSignalBlocker(self.move_all_check):self.move_all_check.setChecked(index==1)
        self.canvas.status.emit('Перемещение: '+self.move_scope.currentText()+'. Заблокированные слои пропускаются.')

    def select_all_layers_ui(self):
        self.auto_select_check.setChecked(False);self.move_scope.setCurrentIndex(0)
        if self.canvas.selection is not None:self.canvas.cancel_selection()
        self.canvas.select_all_layer_nodes();self.refresh_layers();self.set_tool('Перемещение')

    def sync_zoom(self, *_):
        with QSignalBlocker(self.zoom_spin):self.zoom_spin.setValue(round(self.canvas.zoom*100))

    def _make_tools_dock(self):
        dock=self._dock("Инструменты",Qt.DockWidgetArea.LeftDockWidgetArea)
        self.tools_dock=dock
        panel=QWidget();grid=QGridLayout(panel);grid.setSpacing(6)
        self.tool_buttons={};self.tool_group=QButtonGroup(self)
        for i,tool in enumerate([t for t in PaintCanvas.TOOLS if t not in SHAPES]+['Кисти',"Фигуры"]):
            button=AnimatedToolButton();button.setText(tool);button.setIcon(tool_icon(tool));button.setIconSize(QSize(27,27))
            button.setCheckable(True);button.setFixedSize(118,72);button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
            button.setToolTip(tool+(" · двойное нажатие — параметры" if tool not in ("Пипетка","Кисти") else ""));button.clicked.connect(lambda checked=False,t=tool:self.set_tool(t))
            button.doubleClicked.connect(lambda t=tool:self.edit_tool_settings(t))
            self.tool_buttons[tool]=button;self.tool_group.addButton(button);grid.addWidget(button,i//2,i%2)
        grid.setRowStretch((len(self.tool_buttons)+1)//2,1);grid.setColumnStretch(0,0);grid.setColumnStretch(1,0);grid.setAlignment(Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(panel)
        container=QWidget();layout=QVBoxLayout(container);layout.setContentsMargins(0,0,0,0)
        self.brush_edit_button=QPushButton('Редактировать кисть…');self.brush_edit_button.clicked.connect(self.edit_brush);layout.addWidget(self.brush_edit_button);layout.addWidget(scroll);dock.setWidget(container)

    def _dock(self, title, area):
        dock = QDockWidget(title, self)
        dock.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea |
                             Qt.DockWidgetArea.RightDockWidgetArea)
        self.addDockWidget(area, dock)
        dock.setObjectName(title);self.panels_menu.addAction(dock.toggleViewAction())
        return dock

    def _make_layers_dock(self):
        dock = self._dock("Слои", Qt.DockWidgetArea.RightDockWidgetArea)
        self.layers_dock = dock
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(6,6,6,6);layout.setSpacing(4)
        self.layer_list = LayerList()
        self.layer_list.setIconSize(QSize(42,32))
        self.layer_list.setMinimumHeight(125)
        self.layer_list.setMaximumHeight(140)
        dock.topLevelChanged.connect(lambda floating:self.layer_list.setMaximumHeight(16777215 if floating else 140))
        self.layer_list.itemSelectionChanged.connect(self.select_layer_items)
        self.layer_list.orderDropped.connect(self.canvas.reorder_layers)
        self.layer_list.nodesDropped.connect(lambda ids,target,mode:self.run_canvas_action(self.canvas.drop_nodes,ids,target,mode))
        self.layer_list.groupToggled.connect(self.canvas.toggle_group)
        self.layer_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.layer_list.customContextMenuRequested.connect(self.layer_context_menu)
        self.layer_list.itemChanged.connect(self.layer_item_changed)
        self.layer_list.itemDoubleClicked.connect(
            lambda item: self.canvas.rename_node(item.data(Qt.ItemDataRole.UserRole+2)))
        layout.addWidget(self.layer_list)
        self.layer_selection_label = QLabel('Ctrl / Shift — несколько слоёв · перетаскивайте для порядка')
        self.layer_selection_label.setWordWrap(True)
        layout.addWidget(self.layer_selection_label)
        self.layer_locks = {}
        lock_row = QHBoxLayout()
        for key,label,tip in [('locked','Правки','Защитить рисование, текст и перемещение'),
                              ('position_locked','Положение','Запретить перемещение и ручки трансформации'),
                              ('alpha_locked','Альфа','Рисовать только по непрозрачным пикселям растровых слоёв')]:
            control = QCheckBox(label);control.setTristate(True);control.setToolTip(tip)
            control.clicked.connect(lambda value,k=key:self.canvas.set_selected_flag(k,bool(value)))
            self.layer_locks[key]=control;lock_row.addWidget(control)
        layout.addLayout(lock_row)
        self.layer_label_choice = QComboBox()
        self.layer_label_choice.addItem('Разные метки',None)
        for color,label in LABELS.items():self.layer_label_choice.addItem(label,color)
        self.layer_label_choice.activated.connect(lambda index:self.canvas.set_selected_flag('color_label',self.layer_label_choice.itemData(index)) if self.layer_label_choice.itemData(index) is not None else None)
        blend_row=QHBoxLayout()
        self.blend_choice=QComboBox()
        self.blend_choice.addItem('Разные режимы',None)
        self.blend_choice.model().item(0).setEnabled(False)
        for mode,(label,description,native) in MODES.items():
            self.blend_choice.addItem(label,mode)
            self.blend_choice.setItemData(self.blend_choice.count()-1,description,Qt.ItemDataRole.ToolTipRole)
        self.blend_choice.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.blend_choice.setMinimumContentsLength(8)
        self.blend_choice.activated.connect(lambda index:self.canvas.set_selected_blend(self.blend_choice.itemData(index)) if self.blend_choice.itemData(index) is not None else None)
        self.layer_label_choice.setMinimumWidth(95);self.layer_label_choice.setMaximumWidth(115)
        self.blend_choice.setAccessibleName('Режим наложения выбранных слоёв')
        blend_row.addWidget(QLabel('Наложение'));blend_row.addWidget(self.blend_choice,1);blend_row.addWidget(self.layer_label_choice)
        layout.addLayout(blend_row)
        self.clip_check=QCheckBox('Обтравка к нижнему базовому слою');self.clip_check.setToolTip('Содержимое и свечение ограничиваются прозрачностью базового слоя ниже, в этой же папке.')
        self.clip_check.toggled.connect(self.change_clipping);layout.addWidget(self.clip_check)
        row = QHBoxLayout()
        for label, callback in [
            ("Добавить", self.canvas.add_layer),
            ("Удалить", self.canvas.delete_layer),
            ("↑", lambda: self.reorder_layer(1)),
            ("↓", lambda: self.reorder_layer(-1))
        ]:
            button = QPushButton(label)
            button.clicked.connect(callback)
            row.addWidget(button)
        group_button=QPushButton('Группы')
        group_menu=QMenu(group_button)
        group_menu.addAction('Сгруппировать выбранные · Ctrl+G',lambda:self.run_canvas_action(self.canvas.create_group,True))
        group_menu.addAction('Новая пустая группа',lambda:self.run_canvas_action(self.canvas.create_group,False))
        group_menu.addAction('Разгруппировать (снять свойства группы)',self.canvas.ungroup_selected)
        group_button.setMenu(group_menu);row.addWidget(group_button)
        layout.addLayout(row)
        opacity_row = QHBoxLayout()
        opacity_row.addWidget(QLabel("Непрозрачность"))
        self.layer_opacity = AnimatedSlider(Qt.Orientation.Horizontal)
        self.layer_opacity.setRange(0, 100)
        self.layer_opacity.setValue(100)
        self.layer_opacity.valueChanged.connect(
            lambda value: self.canvas.set_current_opacity(value))
        self.layer_opacity.sliderPressed.connect(self.canvas.begin_opacity_edit)
        self.layer_opacity.sliderReleased.connect(self.canvas.end_opacity_edit)
        self.layer_opacity_label = QLabel("100 %")
        self.layer_opacity_label.setFixedHeight(20)
        self.layer_opacity.valueChanged.connect(lambda value:self.layer_opacity_label.setText(f"{value} %"))
        opacity_row.addWidget(self.layer_opacity,1)
        opacity_row.addWidget(self.layer_opacity_label)
        self.layer_opacity.setToolTip("Непрозрачность активного слоя")
        layout.addLayout(opacity_row)
        actions=QHBoxLayout();self.merge_selected_button=QPushButton('Объединить');self.merge_selected_button.setToolTip('Объединить выбранные слои · Ctrl+E');self.merge_selected_button.clicked.connect(lambda:self.run_canvas_action(self.canvas.merge_selected));self.layer_glow_button=QPushButton('Свечение…');self.layer_glow_button.clicked.connect(self.edit_glow);actions.addWidget(self.merge_selected_button);actions.addWidget(self.layer_glow_button);layout.addLayout(actions)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(panel)
        scroll.setMinimumHeight(325)
        self.background_button=QToolButton();self.background_button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon);self.background_button.setText('Фон прозрачности');self.background_button.setIcon(self.transparency_icon());self.background_button.setToolTip('Светлая или тёмная шахматка. Подложка не попадает в экспорт.');self.background_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup);self.background_button.setMenu(self.transparency_menu())
        def sync_background_menu():
            for action in self.background_button.menu().actions():
                if action.data() in ('light','dark'):action.setChecked(self.canvas.show_checkerboard and action.data()==self.canvas.checker_style)
        self.background_button.menu().aboutToShow.connect(sync_background_menu)
        self.layer_photo_add_button = QPushButton('Добавить фото')
        self.layer_photo_add_button.setToolTip('Добавить изображение отдельным слоем на текущий холст.')
        self.layer_photo_add_button.clicked.connect(self.import_layer)
        wrapper = QWidget()
        outer = QVBoxLayout(wrapper)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll, 1)
        footer = QHBoxLayout()
        footer.addWidget(self.layer_photo_add_button)
        footer.addWidget(self.background_button)
        outer.addLayout(footer)
        dock.setWidget(wrapper)

    def _make_color_dock(self):
        dock = self._dock("Цвет", Qt.DockWidgetArea.RightDockWidgetArea)
        self.color_dock = dock
        panel = QWidget()
        layout = QVBoxLayout(panel)
        self.color_preview = QPushButton("Текущий цвет — нажмите для изменения")
        self.color_preview.clicked.connect(self.choose_color)
        layout.addWidget(self.color_preview)
        hex_row = QHBoxLayout()
        self.hex_input = QLineEdit("#202020")
        self.hex_input.setPlaceholderText("HEX, например #35A7FF")
        apply_hex = QPushButton("Применить")
        apply_hex.clicked.connect(self.apply_hex_color)
        hex_row.addWidget(self.hex_input, 1)
        hex_row.addWidget(apply_hex)
        layout.addLayout(hex_row)
        eyedropper = QPushButton("⌁ Взять цвет с холста (I)")
        eyedropper.clicked.connect(lambda: self.set_tool("Пипетка"))
        layout.addWidget(eyedropper)
        layout.addWidget(QLabel("Быстрые цвета"))
        grid = QGridLayout()
        self.swatches = [
            "#000000", "#202020", "#ffffff", "#e53935", "#ff9800", "#fdd835",
            "#43a047", "#00acc1", "#1e88e5", "#3949ab", "#8e24aa",
            "#ec407a", "#795548", "#9e9e9e"
        ]
        self.swatch_buttons = []
        for i,hex_color in enumerate(self.swatches):
            button = ColorSwatch(hex_color)
            self.swatch_buttons.append(button)
            button.setToolTip(hex_color)
            button.clicked.connect(lambda checked=False, c=hex_color: self.set_color(QColor(c)))
            grid.addWidget(button,i//7,i%7)
        layout.addLayout(grid)
        layout.addWidget(QLabel("RGB"))
        self.rgb_label = QLabel()
        layout.addWidget(self.rgb_label)
        layout.addStretch(1)
        self.color_preview.setMinimumHeight(45)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(panel)
        dock.setWidget(scroll)
        self.update_color_button(self.canvas.color)

    def _make_palette_dock(self):
        from color_palettes import PalettePanel
        self.palette_dock=self._dock('Палитры и последние цвета',Qt.DockWidgetArea.RightDockWidgetArea)
        self.palette_panel=PalettePanel(self);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(self.palette_panel);self.palette_dock.setWidget(scroll)

    def _make_history_dock(self):
        dock = self._dock("История действий", Qt.DockWidgetArea.LeftDockWidgetArea)
        panel = QWidget()
        layout = QVBoxLayout(panel)
        self.history_label = QLabel(
            "История хранит последние действия.\nCtrl+Z — отмена, Ctrl+Y — повтор."
        )
        self.history_label.setWordWrap(True)
        layout.addWidget(self.history_label)
        self.history_dock=dock
        dock.setWidget(panel)

    def refresh_layers(self):
        if not hasattr(self, "layer_list"):
            return
        if self.canvas.groups:
            self.refresh_group_rows();return
        self.layer_list.group_mode=False
        self.layer_list.blockSignals(True)
        while self.layer_list.count() > len(self.canvas.layers):
            self.layer_list.takeItem(self.layer_list.count()-1)
        for row,index in enumerate(reversed(range(len(self.canvas.layers)))):
            layer = self.canvas.layers[index]
            item = self.layer_list.item(row)
            if item is None:
                item = QListWidgetItem()
                self.layer_list.addItem(item)
            item.setText(layer.name)
            item.setForeground(QBrush(QColor(layer.color_label)) if layer.color_label else QBrush())
            item.setData(Qt.ItemDataRole.UserRole+2,layer.id)
            item.setData(Qt.ItemDataRole.UserRole+3,layer.kind)
            item.setData(Qt.ItemDataRole.UserRole+6,0)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable |
                          Qt.ItemFlag.ItemIsEditable | Qt.ItemFlag.ItemIsSelectable)
            item.setCheckState(Qt.CheckState.Checked if layer.visible else Qt.CheckState.Unchecked)
            item.setData(Qt.ItemDataRole.UserRole, index)
            key = str(layer.image.cacheKey())+layer.kind
            if item.data(Qt.ItemDataRole.UserRole+1) != key:
                thumb = layer.image.scaled(42,32,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)
                item.setIcon(tool_icon('Текст',self._theme_colors[5]) if layer.kind=='text' else tool_icon('Фигуры',self._theme_colors[5]) if 'shape' in self.canvas.raster_objects.get(layer.id,{}) else QIcon(QPixmap.fromImage(thumb)))
                item.setData(Qt.ItemDataRole.UserRole+1,key)
            locks=', '.join(name for key,name in [('locked','правки защищены'),('position_locked','положение защищено'),('alpha_locked','альфа защищена')] if getattr(layer,key))
            item.setToolTip(f"{layer.name} · {round(layer.opacity*100)} %"+(' · '+locks if locks else ''))
            item.setSelected(layer.id in self.canvas.selected_layer_ids())
        row = len(self.canvas.layers) - 1 - self.canvas.active_layer
        self.layer_list.setCurrentRow(row,QItemSelectionModel.SelectionFlag.NoUpdate)
        self.layer_list.blockSignals(False)
        if hasattr(self, "layer_opacity"):
            self.layer_opacity.blockSignals(True)
            self.layer_opacity.setValue(int(self.canvas.active.opacity * 100))
            self.layer_opacity.blockSignals(False)
            self.layer_opacity.visual_value = float(self.layer_opacity.value())
            self.layer_opacity_label.setText(f"{self.layer_opacity.value()} %")
        self.refresh_layer_controls()
        self.refresh_history_status()

    def refresh_group_rows(self):
        rows=self.canvas.tree_rows();view=self.layer_list
        view.blockSignals(True);view.group_mode=True
        try:
            while view.count()>len(rows):view.takeItem(view.count()-1)
            for row,(identifier,depth) in enumerate(rows):
                node=self.canvas.node(identifier);item=view.item(row)
                if item is None:item=QListWidgetItem();view.addItem(item)
                prefix='    '*depth+('▸ ' if node.collapsed else '▾ ' if node.kind=='group' else '') if node.kind=='group' else '    '*depth
                item.setText(prefix+node.name);item.setData(Qt.ItemDataRole.UserRole+6,len(prefix))
                item.setFlags(item.flags()|Qt.ItemFlag.ItemIsUserCheckable|Qt.ItemFlag.ItemIsEditable|Qt.ItemFlag.ItemIsSelectable)
                item.setData(Qt.ItemDataRole.UserRole+2,identifier);item.setData(Qt.ItemDataRole.UserRole+3,node.kind)
                item.setData(Qt.ItemDataRole.UserRole,None if node.kind=='group' else self.canvas.layers.index(node))
                item.setCheckState(Qt.CheckState.Checked if node.visible else Qt.CheckState.Unchecked)
                item.setSelected(identifier in self.canvas.selected_node_ids())
                item.setForeground(QBrush(QColor(node.color_label)) if node.color_label else QBrush())
                if node.kind=='group':
                    item.setData(Qt.ItemDataRole.UserRole+1,None)
                    item.setIcon(group_icon(node.collapsed,node.color_label or self._theme_colors[5]))
                    item.setToolTip(f'{node.name} · группа · {len(self.canvas.descendant_layers(identifier))} слоёв · {round(node.opacity*100)} %\nЩелчок по папке — свернуть/развернуть. Центр строки при переносе — вложить.')
                else:
                    key=str(node.image.cacheKey())+node.kind
                    if item.data(Qt.ItemDataRole.UserRole+1)!=key:
                        thumb=node.image.scaled(42,32,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)
                        item.setIcon(tool_icon('Текст',self._theme_colors[5]) if node.kind=='text' else QIcon(QPixmap.fromImage(thumb)))
                        item.setData(Qt.ItemDataRole.UserRole+1,key)
                    item.setToolTip(f'{node.name} · {round(node.opacity*100)} %')
            current=getattr(self.canvas,'current_node',self.canvas.active.id)
            for row,(identifier,depth) in enumerate(rows):
                if identifier==current:view.setCurrentRow(row,QItemSelectionModel.SelectionFlag.NoUpdate);break
        finally:view.blockSignals(False)
        self.refresh_layer_controls();self.refresh_history_status()

    def select_layer_row(self, row):
        item = self.layer_list.item(row)
        if item is not None:
            self.canvas.set_active_layer(item.data(Qt.ItemDataRole.UserRole))
            if hasattr(self,"layer_opacity"):
                with QSignalBlocker(self.layer_opacity):
                    self.layer_opacity.setValue(round(self.canvas.active.opacity*100))
                self.layer_opacity.visual_value = float(self.layer_opacity.value())
                self.layer_opacity_label.setText(f"{self.layer_opacity.value()} %")

    def layer_item_changed(self, item):
        if self.canvas.groups:
            identifier=item.data(Qt.ItemDataRole.UserRole+2);node=self.canvas.node(identifier)
            if node is None:return
            name=item.text()[item.data(Qt.ItemDataRole.UserRole+6) or 0:]
            visible=item.checkState()==Qt.CheckState.Checked
            if name.strip() and name!=node.name:self.canvas.push_history();node.name=name.strip()
            if node.visible!=visible:self.canvas.set_node_visible(identifier,visible)
            else:self.canvas.changed.emit()
            return
        index = item.data(Qt.ItemDataRole.UserRole)
        if item.text() != self.canvas.layers[index].name:
            self.canvas.push_history()
            self.canvas.layers[index].name = item.text()
        visible = item.checkState() == Qt.CheckState.Checked
        # Capture every item field before changed triggers a list rebuild.
        if self.canvas.layers[index].visible != visible:
            self.canvas.set_layer_visible(index, visible)
        else:
            self.canvas.changed.emit()

    def select_layer_items(self):
        items=self.layer_list.selectedItems()
        if not items:return
        active=self.layer_list.currentItem()
        if active not in items:active=items[0]
        self._text_edit_timer.stop();self.end_text_history_group()
        self.canvas.set_selected_nodes([item.data(Qt.ItemDataRole.UserRole+2) for item in items],
                                       active.data(Qt.ItemDataRole.UserRole+2))
        if self.canvas.tool=="Перемещение":
            self.move_scope.setCurrentIndex(0);self.auto_select_check.setChecked(False);self.canvas.selection=None
        self.refresh_layer_controls()
        if hasattr(self,"mask_panel"):self.mask_panel.refresh()

    def change_clipping(self,value):
        self.canvas.set_clipping(value);self.refresh_layer_controls()

    def refresh_layer_controls(self):
        if hasattr(self,'merge_selected_button'):
            nodes=[self.canvas.node(i) for i in self.canvas.selected_node_ids()]
            allowed=len(nodes)>=2 and all(n is not None and n.kind!='group' and not self.canvas.node_locked(n) and not n.alpha_locked for n in nodes) and len({self.canvas.parent_id(n.id) for n in nodes})==1
            self.merge_selected_button.setEnabled(allowed)
            self.layer_glow_button.setEnabled(len(nodes)==1 and nodes[0].kind!='group' and not self.canvas.node_locked(nodes[0]))
        if not hasattr(self,'layer_locks'):return
        if hasattr(self,'clip_check'):
            single=len(self.canvas.selected_node_ids())==1 and self.canvas.control_node().kind!='group'
            with QSignalBlocker(self.clip_check):self.clip_check.setChecked(single and self.canvas.active.clipped)
            self.clip_check.setEnabled(single and not self.canvas.node_locked(self.canvas.active) and (self.canvas.active.clipped or self.canvas.clipping_base() is not None))
        layers=self.canvas.selected_nodes() if self.canvas.groups else self.canvas.selected_layers()
        if hasattr(self,'text_controls') and 0<=self.canvas.selected_text<len(self.canvas.text_objects):
            self.text_controls.setEnabled(not self.canvas.node_locked(self.canvas.text_layer(self.canvas.text_objects[self.canvas.selected_text]) or self.canvas.active))
        if hasattr(self,'photo_remove_button'):
            single=len(self.canvas.selected_node_ids())==1 and self.canvas.control_node().kind!='group'
            unlocked=single and not self.canvas.node_locked(self.canvas.active)
            self.photo_remove_button.setEnabled(unlocked and not any(t.get('layer_id')==self.canvas.active.id for t in self.canvas.text_objects))
            self.glow_button.setEnabled(unlocked)
        self.layer_selection_label.setText(f'Выбрано: {len(layers)} · Ctrl/Shift · перетаскивание')
        for key,control in self.layer_locks.items():
            values={getattr(layer,key) for layer in layers}
            with QSignalBlocker(control):
                control.setCheckState(Qt.CheckState.PartiallyChecked if len(values)>1 else
                                     Qt.CheckState.Checked if True in values else Qt.CheckState.Unchecked)
            control.setEnabled(key!='alpha_locked' or any(l.kind=='raster' for l in layers))
        modes={node.blend_mode for node in layers}
        with QSignalBlocker(self.blend_choice):
            self.blend_choice.setCurrentIndex(self.blend_choice.findData(next(iter(modes))) if len(modes)==1 else 0)
        self.blend_choice.setToolTip(MODES[next(iter(modes))][1]+'\nПрименяется к выбранным слоям/папкам. Для заметного эффекта обычно нужен видимый рисунок ниже; на прозрачном фоне режим может выглядеть как обычный.' if len(modes)==1 else 'У выбранных элементов разные режимы. Выбор применится ко всем выбранным.')
        labels={layer.color_label for layer in layers}
        with QSignalBlocker(self.layer_label_choice):
            self.layer_label_choice.setCurrentIndex(self.layer_label_choice.findData(next(iter(labels))) if len(labels)==1 else 0)
        if hasattr(self,'layer_opacity'):
            with QSignalBlocker(self.layer_opacity):self.layer_opacity.setValue(round(self.canvas.control_node().opacity*100))
            self.layer_opacity.visual_value=float(self.layer_opacity.value())
            self.layer_opacity_label.setText(f'{self.layer_opacity.value()} %')
            self.layer_opacity.setToolTip('Непрозрачность группы' if self.canvas.control_node().kind=='group' else 'Непрозрачность активного слоя')

    def layer_context_menu(self,point):
        item=self.layer_list.itemAt(point)
        if item is not None and not item.isSelected():self.layer_list.setCurrentItem(item)
        menu=QMenu(self)
        menu.addAction('Размер / поворот / замена… · Ctrl+T',self.edit_placement)
        menu.addAction('Внешнее свечение…',self.edit_glow)
        action=menu.addAction('Обтравка к нижнему слою');action.setCheckable(True);action.setChecked(getattr(self.canvas.control_node(),'clipped',False));action.setEnabled(self.clip_check.isEnabled());action.triggered.connect(self.change_clipping)
        menu.addAction('Удалить фото / изображение',self.remove_photo)
        action=menu.addAction('Объединить выбранные · Ctrl+E',lambda:self.run_canvas_action(self.canvas.merge_selected));action.setEnabled(self.merge_selected_button.isEnabled())
        menu.addAction('Дублировать выбранные · Ctrl+J',lambda:self.run_canvas_action(self.canvas.duplicate_layer))
        menu.addAction('Удалить выбранные',self.canvas.delete_layer)
        menu.addAction('Сгруппировать · Ctrl+G',lambda:self.run_canvas_action(self.canvas.create_group,True))
        menu.addAction('Разгруппировать (снять свойства группы)',self.canvas.ungroup_selected)
        menu.addAction('Вынести выбранные из группы',self.move_nodes_out)
        menu.addSeparator()
        for key,label in [('locked','Защитить правки'),('position_locked','Защитить положение'),('alpha_locked','Защитить прозрачность')]:
            action=menu.addAction(label);action.setCheckable(True)
            action.setChecked(all(getattr(l,key) for l in self.canvas.selected_nodes()))
            action.setEnabled(key!='alpha_locked' or any(l.kind=='raster' for l in self.canvas.selected_nodes()))
            action.triggered.connect(lambda value,k=key:self.canvas.set_selected_flag(k,value))
        menu.addAction('Маска слоя / папки…',self.show_mask_panel)
        blend=menu.addMenu('Наложение')
        for mode,(label,description,native) in MODES.items():blend.addAction(label,lambda checked=False,m=mode:self.canvas.set_selected_blend(m))
        labels=menu.addMenu('Цветовая метка')
        for color,label in LABELS.items():labels.addAction(label,lambda checked=False,c=color:self.canvas.set_selected_flag('color_label',c))
        menu.exec(self.layer_list.viewport().mapToGlobal(point))

    def move_nodes_out(self):
        ids=self.canvas.selected_node_ids()
        parents={self.canvas.parent_id(identifier) for identifier in ids}
        if len(parents)!=1 or None in parents:return
        parent=next(iter(parents))
        self.run_canvas_action(self.canvas.move_nodes,ids,self.canvas.parent_id(parent))

    def reorder_layer(self, direction):
        self.canvas.shift_selected_layers(direction)

    def set_tool(self,tool):
        self.canvas.cancel_pending_preview()
        if tool=='Кисти':self.choose_brush();return
        if tool=='Фигуры':
            self.choose_shape();return
        if tool not in PaintCanvas.TOOLS or self.canvas.drawing or self.canvas.wand_job is not None:return
        if tool!=self.canvas.tool:self.canvas.clear_transient_selection();self.canvas.update()
        if self.canvas.editing_mask is not None and tool not in (*RETOUCH_TOOLS,'Кисть','Карандаш','Маркер','Мягкая кисть','Ластик','Заливка','Градиент','Выделение','Лассо','Волшебная палочка','Пипетка'):
            self.canvas.stop_mask_edit();self.canvas.changed.emit()
        self.canvas.tool=tool;self.canvas.update_cursor()
        brush=tool in ('Кисть','Карандаш','Маркер','Мягкая кисть','Ластик',*RETOUCH_TOOLS)
        for control in (self.size_spin,self.size_slider):control.setEnabled(brush)
        for control in (self.opacity_spin,self.opacity_slider):control.setEnabled(brush or tool in SHAPES or tool=='Заливка')
        self.fill_tolerance_spin.setEnabled(tool=='Заливка')
        self.size_spin.setToolTip('Размер выбранной кисти. Для фигуры используйте её параметры.' if brush else 'Размер кисти доступен при выборе инструмента рисования.')
        if tool!="Перемещение":self.canvas._candidate_key=None;self.canvas._candidate_object=None
        if hasattr(self,'brush_edit_button'):
            self.brush_edit_button.setEnabled(tool in ('Кисть','Мягкая кисть'))
            self.brush_edit_button.setToolTip('Настройки выбранной кисти. Карандаш, маркер и ластик настраиваются двойным нажатием на их значки.')
        display='Фигуры' if tool in SHAPES else tool
        if hasattr(self,'tool_buttons'):self.tool_buttons[display].setChecked(True)
        if hasattr(self,'tool_combo'):
            with QSignalBlocker(self.tool_combo):self.tool_combo.setCurrentText(display)
        if hasattr(self,'selection_panel'):
            self.selection_panel.refresh()
            if tool in ('Выделение','Лассо','Волшебная палочка'):self.show_selection_panel()
        if tool in RETOUCH_TOOLS and hasattr(self,"retouch_dock"):self.retouch_panel.refresh();self.retouch_dock.show();self.retouch_dock.raise_()
        if tool=="Градиент" and hasattr(self,"gradient_dock"):self.gradient_panel.refresh();self.gradient_dock.show();self.gradient_dock.raise_()
        self.canvas.setFocus();self.canvas.status.emit(f'Инструмент: {tool}')

    def choose_shape(self):
        current=getattr(self,'_last_shape',self.canvas.tool if self.canvas.tool in SHAPES else 'Прямоугольник')
        while True:
            picker=ShapePicker(current,self)
            if picker.exec()!=QDialog.DialogCode.Accepted:
                self.set_tool(self.canvas.tool);return
            current=picker.selected;self._last_shape=current
            if self.shape_settings(current,from_picker=True)!=ShapeDialog.Back:return

    def shape_settings(self,name=None,from_picker=False):
        if not isinstance(name,str):name=self.canvas.tool if self.canvas.tool in SHAPES else 'Прямоугольник'
        options=dict(self._shape_drafts.get(name,self.canvas.shape_options))
        if name!=getattr(self,'_shape_back_name',None):
            for key in ('stroke','fill','filled'):options[key]=self.canvas.shape_options[key]
        dialog=ShapeDialog(name,options,self)
        result=dialog.exec()
        if result==ShapeDialog.Back:
            self._shape_drafts[name]=dialog.values();self._shape_back_name=name
            if not from_picker:self.choose_shape()
            return result
        if result==QDialog.DialogCode.Accepted:
            self._shape_drafts[name]=dialog.values()
            self.canvas.shape_options=dialog.values();self.canvas._shape_configured=True;self._shape_back_name=None;self.save_shape_style();self.set_tool(name)
            self.tool_buttons['Фигуры'].setToolTip('Фигуры · '+name)

    def on_shape_created(self):
        self.canvas.shape_options['exact']=False
        for value in self._shape_drafts.values():value['exact']=False
        self.set_tool('Перемещение')
    def save_shape_style(self):
        value={k:self.canvas.shape_options[k] for k in ('stroke','fill','filled')};self.settings.setValue('shapes/style_056',json.dumps(value));self.settings.sync()

    def _make_selection_transform_dock(self):
        from transform_panel import TransformDock,TransformPanel
        self._transform_ui_locked=False;self.transform_dock=TransformDock(self);self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,self.transform_dock)
        self.transform_panel=TransformPanel(self);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(self.transform_panel)
        wrapper=QWidget();layout=QVBoxLayout(wrapper);layout.setContentsMargins(6,4,6,6);layout.addWidget(scroll,1)
        # Commit controls stay visible even when a short dock needs scrolling.
        for widget in (self.transform_panel.status,self.transform_panel.actions):
            self.transform_panel.layout().removeWidget(widget);layout.addWidget(widget)
        self.transform_dock.setWidget(wrapper)
        self.tabifyDockWidget(self.color_dock,self.transform_dock);self.transform_dock.hide()
        self.transform_apply_action=self._action('Применить предпросмотр','',self.apply_preview_values);self.transform_apply_action.setShortcuts([QKeySequence('Return'),QKeySequence('Enter')]);self.transform_apply_action.setEnabled(False)
        self.transform_cancel_action=self._action('Отменить предпросмотр','Escape',self.canvas.cancel_pending_preview);self.transform_cancel_action.setEnabled(False)
        self.canvas.selectionTransformChanged.connect(self.sync_selection_transform_ui)

    def _make_gradient_dock(self):
        from gradient_panel import GradientDock,GradientPanel
        self.gradient_dock=GradientDock(self);self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,self.gradient_dock)
        self.gradient_panel=GradientPanel(self);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(self.gradient_panel)
        wrapper=QWidget();layout=QVBoxLayout(wrapper);layout.setContentsMargins(6,4,6,6);layout.addWidget(scroll,1);layout.addWidget(self.gradient_panel.status);layout.addWidget(self.gradient_panel.actions);self.gradient_dock.setWidget(wrapper)
        self.tabifyDockWidget(self.color_dock,self.gradient_dock);self.gradient_dock.hide();self.canvas.gradientChanged.connect(self.sync_selection_transform_ui)

    def _make_retouch_dock(self):
        from retouch_panel import RetouchDock,RetouchPanel
        self.retouch_dock=RetouchDock(self);self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,self.retouch_dock);self.retouch_panel=RetouchPanel(self);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(self.retouch_panel);self.retouch_dock.setWidget(scroll)
        self.tabifyDockWidget(self.color_dock,self.retouch_dock);self.retouch_dock.hide();self.canvas.retouchChanged.connect(self.sync_selection_transform_ui)

    def show_adjustment_dialog(self):
        from adjustment_dialog import AdjustmentDialog
        if not self.canvas.start_adjustment():return
        dialog=AdjustmentDialog(self)
        try:dialog.exec()
        finally:
            self.canvas.cancel_adjustment();dialog.deleteLater()

    def apply_preview_values(self):
        if self.canvas.retouch_session is not None:self.canvas.finish_retouch();return
        if self.canvas.gradient_session is not None:self.gradient_panel.apply_values()
        else:self.transform_panel.apply_values()

    def sync_selection_transform_ui(self):
        gradient=self.canvas.gradient_session is not None
        retouch=self.canvas.retouch_session is not None
        active=self.canvas.selection_transform is not None or gradient or retouch
        dock=self.retouch_dock if retouch else self.gradient_dock if gradient else self.transform_dock
        if active and not self._transform_ui_locked:
            self._transform_ui_locked=True
            safe={dock}
            if gradient:safe.add(self.palette_dock)
            widgets=[self.menuBar()]+list(self.findChildren(QToolBar))+[d for d in self.findChildren(QDockWidget) if d not in safe]
            self._transform_widget_states=[(w,w.isEnabled()) for w in widgets]
            self._transform_action_states=[(a,a.isEnabled()) for a in self.findChildren(QAction)]
            for w,_ in self._transform_widget_states:w.setEnabled(False)
            for a,_ in self._transform_action_states:a.setEnabled(False)
            self.transform_apply_action.setEnabled(True);self.transform_cancel_action.setEnabled(True)
            dock.setEnabled(True);dock.show();dock.raise_();self.resizeDocks([dock],[560],Qt.Orientation.Vertical)
        if hasattr(self,"gradient_panel"):self.gradient_panel.refresh()
        if hasattr(self,"retouch_panel"):self.retouch_panel.refresh()
        if active and not gradient and not retouch:self.transform_panel.refresh()
        if active:return
        if not self._transform_ui_locked:return
        self._transform_ui_locked=False
        for a,enabled in self._transform_action_states:a.setEnabled(enabled)
        for w,enabled in self._transform_widget_states:w.setEnabled(enabled)
        self.transform_dock.hide();self.set_tool(self.canvas.tool);self.refresh_layers();self.canvas.update_cursor()

    def _make_selection_dock(self):
        from selection_panel import SelectionPanel
        self.selection_dock=self._dock('Выделение',Qt.DockWidgetArea.RightDockWidgetArea)
        self.selection_panel=SelectionPanel(self);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(self.selection_panel);self.selection_dock.setWidget(scroll)
        self.tabifyDockWidget(self.color_dock,self.selection_dock);self.selection_dock.hide();self.canvas.changed.connect(self.selection_panel.refresh);self.canvas.selectionStateChanged.connect(self.selection_panel.refresh)

    def show_selection_panel(self):
        self.selection_panel.refresh();self.selection_dock.show();self.selection_dock.raise_()

    def _make_mask_dock(self):
        self.mask_dock=self._dock('Маска слоя',Qt.DockWidgetArea.RightDockWidgetArea)
        self.mask_panel=MaskPanel(self);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(self.mask_panel)
        self.mask_dock.setWidget(scroll);self.tabifyDockWidget(self.color_dock,self.mask_dock);self.mask_dock.hide()

    def show_mask_panel(self):
        self.mask_panel.refresh();self.mask_dock.show();self.mask_dock.raise_()

    def _make_text_dock(self):
        self.text_dock=self._dock('Редактирование текста',Qt.DockWidgetArea.RightDockWidgetArea)
        self.text_controls=TextControls(dict(text='',size=48), preview_font=True);self.text_controls.setEnabled(False)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(self.text_controls);self.text_dock.setWidget(scroll)
        self.tabifyDockWidget(self.color_dock,self.text_dock);self.text_dock.hide()
        self._text_edit_timer=QTimer(self);self._text_edit_timer.setSingleShot(True);self._text_edit_timer.setInterval(650)
        self._text_edit_timer.timeout.connect(self.end_text_history_group)
        self.canvas.historyRestored.connect(self._text_edit_timer.stop)
        self.text_controls.edited.connect(self.apply_inline_text)
        self.canvas.textSelected.connect(self.sync_text_inspector)

    def sync_text_inspector(self,index):
        if not 0<=index<len(self.canvas.text_objects):
            self._text_edit_timer.stop();self.end_text_history_group();self.text_controls.setEnabled(False);return
        self.text_controls.setEnabled(not self.canvas.node_locked(self.canvas.text_layer(self.canvas.text_objects[index]) or self.canvas.active))
        item=self.canvas.text_objects[index]
        key=(index,item.get('layer_id'))
        if getattr(self,'_inspected_text_key',None)!=key:
            self._text_edit_timer.stop();self.end_text_history_group()
        self._inspected_text_key=key
        self.text_controls.set_item(item);self.text_dock.show();self.text_dock.raise_()

    def apply_inline_text(self,values):
        index=self.canvas.selected_text
        if not 0<=index<len(self.canvas.text_objects):return
        if not self.canvas.can_edit(self.canvas.text_layer(self.canvas.text_objects[index])):
            self.text_controls.set_item(self.canvas.text_objects[index]);return
        if not self._text_edit_timer.isActive() or not self.canvas._history_group_active:
            self.canvas.push_history()
            self.canvas._history_group_active=True
        if not getattr(self,"_color_picker_active",False):self._text_edit_timer.start()
        self.canvas.text_objects[index].update({key:value for key,value in values.items() if key not in ('x','y','layer_id')})
        layer=self.canvas.text_layer(self.canvas.text_objects[index])
        if layer and layer.kind=='text' and layer.name.startswith('Текст · '):layer.name='Текст · '+values['text'][:22]
        self.canvas.changed.emit();self.canvas.update()

    def end_text_history_group(self):
        was_active=self.canvas._history_group_active
        self.canvas._history_group_active=False
        if was_active:self.canvas.commit_history()

    def edit_selected_text(self):
        index=self.canvas.selected_text
        self.canvas.edit_text_dialog(index if 0<=index<len(self.canvas.text_objects) else None)

    def remove_photo(self):
        self.run_canvas_action(self.canvas.remove_selected_image)

    def edit_glow(self):
        from glow_dialog import GlowDialog
        from effects import validate_glow
        c=self.canvas
        if c.drawing or c.fill_job is not None:return
        if len(c.selected_node_ids())!=1 or c.control_node().kind=='group':
            c.status.emit('Выберите один слой с фото, текстом или рисунком.');return
        if not c.can_edit():return
        dialog=GlowDialog(c.active,c.layer_image(c.active,include_effects=False),c.doc_size,self)
        if dialog.exec()!=QDialog.DialogCode.Accepted:return
        value=None if dialog.deleted else validate_glow(dialog.values())
        if value==c.active.glow:return
        c.push_history();c.active.glow=value;c.changed.emit();c.update()

    def import_layer(self):
        filename,_=QFileDialog.getOpenFileName(self,'Изображение отдельным слоем','','Изображения (*.png *.jpg *.jpeg *.bmp *.webp)')
        if filename:self.import_paths([filename],'layer')

    def import_texture(self):
        filename,_=QFileDialog.getOpenFileName(self,'Своя текстура','','Изображения (*.png *.jpg *.jpeg *.bmp *.webp)')
        if filename:self.import_paths([filename],'texture')

    def import_paths(self,paths,mode=None):
        from image_dialogs import ImportChoice
        from raster_objects import read_image
        if self.canvas.drawing or self.canvas.fill_job is not None:return
        if not paths:return
        if mode is None:
            dialog=ImportChoice(paths,self)
            if dialog.exec()!=QDialog.DialogCode.Accepted:return
            mode=dialog.mode
        if mode == 'document':
            return len(paths) == 1 and self.open_image_path(paths[0])
        for path in paths:
            try:
                image=read_image(path)
                if self.canvas.import_object(image,Path(path).stem,mode=='texture'):
                    self.move_scope.setCurrentIndex(0);self.auto_select_check.setChecked(False);self.set_tool('Перемещение')
            except (ValueError,MemoryError,OSError) as error:QMessageBox.warning(self,APP_NAME,f'{Path(path).name}: {error}');break

    def dragEnterEvent(self,event):
        if event.mimeData().hasUrls() and all(url.isLocalFile() and Path(url.toLocalFile()).suffix.lower() in ('.png','.jpg','.jpeg','.bmp','.webp') for url in event.mimeData().urls()):event.acceptProposedAction()
        else:event.ignore()

    def dropEvent(self,event):
        paths=[u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
        if paths:self.import_paths(paths);event.acceptProposedAction()
        else:event.ignore()

    def edit_placement(self,whole_layer=False):
        if self.canvas.selection is not None and not whole_layer:
            self.run_canvas_action(self.canvas.start_selection_transform);return
        from image_dialogs import PlacementDialog
        c=self.canvas
        if c.drawing or c.fill_job is not None:return
        if len(c.selected_node_ids())!=1 or c.control_node().kind=='group':
            c.status.emit('Выберите один слой с изображением или эффектом.');return
        if not c.can_edit(move=True):return
        obj=c.object_for_layer()
        if obj is None:
            if c.selected_text>=0:self.edit_selected_text()
            else:c.status.emit(getattr(c,'_object_error','') or 'В слое нет изображения. Добавьте фото или нарисуйте эффект. Текст редактируется отдельно.')
            return
        if 'shape' in obj:
            o=dict(obj['shape']['options'],width=obj['width'],height=obj['height'],rotation=obj['rotation'],exact=True)
            dialog=ShapeDialog(obj['shape']['name'],o,self,placement=obj,opacity=round(c.active.opacity*100))
            dialog.back.hide()
            if dialog.exec()==QDialog.DialogCode.Accepted:self.run_canvas_action(c.set_object,c.active,dialog.object_values(),True,dialog.object_opacity.value()/100)
            return
        dialog=PlacementDialog(obj,c.doc_size,c.active,self)
        if dialog.exec()==QDialog.DialogCode.Accepted:
            try:
                if c.set_object(c.active,dialog.values(),opacity=dialog.opacity.value()/100,blend=dialog.blend.currentData()):
                    c.selection=None;self.move_scope.setCurrentIndex(0);self.auto_select_check.setChecked(False);self.set_tool('Перемещение')
            except (ValueError,MemoryError) as error:QMessageBox.warning(self,APP_NAME,str(error))

    def run_canvas_action(self,callback,*args):
        try:callback(*args)
        except (ValueError,MemoryError) as error:QMessageBox.warning(self,APP_NAME,str(error))

    def remember_fill_color(self, color):
        self.canvas.last_fill_color = QColor(color)
        self.settings.setValue('fill/color', color.name(QColor.NameFormat.HexArgb))

    def edit_tool_settings(self,tool):
        if tool in RETOUCH_TOOLS:self.set_tool(tool);self.retouch_dock.show();self.retouch_dock.raise_();return
        if self.canvas.drawing or self.canvas.fill_job is not None:return
        if tool in ('Кисть','Карандаш','Маркер','Мягкая кисть','Ластик'):
            self.set_tool(tool);self.choose_brush(edit_current=True)
        elif tool=='Заливка':
            from tool_settings import FillSettingsDialog
            self.set_tool(tool);dialog=FillSettingsDialog(self.canvas,self)
            if dialog.exec()==QDialog.DialogCode.Accepted:
                self.fill_tolerance_spin.setValue(dialog.tolerance.value())
                self.opacity_slider.setValue(dialog.opacity.value())
                self.set_color(dialog.color.color)
                if not self.canvas.editing_mask:
                    self.remember_fill_color(dialog.color.color)
        elif tool=='Градиент':self.set_tool(tool)
        elif tool in ('Выделение','Лассо','Волшебная палочка'):self.set_tool(tool);self.show_selection_panel()
        elif tool=='Фигуры':self.choose_shape()
        elif tool=='Текст':self.set_tool(tool);self.edit_selected_text()
        elif tool=='Перемещение':self.set_tool(tool);self.edit_placement()

    def edit_brush(self):self.choose_brush(edit_current=True)

    def choose_brush(self,edit_current=False):
        from brush_panel import BrushDialog
        dialog=BrushDialog(self.canvas,self)
        if edit_current:dialog.pick(dialog.tool,None)
        if dialog.exec()==QDialog.DialogCode.Accepted:
            tool,size,opacity,hardness,stabilizer=dialog.values()
            appearance=dialog.appearance()
            self.canvas.brush_shape=appearance['shape'];self.canvas.brush_outline=appearance['outline'];self.canvas.brush_outline_color=appearance['outline_color'];self.set_color(appearance['color'])
            for key in ('shape','outline'):self.settings.setValue('brush/'+key,appearance[key])
            self.settings.setValue('brush/outline_color',appearance['outline_color'].name())
            for key,value in dialog.dynamics().items():
                setattr(self.canvas,'brush_'+key,value);self.settings.setValue('brush/'+key,value)
            self.canvas.brush_hardness=hardness;self.canvas.brush_stabilizer=stabilizer
            self.settings.setValue('brush/hardness',hardness);self.settings.setValue('brush/stabilizer',stabilizer)
            self.size_spin.setValue(size);self.opacity_slider.setValue(opacity);self.set_tool(tool)
        else:self.set_tool(self.canvas.tool)

    def set_checker_style(self,style):
        if style not in ('light','dark'):return
        self.canvas.checker_style=style;self.canvas.show_checkerboard=True
        self.settings.setValue('canvas/checker',style);self.canvas.update()

    def toggle_checkerboard(self):
        self.canvas.show_checkerboard=not self.canvas.show_checkerboard;self.canvas.update()

    def set_brush_size(self, value):
        self.canvas.brush_size = value
        self.canvas.update_cursor()

    def set_brush_opacity(self, value):
        self.canvas.brush_opacity = value

    def choose_color(self):
        original=QColor(self.canvas.color);style=dict(self.canvas.shape_options);self._color_previewing=True
        dialog=QColorDialog(original,self);dialog.setWindowTitle('Цвет — живой предпросмотр');dialog.setOption(QColorDialog.ColorDialogOption.DontUseNativeDialog,True)
        dialog.currentColorChanged.connect(self.set_color)
        result=dialog.exec()
        if result==QDialog.DialogCode.Accepted:
            self._color_previewing=False;self.set_color(dialog.currentColor())
        else:
            self.set_color(original);self.canvas.shape_options=style;self._color_previewing=False
        dialog.deleteLater()

    def set_color(self,color):
        color=QColor(color)
        if not color.isValid():return
        self.canvas.color=color;self.update_color_button(color);self.canvas.colorChanged.emit(color)
        key='fill' if self.canvas.shape_options.get('filled') else 'stroke';self.canvas.shape_options[key]=color.name()
        if not getattr(self,'_color_previewing',False):self.save_shape_style()

    def apply_hex_color(self):
        value = self.hex_input.text().strip()
        if not value.startswith("#"):
            value = "#" + value
        color = QColor(value)
        if color.isValid():
            self.set_color(color)
        else:
            QMessageBox.warning(self, "Неверный цвет", "Введите HEX в формате #35A7FF.")

    def update_color_button(self, color):
        if not color.isValid():
            return
        if hasattr(self, "color_button"):
            self.color_button.setStyleSheet(
                f"background-color: {color.name()}; color: "
                f"{'black' if color.lightness() > 140 else 'white'};")
        if hasattr(self, "color_preview"):
            self.color_preview.setStyleSheet(
                f"background-color: {color.name()}; color: "
                f"{'black' if color.lightness() > 140 else 'white'};")
        if hasattr(self, "rgb_label"):
            self.rgb_label.setText(
                f"HEX {color.name().upper()}\nRGB {color.red()}, {color.green()}, {color.blue()}")
        for button in getattr(self,"swatch_buttons",[]):
            button.setChecked(button.color == color)
        if hasattr(self, "hex_input") and self.hex_input.text().strip().lower() != color.name().lower():
            self.hex_input.setText(color.name().upper())

    def set_zoom(self, zoom):
        self.canvas.set_zoom(zoom)

    def show_start_screen(self):
        dialog = QDialog(self)
        dialog.setWindowTitle(f'DOGFORST Paint Studio · {APP_VERSION}')
        dialog.setMinimumWidth(400)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(22, 18, 22, 18)
        layout.addWidget(BrandBadge(dialog))
        title = QLabel('С чего начнём?')
        font = title.font()
        font.setPointSize(font.pointSize() + 5)
        font.setBold(True)
        title.setFont(font)
        layout.addWidget(title)
        for label, hint, action in (
            ('Импортировать изображение…', 'Открыть фото и создать холст по его размеру.', self.open_image),
            ('Новый холст…', 'Выбрать размеры для рисунка с нуля.', self.new_document),
            ('Открыть проект…', 'Продолжить работу с файлом .mpaint.', self.open_project),
        ):
            button = QPushButton(label)
            button.setMinimumHeight(38)
            button.clicked.connect(lambda checked=False, run=action: dialog.accept() if run() else None)
            layout.addWidget(button)
            description = QLabel(hint)
            description.setWordWrap(True)
            layout.addWidget(description)
            layout.addSpacing(5)
        close_button = QPushButton('Перейти в редактор')
        close_button.clicked.connect(dialog.reject)
        layout.addWidget(close_button)
        dialog.exec()
        dialog.deleteLater()

    def new_document(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Новый холст DOGFORST")
        dialog.resize(370, 215)
        form = QFormLayout(dialog)
        import_image = QPushButton('Импортировать изображение…')
        import_image.setToolTip('Создать документ по размеру выбранного изображения.')
        import_result = 2
        import_image.clicked.connect(lambda: dialog.done(import_result))
        form.addRow(import_image)
        preset = QComboBox()
        preset.addItems(["Пользовательский", "Квадрат 1080 × 1080", "YouTube 1920 × 1080", "Shorts 1080 × 1920", "HD 1280 × 720", "Аватар 512 × 512"])
        width_spin = QSpinBox(); width_spin.setRange(1, 12000); width_spin.setValue(1200)
        height_spin = QSpinBox(); height_spin.setRange(1, 12000); height_spin.setValue(800)
        form.addRow("Шаблон:", preset)
        form.addRow("Ширина (px):", width_spin)
        form.addRow("Высота (px):", height_spin)
        def apply_preset(index):
            sizes = {1: (1080,1080), 2: (1920,1080), 3: (1080,1920), 4: (1280,720), 5: (512,512)}
            if index in sizes:
                width_spin.setValue(sizes[index][0]); height_spin.setValue(sizes[index][1])
        preset.currentIndexChanged.connect(apply_preset)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        result = dialog.exec()
        if result == import_result:
            return self.open_image()
        if result != QDialog.DialogCode.Accepted or not self.confirm_document_change():
            return False
        try:
            self.canvas.new_document(width_spin.value(), height_spin.value())
        except ValueError as error:
            QMessageBox.warning(self, APP_NAME, str(error))
            return False
        self.current_file = None
        self._file_token = self._file_token_path = None
        self.canvas.history.clear()
        self.canvas.future.clear()
        self.mark_clean()
        self.refresh_layers()
        self.start_document_session()
        return True

    def resize_canvas(self):
        old_w, old_h = self.canvas.doc_size
        dialog = QDialog(self)
        dialog.setWindowTitle("Настроить размер холста")
        form = QFormLayout(dialog)
        width_spin = QSpinBox(); width_spin.setRange(1, 12000); width_spin.setValue(old_w)
        height_spin = QSpinBox(); height_spin.setRange(1, 12000); height_spin.setValue(old_h)
        anchor = QComboBox(); anchor.addItems(["По центру", "Слева сверху"])
        form.addRow("Ширина (пиксели):", width_spin)
        form.addRow("Высота (пиксели):", height_spin)
        form.addRow("Расположение содержимого:", anchor)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        width, height = width_spin.value(), height_spin.value()
        if (width, height) == (old_w, old_h):
            return
        if width * height > 60_000_000 or width*height*(len(self.canvas.layers)+len(self.canvas.masks))+self.canvas.source_pixels() > 120_000_000:
            QMessageBox.warning(self, "Слишком большой холст", "Выбранный холст слишком велик. Выбери меньший размер, чтобы избежать нехватки памяти.")
            return
        canvas = self.canvas
        size_only = (
            self.current_file is None and not self.dirty
            and len(canvas.layers) == 1 and not canvas.text_objects
            and not canvas.raster_objects and not canvas.groups and not canvas.masks
        )
        if size_only:
            from raster_objects import alpha_bounds
            size_only = alpha_bounds(canvas.active.image) is None
        canvas.push_history(mark_modified=not size_only)
        dx, dy = ((width - old_w) // 2, (height - old_h) // 2) if anchor.currentIndex() == 0 else (0, 0)
        resized_layers = []
        for layer in self.canvas.layers:
            image = transparent_image(width, height)
            painter = QPainter(image)
            painter.drawImage(dx, dy, layer.image)
            painter.end()
            resized_layers.append(Layer(layer.name, image, layer.visible, layer.opacity, layer.id, layer.kind, **layer.flags()))
        self.canvas.transform_masks((width,height),QPointF(dx,dy))
        self.canvas.doc_size = (width, height)
        self.canvas.layers = resized_layers
        for obj in self.canvas.raster_objects.values():obj["x"]+=dx;obj["y"]+=dy
        from raster_objects import render_object
        for layer in self.canvas.layers:
            if layer.id in self.canvas.raster_objects:layer.image=render_object(self.canvas.raster_objects[layer.id],(width,height))
        self.canvas.reset_object_keys()
        for item in self.canvas.text_objects:
            item["x"] = float(item.get("x",0))+dx
            item["y"] = float(item.get("y",0))+dy
        self.canvas.selection = None
        self.canvas.fit_canvas()
        self.canvas.changed.emit()
        self.canvas.update()
        self.statusBar().showMessage(f"Размер холста: {width} × {height} px", 5000)

    def open_image(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Открыть изображение", "",
            "Изображения (*.png *.jpg *.jpeg *.bmp *.webp *.gif);;Все файлы (*.*)")
        return bool(filename) and self.open_image_path(filename)

    def open_image_path(self, filename):
        if not self.confirm_document_change():
            return False
        try:
            self.canvas.load_image(filename)
        except Exception as error:
            logging.getLogger("dogforst").exception("Image open failed")
            QMessageBox.critical(self, "Ошибка открытия", str(error))
            return False
        self.current_file = None
        self._file_token = self._file_token_path = None
        self.canvas.history.clear()
        self.canvas.future.clear()
        self.mark_clean()
        self.refresh_layers()
        self.start_document_session()
        self.statusBar().showMessage(f"Открыто: {filename}", 5000)
        return True

    def open_project(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Открыть проект DOGFORST", "", "Проекты DOGFORST (*.mpaint)")
        if not filename or not self.confirm_document_change():
            return False
        try:
            token = project_fingerprint(filename)
            self.canvas.load_project(filename)
        except Exception as error:
            logging.getLogger("dogforst").exception("Project open failed")
            QMessageBox.critical(self, "Ошибка проекта", str(error))
            return False
        self.current_file = filename
        self._file_token, self._file_token_path = token, str(Path(filename).absolute())
        self.canvas.history.clear()
        self.canvas.future.clear()
        self.mark_clean()
        self.refresh_layers()
        self.start_document_session()
        return True

    def save_project(self):
        if not self.current_file:
            return self.save_project_as()
        try:
            options = {'return_token': True, 'backup_limit': self._safety.backup_limit if self._safety else 10}
            if self._file_token_path == str(Path(self.current_file).absolute()):
                options['expected_fingerprint'] = self._file_token
            self.current_file, self._file_token = self._write_project(self.current_file, **options)
            self._file_token_path = str(Path(self.current_file).absolute())
            self.complete_project_save()
            return True
        except OperationCancelled:
            self.statusBar().showMessage("Сохранение отменено. Предыдущий файл не изменён.", 6000)
            return False
        except Exception as error:
            logging.getLogger("dogforst").exception("Manual project save failed")
            QMessageBox.critical(self, "Ошибка сохранения", str(error))
            return False

    def save_project_as(self):
        filename, _ = QFileDialog.getSaveFileName(
            self, "Сохранить проект", "Рисунок.mpaint",
            "Проекты DOGFORST (*.mpaint)")
        if filename:
            if not filename.lower().endswith(".mpaint"):
                filename += ".mpaint"
            try:
                self.current_file, self._file_token = self._write_project(filename, return_token=True, backup_limit=self._safety.backup_limit if self._safety else 10)
                self._file_token_path = str(Path(self.current_file).absolute())
                self.complete_project_save()
                return True
            except OperationCancelled:
                self.statusBar().showMessage("Сохранение отменено. Предыдущий файл не изменён.", 6000)
                return False
            except Exception as error:
                logging.getLogger("dogforst").exception("Manual project save failed")
                QMessageBox.critical(self, "Ошибка сохранения", str(error))
        return False

    def remove_background(self):
        from background_cut import BackgroundCutDialog
        from raster_objects import render_object
        canvas = self.canvas
        if canvas.drawing or canvas.fill_job is not None or canvas.wand_job is not None:
            return
        layer = canvas.active
        if (len(canvas.selected_node_ids()) != 1 or canvas.control_node().kind == 'group'
                or canvas.editing_mask or any(text.get('layer_id') == layer.id for text in canvas.text_objects)):
            canvas.status.emit('Выберите один растровый слой или фото.')
            return
        if not canvas.can_edit(erase=True):
            return
        canvas.cancel_pending_preview()
        stamp = canvas.selection_stamp()
        photo = canvas.raster_objects.get(layer.id)
        if photo is not None and 'shape' in photo:
            photo = None
        source = photo['source'] if photo is not None else layer.image
        dialog = BackgroundCutDialog(source, canvas.wand_tolerance, self)
        try:
            if dialog.exec() != QDialog.DialogCode.Accepted or dialog.result is None:
                return
            if canvas.selection_stamp() != stamp or canvas.active.id != layer.id:
                canvas.status.emit('Документ изменился. Откройте вырезание фона заново.')
                return
            updated = dict(photo, source=dialog.result) if photo is not None else None
            image = render_object(updated, canvas.doc_size) if updated is not None else dialog.result
            canvas.push_history()
            layer.image = image
            if updated is not None:
                canvas.remember_object(layer, updated)
            canvas.changed.emit()
            canvas.update()
            canvas.status.emit('Фон удалён. Ctrl+Z — отменить.')
        except (ValueError, MemoryError) as error:
            QMessageBox.warning(self, APP_NAME, str(error))
        finally:
            dialog.deleteLater()

    def export_image(self):
        dialog=ExportDialog(self)
        if dialog.exec()!=QDialog.DialogCode.Accepted:return
        extension=dialog.extension
        formats={'png':'PNG (*.png)','jpg':'JPEG (*.jpg *.jpeg)','bmp':'BMP (*.bmp)','webp':'WEBP (*.webp)'}
        directory = Path(self.settings.value('export/directory', '') or
                         QStandardPaths.writableLocation(QStandardPaths.StandardLocation.PicturesLocation)
                         or str(Path.home()))
        if not directory.is_dir():
            directory = Path.home()
        suggested = directory / f'Рисунок.{extension}'
        if extension == 'png':
            number = 0
            while suggested.exists() or suggested.is_symlink():
                number += 1
                suggested = directory / f'Рисунок{number}.png'
        filename, _ = QFileDialog.getSaveFileName(
            self, 'Сохранить изображение', str(suggested), formats[extension])
        if not filename:return
        # The mini-dialog is authoritative; do not silently export another codec.
        target=Path(filename)
        allowed=('.jpg','.jpeg') if extension=='jpg' else ('.'+extension,)
        if target.suffix.lower() not in allowed:
            filename=str(target.with_suffix('.'+extension))
            if Path(filename).exists():
                answer=QMessageBox.question(self,APP_NAME,f'Заменить существующий файл?\n{filename}',QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)
                if answer!=QMessageBox.StandardButton.Yes:return
        try:
            self.canvas.export_image(filename,dialog.quality.value(),dialog.background.color.name())
            self.settings.setValue('export/directory', str(Path(filename).resolve().parent))
            self.statusBar().showMessage(f'Изображение сохранено: {filename}',5000)
        except Exception as error:QMessageBox.critical(self,'Ошибка экспорта',str(error))

    def undo(self):
        self.run_canvas_action(self.canvas.undo)
        self.refresh_layers()

    def redo(self):
        self.run_canvas_action(self.canvas.redo)
        self.refresh_layers()

    def deselect(self):
        if self.canvas.cancel_object_drag():return
        self.canvas.cancel_selection()

    def complete_project_save(self):
        if self._safety and self._safety.last_manual_snapshot != (self._safety.session, self._safety.revision):
            saved_session, saved_revision = self._safety.last_manual_snapshot
            if saved_session == self._safety.session:
                self._safety.saved(saved_revision)
            self.dirty = True
            self.update_title()
            self.statusBar().showMessage('Снимок проекта сохранён. В документе есть более новые изменения.', 9000)
        else:
            self.mark_clean()
            self.statusBar().showMessage(f'Проект сохранён: {self.current_file}', 4000)

    def _write_project(self, filename, **options):
        if self._safety:
            return self._safety.write_project(filename, **options)
        return self.canvas.save_project(filename, **options)

    def safety_action(self, method, **kwargs):
        if self._safety:
            return getattr(self._safety, method)(**kwargs)
        QMessageBox.warning(self, APP_NAME, 'Хранилище автосохранения недоступно. Проверьте права на папку данных приложения.')
        return False

    def start_document_session(self):
        if self.current_file is None:
            self._file_token = self._file_token_path = None
        if self._safety:
            try:
                self._safety.new_document()
            except OSError as error:
                logging.getLogger('dogforst').exception('Could not start recovery session')
                self._safety.timer.stop()
                self.statusBar().showMessage('Автосохранение недоступно: '+str(error))

    def closeEvent(self, event):
        self.canvas.cancel_pending_preview()
        if self._safety and not self._safety.prepare_close():
            event.ignore()
            return
        if self.confirm_document_change():
            if self._safety:
                self._safety.finish_close()
            self.persist_workspace();event.accept()
        else:
            event.ignore()
