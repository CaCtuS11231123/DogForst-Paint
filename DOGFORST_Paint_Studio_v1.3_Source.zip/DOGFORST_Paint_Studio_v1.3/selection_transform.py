"""Transactional selected-pixel transforms. Model data stays unchanged until Apply.

Workers own immutable QImage inputs and value transforms; at most one job runs per canvas.
"""
import math,threading,uuid
from dataclasses import dataclass
from PySide6.QtCore import Qt,QPointF,QRectF,QRect,QObject,QRunnable,Signal,QTimer,QThreadPool
from PySide6.QtGui import QImage,QPainter,QColor,QTransform,QPolygonF,QPen
import numpy as np
from layers import Layer,transparent_image
from masks import apply_mask
from selection_tools import gray_array,from_array,mask_bounds


def validate_parameters(value):
    for key in ('x','y','width','height','rotation'):
        n=value[key]
        if isinstance(n,bool) or not isinstance(n,(float,int)) or not math.isfinite(n):raise ValueError('Некорректный параметр трансформации.')
    if abs(value['x'])>100000 or abs(value['y'])>100000 or not 1<=value['width']<=24000 or not 1<=value['height']<=24000 or abs(value['rotation'])>36000:raise ValueError('Параметры трансформации вне допустимых границ.')
    for key in ('flip_h','flip_v','smooth'):
        if not isinstance(value[key],bool):raise ValueError('Некорректный режим трансформации.')
    return dict(value)


def placement_matrix(p):
    t=QTransform().translate(p['x']+p['width']/2,p['y']+p['height']/2).rotate(p['rotation'])
    t.scale(-1 if p['flip_h'] else 1,-1 if p['flip_v'] else 1)
    return t.translate(-p['width']/2,-p['height']/2)


def source_matrix(p,rect):return placement_matrix(p).scale(p['width']/rect.width(),p['height']/rect.height())


def identity(p,rect):
    return (not p['flip_h'] and not p['flip_v'] and abs(p['rotation']%360)<1e-7 and
            all(abs(p[key]-value)<1e-7 for key,value in [('x',rect.x()),('y',rect.y()),('width',rect.width()),('height',rect.height())]))


def alpha_image(coverage):
    keep,gray=gray_array(coverage);pixels=np.empty((coverage.height(),coverage.width(),4),dtype=np.uint8)
    pixels[:,:,:3]=255;pixels[:,:,3]=gray
    return QImage(pixels.data,coverage.width(),coverage.height(),coverage.width()*4,QImage.Format.Format_RGBA8888).copy().convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)


def cut_and_remainder(image,coverage,rect,opaque):
    cut=apply_mask(image.copy(rect),coverage,rect)
    remainder=QImage(image);alpha=alpha_image(coverage.copy(rect));p=QPainter(remainder)
    if not opaque:p.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationOut)
    p.drawImage(rect.topLeft(),alpha);p.end()
    return cut,remainder


@dataclass(frozen=True)
class TransformInput:
    size:tuple
    rect:object
    raw:object
    coverage:object
    linked_mask:object=None
    mask_only:bool=False


def render_transform(data,parameters,cancelled,prepared=None):
    p=validate_parameters(parameters);rect=data.rect
    if cancelled.is_set():return None
    if identity(p,rect):return dict(image=QImage(data.raw),linked=QImage(data.linked_mask) if data.linked_mask is not None else None,coverage=QImage(data.coverage),prepared=prepared)
    if prepared is None:
        cut,rest=cut_and_remainder(data.raw,data.coverage,rect,data.mask_only)
        prepared=dict(cut=cut,rest=rest,alpha=alpha_image(data.coverage.copy(rect)))
        if cancelled.is_set():return None
        if data.linked_mask is not None:
            cut,rest=cut_and_remainder(data.linked_mask,data.coverage,rect,True);prepared.update(mask_cut=cut,mask_rest=rest)
    if cancelled.is_set():return None
    matrix=source_matrix(p,rect)
    def draw(rest,cut):
        result=QImage(rest);painter=QPainter(result)
        try:
            painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform,p['smooth']);painter.setRenderHint(QPainter.RenderHint.Antialiasing,True)
            painter.setTransform(matrix);painter.drawImage(0,0,cut)
        finally:painter.end()
        return result
    image=draw(prepared['rest'],prepared['cut'])
    if cancelled.is_set():return None
    linked=draw(prepared['mask_rest'],prepared['mask_cut']) if data.linked_mask is not None else None
    alpha=draw(transparent_image(*data.size),prepared['alpha'])
    values=np.frombuffer(alpha.constBits(),dtype=np.uint32).reshape(alpha.height(),alpha.bytesPerLine()//4)[:,:alpha.width()]
    coverage=from_array((values>>24).astype(np.uint8))
    if cancelled.is_set():return None
    return dict(image=image,linked=linked,coverage=coverage,prepared=prepared)


class TransformSignals(QObject):done=Signal(object,object,str)
class TransformJob(QRunnable):
    def __init__(self,uid,version,data,parameters,prepared):
        super().__init__();self.uid=uid;self.version=version;self.data=data;self.parameters=dict(parameters);self.prepared=prepared
        self.cancelled=threading.Event();self.signals=TransformSignals()
    def run(self):
        try:self.signals.done.emit(self,render_transform(self.data,self.parameters,self.cancelled,self.prepared),'')
        except Exception as error:self.signals.done.emit(self,None,'Недостаточно памяти для трансформации.' if isinstance(error,MemoryError) else str(error) or type(error).__name__)


class TransformSession:
    def __init__(self,node_id,mask_id,stamp,data):
        self.uid=uuid.uuid4().hex;self.node_id=node_id;self.mask_id=mask_id;self.stamp=stamp;self.data=data
        r=data.rect;self.parameters=dict(x=float(r.x()),y=float(r.y()),width=float(r.width()),height=float(r.height()),rotation=0.,flip_h=False,flip_v=False,smooth=True)
        self.version=0;self.rendered_version=-1;self.result=None;self.prepared=None;self.keep_aspect=True;self.drag=None;self.apply_requested=False;self.error=''


class SelectionTransformMixin:
    def init_selection_transform(self):
        self.selection_transform=None;self._selection_transform_job=None
        self._selection_transform_timer=QTimer(self);self._selection_transform_timer.setSingleShot(True);self._selection_transform_timer.setInterval(16)
        self._selection_transform_timer.timeout.connect(self.launch_selection_transform_job)
    def start_selection_transform(self):
        if self.adjustment_session is not None or self.retouch_session is not None:return False
        if self.gradient_session is not None:self.status.emit("Сначала примените или отмените градиент.");return False
        if self.selection_transform is not None:return True
        if self.drawing or self.fill_job is not None or self.wand_job is not None:return False
        if self._lasso_points:self.status.emit('Сначала замкните или отмените контур лассо.');return False
        if self.selection is None:self.status.emit('Сначала выделите область прямоугольником, лассо или палочкой.');return False
        mask_id=self.editing_mask if self.editing_mask in self.masks else None
        if mask_id is None and (len(self.selected_node_ids())!=1 or self.control_node().kind=='group'):
            self.status.emit('Для трансформации области выберите один слой.');return False
        node=self.node(mask_id) if mask_id else self.active
        if self.node_locked(node,move=True):self.status.emit('Слой/маска защищены от правок или перемещения.');return False
        if mask_id is None and not self.can_edit(move=True,erase=True):return False
        rect=self.selection.toAlignedRect().intersected(QRect(0,0,*self.doc_size))
        if rect.isEmpty():self.status.emit('Выделение находится за пределами холста.');return False
        raw=QImage(self.masks[mask_id]) if mask_id else self.raw_pixels(self.active)
        coverage=self.selection_coverage();linked=QImage(self.masks[node.id]) if not mask_id and node.id in self.masks else None
        data=TransformInput(tuple(self.doc_size),rect,raw,coverage,linked,bool(mask_id))
        self.selection_transform=TransformSession(node.id,mask_id,self.selection_stamp(),data)
        self.selectionTransformChanged.emit();self.update();self._selection_transform_timer.start()
        self.status.emit('Трансформация области: рамка — размер/перенос, круг — поворот · Enter — применить · Esc — отменить')
        return True
    def update_selection_transform(self,**values):
        session=self.selection_transform
        if session is None:return
        parameters=validate_parameters(dict(session.parameters,**values))
        if parameters==session.parameters:return
        session.parameters=parameters;session.version+=1;session.error='';session.apply_requested=False
        self.selectionTransformChanged.emit();self.update();self._selection_transform_timer.start()
    def launch_selection_transform_job(self):
        s=self.selection_transform
        if s is None or self._selection_transform_job is not None or s.rendered_version==s.version:return
        job=TransformJob(s.uid,s.version,s.data,s.parameters,s.prepared);self._selection_transform_job=job
        job.signals.done.connect(self.finish_selection_transform_job);self.selectionTransformChanged.emit();QThreadPool.globalInstance().start(job)
    def finish_selection_transform_job(self,job,result,error):
        if job is not self._selection_transform_job:return
        self._selection_transform_job=None;s=self.selection_transform
        if s is None:return
        if job.uid!=s.uid:self.launch_selection_transform_job();return
        if error and job.version!=s.version:self.launch_selection_transform_job();return
        if error:
            s.error=error;s.apply_requested=False;self.status.emit(error);self.selectionTransformChanged.emit();return
        if result is not None:
            s.prepared=result['prepared']
            if job.version==s.version:s.result=result;s.rendered_version=job.version;self.update()
        self.selectionTransformChanged.emit()
        if s.rendered_version!=s.version:self.launch_selection_transform_job()
        elif s.apply_requested:self.apply_selection_transform()
    def cancel_selection_transform(self):
        if self.selection_transform is None:return False
        self.selection_transform=None;self._selection_transform_timer.stop()
        if self._selection_transform_job is not None:self._selection_transform_job.cancelled.set()
        self.selectionTransformChanged.emit();self.update();self.status.emit('Трансформация отменена. Исходные пиксели и выделение сохранены.');return True
    def apply_selection_transform(self):
        s=self.selection_transform
        if s is None:return False
        if self.selection_stamp()!=s.stamp or self.control_node().id!=s.node_id or self.editing_mask!=s.mask_id:
            self.cancel_selection_transform();self.status.emit('Документ или выбранный слой изменились: предпросмотр отменён.');return False
        if identity(s.parameters,s.data.rect):self.cancel_selection_transform();self.status.emit('Параметры не изменены. Пиксели сохранены точно.');return True
        if s.rendered_version!=s.version or s.result is None:
            s.apply_requested=True;self.status.emit('Применение после завершения пересчёта…');self.launch_selection_transform_job();return False
        result=s.result
        if result['image']==s.data.raw and result['coverage']==s.data.coverage:
            self.cancel_selection_transform();return True
        self.selection_transform=None;self._selection_transform_timer.stop()
        self.push_history()
        if s.mask_id:self.masks[s.mask_id]=QImage(result['image'])
        else:
            node=self.node(s.node_id);node.image=QImage(result['image']);node.kind='raster'
            self.text_objects=[item for item in self.text_objects if item.get('layer_id')!=s.node_id]
            if result['linked'] is not None:self.masks[s.node_id]=QImage(result['linked'])
            self.selected_text=-1;self.textSelected.emit(-1)
        self.selection=mask_bounds(result['coverage']);self.selection_mask=QImage(result['coverage']) if self.selection else None;self._selection_overlay_key=None
        self.changed.emit();self.selectionTransformChanged.emit();self.selectionStateChanged.emit();self.update();self.status.emit('Трансформация применена · Ctrl+Z — отменить')
        return True
    def selection_transform_context(self):
        s=self.selection_transform
        if s is None or s.result is None:return self.layers,self.text_objects,self.masks
        result=s.result;masks=dict(self.masks)
        if s.mask_id:masks[s.mask_id]=result['image'];return self.layers,self.text_objects,masks
        layers=[Layer(l.name,QImage(result['image']),l.visible,l.opacity,l.id,'raster',**l.flags()) if l.id==s.node_id else l for l in self.layers]
        texts=[t for t in self.text_objects if t.get('layer_id')!=s.node_id]
        if result['linked'] is not None:masks[s.node_id]=result['linked']
        return layers,texts,masks
    def selection_transform_handles(self):
        s=self.selection_transform
        if s is None:return {}
        p=s.parameters;t=placement_matrix(p);w,h=p['width'],p['height']
        points={'tl':QPointF(0,0),'tm':QPointF(w/2,0),'tr':QPointF(w,0),'mr':QPointF(w,h/2),'br':QPointF(w,h),'bm':QPointF(w/2,h),'bl':QPointF(0,h),'ml':QPointF(0,h/2),'rotate':QPointF(w/2,-28/max(.1,self.zoom))}
        return {key:self.screen_point(t.map(pt)) for key,pt in points.items()}
    def paint_selection_transform(self,painter):
        s=self.selection_transform
        if s is None:return
        handles=self.selection_transform_handles();polygon=QPolygonF([handles[k] for k in ('tl','tr','br','bl')])
        painter.save();painter.setRenderHint(QPainter.RenderHint.Antialiasing);painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor('#101827'),3));painter.drawPolygon(polygon);painter.setPen(QPen(QColor('#80caff'),1));painter.drawPolygon(polygon)
        painter.drawLine(handles['rotate'],(handles['tl']+handles['tr'])/2);self._paint_handles(painter,handles)
        p=s.parameters;busy=' · пересчёт…' if s.rendered_version!=s.version else ''
        self._overlay_label(painter,polygon.boundingRect().bottomLeft()+QPointF(0,24),f"{p['width']:.1f} × {p['height']:.1f} px · {p['rotation']:.1f}°{busy} · Enter — применить · Esc — отменить")
        painter.restore()
    def selection_transform_press(self,screen,pos):
        s=self.selection_transform;handles=self.selection_transform_handles();key=self.handle_at(screen,handles)
        if key is None:
            polygon=QPolygonF([handles[k] for k in ('tl','tr','br','bl')])
            if polygon.containsPoint(screen,Qt.FillRule.OddEvenFill):key='move'
        if key:s.drag=dict(key=key,start=QPointF(pos),parameters=dict(s.parameters))
    def selection_transform_move(self,screen,pos,modifiers):
        s=self.selection_transform
        if s is None:return
        if s.drag is None:
            key=self.handle_at(screen,self.selection_transform_handles())
            self.setCursor(Qt.CursorShape.CrossCursor if key=='rotate' else Qt.CursorShape.SizeFDiagCursor if key else Qt.CursorShape.SizeAllCursor);return
        drag=s.drag;old=drag['parameters'];p=dict(old);key=drag['key']
        if key=='move':
            delta=pos-drag['start']
            if modifiers&Qt.KeyboardModifier.ShiftModifier:delta=QPointF(delta.x(),0) if abs(delta.x())>abs(delta.y()) else QPointF(0,delta.y())
            p['x']+=delta.x();p['y']+=delta.y()
        elif key=='rotate':
            center=QPointF(old['x']+old['width']/2,old['y']+old['height']/2);a=drag['start']-center;b=pos-center
            angle=old['rotation']+math.degrees(math.atan2(b.y(),b.x())-math.atan2(a.y(),a.x()))
            p['rotation']=round(angle/15)*15 if modifiers&Qt.KeyboardModifier.ShiftModifier else round((angle+180)%360-180,1)
        else:
            local=placement_matrix(old).inverted()[0].map(pos)
            anchor=QPointF(old['width'] if 'l' in key else old['width']/2 if key in ('tm','bm') else 0,old['height'] if 't' in key else old['height']/2 if key in ('ml','mr') else 0)
            w=old['width'] if key in ('tm','bm') else max(1.,min(24000.,anchor.x()-local.x() if 'l' in key else local.x()-anchor.x()))
            h=old['height'] if key in ('ml','mr') else max(1.,min(24000.,anchor.y()-local.y() if 't' in key else local.y()-anchor.y()))
            locked=s.keep_aspect != bool(modifiers&Qt.KeyboardModifier.ShiftModifier)
            if key in ('tl','tr','br','bl') and locked:
                scale=min(24000/old['width'],24000/old['height'],max(w/old['width'],h/old['height']));w=old['width']*scale;h=old['height']*scale
            p.update(width=w,height=h)
            new_anchor=QPointF(w if 'l' in key else w/2 if key in ('tm','bm') else 0,h if 't' in key else h/2 if key in ('ml','mr') else 0)
            before=placement_matrix(old).map(anchor);after=placement_matrix(p).map(new_anchor);p['x']+=before.x()-after.x();p['y']+=before.y()-after.y()
        p['x']=max(-100000.,min(100000.,p['x']));p['y']=max(-100000.,min(100000.,p['y']))
        self.update_selection_transform(**p)
