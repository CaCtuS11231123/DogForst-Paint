@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run setup_windows.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install -r requirements-dev.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" scripts\check_build_environment.py
if errorlevel 1 goto failed
".venv\Scripts\python.exe" scripts\run_tests.py
if errorlevel 1 goto failed
".venv\Scripts\python.exe" scripts\write_release_manifest.py
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean DOGFORST_Paint_Studio.spec
if errorlevel 1 goto failed
copy /y "diagnose_windows.bat" "dist\DOGFORST_Paint_Studio\diagnose_windows.bat" >nul
if errorlevel 1 goto failed
".venv\Scripts\python.exe" scripts\write_release_manifest.py dist\DOGFORST_Paint_Studio frozen
if errorlevel 1 goto failed
"dist\DOGFORST_Paint_Studio\DOGFORST_Paint_Studio.exe" --verify-installation
if errorlevel 1 goto failed
"dist\DOGFORST_Paint_Studio\DOGFORST_Paint_Studio.exe" --smoke-test
if errorlevel 1 goto failed
echo Build and smoke launch completed. Read the manual test checklist in README_RU.md.
echo Send the entire dist\DOGFORST_Paint_Studio folder, including _internal, release_integrity.json and diagnose_windows.bat.
pause
exit /b 0
:failed
echo Build or validation failed. Read the error above.
pause
exit /b 1
