"""Modal controls over a non-mutating full-quality canvas preview."""
from PySide6.QtCore import Qt,QRectF,QSignalBlocker
from PySide6.QtGui import QPainter,QColor,QPen
from PySide6.QtWidgets import (QDialog,QWidget,QVBoxLayout,QHBoxLayout,QFormLayout,QLabel,QSpinBox,
    QComboBox,QCheckBox,QPushButton,QProgressBar,QTabWidget,QSplitter,QScrollArea,QDialogButtonBox)
from widgets import AnimatedSlider
from adjustments import DEFAULT_ADJUSTMENT,EFFECTS,PRESETS

class ComparisonPreview(QWidget):
    def __init__(self,canvas,parent=None):
        super().__init__(parent);self.canvas=canvas;self.split=50;self.dark=False;self.crop=True;self.setMinimumSize(300,300)
    def paintEvent(self,event):
        p=QPainter(self);p.fillRect(self.rect(),QColor('#202634' if self.dark else '#eef1f6'));s=self.canvas.adjustment_session
        if s is None:p.end();return
        src=s.data.raw;after=s.result or src
        area=QRectF(s.data.bounds).adjusted(-12,-12,12,12).intersected(QRectF(src.rect())) if self.crop and s.data.bounds else QRectF(src.rect())
        available=QRectF(self.rect()).adjusted(12,34,-12,-15);scale=min(available.width()/area.width(),available.height()/area.height());target=QRectF(0,0,area.width()*scale,area.height()*scale);target.moveCenter(available.center())
        p.save();p.setClipRect(target)
        for y in range(int(target.top()),int(target.bottom())+12,12):
            for x in range(int(target.left()),int(target.right())+12,12):
                c=('#343842' if (x//12+y//12)%2 else '#272b34') if self.dark else ('#ffffff' if (x//12+y//12)%2 else '#dce2eb');p.fillRect(x,y,12,12,QColor(c))
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        p.drawImage(target,src,area);divider=target.left()+target.width()*self.split/100
        p.setClipRect(QRectF(divider,target.top(),target.right()-divider,target.height()));p.drawImage(target,after,area);p.restore()
        p.setPen(QPen(QColor('#53bfff'),2));p.drawLine(int(divider),int(target.top()),int(divider),int(target.bottom()));p.setPen(QColor('#edf3fc' if self.dark else '#283a54'));p.drawText(14,23,'ДО');p.drawText(self.width()-65,23,'ПОСЛЕ');p.end()

class AdjustmentDialog(QDialog):
    def __init__(self,owner):
        super().__init__(owner);self.owner=owner;self.c=owner.canvas;self._shown_parameters=None;self.reduce_motion=getattr(owner,"reduce_motion",False)
        self.setWindowTitle('Коррекция и фильтры · DOGFORST');self.resize(980,650);self.setMinimumSize(780,550)
        root=QVBoxLayout(self);label=QLabel('Предпросмотр из исходника. Применение — одно действие Undo. Текст, фигура и фото после изменения становятся пикселями; Ctrl+Z возвращает исходник.');label.setWordWrap(True);root.addWidget(label)
        split=QSplitter();root.addWidget(split,1);left=QWidget();layout=QVBoxLayout(left);layout.setContentsMargins(0,0,8,0);split.addWidget(left)
        self.presets=QComboBox();s=self.c.adjustment_session
        for name in PRESETS:
            if not s.data.mask_only or name in ('Без коррекции','Выразительный','Негатив'):self.presets.addItem(name)
        self.presets.setPlaceholderText('Свои параметры');layout.addWidget(QLabel('Цветовые пресеты'));layout.addWidget(self.presets);self.presets.activated.connect(self.apply_preset)
        tabs=QTabWidget();layout.addWidget(tabs,1);self.fields={};self.sliders={};self.forms={}
        for title in ('Свет','Цвет','Фильтр'):
            page=QWidget();form=QFormLayout(page);form.setSpacing(15);form.setContentsMargins(10,16,10,12);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(page);tabs.addTab(scroll,title);self.forms[title]=form
        for key,title,lo,hi,tab in [('brightness','Яркость',-100,100,'Свет'),('contrast','Контраст',-100,100,'Свет'),('gamma','Гамма × 100',25,300,'Свет'),('saturation','Насыщенность',-100,100,'Цвет'),('hue','Оттенок, °',-180,180,'Цвет'),('temperature','Теплота',-100,100,'Цвет'),('tint','Зелёный / пурпурный',-100,100,'Цвет')]:self.add_field(key,title,lo,hi,tab)
        self.checks={}
        for key,title in [('grayscale','Чёрно-белый'),('invert','Инверсия цветов'),('sepia','Сепия')]:
            box=QCheckBox(title);box.toggled.connect(lambda v,k=key:self.change(k,v));self.forms['Цвет'].addRow(box);self.checks[key]=box
        self.effects=QComboBox()
        for key,(name,*_) in EFFECTS.items():self.effects.addItem(name,key)
        self.effects.currentIndexChanged.connect(self.change_effect);self.forms['Фильтр'].addRow('Эффект',self.effects)
        self.add_field('amount','Параметр фильтра',0,100,'Фильтр');self.add_field('strength','Общая сила, %',0,100,'Фильтр')
        info=QLabel('Фильтры сохраняют альфа-канал. Шум повторяемый; изменения рассчитываются заново из исходника. Коррекция ограничена выбранным слоем/маской и выделением.');info.setWordWrap(True);self.forms['Фильтр'].addRow(info)
        self.original=QCheckBox('Показать оригинал на холсте');self.original.toggled.connect(self.c.show_adjustment_original);layout.addWidget(self.original)
        reset=QPushButton('Сбросить всё');reset.clicked.connect(lambda:self.c.update_adjustment(**DEFAULT_ADJUSTMENT));layout.addWidget(reset)
        right=QWidget();rv=QVBoxLayout(right);rv.setContentsMargins(8,0,0,0);split.addWidget(right);self.preview=ComparisonPreview(self.c);rv.addWidget(self.preview,1)
        compare=AnimatedSlider(Qt.Orientation.Horizontal);compare.setRange(0,100);compare.setValue(50);compare.valueChanged.connect(self.move_divider);compare.setToolTip('Переместите границу сравнения До / После');rv.addWidget(QLabel('Сравнение До / После'));rv.addWidget(compare)
        row=QHBoxLayout();self.background=QComboBox();self.background.addItems(['Светлая шахматка','Тёмная шахматка']);self.background.currentIndexChanged.connect(self.background_changed);row.addWidget(self.background)
        self.crop=QCheckBox('Приблизить выделение');self.crop.setChecked(True);self.crop.setEnabled(bool(s.data.bounds));self.crop.toggled.connect(self.crop_changed);row.addWidget(self.crop);rv.addLayout(row);split.setSizes([390,550])
        self.status=QLabel();self.status.setWordWrap(True);root.addWidget(self.status);self.progress=QProgressBar();self.progress.setRange(0,100);root.addWidget(self.progress)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Apply|QDialogButtonBox.StandardButton.Cancel);self.apply=buttons.button(QDialogButtonBox.StandardButton.Apply);self.apply.setText('Применить');self.apply.setDefault(True);self.apply.clicked.connect(self.c.apply_adjustment);buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена · Esc');buttons.rejected.connect(self.reject);root.addWidget(buttons)
        self.c.adjustmentChanged.connect(self.refresh);self.c.adjustmentFinished.connect(self.finished_preview);self.refresh()
        if s.data.mask_only:
            for k in ('saturation','hue','temperature','tint'):self.fields[k].setEnabled(False);self.sliders[k].setEnabled(False)
            self.checks['grayscale'].setEnabled(False);self.checks['sepia'].setEnabled(False)
    def add_field(self,key,title,lo,hi,tab):
        row=QHBoxLayout();slider=AnimatedSlider(Qt.Orientation.Horizontal);slider.setRange(lo,hi);spin=QSpinBox();spin.setRange(lo,hi);spin.setMinimumWidth(72);row.addWidget(slider,1);row.addWidget(spin);self.forms[tab].addRow(title,row);self.fields[key]=spin;self.sliders[key]=slider
        if key=='amount':self.amount_label=self.forms[tab].labelForField(row)
        slider.valueChanged.connect(lambda v,k=key:self.change(k,v));spin.valueChanged.connect(lambda v,k=key:self.change(k,v))
    def change(self,key,value):
        self.c.update_adjustment(**{key:value})
    def change_effect(self,index):
        key=self.effects.itemData(index)
        if key:self.c.update_adjustment(effect=key,amount=EFFECTS[key][3])
    def apply_preset(self,index):
        self.c.update_adjustment(**dict(DEFAULT_ADJUSTMENT,**PRESETS[self.presets.itemText(index)]))
    def move_divider(self,value):self.preview.split=value;self.preview.update()
    def background_changed(self,index):self.preview.dark=bool(index);self.preview.update()
    def crop_changed(self,value):self.preview.crop=value;self.preview.update()
    def refresh(self):
        s=self.c.adjustment_session
        if s is None:return
        p=s.parameters
        if p!=self._shown_parameters:
            self._shown_parameters=dict(p)
            key=p['effect'];lo,hi=EFFECTS[key][1:3]
            self.amount_label.setText({'none':'Параметр фильтра','blur':'Радиус, px','sharpen':'Усиление, %','pixelate':'Блок, px','posterize':'Число уровней','noise':'Количество, %','vignette':'Затемнение, %'}[key])
            match=next((name for name,value in PRESETS.items() if dict(DEFAULT_ADJUSTMENT,**value)==p),None)
            with QSignalBlocker(self.presets):self.presets.setCurrentIndex(self.presets.findText(match) if match else -1)
            for widget in (self.fields['amount'],self.sliders['amount']):
                with QSignalBlocker(widget):widget.setRange(lo,hi)
                widget.setEnabled(key!='none')
            for key,spin in self.fields.items():
                with QSignalBlocker(spin):spin.setValue(p[key])
                with QSignalBlocker(self.sliders[key]):self.sliders[key].setValue(p[key])
            for key,box in self.checks.items():
                with QSignalBlocker(box):box.setChecked(p[key])
            with QSignalBlocker(self.effects):self.effects.setCurrentIndex(self.effects.findData(p['effect']))
        pending=s.rendered_version!=s.version;self.apply.setEnabled(not s.error and not s.apply_requested);self.progress.setValue(s.progress);self.progress.setVisible(pending and not s.error)
        self.status.setText(s.error or ('Обработка… '+str(s.progress)+' %. Esc отменяет весь предпросмотр.' if pending else 'Предпросмотр готов. Сравните До / После и нажмите «Применить».'))
        self.preview.update()
    def finished_preview(self,accepted):
        if accepted:super().accept()
        else:super().reject()
    def reject(self):
        if not self.c.cancel_adjustment():super().reject()
    def accept(self):self.c.apply_adjustment()
