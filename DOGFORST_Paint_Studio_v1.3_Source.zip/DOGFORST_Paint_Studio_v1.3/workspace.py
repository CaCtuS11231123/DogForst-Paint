"""Recoverable dock layout, transparency display and workspace commands."""
from PySide6.QtCore import Qt,QTimer,QByteArray
from PySide6.QtGui import QColor,QPixmap,QIcon,QPainter,QPen
from PySide6.QtWidgets import QDockWidget,QToolBar,QMenu,QColorDialog,QMessageBox
from layers import Layer,transparent_image

class WorkspaceMixin:
    def configure_workspace(self):
        for dock in self.findChildren(QDockWidget):
            dock.setObjectName(dock.windowTitle())
            if dock.toggleViewAction() not in self.panels_menu.actions():self.panels_menu.addAction(dock.toggleViewAction())
        for i,toolbar in enumerate(self.findChildren(QToolBar)):toolbar.setObjectName('dogforst_toolbar_'+str(i))
        self._default_dock_state=self.saveState(55)
        self.canvas.workspaceMenuRequested.connect(self.show_workspace_menu)
        self.layer_list.backgroundDoubleClicked.connect(self.show_workspace_menu)
        state=self.settings.value('workspace/layout_055')
        if isinstance(state,QByteArray) and not state.isEmpty():self.restoreState(state,55)
    def restore_default_layout(self):
        self.canvas.cancel_pending_preview()
        for dock in self.findChildren(QDockWidget):dock.setFloating(False)
        self.restoreState(self._default_dock_state,55)
        for dock in (self.tools_dock,self.layers_dock,self.color_dock,self.history_dock):dock.show()
        self.color_dock.raise_();self.resizeDocks([self.tools_dock,self.color_dock],[293,370],Qt.Orientation.Horizontal)
        self.resizeDocks([self.layers_dock,self.color_dock],[410,300],Qt.Orientation.Vertical)
        self.settings.remove('workspace/layout_055');self.statusBar().showMessage('Панели возвращены на исходные места.',5000)
    def persist_workspace(self):self.settings.setValue('workspace/layout_055',self.saveState(55));self.settings.sync()
    def transparency_icon(self):
        pix=QPixmap(24,24);pix.fill(Qt.GlobalColor.transparent);p=QPainter(pix)
        for y in range(2,22,5):
            for x in range(2,22,5):p.fillRect(x,y,5,5,QColor('#35445b' if ((x-2)//5+(y-2)//5)%2 else '#e4ecf5'))
        p.setPen(QPen(QColor('#82a5ce'),1));p.drawRect(2,2,20,20);p.end();return QIcon(pix)
    def transparency_menu(self):
        menu=QMenu('Фон прозрачности',self)
        for label,key in [('Светлая шахматка','light'),('Тёмная шахматка','dark')]:
            action=menu.addAction(label);action.setData(key);action.setCheckable(True);action.setChecked(self.canvas.show_checkerboard and self.canvas.checker_style==key);action.triggered.connect(lambda checked=False,k=key:self.set_checker_style(k))
        note=menu.addAction('Подложка не попадает в экспорт');note.setEnabled(False);return menu
    def show_workspace_menu(self,point):
        previous=getattr(self,'_workspace_popup',None)
        if previous is not None:
            try:previous.close()
            except RuntimeError:pass
        menu=self.workspace_menu();self._workspace_popup=menu;menu.aboutToHide.connect(menu.deleteLater);menu.popup(point)
    def workspace_menu(self):
        menu=QMenu(self);menu.addAction('Новый прозрачный слой',self.canvas.add_layer);menu.addAction('Добавить слой фона…',self.add_background)
        action=menu.addAction('Дублировать выбранные слои',lambda:self.run_canvas_action(self.canvas.duplicate_layer));action.setEnabled(bool(self.canvas.selected_layer_ids()))
        menu.addSeparator();menu.addAction('Добавить фото…',self.import_layer);menu.addAction('Создать новый холст…',self.new_document);menu.addSeparator();menu.addMenu(self.transparency_menu());menu.addAction('Вернуть панели на места',self.restore_default_layout);return menu
    def add_background(self):
        color=QColorDialog.getColor(QColor('#ffffff'),self,'Цвет нового слоя фона')
        if color.isValid():self.run_canvas_action(self.create_background,color)
    def create_background(self,color):
        c=self.canvas
        if not c.can_insert(None):return
        if (len(c.layers)+len(c.masks)+1)*c.doc_size[0]*c.doc_size[1]+c.source_pixels()>120_000_000:raise ValueError('Недостаточно памяти для нового слоя фона.')
        image=transparent_image(*c.doc_size);image.fill(color);layer=Layer('Фон',image);c.push_history();c.layers.insert(0,layer);c.layer_stack.insert(0,layer.id);c.set_selected_nodes({layer.id},layer.id);c.changed.emit();c.update()
