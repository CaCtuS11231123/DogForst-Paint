"""Preview connected color removal, then apply it as a single edit."""

import numpy as np
from PySide6.QtCore import Qt, QRectF, QThreadPool, QTimer, Signal
from PySide6.QtGui import QColor, QImage, QPainter, QPixmap
from PySide6.QtWidgets import (
    QCheckBox, QDialog, QDialogButtonBox, QHBoxLayout, QLabel, QPushButton,
    QSpinBox, QVBoxLayout, QWidget,
)

from selection_tools import SelectionJob, gray_array, wand_mask


def cut_background(source, seeds, tolerance, connected, cancelled):
    removed = np.zeros((source.height(), source.width()), dtype=bool)
    for x, y in seeds:
        mask = wand_mask(source, x, y, tolerance, connected, cancelled)
        if mask is None:
            return None
        image, coverage = gray_array(mask)
        removed |= coverage != 0
    if cancelled.is_set():
        return None
    result = source.convertToFormat(QImage.Format.Format_RGBA8888)
    pixels = np.frombuffer(result.bits(), np.uint8).reshape(
        result.height(), result.bytesPerLine())[:, :result.width() * 4]
    pixels.reshape(result.height(), result.width(), 4)[removed] = 0
    return result.convertToFormat(QImage.Format.Format_ARGB32)


class BackgroundPreview(QWidget):
    picked = Signal(int, int, bool)

    def __init__(self, source):
        super().__init__()
        self.source = source
        self.preview = source
        self.setMinimumSize(420, 290)
        self.setCursor(Qt.CursorShape.CrossCursor)
        self.checker = QPixmap(24, 24)
        self.checker.fill(QColor('#eef1f6'))
        painter = QPainter(self.checker)
        painter.fillRect(12, 0, 12, 12, QColor('#c2c9d4'))
        painter.fillRect(0, 12, 12, 12, QColor('#c2c9d4'))
        painter.end()

    def image_rect(self):
        size = self.source.size().scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio)
        rect = QRectF(0, 0, max(1, size.width()), max(1, size.height()))
        rect.moveCenter(QRectF(self.rect()).center())
        return rect

    def paintEvent(self, event):
        painter = QPainter(self)
        rect = self.image_rect()
        painter.setClipRect(rect)
        painter.drawTiledPixmap(rect.toAlignedRect(), self.checker)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        painter.drawImage(rect, self.preview, QRectF(self.preview.rect()))
        painter.end()

    def mousePressEvent(self, event):
        rect = self.image_rect()
        point = event.position()
        if event.button() == Qt.MouseButton.LeftButton and rect.contains(point):
            x = int((point.x() - rect.left()) * self.source.width() / rect.width())
            y = int((point.y() - rect.top()) * self.source.height() / rect.height())
            if 0 <= x < self.source.width() and 0 <= y < self.source.height():
                self.picked.emit(x, y, bool(event.modifiers() & Qt.KeyboardModifier.ShiftModifier))


class BackgroundCutDialog(QDialog):
    def __init__(self, source, tolerance, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Вырезать фон')
        self.resize(680, 540)
        self.source = QImage(source)
        self.result = None
        self.seeds = []
        self.job = None
        self.revision = 0
        layout = QVBoxLayout(self)
        hint = QLabel('Нажмите на фон. Shift + клик добавляет участок. Шахматка показывает прозрачность.')
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.preview = BackgroundPreview(self.source)
        layout.addWidget(self.preview, 1)
        self.preview.picked.connect(self.pick)
        row = QHBoxLayout()
        row.addWidget(QLabel('Допуск'))
        self.tolerance = QSpinBox()
        self.tolerance.setRange(0, 255)
        self.tolerance.setValue(tolerance)
        row.addWidget(self.tolerance)
        self.connected = QCheckBox('Только соседние пиксели')
        self.connected.setChecked(True)
        row.addWidget(self.connected)
        reset = QPushButton('Сбросить точки')
        reset.clicked.connect(self.reset)
        row.addWidget(reset)
        layout.addLayout(row)
        self.status = QLabel('Выберите участок фона.')
        layout.addWidget(self.status)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.apply = buttons.button(QDialogButtonBox.StandardButton.Ok)
        self.apply.setText('Удалить фон')
        self.apply.setEnabled(False)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(120)
        self.timer.timeout.connect(self.start_preview)
        self.connected.toggled.connect(self.schedule_preview)
        self.tolerance.valueChanged.connect(self.schedule_preview)
        self.finished.connect(self.stop_preview)

    def pick(self, x, y, add):
        if not add:
            self.seeds.clear()
        if (x, y) not in self.seeds:
            if len(self.seeds) >= 16:
                self.status.setText('Выбрано 16 участков. Сбросьте точки для нового выделения.')
                return
            self.seeds.append((x, y))
        self.schedule_preview()

    def reset(self):
        self.seeds.clear()
        self.schedule_preview()

    def schedule_preview(self):
        self.revision += 1
        self.result = None
        self.apply.setEnabled(False)
        if self.job is not None:
            self.job.cancelled.set()
        if self.seeds:
            self.status.setText('Пересчёт предпросмотра…')
            self.timer.start()
        else:
            self.timer.stop()
            self.preview.preview = self.source
            self.preview.update()
            self.status.setText('Выберите участок фона.')

    def start_preview(self):
        if self.job is not None or not self.seeds:
            return
        self.job_revision = self.revision
        self.job = SelectionJob(cut_background, (
            self.source, tuple(self.seeds), self.tolerance.value(), self.connected.isChecked()))
        self.job.signals.done.connect(self.finish_preview)
        QThreadPool.globalInstance().start(self.job)

    def finish_preview(self, job, result, error):
        if self.job is not job:
            return
        self.job = None
        if self.job_revision != self.revision or job.cancelled.is_set():
            if self.isVisible() and self.seeds and not self.timer.isActive():
                self.start_preview()
            return
        if error:
            self.status.setText(error)
            return
        if result is not None:
            self.preview.preview = result
            self.preview.update()
            if result != self.source:
                self.result = result
                self.apply.setEnabled(True)
                self.status.setText('Проверьте края объекта и нажмите «Удалить фон».')
            else:
                self.status.setText('Здесь уже прозрачно. Выберите другой участок.')

    def stop_preview(self, result):
        self.timer.stop()
        if self.job is not None:
            self.job.cancelled.set()
