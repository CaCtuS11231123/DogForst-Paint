"""Gradient rendering and cancellable preview transactions; no document mutation before Apply."""
import math,threading,uuid,copy
from dataclasses import dataclass
from PySide6.QtCore import Qt,QPointF,QRectF,QObject,QRunnable,Signal,QTimer,QThreadPool
from PySide6.QtGui import QImage,QColor,QPainter,QPen,QLinearGradient,QRadialGradient
from layers import Layer
from selection_tools import blend_selection

DEFAULT_GRADIENT=dict(kind='linear',opacity=100,stops=[(0.,'#ff42b8cf'),(1.,'#ff8960db')])

def validate_gradient(p):
    if p.get('kind') not in ('linear','radial'):raise ValueError('Неизвестный вид градиента.')
    for key in ('x1','y1','x2','y2','opacity'):
        v=p[key]
        if isinstance(v,bool) or not isinstance(v,(float,int)) or not math.isfinite(v):raise ValueError('Некорректный параметр градиента.')
    if not 0<=p['opacity']<=100 or any(abs(p[k])>100000 for k in ('x1','y1','x2','y2')):raise ValueError('Параметры вне допустимых границ.')
    stops=p['stops']
    if not isinstance(stops,(list,tuple)) or not 2<=len(stops)<=16:raise ValueError('Нужно от 2 до 16 цветовых точек.')
    checked=[]
    for entry in stops:
        if not isinstance(entry,(list,tuple)) or len(entry)!=2:raise ValueError("Некорректная цветовая точка.")
        at,value=entry
        if not isinstance(value,str):raise ValueError("Некорректный цвет точки.")
        if isinstance(at,bool) or not isinstance(at,(int,float)) or not math.isfinite(at) or not 0<=at<=1:raise ValueError('Позиция точки должна быть от 0 до 100%.')
        c=QColor(value)
        if not c.isValid():raise ValueError('Некорректный цвет точки.')
        checked.append((float(at),c.name(QColor.NameFormat.HexArgb)))
    checked.sort()
    if any(b[0]-a[0]<.00001 for a,b in zip(checked,checked[1:])):raise ValueError('Цветовые точки должны иметь разные позиции.')
    return dict(p,stops=checked)

def gradient_brush(p,mask_only=False):
    a=QPointF(p['x1'],p['y1']);b=QPointF(p['x2'],p['y2'])
    g=QLinearGradient(a,b) if p['kind']=='linear' else QRadialGradient(a,max(.001,math.hypot(b.x()-a.x(),b.y()-a.y())))
    for at,value in p['stops']:
        c=QColor(value)
        if mask_only:
            gray=round(.299*c.red()+.587*c.green()+.114*c.blue());c=QColor(gray,gray,gray,c.alpha())
        g.setColorAt(at,c)
    return g

@dataclass(frozen=True)
class GradientInput:
    raw:object
    coverage:object=None
    bounds:object=None
    alpha_locked:bool=False
    mask_only:bool=False

def render_gradient(data,parameters,cancelled):
    p=validate_gradient(parameters)
    if cancelled.is_set():return None
    result=QImage(data.raw);bounds=(data.bounds or QRectF(data.raw.rect())).toAlignedRect().intersected(data.raw.rect())
    if math.hypot(p['x2']-p['x1'],p['y2']-p['y1'])<.01: return result
    g=gradient_brush(p,data.mask_only)
    painter=QPainter(result)
    try:
        painter.setOpacity(p['opacity']/100)
        if data.alpha_locked and not data.mask_only:painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceAtop)
        for y in range(bounds.top(),bounds.bottom()+1,256):
            if cancelled.is_set():return None
            painter.fillRect(bounds.x(),y,bounds.width(),min(256,bounds.bottom()-y+1),g)
    finally:painter.end()
    if data.coverage is not None:
        # Strip blending caps temporary numpy buffers, while preserving exact pixels outside coverage.
        for y in range(bounds.top(),bounds.bottom()+1,256):
            if cancelled.is_set():return None
            tile=QRectF(bounds.x(),y,bounds.width(),min(256,bounds.bottom()-y+1))
            blend_selection(data.raw,result,data.coverage,tile,target=result)
    return None if cancelled.is_set() else result

class GradientSignals(QObject):done=Signal(object,object,str)
class GradientJob(QRunnable):
    def __init__(self,session):
        super().__init__();self.uid=session.uid;self.version=session.version;self.data=session.data;self.parameters=copy.deepcopy(session.parameters);self.cancelled=threading.Event();self.signals=GradientSignals()
    def run(self):
        try:self.signals.done.emit(self,render_gradient(self.data,self.parameters,self.cancelled),'')
        except Exception as e:self.signals.done.emit(self,None,'Недостаточно памяти для градиента.' if isinstance(e,MemoryError) else str(e))

class GradientSession:
    def __init__(self,node_id,mask_id,stamp,data,parameters):
        self.uid=uuid.uuid4().hex;self.node_id=node_id;self.mask_id=mask_id;self.stamp=stamp;self.data=data;self.parameters=parameters
        self.version=0;self.rendered_version=-1;self.result=None;self.error='';self.apply_requested=False;self.drag=None

class GradientMixin:
    def init_gradient(self):
        self.gradient_session=None;self.gradient_options=copy.deepcopy(DEFAULT_GRADIENT);self._gradient_job=None
        self._gradient_timer=QTimer(self);self._gradient_timer.setSingleShot(True);self._gradient_timer.setInterval(20);self._gradient_timer.timeout.connect(self.launch_gradient_job)
    def cancel_pending_preview(self):
        return self.cancel_adjustment() or self.cancel_retouch() or self.cancel_gradient() or self.cancel_selection_transform()
    def preview_context(self):
        if self.adjustment_session is not None:return self.adjustment_context()
        if self.retouch_session is not None:return self.retouch_context()
        s=self.gradient_session
        if s is None:return self.selection_transform_context()
        if s.result is None:return self.layers,self.text_objects,self.masks
        if s.mask_id:
            masks=dict(self.masks);masks[s.mask_id]=s.result;return self.layers,self.text_objects,masks
        layers=[Layer(l.name,QImage(s.result),l.visible,l.opacity,l.id,'raster',**l.flags()) if l.id==s.node_id else l for l in self.layers]
        return layers,[t for t in self.text_objects if t.get('layer_id')!=s.node_id],self.masks
    def start_gradient(self,start,end=None):
        if self.adjustment_session is not None or self.retouch_session is not None or self.selection_transform is not None or self.drawing or self.fill_job is not None or self.wand_job is not None:return False
        if self.gradient_session is not None:return True
        if self._lasso_points:return False
        mask_id=self.editing_mask if self.editing_mask in self.masks else None
        if mask_id is None and (len(self.selected_node_ids())!=1 or self.control_node().kind=='group'):
            self.status.emit('Для градиента выберите один слой или маску.');return False
        node=self.node(mask_id) if mask_id else self.active
        allowed=self.can_edit_mask(mask_id) if mask_id else self.can_edit()
        if not allowed:return False
        raw=QImage(self.masks[mask_id]) if mask_id else self.raw_pixels(node)
        p=validate_gradient(dict(self.gradient_options,x1=start.x(),y1=start.y(),x2=(end or start+QPointF(1,0)).x(),y2=(end or start+QPointF(1,0)).y()))
        data=GradientInput(raw,self.selection_coverage() if self.selection else None,QRectF(self.selection) if self.selection else None,bool(node.alpha_locked) if not mask_id else False,bool(mask_id))
        self.gradient_session=GradientSession(node.id,mask_id,self.selection_stamp(),data,p)
        self.gradientChanged.emit();self._gradient_timer.start();self.update();self.status.emit('Градиент: потяните концы линии, настройте цвета · Enter — применить · Esc — отменить');return True
    def update_gradient(self,**values):
        s=self.gradient_session
        base=s.parameters if s else dict(self.gradient_options,x1=0.,y1=0.,x2=100.,y2=0.)
        p=validate_gradient(dict(base,**values));self.gradient_options={k:copy.deepcopy(p[k]) for k in ('kind','opacity','stops')}
        if s is not None and p!=s.parameters:
            s.parameters=p;s.version+=1;s.error='';s.apply_requested=False;self._gradient_timer.start();self.update()
        self.gradientChanged.emit()
    def launch_gradient_job(self):
        s=self.gradient_session
        if s is None or self._gradient_job is not None or s.rendered_version==s.version:return
        job=GradientJob(s);self._gradient_job=job;job.signals.done.connect(self.finish_gradient_job);QThreadPool.globalInstance().start(job)
    def finish_gradient_job(self,job,result,error):
        if job is not self._gradient_job:return
        self._gradient_job=None;s=self.gradient_session
        if s is None:return
        if s.uid!=job.uid or s.version!=job.version:self.launch_gradient_job();return
        if error:s.error=error;s.apply_requested=False;self.status.emit(error)
        elif result is not None:s.result=result;s.rendered_version=s.version;self.update()
        self.gradientChanged.emit()
        if not error and s.apply_requested:self.apply_gradient()
    def cancel_gradient(self):
        if self.gradient_session is None:return False
        self.gradient_session=None;self._gradient_timer.stop()
        if self._gradient_job is not None:self._gradient_job.cancelled.set()
        self.gradientChanged.emit();self.update();self.status.emit('Градиент отменён. Исходный слой сохранён.');return True
    def apply_gradient(self):
        s=self.gradient_session
        if s is None:return False
        if self.selection_stamp()!=s.stamp or self.control_node().id!=s.node_id or self.editing_mask!=s.mask_id:
            self.cancel_gradient();self.status.emit('Документ изменился: предпросмотр градиента отменён.');return False
        if s.error:return False
        if s.rendered_version!=s.version or s.result is None:s.apply_requested=True;self.launch_gradient_job();return False
        if s.result==s.data.raw:self.cancel_gradient();return True
        self.gradient_session=None;self._gradient_timer.stop();self.push_history()
        if s.mask_id:self.masks[s.mask_id]=QImage(s.result)
        else:
            node=self.node(s.node_id);node.image=QImage(s.result);node.kind='raster'
            self.text_objects=[t for t in self.text_objects if t.get('layer_id')!=s.node_id];self.selected_text=-1;self.textSelected.emit(-1)
        self.changed.emit();self.gradientChanged.emit();self.update();self.status.emit('Градиент применён · Ctrl+Z — отменить');return True
    def gradient_handles(self):
        s=self.gradient_session
        if s is None:return {}
        p=s.parameters;return {'a':self.screen_point(QPointF(p['x1'],p['y1'])),'b':self.screen_point(QPointF(p['x2'],p['y2']))}
    def gradient_press(self,screen,pos):
        s=self.gradient_session;key=self.handle_at(screen,self.gradient_handles())
        if key:s.drag=key
    def gradient_move(self,pos,modifiers):
        s=self.gradient_session
        if s is None or s.drag is None:return
        n='1' if s.drag=='a' else '2';other='2' if n=='1' else '1';p=s.parameters
        if modifiers&Qt.KeyboardModifier.ShiftModifier:
            dx=pos.x()-p['x'+other];dy=pos.y()-p['y'+other];length=math.hypot(dx,dy);angle=round(math.atan2(dy,dx)/(math.pi/12))*math.pi/12
            pos=QPointF(p['x'+other]+length*math.cos(angle),p['y'+other]+length*math.sin(angle))
        self.update_gradient(**{'x'+n:max(-100000,min(100000,pos.x())),'y'+n:max(-100000,min(100000,pos.y()))})
    def paint_gradient(self,painter):
        s=self.gradient_session
        if s is None:return
        h=self.gradient_handles();painter.save()
        for color,width in [('#101827',4),('#b5e8ff',1.5)]:painter.setPen(QPen(QColor(color),width));painter.drawLine(h['a'],h['b'])
        self._paint_handles(painter,h)
        p=s.parameters;angle=math.degrees(math.atan2(p['y2']-p['y1'],p['x2']-p['x1']));self._overlay_label(painter,h['b']+QPointF(0,25),f'Градиент · {angle:.1f}° · Enter — применить · Esc — отменить');painter.restore()
