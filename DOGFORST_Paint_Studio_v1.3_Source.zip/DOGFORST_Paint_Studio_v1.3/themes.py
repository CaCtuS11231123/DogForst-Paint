from PySide6.QtCore import Qt, QSize, QRectF
from PySide6.QtGui import QPixmap, QPainter, QColor, QPen, QIcon, QLinearGradient
from PySide6.QtWidgets import QDialog, QVBoxLayout, QGridLayout, QLabel, QToolButton, QDialogButtonBox, QButtonGroup, QScrollArea, QWidget, QCheckBox, QPushButton, QHBoxLayout

# bg, fg, panel, selection, control, accent, canvas
THEMES = {
    'Light': ('#f2f5fb','#1c2940','#e6ecf6','#cfdef6','#ffffff','#286de0','#d4deed'),
    'Dark': ('#202632','#e8efff','#181e29','#354866','#2a3446','#82baff','#121722'),
    'Neon': ('#171428','#f0eaff','#100e1c','#44346c','#24203c','#9b8bff','#0e0c19'),
    'Soft': ('#f4eff5','#493f59','#eae2ef','#ddd1eb','#fffafd','#8264ac','#dfd7e6'),
    'Графит': ('#292929','#f2f2f2','#1d1d1d','#4b4b4b','#383838','#b8b8b8','#181818'),
    'Океан': ('#102b36','#e3fbff','#0b2029','#17657a','#17404c','#55d9ed','#071b24'),
    'Фиолетовая': ('#261e35','#f4eaff','#1b1428','#674a91','#382b4d','#c4a1ff','#160e22'),
    'Midnight': ('#111d30','#edf3ff','#0b1321','#243f62','#1a2b45','#70b8ff','#080f1c'),
    'Mint': ('#eaf5ef','#173b32','#dbece3','#b9dbcb','#f8fffb','#247b62','#cdded4'),
    'Rose': ('#fbf0f3','#533342','#f1dfe6','#e7c7d4','#fffbfd','#af5277','#e8d6df'),
    'Sunset': ('#30202a','#fff0df','#231820','#68404b','#422c35','#ffb06b','#1c1219'),
    'Nord': ('#2e3440','#eceff4','#242a35','#434f63','#394352','#88c0d0','#1d2430'),
    'Paper': ('#f7f2e7','#413b30','#eae2d2','#d7cbb5','#fffcf5','#8c7043','#ddd5c5'),
    'AMOLED': ('#08090d','#e9effa','#000000','#242a39','#141821','#90b7ff','#000000'),
    'Перламутр': ('#202832','#e7edf2','#1a222c','#3a4655','#293442','#a7b7c8','#202832'),
    'Аврора': ('#202a36','#e5f1f2','#18232f','#384c5b','#293845','#9bc6c3','#202a36'),
    'Lavender': ('#eeecfa','#35304e','#dfdaf1','#c9bfe5','#fcfaff','#7855bf','#d5d0e7'),

}


def theme_stylesheet(colors,font_points=10):
    bg, fg, panel, selection, control, accent, canvas = colors
    disabled = '#87929e' if QColor(bg).lightness()<128 else '#737b85'
    return f'''
    QWidget {{ background: {bg}; color: {fg}; font-family: 'Segoe UI'; font-size: {font_points}pt; }}
    QMenuBar, QToolBar, QStatusBar {{ background: {panel}; padding: 5px; }}
    QToolBar {{ border: 0; spacing: 6px; padding: 6px; }}
    QMenu {{ background: {control}; border: 1px solid {selection}; padding: 5px; }}
    QMenu::item:selected, QMenuBar::item:selected {{ background: {selection}; border-radius: 5px; }}
    QDockWidget::title {{ background: {panel}; padding: 10px; font-weight: 600; }}
    QPushButton, QToolButton, QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit, QTextEdit, QFontComboBox {{
        background: {control}; border: 1px solid {selection}; border-radius: 8px; padding: 6px; color: {fg}; }}
    QPushButton:disabled, QToolButton:disabled, QComboBox:disabled, QFontComboBox:disabled,
    QSpinBox:disabled, QDoubleSpinBox:disabled, QLineEdit:disabled, QTextEdit:disabled,
    QPlainTextEdit:disabled, QLineEdit:read-only, QTextEdit:read-only,
    QSpinBox[readOnly="true"], QDoubleSpinBox[readOnly="true"] {{
        background: #161c26; color: #aab6c8; border: 1px solid #445166; }}
    QCheckBox:disabled, QLabel:disabled {{ color: #8492a8; }}
    QSlider::groove:horizontal:disabled {{ background: #161c26; border: 1px solid #445166; }}
    QSlider::sub-page:horizontal:disabled {{ background: #323e50; }}
    QSlider::handle:horizontal:disabled {{ background: #66748a; border: 1px solid #445166; }}
    QPushButton:hover:enabled, QToolButton:hover:enabled {{ border-color: {accent}; }}
    QPushButton:pressed:enabled, QToolButton:checked:enabled {{ background: {selection}; border-color: {accent}; }}
    QComboBox QAbstractItemView {{ background: {control}; color: {fg}; selection-background-color: {selection}; }}
    QListWidget {{ background: {panel}; border: 1px solid {selection}; border-radius: 8px; }}
    QListWidget::item {{ padding: 9px; border-radius: 6px; }}
    QListWidget::item:selected {{ background: {selection}; color: {fg}; }}
    QSlider::groove:horizontal {{ height: 5px; background: {selection}; border-radius: 2px; }}
    QSlider::sub-page:horizontal {{ background: {accent}; border-radius: 2px; }}
    QSlider::handle:horizontal {{ background: {accent}; width: 14px; margin: -5px 0; border-radius: 7px; }}
    QToolTip {{ color: {fg}; background: {control}; border: 1px solid {accent}; padding: 6px; }}
    QTabBar::tab {{ background: {panel}; padding: 8px; }}
    QTabBar::tab:selected {{ background: {selection}; }}
    '''


def theme_preview(name):
    bg,fg,panel,selection,control,accent,canvas = THEMES[name]
    pix = QPixmap(278,136); pix.fill(QColor(bg))
    p = QPainter(pix); p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.fillRect(0,0,278,23,QColor(panel)); p.fillRect(6,30,28,99,QColor(panel))
    p.fillRect(220,30,52,99,QColor(panel)); p.fillRect(42,30,170,99,QColor(canvas))
    if name in ('Перламутр','Аврора'):
        gradient=QLinearGradient(42,30,212,129);gradient.setColorAt(0,QColor('#30434b'));gradient.setColorAt(1,QColor('#3d354e'));p.fillRect(42,30,170,99,gradient)
    p.fillRect(59,42,136,75,QColor('#ffffff'))
    p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor(accent));p.drawRoundedRect(QRectF(11,36,18,18),5,5)
    p.setPen(QPen(QColor(accent),6,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap))
    p.drawLine(85,92,117,64);p.drawLine(117,64,165,92)
    if name == 'Neon':
        p.setPen(QPen(QColor('#42cfff'),3));p.drawEllipse(QRectF(121,60,35,35))
    p.setPen(QColor(fg));p.drawText(12,16,'DOGFORST');p.setPen(Qt.PenStyle.NoPen)
    for y in (39,64,89):
        p.setBrush(QColor(selection));p.drawRoundedRect(QRectF(226,y,40,17),4,4)
    p.end();return pix


class ThemeDialog(QDialog):
    def __init__(self,current,parent=None):
        super().__init__(parent);self.setWindowTitle('Темы DOGFORST');self.resize(840,740)
        self.selected=current;root=QVBoxLayout(self)
        title=QLabel('Твоя студия. Твоё настроение.');title.setStyleSheet('font-size:21px;font-weight:600;padding:8px;');root.addWidget(title)
        root.addWidget(QLabel(f'{len(THEMES)} тем, включая классические. Выберите карточку и нажмите «Применить».'))
        self.motion=QCheckBox('Мягкий перелив: «Перламутр» и «Аврора» (можно выключить)')
        self.motion.setChecked(parent.settings.value('theme/motion',True,type=bool) if parent is not None and hasattr(parent,'settings') else True)
        root.addWidget(self.motion)
        from readability import THEME_NOTICE
        self.reduce_check=QCheckBox('Уменьшить движение: без переливов, переходов и бегущей рамки')
        self.large_check=QCheckBox('Крупный текст интерфейса')
        self.contrast_check=QCheckBox('Высокий контраст интерфейса')
        for control,key in [(self.reduce_check,'reduce_motion'),(self.large_check,'large_text'),(self.contrast_check,'contrast')]:
            control.setChecked(parent.settings.value('readability/'+key,False,type=bool) if parent is not None and hasattr(parent,'settings') else False)
            root.addWidget(control)
        self.reduce_motion=self.reduce_check.isChecked();self.ui_scale=1.2 if self.large_check.isChecked() else 1.
        presets=QHBoxLayout()
        for text,callback in [('Комфорт для глаз',self.comfort_preset),('Крупнее текст',lambda:self.large_check.setChecked(True)),('Больше контраста',lambda:self.contrast_check.setChecked(True))]:
            button=QPushButton(text);button.clicked.connect(callback);presets.addWidget(button)
        root.addLayout(presets)
        note=QLabel(THEME_NOTICE);note.setWordWrap(True);root.addWidget(note)
        scroll=QScrollArea();scroll.setWidgetResizable(True);panel=QWidget();grid=QGridLayout(panel);grid.setSpacing(10)
        scroll.setWidget(panel);root.addWidget(scroll,1);self.group=QButtonGroup(self)
        from widgets import AnimatedToolButton
        for i,name in enumerate(THEMES):
            b=AnimatedToolButton();b.setCheckable(True);b.setText(name);b.setIcon(QIcon(theme_preview(name)))
            b.setIconSize(QSize(215,105));b.setFixedSize(233,141);b.accent=QColor(THEMES[name][5]);self.group.addButton(b)
            b.setChecked(name==current);b.clicked.connect(lambda checked=False,n=name:setattr(self,'selected',n));grid.addWidget(b,i//3,i%3)
        self.reduce_check.toggled.connect(self.motion_changed)
        self.motion.setEnabled(not self.reduce_check.isChecked())
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Apply|QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Apply).setText('Применить');buttons.button(QDialogButtonBox.StandardButton.Apply).clicked.connect(self.accept)
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена');buttons.rejected.connect(self.reject);root.addWidget(buttons)

    def motion_changed(self,value):
        self.reduce_motion=value;self.motion.setEnabled(not value)
        for button in self.group.buttons():button._animate()

    def comfort_preset(self):
        self.reduce_check.setChecked(True);self.large_check.setChecked(True);self.motion.setChecked(False)
        self.selected='Soft'
        for button in self.group.buttons():
            if button.text()=='Soft':button.setChecked(True)
