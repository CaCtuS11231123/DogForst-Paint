"""Gradient controls with real stop colours, positions, transparency and sticky commit buttons."""
from PySide6.QtCore import Qt,QSignalBlocker,QRectF
from PySide6.QtGui import QColor,QPainter,QPen
from PySide6.QtWidgets import QWidget,QDockWidget,QVBoxLayout,QHBoxLayout,QFormLayout,QLabel,QComboBox,QDoubleSpinBox,QSpinBox,QPushButton,QListWidget,QColorDialog
from gradients import gradient_brush
from widgets import AnimatedSlider

class GradientBar(QWidget):
    def __init__(self,canvas):super().__init__();self.canvas=canvas;self.setFixedHeight(46)
    def paintEvent(self,event):
        p=QPainter(self)
        for y in range(0,self.height(),8):
            for x in range(0,self.width(),8):p.fillRect(x,y,8,8,QColor('#d4dbe7' if (x//8+y//8)%2 else '#ffffff'))
        options=dict(self.canvas.gradient_options,kind='linear',x1=0.,y1=0.,x2=float(max(1,self.width())),y2=0.)
        p.setOpacity(options['opacity']/100);p.fillRect(self.rect(),gradient_brush(options));p.setOpacity(1);p.setPen(QPen(QColor('#7597ba'),1));p.drawRect(self.rect().adjusted(0,0,-1,-1));p.end()

class GradientDock(QDockWidget):
    def __init__(self,owner):super().__init__('Градиент',owner);self.owner=owner
    def closeEvent(self,event):self.owner.canvas.cancel_gradient();super().closeEvent(event)

class GradientPanel(QWidget):
    def __init__(self,owner):
        super().__init__();self.owner=owner;self.c=owner.canvas;self.selected=0;self.loading=False;root=QVBoxLayout(self)
        self.target=QLabel('Выберите слой и протяните линию на холсте.');self.target.setWordWrap(True);root.addWidget(self.target)
        self.bar=GradientBar(self.c);root.addWidget(self.bar);form=QFormLayout();root.addLayout(form)
        self.kind=QComboBox();self.kind.addItems(['Линейный','Радиальный']);self.kind.currentIndexChanged.connect(lambda i:self.change(kind='linear' if i==0 else 'radial'));form.addRow('Вид',self.kind)
        self.opacity=AnimatedSlider(Qt.Orientation.Horizontal);self.opacity.setRange(0,100);self.opacity_number=QSpinBox();self.opacity_number.setRange(0,100);self.opacity_number.setSuffix(' %');self.opacity.valueChanged.connect(lambda v:self.change(opacity=v));self.opacity_number.valueChanged.connect(lambda v:self.change(opacity=v))
        row=QHBoxLayout();row.addWidget(self.opacity,1);row.addWidget(self.opacity_number);form.addRow('Непрозрачность',row)
        self.presets=QComboBox();self.presets.addItems(['Пресеты…','Океан','Закат','Чёрный → белый','Текущий цвет → прозрачный']);self.presets.activated.connect(self.preset);root.addWidget(self.presets)
        self.stops=QListWidget();self.stops.setMaximumHeight(120);self.stops.currentRowChanged.connect(self.select_stop);root.addWidget(self.stops)
        self.position=QDoubleSpinBox();self.position.setRange(0,100);self.position.setDecimals(1);self.position.setSuffix(' %');self.position.setKeyboardTracking(False);self.position.valueChanged.connect(self.move_stop)
        self.alpha=QSpinBox();self.alpha.setRange(0,100);self.alpha.setSuffix(' %');self.alpha.valueChanged.connect(self.alpha_stop)
        form2=QFormLayout();form2.addRow('Позиция точки',self.position);form2.addRow('Непрозрачность точки',self.alpha);root.addLayout(form2)
        row=QHBoxLayout();self.color=QPushButton('Цвет точки…');self.color.clicked.connect(self.pick_color);row.addWidget(self.color);self.from_current=QPushButton('Текущий цвет');self.from_current.clicked.connect(lambda:self.set_stop_color(self.c.color));row.addWidget(self.from_current);root.addLayout(row)
        row=QHBoxLayout();self.add=QPushButton('+ Точка');self.add.clicked.connect(self.add_stop);self.remove=QPushButton('Удалить точку');self.remove.clicked.connect(self.remove_stop);self.reverse=QPushButton('Развернуть');self.reverse.clicked.connect(self.reverse_stops)
        for w in (self.add,self.remove,self.reverse):row.addWidget(w)
        root.addLayout(row)
        self.coordinates={};form3=QFormLayout();root.addLayout(form3)
        for key,label in [('x1','Начало X'),('y1','Начало Y'),('x2','Конец X'),('y2','Конец Y')]:
            spin=QDoubleSpinBox();spin.setRange(-100000,100000);spin.setDecimals(1);spin.setSuffix(' px');spin.setKeyboardTracking(False);spin.valueChanged.connect(lambda v,k=key:self.change(**{k:v}));form3.addRow(label,spin);self.coordinates[key]=spin
        note=QLabel('Протяните линию на холсте. Затем двигайте её концы или введите координаты. Shift — шаг угла 15°. Радиальный градиент: начало — центр, конец — радиус.\n\nВыделение ограничивает заливку. На маске цвета переводятся в серый. При применении пиксельной правки текст и фото растрируются; Undo возвращает исходник.');note.setWordWrap(True);root.addWidget(note);root.addStretch()
        self.status=QLabel();self.status.setWordWrap(True);self.actions=QWidget();row=QHBoxLayout(self.actions);row.setContentsMargins(0,0,0,0);self.apply=QPushButton('Применить');self.cancel=QPushButton('Отменить');self.apply.clicked.connect(self.apply_values);self.cancel.clicked.connect(self.c.cancel_gradient);row.addWidget(self.apply);row.addWidget(self.cancel)
        self.refresh()
    def change(self,**values):
        if self.loading:return
        try:self.c.update_gradient(**values)
        except ValueError as e:self.status.setText(str(e));self.refresh()
    def select_stop(self,index):
        if self.loading:return
        self.selected=max(0,index);self.refresh()
    def set_stops(self,stops,selected=None):
        if selected is not None:self.selected=selected
        self.change(stops=stops)
    def move_stop(self,value):
        if self.loading:return
        stops=list(self.c.gradient_options['stops']);at,color=stops[self.selected]
        if any(i!=self.selected and abs(v-value/100)<.00001 for i,(v,c) in enumerate(stops)):
            self.owner.statusBar().showMessage('У точек должны быть разные позиции.',4000);self.refresh();return
        stops[self.selected]=(value/100,color);stops.sort();self.selected=stops.index((value/100,color));self.set_stops(stops)
    def alpha_stop(self,value):
        if self.loading:return
        c=QColor(self.c.gradient_options['stops'][self.selected][1]);c.setAlpha(round(value*255/100));self.set_stop_color(c)
    def set_stop_color(self,color):
        if not QColor(color).isValid():return
        stops=list(self.c.gradient_options['stops']);stops[self.selected]=(stops[self.selected][0],QColor(color).name(QColor.NameFormat.HexArgb));self.set_stops(stops)
    def pick_color(self):
        original=QColor(self.c.gradient_options['stops'][self.selected][1]);dialog=QColorDialog(original,self);dialog.setWindowTitle('Цвет точки — живой предпросмотр')
        dialog.setOption(QColorDialog.ColorDialogOption.DontUseNativeDialog,True);dialog.setOption(QColorDialog.ColorDialogOption.ShowAlphaChannel,True);dialog.currentColorChanged.connect(self.set_stop_color)
        from PySide6.QtWidgets import QDialog
        if dialog.exec()!=QDialog.DialogCode.Accepted:self.set_stop_color(original)
        else:self.set_stop_color(dialog.currentColor())
        dialog.deleteLater()
    def add_stop(self):
        stops=list(self.c.gradient_options['stops'])
        if len(stops)>=16:return
        a,b=max(zip(stops,stops[1:]),key=lambda pair:pair[1][0]-pair[0][0]);new=((a[0]+b[0])/2,self.c.color.name(QColor.NameFormat.HexArgb));stops.append(new);stops.sort();self.set_stops(stops,stops.index(new))
    def remove_stop(self):
        stops=list(self.c.gradient_options['stops'])
        if len(stops)<=2:return
        del stops[self.selected];self.set_stops(stops,min(self.selected,len(stops)-1))
    def reverse_stops(self):self.set_stops([(1-at,c) for at,c in reversed(self.c.gradient_options['stops'])],len(self.c.gradient_options['stops'])-1-self.selected)
    def preset(self,index):
        options={1:[(0.,'#ff42b8cf'),(.5,'#ff526fdb'),(1.,'#ff9a65d6')],2:[(0.,'#fff1c27d'),(.5,'#ffe37c93'),(1.,'#ff6763bc')],3:[(0.,'#ff000000'),(1.,'#ffffffff')]}
        if index==4:
            a=QColor(self.c.color);b=QColor(a);b.setAlpha(0);options[4]=[(0.,a.name(QColor.NameFormat.HexArgb)),(1.,b.name(QColor.NameFormat.HexArgb))]
        if index in options:self.set_stops(options[index],0)
    def apply_values(self):
        for spin in [self.position,*self.coordinates.values()]:spin.interpretText()
        self.owner.run_canvas_action(self.c.apply_gradient)
    def refresh(self):
        self.loading=True
        try:
            s=self.c.gradient_session;p=s.parameters if s else self.c.gradient_options;stops=p['stops'];self.selected=min(self.selected,len(stops)-1)
            self.kind.setCurrentIndex(p['kind']=='radial');self.opacity.setValue(round(p['opacity']));self.opacity_number.setValue(round(p['opacity']))
            self.stops.clear()
            for at,color in stops:
                c=QColor(color);self.stops.addItem(f'{at*100:.1f}%   {c.name().upper()}   ·   {round(c.alphaF()*100)}%')
            self.stops.setCurrentRow(self.selected);at,value=stops[self.selected];c=QColor(value);
            if not self.position.hasFocus():self.position.setValue(at*100)
            self.alpha.setValue(round(c.alphaF()*100));self.color.setStyleSheet(f'background-color: {c.name()}; color: {"black" if c.lightness()>140 else "white"};')
            self.remove.setEnabled(len(stops)>2);self.add.setEnabled(len(stops)<16)
            for key,spin in self.coordinates.items():
                spin.setEnabled(s is not None)
                if s and not spin.hasFocus():spin.setValue(p[key])
            node=self.c.node(s.node_id) if s else None;self.target.setText(('Маска: ' if s and s.mask_id else 'Слой: ')+node.name if node else 'Выберите один слой и протяните линию на холсте.')
            busy=s is not None and s.rendered_version!=s.version;self.status.setText(s.error if s and s.error else 'Пересчёт… Отмена доступна.' if busy else 'Предпросмотр. Enter — применить, Esc — отменить.' if s else 'Готово к рисованию градиента.')
            self.apply.setEnabled(s is not None and not busy and not s.error);self.cancel.setEnabled(s is not None);self.bar.update()
        finally:self.loading=False
