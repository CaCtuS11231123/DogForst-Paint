"""Editable raster placements: retain originals while caching compatible layer pixels."""
import math,copy
import numpy as np
from PySide6.QtCore import Qt,QPointF,QRectF
from PySide6.QtGui import QImage,QImageReader,QPainter,QTransform,QBrush,QPolygonF,QColor
from layers import Layer,transparent_image

LIMIT=120_000_000
DEFAULTS=dict(x=0.,y=0.,width=1.,height=1.,rotation=0.,repeat=False,tile_scale=100.,flip_h=False,flip_v=False)

def clone_object(obj):
    result=dict(obj,source=QImage(obj['source']))
    if 'shape' in result:result['shape']=copy.deepcopy(result['shape'])
    return result
def object_metadata(obj):
    result={key:obj.get(key,value) for key,value in DEFAULTS.items()}
    if 'shape' in obj:result['shape']=copy.deepcopy(obj['shape'])
    return result

def validate_object(obj):
    if not isinstance(obj,dict):raise ValueError('Некорректный объект изображения.')
    for key in ('x','y','width','height','rotation','tile_scale'):
        value=obj.get(key,DEFAULTS[key])
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):raise ValueError('Некорректная геометрия изображения.')
    if not 1<=obj['width']<=24000 or not 1<=obj['height']<=24000 or abs(obj['x'])>100000 or abs(obj['y'])>100000 or abs(obj['rotation'])>36000 or not 5<=obj['tile_scale']<=800:raise ValueError('Параметры изображения за допустимыми границами.')
    for key in ('repeat','flip_h','flip_v'):
        if not isinstance(obj.get(key,False),bool):raise ValueError('Некорректное отражение/повтор изображения.')
    if 'shape' in obj:
        from shape_objects import validate_shape
        validate_shape(obj['shape'])
    image=obj.get('source')
    if not isinstance(image,QImage) or image.isNull() or image.width()*image.height()>60_000_000 or max(image.width(),image.height())>12000:raise ValueError('Недопустимый исходник изображения.')

def read_image(filename):
    reader=QImageReader(str(filename));reader.setAutoTransform(True)
    size=reader.size()
    if not size.isValid() or max(size.width(),size.height())>12000 or size.width()*size.height()>60_000_000:raise ValueError('Изображение повреждено или превышает 60 млн пикселей / 12000 px.')
    image=reader.read()
    if image.isNull():raise ValueError('Не удалось прочитать изображение: '+reader.errorString())
    return image.convertToFormat(QImage.Format.Format_ARGB32)

def object_transform(obj):
    x,y,w,h=(obj[k] for k in ('x','y','width','height'))
    t=QTransform().translate(x+w/2,y+h/2).rotate(obj['rotation'])
    t.scale(-1 if obj.get('flip_h') else 1,-1 if obj.get('flip_v') else 1)
    return t.translate(-w/2,-h/2)

def paint_object(p,obj):
    p.save()
    try:
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform,True)
        p.setTransform(object_transform(obj),True);rect=QRectF(0,0,obj['width'],obj['height'])
        if 'shape' in obj:
            from shapes import draw_shape
            draw_shape(p,obj['shape']['name'],rect,obj['shape']['options'])
        elif obj['repeat']:
            brush=QBrush(obj['source']);scale=obj['tile_scale']/100
            brush.setTransform(QTransform().scale(scale,scale));p.fillRect(rect,brush)
        else:p.drawImage(rect,obj['source'])
    finally:p.restore()

def render_object(obj,size):
    validate_object(obj)
    image=transparent_image(*size);p=QPainter(image)
    try:paint_object(p,obj)
    finally:p.end()
    return image

def alpha_bounds(image):
    image=image.convertToFormat(QImage.Format.Format_ARGB32)
    arr=np.frombuffer(image.constBits(),dtype=np.uint32).reshape(image.height(),image.bytesPerLine()//4)[:,:image.width()]
    left,top,right,bottom=image.width(),image.height(),-1,-1
    for y in range(0,image.height(),128):
        block=(arr[y:y+128]>>24)!=0;ys,xs=np.nonzero(block)
        if len(xs):left=min(left,int(xs.min()));right=max(right,int(xs.max()));top=min(top,y+int(ys.min()));bottom=max(bottom,y+int(ys.max()))
    return QRectF(left,top,right-left+1,bottom-top+1) if right>=left else None

class RasterObjectsMixin:
    def remove_selected_image(self):
        if self.drawing or self.fill_job is not None:return False
        if len(self.selected_node_ids())!=1 or self.control_node().kind=='group' or any(t.get('layer_id')==self.active.id for t in self.text_objects):
            self.status.emit('Для удаления фото выберите один слой изображения справа.');return False
        if not self.can_edit():return False
        if len(self.layers)>1:self.delete_layer();return True
        self.push_history();self.stop_mask_edit();old=self.active.id;new=Layer('Слой 1',transparent_image(*self.doc_size))
        siblings=self.child_ids(self.parent_id(old));siblings[siblings.index(old)]=new.id;self.layers=[new]
        self.active_layer=0;self.selection=None;self.text_objects=[];self.selected_text=-1
        self.set_selected_nodes({self.active.id},self.active.id);self.changed.emit();self.update()
        self.status.emit('Фото удалено. Остался пустой холст. Ctrl+Z — вернуть.');return True

    def source_pixels(self):return sum(o['source'].width()*o['source'].height() for o in self.raster_objects.values())
    def sync_raster_objects(self):
        live={l.id:l for l in self.layers}
        for identifier in list(self.raster_objects):
            layer=live.get(identifier)
            if layer is None or self._object_keys.get(identifier)!=layer.image.cacheKey():
                self.raster_objects.pop(identifier,None);self._object_keys.pop(identifier,None)
    def remember_object(self,layer,obj):
        self.raster_objects[layer.id]=clone_object(obj);self._object_keys[layer.id]=layer.image.cacheKey()
    def reset_object_keys(self):self._object_keys={l.id:l.image.cacheKey() for l in self.layers if l.id in self.raster_objects}
    def object_for_layer(self,layer=None):
        layer=layer or self.active
        if any(t.get('layer_id')==layer.id for t in self.text_objects):return None
        if layer.id in self.raster_objects:return clone_object(self.raster_objects[layer.id])
        self._object_error=""
        rect=alpha_bounds(layer.image)
        if rect is None:return None
        if (len(self.layers)+len(self.masks))*self.doc_size[0]*self.doc_size[1]+self.source_pixels()+int(rect.width()*rect.height())>LIMIT:
            self._object_error="Недостаточно бюджета памяти для исходника. Уменьшите холст или число слоёв.";return None
        return dict(DEFAULTS,source=layer.image.copy(rect.toAlignedRect()),x=rect.x(),y=rect.y(),width=rect.width(),height=rect.height())
    def import_object(self,source,name='Изображение',texture=False):
        parent=self.insertion_parent()
        if not self.can_insert(parent):return False
        if not isinstance(source,QImage) or source.isNull():raise ValueError('Пустое изображение.')
        if self.editing_mask:self.stop_mask_edit()
        if (len(self.layers)+len(self.masks)+1)*self.doc_size[0]*self.doc_size[1]+self.source_pixels()+source.width()*source.height()>LIMIT:raise ValueError('Достигнут бюджет памяти слоёв, масок и исходников.')
        factor=min(1.,self.doc_size[0]/source.width(),self.doc_size[1]/source.height())
        w,h=(self.doc_size if texture else (max(1.,source.width()*factor),max(1.,source.height()*factor)))
        obj=dict(DEFAULTS,source=QImage(source),x=(self.doc_size[0]-w)/2,y=(self.doc_size[1]-h)/2,width=float(w),height=float(h),repeat=bool(texture))
        image=render_object(obj,self.doc_size);layer=Layer(name,image)
        self.push_history();self.layers.insert(self.active_layer+1,layer);self.active_layer+=1
        self.attach_layer(layer.id,parent);self.remember_object(layer,obj);self.selection=None;self.select_text(-1)
        self.set_selected_nodes({layer.id},layer.id);self.changed.emit();self.update();return True
    def set_object(self,layer,obj,record=True,opacity=None,blend=None):
        obj=clone_object(obj)
        if 'shape' in obj:
            if obj['width']>1:obj['shape']['options']['flat_x']=False
            if obj['height']>1:obj['shape']['options']['flat_y']=False
        if not self.can_edit(layer,move=True):return False
        validate_object(obj)
        old_pixels=self.raster_objects.get(layer.id,{}).get('source',QImage())
        total=(len(self.layers)+len(self.masks))*self.doc_size[0]*self.doc_size[1]+self.source_pixels()-old_pixels.width()*old_pixels.height()+obj['source'].width()*obj['source'].height()
        if total>LIMIT:raise ValueError('Достигнут бюджет памяти исходников.')
        result=render_object(obj,self.doc_size)
        previous=self.object_for_layer(layer)
        mask=self.masks.get(layer.id)
        # Transform an attached mask from the current placement into the new placement.
        moved_mask=None
        if previous and mask is not None:
            from masks import mask_image
            old=object_transform(previous).scale(previous['width'],previous['height'])
            new=object_transform(obj).scale(obj['width'],obj['height'])
            matrix=old.inverted()[0]*new
            moved_mask=mask_image(self.doc_size);p=QPainter(moved_mask);p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform,True)
            p.setTransform(matrix);p.drawImage(0,0,mask);p.end()
            # Smooth interpolation over white must remain valid opaque gray.
        if record:self.push_history()
        layer.image=result;self.remember_object(layer,obj)
        if moved_mask is not None:self.masks[layer.id]=moved_mask
        if opacity is not None:layer.opacity=opacity
        if blend is not None:layer.blend_mode=blend
        if record:self.changed.emit()
        self.update();return True
    def transform_candidate(self):
        key=(self.active.id,self.active.image.cacheKey())
        if self.active.id in self.raster_objects:return self.raster_objects[self.active.id]
        if getattr(self,'_candidate_key',None)!=key:
            self._candidate_key=key;self._candidate_object=self.object_for_layer()
        return getattr(self,'_candidate_object',None)
    def object_handles(self):
        if self.drawing and self._interaction=="move" and self.active.id not in self.raster_objects:return {}
        if self.tool!='Перемещение' or self.auto_select_layer or self.move_all_layers or self.move_all_visible or self.selection or self.editing_mask or len(self.selected_node_ids())!=1 or self.control_node().kind=='group' or self.selected_text>=0:return {}
        obj=self.transform_candidate()
        if obj is None:return {}
        t=object_transform(obj);w,h=obj['width'],obj['height']
        if min(w,h)*self.zoom<24:return {}
        return {k:self.screen_point(t.map(pt)) for k,pt in {'tl':QPointF(0,0),'tr':QPointF(w,0),'br':QPointF(w,h),'bl':QPointF(0,h),'mr':QPointF(w,h/2),'bm':QPointF(w/2,h),'rotate':QPointF(w/2,-28/max(.1,self.zoom))}.items()}
    def paint_object_overlay(self,painter):
        handles=self.object_handles()
        if not handles:return
        obj=self.transform_candidate()
        polygon=QPolygonF([handles[k] for k in ('tl','tr','br','bl')])
        from PySide6.QtGui import QPen
        painter.setBrush(Qt.BrushStyle.NoBrush);painter.setPen(QPen(QColor('#101827'),3));painter.drawPolygon(polygon)
        painter.setPen(QPen(QColor('#80caff'),1));painter.drawPolygon(polygon)
        painter.drawLine(handles['rotate'],(handles['tl']+handles['tr'])/2);self._paint_handles(painter,handles)
        self._overlay_label(painter,polygon.boundingRect().bottomLeft()+QPointF(0,23),f"{self.active.name} · {obj['width']:.0f} × {obj['height']:.0f} px · {obj['rotation']:.0f}° · Shift: свободно / 15°")
    def cancel_object_drag(self):
        if not self._interaction.startswith("object_"):return False
        if self._object_recorded and self.history_engine.pending is not None:
            before=self.history_engine.pending;self.history_engine.pending=None;self.restore(before)
        self.drawing=False;self._interaction="";self.update();return True
    def begin_object_drag(self,handle,pos):
        if not self.can_edit(move=True):return
        self._object_old=clone_object(self.transform_candidate());self._object_mask=QImage(self.masks[self.active.id]) if self.active.id in self.masks else None
        self._object_original_image=QImage(self.active.image);self._object_drag_start=QPointF(pos)
        self._object_recorded=False;self._interaction='object_'+handle;self.drawing=True
    def drag_object(self,handle,pos,modifiers):
        old=self._object_old;obj=clone_object(old)
        if handle=='rotate':
            center=QPointF(old['x']+old['width']/2,old['y']+old['height']/2);a=self._object_drag_start-center;b=pos-center
            angle=old['rotation']+math.degrees(math.atan2(b.y(),b.x())-math.atan2(a.y(),a.x()))
            obj['rotation']=round(angle/15)*15 if modifiers&Qt.KeyboardModifier.ShiftModifier else round(angle)
        else:
            local=object_transform(old).inverted()[0].map(pos)
            anchor=QPointF(old['width'] if 'l' in handle else 0,old['height'] if 't' in handle else 0)
            w=max(1.,min(24000.,(anchor.x()-local.x() if 'l' in handle else local.x()-anchor.x()))) if handle!='bm' else old['width']
            h=max(1.,min(24000.,(anchor.y()-local.y() if 't' in handle else local.y()-anchor.y()))) if handle!='mr' else old['height']
            if handle not in ('mr','bm') and not (modifiers&Qt.KeyboardModifier.ShiftModifier):
                scale=max(w/old['width'],h/old['height']);w=min(24000.,old['width']*scale);h=min(24000.,old['height']*scale)
            obj.update(width=w,height=h)
            # Opposite edge/corner stays fixed even when rotated or flipped.
            new_anchor=QPointF(w if 'l' in handle else 0,h if 't' in handle else 0)
            before=object_transform(old).map(anchor);after=object_transform(obj).map(new_anchor)
            obj['x']+=before.x()-after.x();obj['y']+=before.y()-after.y()
        if not self._object_recorded:self.push_history();self._object_recorded=True
        # Always render from the immutable original and initial mask, not the previous drag tick.
        self.raster_objects[self.active.id]=clone_object(old)
        if self._object_mask is not None:self.masks[self.active.id]=QImage(self._object_mask)
        self.set_object(self.active,obj,record=False)
        self.status.emit(f"{self.active.name}: {obj['width']:.0f} × {obj['height']:.0f} px · {obj['rotation']:.0f}°")
