"""Live clipping chains: each clipped sibling uses the last non-clipped sibling's alpha."""
from PySide6.QtGui import QImage,QPainter
from layers import transparent_image


def clip_image(image,base,opacity=1.):
    result=QImage(image)
    if opacity!=1:
        faded=transparent_image(base.width(),base.height());p=QPainter(faded);p.setOpacity(opacity);p.drawImage(0,0,base);p.end();base=faded
    p=QPainter(result);p.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationIn);p.drawImage(0,0,base);p.end()
    return result

class ClippingMixin:
    def clipping_base(self,layer=None):
        layer=layer or self.active;ids=self.child_ids(self.parent_id(layer.id));base=None
        for identifier in ids:
            if identifier==layer.id:return base
            node=self.node(identifier)
            if not getattr(node,'clipped',False):base=node
        return None
    def set_clipping(self,enabled):
        if len(self.selected_node_ids())!=1 or self.control_node().kind=='group':self.status.emit('Выберите один слой над базовым слоем.');return
        if not self.can_edit():return
        if enabled and self.clipping_base() is None:self.status.emit('Под слоем нет базового слоя в этой папке.');return
        if self.active.clipped==bool(enabled):return
        self.push_history();self.active.clipped=bool(enabled);self.changed.emit();self.update()
    def layer_clipping(self,image,layer):
        if not layer.clipped:return image
        base=self.clipping_base(layer)
        if base is None or not base.visible or base.opacity<=0:return transparent_image(*self.doc_size)
        if base.kind=='group':
            from compositor import render_image
            alpha=render_image(self.doc_size,self.layers,self.groups,[base.id],self.text_objects,masks=self.masks,disabled_masks=self.disabled_masks)
            return clip_image(image,alpha)
        from text_model import draw_text
        from masks import apply_mask
        alpha=QImage(base.image);p=QPainter(alpha)
        for text in self.text_objects:
            if text.get('layer_id')==base.id:draw_text(p,text)
        p.end()
        if base.id in self.masks and base.id not in self.disabled_masks:alpha=apply_mask(alpha,self.masks[base.id])
        return clip_image(image,alpha,base.opacity)
