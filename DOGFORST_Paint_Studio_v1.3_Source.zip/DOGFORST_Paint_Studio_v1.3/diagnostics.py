"""Bounded local error logs. Never log document contents or image buffers."""
import logging
from logging.handlers import RotatingFileHandler
import os
import sys
import threading
from pathlib import Path
from PySide6.QtCore import QStandardPaths


def application_data_directory():
    override = os.environ.get('DOGFORST_DATA_DIR')
    if override:
        return Path(override).resolve()
    base = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppLocalDataLocation)
    if not base:
        raise OSError('Не найден каталог данных приложения.')
    return Path(base)


def configure_logging(root, version):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger('dogforst')
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        handler.close()
        logger.removeHandler(handler)
    handler = RotatingFileHandler(root / 'errors.log', maxBytes=1_000_000,
                                  backupCount=3, encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    logger.addHandler(handler)
    logger.info('Started DOGFORST %s; Python %s; platform %s', version,
                sys.version.split()[0], sys.platform)
    return logger


def install_exception_hooks(logger, notify=None):
    original = sys.excepthook

    def report(kind, error, traceback):
        if issubclass(kind, (KeyboardInterrupt, SystemExit)):
            original(kind, error, traceback)
            return
        logger.error('Unhandled UI exception', exc_info=(kind, error, traceback))
        if notify:
            notify()

    def report_thread(args):
        logger.error('Unhandled thread exception', exc_info=(args.exc_type, args.exc_value,
                                                           args.exc_traceback))
    sys.excepthook = report
    threading.excepthook = report_thread
