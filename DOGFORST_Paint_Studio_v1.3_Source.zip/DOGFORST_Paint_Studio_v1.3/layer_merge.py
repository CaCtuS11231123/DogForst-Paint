"""Explicit merge of selected sibling layers with a real before/after for changed blending."""
import copy
from PySide6.QtWidgets import QDialog
from layers import Layer
from compositor import render_image

class LayerMergeMixin:
    def merge_selected(self):
        ids=self.selected_node_ids()
        if len(ids)<2 or any(self.node(i).kind=='group' for i in ids):self.status.emit('Выберите два или больше слоёв с Ctrl или Shift.');return False
        parents={self.parent_id(i) for i in ids}
        if len(parents)!=1:self.status.emit('Для объединения выберите слои внутри одной группы.');return False
        selected=[l for l in self.layers if l.id in ids]
        if any(self.node_locked(l) or l.alpha_locked for l in selected):self.status.emit('Сначала снимите защиту выбранных слоёв.');return False
        parent=next(iter(parents));siblings=self.child_ids(parent);positions=[siblings.index(i) for i in ids]
        texts=[t for t in self.text_objects if t.get('layer_id') in ids]
        # Use baked clipping from the actual document; other layer effects are included once.
        clipping=any(getattr(self.node(i),'clipped',False) for i in siblings)
        pair=[Layer(l.name,self.layer_image(l),l.visible,l.opacity,l.id,blend_mode=l.blend_mode) for l in selected] if clipping else selected
        image=render_image(self.doc_size,pair,{},[l.id for l in pair],[] if clipping else texts,masks={} if clipping else {i:m for i,m in self.masks.items() if i in ids},disabled_masks=self.disabled_masks)
        merged=Layer('Объединённые слои',image);remaining=[t for t in self.text_objects if t.get('layer_id') not in ids]
        groups=copy.deepcopy(self.groups);stack=list(self.layer_stack);target=groups[parent].children if parent else stack
        insert=max(positions);target[:]=[i for i in target if i not in ids];target.insert(sum(1 for i in siblings[:insert+1] if i not in ids),merged.id)
        candidate=[l for l in self.layers if l.id not in ids]+[merged]
        # Without groups the compositor follows layer list order.
        order={identifier:i for i,identifier in enumerate(target)}
        if not groups:candidate.sort(key=lambda l:order[l.id])
        risky=(max(positions)-min(positions)+1!=len(ids) or clipping or any(l.blend_mode!='normal' for l in selected))
        if risky:
            before=render_image(self.doc_size,self.layers,self.groups,self.layer_stack,self.text_objects,(420,300),masks=self.masks,disabled_masks=self.disabled_masks)
            after=render_image(self.doc_size,candidate,groups,stack,remaining,(420,300),masks={i:m for i,m in self.masks.items() if i not in ids},disabled_masks=self.disabled_masks-set(ids))
            if before!=after:
                from merge_dialog import MergePreviewDialog
                dialog=MergePreviewDialog(before,after,self.window());dialog.setWindowTitle('Объединить выбранные слои — сравнение')
                if dialog.exec()!=QDialog.DialogCode.Accepted:return False
        self.push_history();self.stop_mask_edit();self.layers=candidate;self.active_layer=self.layers.index(merged);self.groups=groups;self.layer_stack=stack;self.text_objects=remaining
        for i in ids:self.masks.pop(i,None);self.raster_objects.pop(i,None);self.disabled_masks.discard(i)
        self.sync_groups();self.set_selected_nodes({merged.id},merged.id);self.changed.emit();self.update();self.status.emit('Слои объединены. Ctrl+Z возвращает исходные слои.');return True
