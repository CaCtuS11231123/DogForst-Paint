"""Brush library with Back navigation, exact numeric settings and real paint preview."""
from PySide6.QtCore import Qt,QPointF,QRectF,QSize
from PySide6.QtGui import QPainter,QColor,QPen,QPixmap,QIcon
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,
    QStackedWidget,QWidget,QGridLayout,QToolButton,QFormLayout,QSlider,QSpinBox,QComboBox,QCheckBox,QScrollArea,QInputDialog,QMessageBox)
from dialogs import ColorButton
from brushes import paint_soft_segment

PRESETS=(('Круглая','Кисть',100),('Мягкая','Мягкая кисть',25),
         ('Карандаш','Карандаш',100),('Маркер','Маркер',100),('Ластик','Ластик',100))


def sample(painter,rect,tool,size,opacity,hardness,color_value="#2879ce",shape="round",outline=0,outline_color="#17263f",spacing=12,flow=100):
    import math
    painter.save();painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    color=QColor(color_value);color.setAlphaF(opacity/100*(.35 if tool=='Маркер' else 1))
    painter.setPen(QPen(color,size,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin))
    from PySide6.QtGui import QPainterPath
    path=QPainterPath();points=[]
    for i in range(81):points.append(QPointF(rect.left()+rect.width()*i/80,rect.center().y()+math.sin(i/80*math.pi*2)*rect.height()*.23))
    if outline and tool!='Ластик':
        path.moveTo(points[0])
        for pt in points[1:]:path.lineTo(pt)
        cap=Qt.PenCapStyle.SquareCap if shape=='square' else Qt.PenCapStyle.RoundCap
        join=Qt.PenJoinStyle.MiterJoin if shape=='square' else Qt.PenJoinStyle.RoundJoin
        painter.setOpacity(painter.opacity()*opacity/100*(.35 if tool=='Маркер' else 1))
        color=QColor(color_value);rim=QColor(outline_color)
        painter.setPen(QPen(rim,size,Qt.PenStyle.SolidLine,cap,join));painter.drawPath(path)
        painter.setPen(QPen(color,max(1,size-2*outline),Qt.PenStyle.SolidLine,cap,join));painter.drawPath(path);painter.restore();return
    from types import SimpleNamespace
    from layers import Layer,transparent_image
    from ink_stroke import InkStroke
    fake=SimpleNamespace(tool=tool,brush_size=size,brush_opacity=opacity,brush_hardness=hardness,brush_stabilizer=0,brush_shape=shape,brush_spacing=spacing,brush_flow=flow,color=QColor(color_value),selection=None,selection_mask=None,smoothing=True,editing_mask=None,masks={})
    fake.active=Layer('Образец',transparent_image(max(1,math.ceil(rect.right()+size)),max(1,math.ceil(rect.bottom()+size))))
    if tool=='Ластик':fake.active.image.fill(QColor("#5284c5"))
    stroke=InkStroke(fake);stroke.segment(fake,points[0],points[0])
    for a,b in zip(points,points[1:]):stroke.segment(fake,a,b)
    painter.drawImage(0,0,fake.active.image)
    painter.restore()


class BrushPreview(QWidget):
    def __init__(self,dialog):super().__init__();self.dialog=dialog;self.setMinimumSize(400,125)
    def paintEvent(self,event):
        p=QPainter(self);p.fillRect(self.rect(),QColor('#e8edf5'))
        tool,size,opacity,hardness,_=self.dialog.values()
        sample(p,QRectF(35,20,self.width()-70,self.height()-40),tool,min(size,65),opacity,hardness,self.dialog.color.color,self.dialog.shape.currentData(),self.dialog.outline.value() if self.dialog.outline_check.isChecked() else 0,self.dialog.outline_color.color,self.dialog.spacing.value(),self.dialog.flow.value());p.end()


class BrushDialog(QDialog):
    def __init__(self,canvas,parent=None):
        super().__init__(parent);self.setWindowTitle('Параметры кистей и инструментов');self.resize(680,740)
        self.tool=canvas.tool if canvas.tool in [p[1] for p in PRESETS] else 'Кисть'
        root=QVBoxLayout(self);root.addWidget(QLabel('Кисти · выберите образец, затем настройте штрих.'))
        self.pages=QStackedWidget();root.addWidget(self.pages)
        library=QWidget();grid=QGridLayout(library);self.pages.addWidget(library)
        self.preset_buttons=[]
        for i,(name,tool,hardness) in enumerate(PRESETS):
            pix=QPixmap(150,65);pix.fill(Qt.GlobalColor.transparent);p=QPainter(pix)
            sample(p,QRectF(15,8,120,46),tool,12,100,hardness);p.end()
            button=QToolButton();button.setText(name);button.setIcon(QIcon(pix));button.setIconSize(QSize(150,65))
            button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon);button.setMinimumSize(170,100)
            button.clicked.connect(lambda checked=False,t=tool,h=hardness:self.pick(t,h));grid.addWidget(button,i//3,i%3)
            self.preset_buttons.append(button)
        settings=QWidget();layout=QVBoxLayout(settings);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(settings);self.pages.addWidget(scroll)
        self.heading=QLabel();layout.addWidget(self.heading)
        self.size=self.control(layout,'Размер',1,512,canvas.brush_size,' px')
        self.opacity=self.control(layout,'Непрозрачность штриха',0,100,canvas.brush_opacity,' %')
        self.hardness=self.control(layout,'Жёсткость круглой кисти',0,100,canvas.brush_hardness,' %')
        self.stabilizer=self.control(layout,'Стабилизатор линии',0,100,canvas.brush_stabilizer,' %')
        self.spacing=self.control(layout,'Интервал отпечатков',1,50,canvas.brush_spacing,' %')
        self.flow=self.control(layout,'Подача краски',1,100,canvas.brush_flow,' %')
        self.color=ColorButton(canvas.color,'Цвет кисти');layout.addWidget(self.color)
        self.shape=QComboBox();self.shape.addItem('Круглая','round');self.shape.addItem('Квадратная','square');self.shape.setCurrentIndex(self.shape.findData(canvas.brush_shape));layout.addWidget(self.shape)
        outline_row=QHBoxLayout();self.outline_check=QCheckBox('Обводка штриха');self.outline_check.setChecked(canvas.brush_outline>0)
        self.outline=QSpinBox();self.outline.setRange(1,30);self.outline.setValue(canvas.brush_outline or 2);self.outline.setSuffix(' px')
        self.outline_color=ColorButton(canvas.brush_outline_color,'Цвет обводки');outline_row.addWidget(self.outline_check);outline_row.addWidget(self.outline);outline_row.addWidget(self.outline_color);layout.addLayout(outline_row)
        self.tip_note=QLabel('С обводкой штрих имеет чёткий край. На маске используется серый цвет без обводки.');self.tip_note.setWordWrap(True);layout.addWidget(self.tip_note)
        layout.addWidget(QLabel('0% стабилизатора — прямой отклик. Выше — сильнее сглаживание.\nЖёсткость действует на круглую и мягкую кисти.'))
        self.preview=BrushPreview(self);self.preview.setToolTip('Размер образца подогнан под окно. На холсте используется точный размер в пикселях.');layout.addWidget(self.preview)
        for control in (self.size,self.opacity,self.hardness,self.stabilizer,self.outline):control.valueChanged.connect(self.preview.update)
        self.color.colorChanged.connect(self.preview.update);self.outline_color.colorChanged.connect(self.preview.update);self.shape.currentIndexChanged.connect(self.preview.update);self.outline_check.toggled.connect(self.preview.update);self.outline_check.toggled.connect(self.sync_controls)
        bar=QHBoxLayout();root.addLayout(bar)
        self.back=QPushButton('← Назад к кистям');self.back.clicked.connect(lambda:self.reject() if self.pages.currentIndex()==0 else self.go_back());bar.addWidget(self.back)
        self.edit=QPushButton('Редактировать');self.edit.clicked.connect(lambda:self.pick(self.tool,None));bar.addWidget(self.edit)
        cancel=QPushButton('Отмена');cancel.clicked.connect(self.reject);bar.addWidget(cancel)
        self.apply=QPushButton('Выбрать кисть');self.apply.clicked.connect(self.accept);bar.addWidget(self.apply)
        from brush_presets import BrushPresetStore
        from PySide6.QtCore import QSettings
        self.preset_store=BrushPresetStore(parent.settings if parent is not None and hasattr(parent,'settings') else QSettings('DOGFORST','Paint Studio'))
        presets=QHBoxLayout();self.saved=QComboBox();presets.addWidget(self.saved,1)
        for text,fn,attr in [('Загрузить',self.load_preset,'preset_load'),('Сохранить…',self.save_preset,'preset_save'),('Удалить',self.delete_preset,'preset_delete')]:
            button=QPushButton(text);setattr(self,attr,button);button.clicked.connect(fn);presets.addWidget(button)
        self.saved.currentIndexChanged.connect(self.sync_preset_buttons)
        root.insertLayout(1,presets);self.refresh_presets()
        self.spacing.valueChanged.connect(self.preview.update);self.flow.valueChanged.connect(self.preview.update)
        self.go_back()
    def control(self,parent,label,minimum,maximum,value,suffix):
        row=QHBoxLayout();row.addWidget(QLabel(label));slider=QSlider(Qt.Orientation.Horizontal);slider.setRange(minimum,maximum)
        spin=QSpinBox();spin.setRange(minimum,maximum);spin.setSuffix(suffix)
        slider.valueChanged.connect(spin.setValue);spin.valueChanged.connect(slider.setValue);spin.setValue(value)
        row.addWidget(slider,1);row.addWidget(spin);parent.addLayout(row);spin._slider=slider;return spin
    def pick(self,tool,hardness):
        self.tool=tool
        if hardness is not None:self.hardness.setValue(hardness)
        self.setWindowTitle('Параметры инструмента — '+tool)
        self.heading.setText('Настройки · '+tool);self.pages.setCurrentIndex(1)
        self.back.setText('← Назад к кистям');self.back.setEnabled(True);self.edit.hide();self.apply.setEnabled(True);self.sync_controls();self.preview.update()
    def go_back(self):
        self.pages.setCurrentIndex(0);self.back.setText('← Назад к инструментам');self.back.setEnabled(True);self.edit.show();self.apply.setEnabled(False)
    def sync_controls(self,*_):
        painting=self.tool!='Ластик';outlined=painting and self.outline_check.isChecked()
        for control,enabled in [(self.spacing,self.tool in ('Кисть','Мягкая кисть') and not outlined),(self.flow,not outlined)]:control.setEnabled(enabled);control._slider.setEnabled(enabled)
        self.color.setEnabled(painting);self.outline_check.setEnabled(painting)
        self.outline.setEnabled(outlined);self.outline_color.setEnabled(outlined)
        self.shape.setEnabled(self.tool in ('Кисть','Мягкая кисть') or outlined)
        for control,enabled in ((self.hardness,self.tool in ('Кисть','Мягкая кисть') and not outlined),
                                (self.stabilizer,self.tool in ('Кисть','Мягкая кисть','Маркер'))):
            control.setEnabled(enabled);control._slider.setEnabled(enabled)
    def appearance(self):return dict(color=QColor(self.color.color),shape=self.shape.currentData(),outline=self.outline.value() if self.outline_check.isChecked() else 0,outline_color=QColor(self.outline_color.color))
    def values(self):return self.tool,self.size.value(),self.opacity.value(),self.hardness.value(),self.stabilizer.value()

    def dynamics(self):return dict(spacing=self.spacing.value(),flow=self.flow.value())
    def sync_preset_buttons(self,*_):
        available=self.saved.currentText() in self.preset_store.presets;self.preset_load.setEnabled(available);self.preset_delete.setEnabled(available)
    def refresh_presets(self):
        self.saved.clear();self.saved.addItem('Мои пресеты…');self.saved.addItems(list(self.preset_store.presets));self.sync_preset_buttons()
    def save_preset(self):
        name,ok=QInputDialog.getText(self,'Сохранить пресет','Название (совпадающее имя заменяет пресет):')
        if not ok:return
        appearance=self.appearance();tool,size,opacity,hardness,stabilizer=self.values()
        p=dict(tool=tool,size=size,opacity=opacity,hardness=hardness,stabilizer=stabilizer,shape=appearance['shape'],outline=appearance['outline'],color=appearance['color'].name(),outline_color=appearance['outline_color'].name(),**self.dynamics())
        try:self.preset_store.save(name,p);self.refresh_presets();self.saved.setCurrentText(name.strip())
        except ValueError as e:QMessageBox.warning(self,'Пресеты кистей',str(e))
    def load_preset(self):
        p=self.preset_store.presets.get(self.saved.currentText())
        if p is None:return
        for key in ('size','opacity','hardness','stabilizer','spacing','flow'):getattr(self,key).setValue(p[key])
        self.shape.setCurrentIndex(self.shape.findData(p['shape']));self.outline_check.setChecked(p['outline']>0);self.outline.setValue(p['outline'] or 2)
        for widget,key in [(self.color,'color'),(self.outline_color,'outline_color')]:widget.color=QColor(p[key]);widget.refresh()
        self.pick(p['tool'],None)
    def delete_preset(self):self.preset_store.delete(self.saved.currentText());self.refresh_presets()
