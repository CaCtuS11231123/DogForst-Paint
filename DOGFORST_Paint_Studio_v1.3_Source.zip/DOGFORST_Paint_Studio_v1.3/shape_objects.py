"""Editable shape recipes on managed layers, with cached pixels for all old pixel tools."""
import copy,math
from PySide6.QtCore import QRectF,QPointF
from PySide6.QtGui import QColor,QImage,QPainter
from shapes import SHAPES,DEFAULT_SHAPE,draw_shape
from layers import Layer,transparent_image

def validate_shape(value):
    if not isinstance(value,dict) or value.get('name') not in SHAPES or not isinstance(value.get('options'),dict):raise ValueError('Некорректная фигура.')
    o=value['options'];out=dict(DEFAULT_SHAPE,points=5,**{})
    for key in ('stroke','fill'):
        if not isinstance(o.get(key),str) or not QColor(o[key]).isValid():raise ValueError('Некорректный цвет фигуры.')
        out[key]=QColor(o[key]).name()
    for key,lo,hi in [('stroke_width',1,200),('shear',-100,100),('points',3,24)]:
        n=o.get(key,DEFAULT_SHAPE.get(key,5))
        if isinstance(n,bool) or not isinstance(n,(int,float)) or not math.isfinite(n) or not lo<=n<=hi:raise ValueError('Некорректный параметр фигуры: '+key)
        out[key]=n
    for key in ('filled','dashed','flat_x','flat_y'):
        if not isinstance(o.get(key,False),bool):raise ValueError('Некорректная настройка фигуры.')
        out[key]=o.get(key,False)
    out['rotation']=0;out['exact']=False
    return dict(name=value['name'],options=out)

def shape_source(name,options):
    recipe=validate_shape(dict(name=name,options=options));image=transparent_image(256,256);p=QPainter(image);draw_shape(p,name,QRectF(24,24,208,208),recipe['options']);p.end();return image,recipe

class ShapeObjectsMixin:
    def create_shape(self,name,rect,options):
        from raster_objects import DEFAULTS,render_object,alpha_bounds
        if rect.isEmpty() and name not in ('Линия','Стрелка'):return False
        # A selection/alpha lock edits pixels by design; preserve the existing masked path.
        if self.selection is not None or self.active.alpha_locked:return False
        parent=self.insertion_parent()
        if not self.can_insert(parent):return False
        flip_h=rect.width()<0;flip_v=rect.height()<0
        rect=rect.normalized();source,recipe=shape_source(name,options)
        if name in ('Линия','Стрелка'):recipe['options'].update(flat_x=rect.width()==0,flat_y=rect.height()==0)
        obj=dict(DEFAULTS,source=source,shape=recipe,x=rect.x(),y=rect.y(),width=max(1.,rect.width()),height=max(1.,rect.height()),rotation=float(options.get('rotation',0)),flip_h=flip_h,flip_v=flip_v)
        reuse=(self.control_node().kind!='group' and not self.raster_objects.get(self.active.id) and not any(t.get('layer_id')==self.active.id for t in self.text_objects) and alpha_bounds(self.active.image) is None)
        if not reuse and (len(self.layers)+len(self.masks)+1)*self.doc_size[0]*self.doc_size[1]+self.source_pixels()+65536>120_000_000:raise ValueError('Недостаточно памяти для слоя фигуры.')
        image=render_object(obj,self.doc_size)
        if reuse:layer=self.active;layer.image=image;layer.name='Фигура · '+name;layer.opacity*=self.brush_opacity/100
        else:
            layer=Layer('Фигура · '+name,image,opacity=self.brush_opacity/100);self.layers.append(layer);self.attach_layer(layer.id,parent)
            self.sync_groups();siblings=self.child_ids(parent)
            if layer.id in siblings:siblings.remove(layer.id)
            siblings.append(layer.id)
        self.remember_object(layer,obj);self.set_selected_nodes({layer.id},layer.id);self._created_shape=True;return True
