"""Coverage selections: grayscale masks, connected colour selection and safe pixel blending."""
import math,threading
import numpy as np
from scipy import ndimage
from PySide6.QtCore import Qt,QRectF,QPointF,QPoint,QObject,QRunnable,Signal,QThreadPool
from PySide6.QtGui import QImage,QPainter,QColor,QPolygonF,QPen
from PySide6.QtWidgets import QProgressDialog
from layers import transparent_image


def gray_array(image):
    image=image.convertToFormat(QImage.Format.Format_Grayscale8)
    return image,np.frombuffer(image.constBits(),dtype=np.uint8).reshape(image.height(),image.bytesPerLine())[:,:image.width()]

def from_array(array):
    array=np.ascontiguousarray(array,dtype=np.uint8)
    return QImage(array.data,array.shape[1],array.shape[0],array.shape[1],QImage.Format.Format_Grayscale8).copy()

def rect_mask(size,rect):
    mask=QImage(*size,QImage.Format.Format_Grayscale8);mask.fill(0)
    if rect:
        p=QPainter(mask);p.fillRect(rect,QColor('white'));p.end()
    return mask

def polygon_mask(size,points):
    mask=rect_mask(size,None);p=QPainter(mask);p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('white'));p.drawPolygon(QPolygonF(points),Qt.FillRule.OddEvenFill);p.end();return mask

def mask_bounds(mask):
    keep,a=gray_array(mask);left,top,right,bottom=mask.width(),mask.height(),-1,-1
    for y in range(0,mask.height(),128):
        block=a[y:y+128]>0;xs=np.flatnonzero(block.any(axis=0));ys=np.flatnonzero(block.any(axis=1))
        if len(xs):left=min(left,int(xs[0]));right=max(right,int(xs[-1]));top=min(top,y+int(ys[0]));bottom=max(bottom,y+int(ys[-1]))
    return QRectF(left,top,right-left+1,bottom-top+1) if right>=left else None

def combine_masks(before,after,mode):
    if mode=='replace' or (before is None and mode=='add'):return QImage(after)
    if before is None:return rect_mask((after.width(),after.height()),None)
    ka,a=gray_array(before);kb,b=gray_array(after)
    if mode=='add':return from_array(np.maximum(a,b))
    if mode=='intersect':return from_array(np.minimum(a,b))
    output=a.copy();less=a<=b;output-=b;output[less]=0;return from_array(output)

def blend_selection(before,after,mask,rect=None,target=None):
    rect=(rect or QRectF(0,0,before.width(),before.height())).toAlignedRect().intersected(before.rect())
    result=target if target is not None else QImage(before)
    if rect.isEmpty():return result
    a=before.copy(rect).convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
    b=after.copy(rect).convertToFormat(a.format());k,m=gray_array(mask.copy(rect));weight=m.astype(np.uint16)[:,:,None]
    def pixels(i):return np.frombuffer(i.constBits(),dtype=np.uint8).reshape(i.height(),i.bytesPerLine())[:,:i.width()*4].reshape(i.height(),i.width(),4)
    out=((pixels(a).astype(np.uint16)*(255-weight)+pixels(b).astype(np.uint16)*weight+127)//255).astype(np.uint8)
    patch=QImage(out.data,rect.width(),rect.height(),rect.width()*4,a.format()).copy().convertToFormat(result.format())
    def raw(i,writable=False):return np.frombuffer(i.bits() if writable else i.constBits(),dtype=np.uint32).reshape(i.height(),i.bytesPerLine()//4)[:,:i.width()]
    old=before.copy(rect).convertToFormat(result.format());new=after.copy(rect).convertToFormat(result.format())
    block=raw(patch,True);block[m==0]=raw(old)[m==0];block[m==255]=raw(new)[m==255]
    output=raw(result,True);output[rect.y():rect.y()+rect.height(),rect.x():rect.x()+rect.width()]=block
    return result

def selected_pixels(image,mask):
    from masks import apply_mask
    return apply_mask(image,mask)

def moved_pixels(image,mask,delta,opaque=False):
    cut=selected_pixels(image,mask)
    if opaque:
        blank=QImage(image);blank.fill(QColor('white'));result=blend_selection(image,blank,mask)
    else:
        result=QImage(image)
        # gray -> alpha for DestinationOut, without squaring the coverage.
        keep,values=gray_array(mask);rgba=np.empty((mask.height(),mask.width(),4),dtype=np.uint8);rgba[:,:,:3]=255;rgba[:,:,3]=values
        alpha=QImage(rgba.data,mask.width(),mask.height(),mask.width()*4,QImage.Format.Format_RGBA8888).copy()
        p=QPainter(result);p.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationOut);p.drawImage(0,0,alpha);p.end()
    p=QPainter(result);p.drawImage(delta,cut);p.end();return result

def wand_mask(image,x,y,tolerance,connected,cancelled):
    rgba=image.convertToFormat(QImage.Format.Format_RGBA8888);w,h=rgba.width(),rgba.height()
    if not 0<=x<w or not 0<=y<h:return None
    pixels=np.frombuffer(rgba.constBits(),dtype=np.uint8).reshape(h,rgba.bytesPerLine())[:,:w*4].reshape(h,w,4)
    chosen=np.ones((h,w),dtype=bool);seed=pixels[y,x].astype(np.int16)
    for channel in range(4):
        if cancelled.is_set():return None
        chosen&=np.abs(pixels[:,:,channel].astype(np.int16)-seed[channel])<=tolerance
    if seed[3] == 0:
        # Fully transparent pixels have no visible RGB color.
        chosen |= pixels[:, :, 3] == 0
    if connected:
        labels,_=ndimage.label(chosen);chosen=labels==labels[y,x]
    if cancelled.is_set():return None
    return from_array(chosen.astype(np.uint8)*255)

def feather_mask(mask,radius,cancelled):
    keep,values=gray_array(mask)
    result=ndimage.gaussian_filter(values.astype(np.float32),max(.1,radius/3),truncate=3,mode='constant',cval=0)
    if cancelled.is_set():return None
    return from_array(np.clip(np.round(result),0,255).astype(np.uint8))

class SelectionSignals(QObject):done=Signal(object,object,str)
class SelectionJob(QRunnable):
    def __init__(self,fn,args):super().__init__();self.fn=fn;self.args=args;self.cancelled=threading.Event();self.signals=SelectionSignals()
    def run(self):
        try:self.signals.done.emit(self,self.fn(*self.args,self.cancelled),'')
        except Exception as error:self.signals.done.emit(self,None,"Недостаточно памяти для выделения." if isinstance(error,MemoryError) else str(error) or type(error).__name__)

_UNSET=object()

class SelectionMixin:
    @property
    def selection(self):return getattr(self,'_selection',None)
    @selection.setter
    def selection(self,value):
        old=getattr(self,'_selection',None)
        if value is None or old!=value:self.selection_mask=None;self._selection_overlay_key=None
        self._selection=QRectF(value) if value is not None else None
    def init_selections(self):
        self.selection_mode='replace';self.wand_tolerance=24;self.wand_connected=True;self.wand_merged=False
        self.wand_job=None;self._lasso_points=[];self._lasso_hover=None;self.last_selection_mask=None;self._selection_work=None
    def clear_transient_selection(self):
        if self.wand_job is not None:self.wand_job.cancelled.set()
        self._lasso_points=[];self._lasso_hover=None;self._selection_work=None
    def selection_coverage(self):return QImage(self.selection_mask) if self.selection_mask is not None else rect_mask(self.doc_size,self.selection)
    def selection_contains(self,point):
        if not self.selection or not self.selection.contains(point):return False
        return self.selection_mask is None or self.selection_mask.pixelColor(int(point.x()),int(point.y())).red()>0
    def effective_selection_mode(self,modifiers):
        shift=bool(modifiers&Qt.KeyboardModifier.ShiftModifier);alt=bool(modifiers&Qt.KeyboardModifier.AltModifier)
        return 'intersect' if shift and alt else 'add' if shift else 'subtract' if alt else self.selection_mode
    def set_selection_mask(self,mask,mode='replace',record=True,before=_UNSET):
        if record:self.push_history()
        mask=combine_masks(before if before is not _UNSET else self.selection_coverage() if self.selection else None,mask,mode)
        self.selection=mask_bounds(mask);self.selection_mask=QImage(mask) if self.selection else None;self._selection_overlay_key=None
        self.selected_text=-1;self.textSelected.emit(-1);self.changed.emit();self.update()
    def select_all(self):
        target=QRectF(0,0,*self.doc_size)
        if self.selection==target and self.selection_mask is None:return
        self.push_history();self.selection=None;self.selection=target;self.selected_text=-1;self.textSelected.emit(-1);self.changed.emit();self.update()
    def cancel_selection(self):
        if self.cancel_pending_preview():return
        if self.wand_job is not None:self.wand_job.cancelled.set();return
        if self._lasso_points:self._lasso_points=[];self._lasso_hover=None;self.selectionStateChanged.emit();self.update();self.status.emit('Построение лассо отменено.');return
        selecting=self._interaction=='select' or self._interaction.startswith('selection_')
        if self.selection is not None:
            self.last_selection=QRectF(self.selection);self.last_selection_mask=QImage(self.selection_mask) if self.selection_mask is not None else None
            if not selecting and not self.drawing:self.push_history()
        if selecting or self._interaction=='move':self.drawing=False;self.preview=None;self._interaction=''
        self.selection=None;self.selected_text=-1;self.textSelected.emit(-1);self.changed.emit();self.update();self.status.emit('Выделение снято · Ctrl+Shift+D — вернуть')
    def reselect(self):
        if self.last_selection is None:return
        target=self.last_selection.intersected(QRectF(0,0,*self.doc_size))
        if target.isEmpty():return
        self.push_history();self.selection=QRectF(target)
        if self.last_selection_mask is not None and (self.last_selection_mask.width(),self.last_selection_mask.height())==self.doc_size:self.selection_mask=QImage(self.last_selection_mask)
        self.changed.emit();self.update()
    def invert_selection(self):
        keep,a=gray_array(self.selection_coverage());self.set_selection_mask(from_array(255-a))
    def feather_selection(self,radius):
        if not self.selection or radius<=0:return
        self.start_selection_job(feather_mask,(self.selection_coverage(),radius),'Растушёвка выделения…','replace')
    def selection_stamp(self):
        return (self.doc_size,tuple((l.id,l.image.cacheKey(),l.visible,l.opacity,repr(l.flags())) for l in self.layers),repr(self.text_objects),repr(self.groups),tuple((i,m.cacheKey()) for i,m in self.masks.items()),tuple(self.layer_stack),tuple(sorted(self.disabled_masks)),self.selection_mask.cacheKey() if self.selection_mask is not None else repr(self.selection))
    def start_selection_job(self,fn,args,title,mode):
        if self.wand_job is not None or self.fill_job is not None:return
        self._selection_stamp=self.selection_stamp();self._selection_job_before=self.selection_coverage() if self.selection else None;self._selection_job_mode=mode
        self.wand_job=SelectionJob(fn,args);self.selectionStateChanged.emit();self.selection_progress=QProgressDialog(title,'Отмена',0,0,self.window());self.selection_progress.setWindowModality(Qt.WindowModality.ApplicationModal);self.selection_progress.setMinimumDuration(150)
        self.selection_progress.canceled.connect(self.wand_job.cancelled.set);self.wand_job.signals.done.connect(self.finish_selection_job)
        self.selection_progress.show();QThreadPool.globalInstance().start(self.wand_job)
    def finish_selection_job(self,job,mask,error):
        if job is not self.wand_job:return
        self.wand_job=None;self.selectionStateChanged.emit();self.selection_progress.canceled.disconnect();self.selection_progress.close();self.selection_progress.deleteLater()
        if error:self.status.emit('Выделение не выполнено: '+error);return
        if mask is None or job.cancelled.is_set():return
        if self.selection_stamp()!=self._selection_stamp:self.status.emit('Документ изменился: результат выделения пропущен.');return
        self.set_selection_mask(mask,self._selection_job_mode,before=self._selection_job_before)
    def select_wand(self,pos,modifiers):
        source=self.composite_image() if self.wand_merged else self.layer_image(self.active)
        self.start_selection_job(wand_mask,(source,int(pos.x()),int(pos.y()),self.wand_tolerance,self.wand_connected),'Выбор похожих цветов…',self.effective_selection_mode(modifiers))
    def lasso_click(self,pos,modifiers):
        if not self._lasso_points:self._lasso_mode=self.effective_selection_mode(modifiers)
        if len(self._lasso_points)>=3 and (self.screen_point(pos)-self.screen_point(self._lasso_points[0])).manhattanLength()<12:self.finish_lasso();return
        if len(self._lasso_points)<2048:self._lasso_points.append(QPointF(pos));self._lasso_hover=QPointF(pos);self.selectionStateChanged.emit();self.update()
        self.status.emit('Лассо: точки мышью · Enter / двойное нажатие — замкнуть · Backspace — убрать точку · Esc — отменить')
    def finish_lasso(self):
        if len(self._lasso_points)<3:self.status.emit('Для лассо нужны хотя бы три точки.');return
        points=list(self._lasso_points);self._lasso_points=[];self._lasso_hover=None
        self.set_selection_mask(polygon_mask(self.doc_size,points),self._lasso_mode)
    def _paint_selection_mask(self,painter):
        if self.selection_mask is not None and self.selection:
            visible=QRectF(self.doc_point(QPointF(0,0)),self.doc_point(QPointF(self.width(),self.height()))).adjusted(-3/self.zoom,-3/self.zoom,3/self.zoom,3/self.zoom).intersected(self.selection)
            if visible.isEmpty():return
            key=(self.selection_mask.cacheKey(),self._marquee_phase,repr(visible),self.zoom)
            if getattr(self,'_selection_overlay_key',None)!=key:
                rect=visible.toAlignedRect();scale=min(1.,self.zoom);sample=self.selection_mask.copy(rect).scaled(max(1,round(rect.width()*scale)),max(1,round(rect.height()*scale)),Qt.AspectRatioMode.IgnoreAspectRatio,Qt.TransformationMode.SmoothTransformation)
                keep,a=gray_array(sample);solid=a>=128
                edges=solid.copy();inside=solid.copy();inside[1:]&=solid[:-1];inside[:-1]&=solid[1:];inside[:,1:]&=solid[:,:-1];inside[:,:-1]&=solid[:,1:];edges^=inside
                edges[0]|=solid[0];edges[-1]|=solid[-1];edges[:,0]|=solid[:,0];edges[:,-1]|=solid[:,-1]
                pixels=np.empty((a.shape[0],a.shape[1],4),dtype=np.uint8);pixels[:,:,:3]=(70,160,255);pixels[:,:,3]=np.round(a.astype(np.float32)*.16).astype(np.uint8)
                yy,xx=np.indices(a.shape,sparse=True);stripe=((xx+yy+self._marquee_phase*2)//5)%2==0
                pixels[edges&stripe]=(255,255,255,255);pixels[edges&~stripe]=(15,75,170,255)
                self._selection_overlay_image=QImage(pixels.data,a.shape[1],a.shape[0],a.shape[1]*4,QImage.Format.Format_RGBA8888).copy();self._selection_overlay_key=key
            rect=visible.toAlignedRect();painter.drawImage(QRectF(self.screen_point(QPointF(rect.topLeft())),self.screen_point(QPointF(rect.bottomRight()+QPoint(1,1)))),self._selection_overlay_image)
            self._overlay_label(painter,self.screen_point(self.selection.bottomLeft())+QPointF(0,23),'Выбрана подсвеченная область · Esc — снять · Shift: добавить · Alt: вычесть')
    def selection_overlay(self,painter):
        self._paint_selection_mask(painter)
        if self._lasso_points:
            points=[self.screen_point(p) for p in self._lasso_points]
            painter.setPen(QPen(QColor('#ffffff'),3));painter.setBrush(Qt.BrushStyle.NoBrush);painter.drawPolyline(QPolygonF(points))
            painter.setPen(QPen(QColor('#267ee5'),1));painter.drawPolyline(QPolygonF(points))
            if self._lasso_hover:painter.drawLine(points[-1],self.screen_point(self._lasso_hover))
            painter.setBrush(QColor('#ffffff'))
            for pt in points:painter.drawEllipse(pt,3,3)
    def raw_pixels(self,layer):
        from text_model import draw_text
        image=QImage(layer.image);owned=[t for t in self.text_objects if t.get("layer_id")==layer.id]
        if not owned:return image
        p=QPainter(image)
        for text in owned:draw_text(p,text)
        p.end();return image
    def rasterize_for_selection(self,ids):
        for layer in self.layers:
            if layer.id in ids and any(t.get('layer_id')==layer.id for t in self.text_objects):layer.image=self.raw_pixels(layer);layer.kind='raster'
        self.text_objects=[t for t in self.text_objects if t.get('layer_id') not in ids];self.selected_text=-1;self.textSelected.emit(-1)
    def masked_stroke(self,a,b,callback,mask_target=False):
        mask=self.selection_mask
        if mask is None:return callback(a,b)
        key='@mask/'+self.editing_mask if mask_target else self.active.id
        current=self.masks[self.editing_mask] if mask_target else self.active.image
        if self._selection_work is None or getattr(self,'_selection_paint_id',None)!=key:
            self._selection_base=QImage(current);self._selection_work=QImage(current);self._selection_paint_id=key
        if mask_target:self.masks[self.editing_mask]=self._selection_work
        else:self.active.image=self._selection_work
        callback(a,b)
        self._selection_work=self.masks[self.editing_mask] if mask_target else self.active.image
        radius=self.brush_size+4;rect=QRectF(a,b).normalized().adjusted(-radius,-radius,radius,radius)
        result=blend_selection(self._selection_base,self._selection_work,mask,rect,current)
        if mask_target:self.masks[self.editing_mask]=result
        else:self.active.image=result
    def erase_selected_pixels(self,cut=False):
        if self.selection_mask is None:return False
        if self.editing_mask in self.masks:
            if cut:self.copy_selection()
            self.fill_mask(0,True);return True
        if not self.can_edit(erase=True):return True
        if cut:self.copy_selection()
        self.push_history();self.rasterize_for_selection({self.active.id});blank=transparent_image(*self.doc_size)
        self.active.image=blend_selection(self.active.image,blank,self.selection_mask,self.selection);self.changed.emit();self.update();return True
