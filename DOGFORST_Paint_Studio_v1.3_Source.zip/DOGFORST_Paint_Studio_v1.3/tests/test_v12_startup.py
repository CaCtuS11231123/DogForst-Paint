import os
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtGui import QColor, QImage
from PySide6.QtWidgets import QApplication, QFileDialog, QPushButton


def make_photo(tmp_path, size=(63, 41)):
    path = tmp_path / 'тестовое фото.png'
    image = QImage(*size, QImage.Format.Format_ARGB32)
    image.fill(QColor('#4186ad'))
    assert image.save(str(path))
    return path


def click_dialog_button(text):
    dialog = QApplication.activeModalWidget()
    for button in dialog.findChildren(QPushButton):
        if button.text() == text:
            button.click()
            return
    dialog.reject()
    raise AssertionError(f'Button not found: {text}')


def test_start_screen_import_uses_actual_photo_dimensions(window, tmp_path, monkeypatch):
    photo = make_photo(tmp_path)
    monkeypatch.setattr(QFileDialog, 'getOpenFileName', lambda *args: (str(photo), ''))
    QTimer.singleShot(0, lambda: click_dialog_button('Импортировать изображение…'))
    window.show_start_screen()
    assert window.canvas.doc_size == (63, 41)
    assert len(window.canvas.layers) == 1
    assert window.canvas.active.image.pixelColor(0, 0) == QColor('#4186ad')


def test_new_canvas_dialog_import_keeps_existing_project_when_picker_cancelled(window, monkeypatch):
    window.canvas.new_document(80, 72)
    window.current_file = 'сохранённый проект.mpaint'
    window.mark_dirty()
    monkeypatch.setattr(QFileDialog, 'getOpenFileName', lambda *args: ('', ''))
    def confirm():
        raise AssertionError('A cancelled picker must not prompt to replace the current project')
    with monkeypatch.context() as scoped:
        scoped.setattr(window, 'confirm_document_change', confirm)
        QTimer.singleShot(0, lambda: click_dialog_button('Импортировать изображение…'))
        assert window.new_document() is False
    assert window.canvas.doc_size == (80, 72)
    assert window.current_file == 'сохранённый проект.mpaint'
    assert window.dirty


def test_add_photo_from_layers_preserves_canvas_and_undo(window, tmp_path, monkeypatch):
    photo = make_photo(tmp_path)
    window.canvas.new_document(100, 72)
    base = window.canvas.active.id
    monkeypatch.setattr(QFileDialog, 'getOpenFileName', lambda *args: (str(photo), ''))
    window.layer_photo_add_button.click()
    assert window.canvas.doc_size == (100, 72)
    assert len(window.canvas.layers) == 2
    assert window.canvas.layers[0].id == base
    assert window.canvas.active.id in window.canvas.raster_objects
    window.undo()
    assert len(window.canvas.layers) == 1
    assert window.canvas.layers[0].id == base


def test_diagnostic_uses_real_startup_and_reaches_qt_event_loop(tmp_path):
    root = Path(__file__).resolve().parents[1]
    report = tmp_path / 'startup report.txt'
    env = dict(os.environ, DOGFORST_DATA_DIR=str(tmp_path / 'data'), QT_QPA_PLATFORM='offscreen')
    result = subprocess.run(
        [sys.executable, str(root / 'main.py'), '--diagnose-startup', str(report)],
        cwd=root, env=env, capture_output=True, text=True, timeout=20)
    assert result.returncode == 0, result.stderr + report.read_text(encoding='utf-8')
    text = report.read_text(encoding='utf-8')
    assert 'Checking package integrity.' in text
    from release_notes import CURRENT_VERSION
    assert f'DOGFORST Paint Studio {CURRENT_VERSION}' in text
    assert 'Startup OK.' in text
