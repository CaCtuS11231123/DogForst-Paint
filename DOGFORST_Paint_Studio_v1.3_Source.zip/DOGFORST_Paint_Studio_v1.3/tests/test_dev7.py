import json,zipfile,uuid
from pathlib import Path
import pytest
from PySide6.QtCore import Qt,QPointF,QPoint,QRectF,QEvent,QMimeData,QUrl
from PySide6.QtGui import QImage,QColor,QPainter,QMouseEvent,QDragEnterEvent
from PySide6.QtWidgets import QDialog,QFileDialog
from PySide6.QtTest import QTest
from layers import Layer,transparent_image
from raster_objects import DEFAULTS,clone_object,render_object,read_image
from project_manager import read_project,save_project
from recovery import DocumentSnapshot,RecoveryStore
from image_dialogs import PlacementDialog,ImportChoice
from brush_panel import BrushDialog


def setup(window,size=(300,200)):
    c=window.canvas;c.new_document(*size);c.pan=QPointF();c.zoom=1.;c.history.clear();c.future.clear();c.drawing=False
    return c

def source(w=80,h=60):
    image=transparent_image(w,h);image.fill(QColor('#e94969'));p=QPainter(image);p.fillRect(w//2,0,w//2,h,QColor('#3e9fe2'));p.end();return image

def imported(window):
    c=setup(window);c.import_object(source(),'Фото');return c

def move_event(c,pos,modifiers=Qt.KeyboardModifier.NoModifier):
    point=QPointF(pos);c.mouseMoveEvent(QMouseEvent(QEvent.Type.MouseMove,point,point,Qt.MouseButton.NoButton,Qt.MouseButton.LeftButton,modifiers))

def test_selected_effect_moves_under_text_without_switching_layer(window):
    c=setup(window);bg=c.active;bg.image.fill(QColor('white'));c.add_layer();effect=c.active
    p=QPainter(effect.image);p.fillRect(30,30,100,80,QColor('red'));p.end()
    c.add_layer();text=c.active;text.kind='text';c.text_objects=[dict(text='OVERLAP',x=30,y=30,size=42,color='#202020',layer_id=text.id)]
    c.set_selected_nodes({effect.id},effect.id);window.set_tool('Перемещение')
    before_bg=bg.image.copy();before_text=dict(c.text_objects[0]);c.history.clear()
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(65,65));QTest.mouseMove(c,QPoint(85,75));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(85,75))
    assert c.active.id==effect.id and c.selected_text==-1
    assert effect.image.pixelColor(35,35).alpha()==0 and effect.image.pixelColor(55,45)==QColor('red')
    assert bg.image==before_bg and c.text_objects[0]==before_text
    c.undo();assert c.active.image.pixelColor(35,35)==QColor('red')

def test_selecting_layer_in_panel_exits_global_move_and_auto(window):
    c=imported(window);window.set_tool('Перемещение');window.move_scope.setCurrentIndex(2);window.auto_select_check.setChecked(True)
    window.layer_list.setCurrentRow(window.layer_list.count()-1);window.select_layer_items()
    assert not c.move_all_layers and not c.auto_select_layer and window.move_scope.currentIndex()==0


def test_import_fits_and_keeps_original(window):
    c=setup(window);image=source(800,400);assert c.import_object(image,'Большое фото')
    obj=c.raster_objects[c.active.id]
    assert (obj['width'],obj['height'],obj['x'],obj['y'])==(300.,150.,0.,25.)
    assert obj['source']==image and c.object_handles()=={}
    window.set_tool('Перемещение');assert c.object_handles()
    c.undo();assert len(c.layers)==1 and not c.raster_objects
    c.redo();assert c.raster_objects[c.active.id]['source']==image


def test_repeated_resize_restores_from_original(window):
    c=imported(window);identifier=c.active.id;initial=c.active.image.copy();obj=clone_object(c.raster_objects[identifier])
    c.set_object(c.active,dict(obj,width=8.,height=6.));assert c.active.image!=initial
    c.set_object(c.active,obj);assert c.active.image==initial and c.raster_objects[identifier]['source']==source()
    c.undo();assert c.raster_objects[identifier]['width']==8
    c.redo();assert c.active.image==initial


def test_corner_drag_live_and_single_undo(window):
    c=imported(window);window.set_tool('Перемещение');before=clone_object(c.raster_objects[c.active.id]);c.commit_history(force=True);c.history.clear()
    point=c.object_handles()['br'].toPoint();QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=point)
    QTest.mouseMove(c,point+QPoint(40,30));current=c.raster_objects[c.active.id]
    assert c.drawing and current['width']==120 and current['height']==90
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=point+QPoint(40,30))
    c.undo();assert c.raster_objects[c.active.id]['width']==before['width'] and not c.history
    c.redo();assert c.raster_objects[c.active.id]['width']==120


def test_rotation_drag_live_shift_and_escape(window):
    c=imported(window);window.set_tool('Перемещение');c.commit_history(force=True);c.history.clear();before=c.active.image.copy()
    point=c.object_handles()['rotate'].toPoint();QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=point)
    move_event(c,point+QPoint(50,30),Qt.KeyboardModifier.ShiftModifier)
    assert c.drawing and c.raster_objects[c.active.id]['rotation']%15==0 and c.raster_objects[c.active.id]['rotation']!=0
    QTest.keyClick(c,Qt.Key.Key_Escape)
    assert not c.drawing and c.active.image==before and not c.history


def test_existing_effect_can_resize_then_reedit(window):
    c=setup(window);p=QPainter(c.active.image);p.fillRect(20,30,80,60,QColor('red'));p.end()
    assert not c.raster_objects;window.set_tool('Перемещение');assert c.object_handles()
    obj=c.object_for_layer();c.set_object(c.active,dict(obj,width=160.,height=120.,rotation=20.))
    assert c.raster_objects[c.active.id]['source'].size()==source().size()
    c.undo();assert not c.raster_objects and c.active.image.pixelColor(20,30)==QColor('red')


def test_placement_preserves_mask_alignment_and_validity(window):
    c=imported(window);obj=clone_object(c.raster_objects[c.active.id]);c.add_mask();identifier=c.active.id
    p=QPainter(c.masks[identifier]);p.fillRect(int(obj['x'])+10,int(obj['y'])+10,10,10,QColor('black'));p.end()
    c.set_object(c.active,dict(obj,x=obj['x']+20,y=obj['y']+15,width=160.,height=120.))
    from masks import validate_mask
    validate_mask(c.masks[identifier],c.doc_size)
    assert c.masks[identifier].pixelColor(int(obj['x'])+20+25,int(obj['y'])+15+25).red()==0
    c.undo();assert c.masks[identifier].pixelColor(int(obj['x'])+15,int(obj['y'])+15).red()==0


def test_object_move_nudge_keeps_source_and_parameters(window):
    c=imported(window);identifier=c.active.id;before=clone_object(c.raster_objects[identifier]);window.set_tool('Перемещение')
    c.move_selected_by(QPointF(12,8));after=c.raster_objects[identifier]
    assert after['x']==before['x']+12 and after['source']==before['source']
    assert c.active.image==render_object(after,c.doc_size)
    c.undo();assert c.raster_objects[identifier]['x']==before['x']


@pytest.mark.parametrize('action',['paint','filter','delete','merge'])
def test_pixel_operations_rasterize_and_undo_restores_source(window,action):
    c=imported(window);identifier=c.active.id;before=c.active.image.copy();c.commit_history(force=True);c.history.clear()
    if action=='paint':
        window.set_tool('Кисть');QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=QPoint(130,90))
    elif action=='filter':c.apply_filter('invert')
    elif action=='delete':c.delete_layer()
    else:c.merge_down()
    assert identifier not in c.raster_objects
    c.undo();assert identifier in c.raster_objects and next(l for l in c.layers if l.id==identifier).image==before
    c.redo();assert identifier not in c.raster_objects


@pytest.mark.parametrize('group',[False,True])
def test_duplicate_retains_independent_object(window,group):
    c=imported(window);original=c.active.id
    if group:c.create_group()
    c.duplicate_layer();assert len(c.raster_objects)==2
    duplicate=next(i for i in c.raster_objects if i!=original)
    c.set_selected_nodes({duplicate});obj=clone_object(c.raster_objects[duplicate]);c.set_object(c.active,dict(obj,width=120.))
    assert c.raster_objects[original]['width']==80 and c.raster_objects[duplicate]['width']==120
    c.undo();assert c.raster_objects[duplicate]['width']==80


def test_repeat_texture_and_replace_preserve_geometry(window,tmp_path,monkeypatch):
    c=setup(window,(160,120));image=source(10,10);c.import_object(image,'Текстура',True);obj=c.raster_objects[c.active.id]
    assert obj['repeat'] and obj['width']==160 and c.active.image.pixelColor(1,1)==c.active.image.pixelColor(11,1)
    dialog=PlacementDialog(obj,c.doc_size,c.active,window);original=dialog.values();path=tmp_path/'replacement.png';assert source(40,20).save(str(path))
    monkeypatch.setattr(QFileDialog,'getOpenFileName',lambda *a,**k:(str(path),'PNG'))
    dialog.replace_source();new=dialog.values()
    assert all(new[k]==original[k] for k in DEFAULTS) and new['source'].width()==40
    dialog.reject();assert c.raster_objects[c.active.id]['source']==image
    c.set_object(c.active,new);assert c.raster_objects[c.active.id]['source'].width()==40


def test_dialog_aspect_flip_opacity_and_cancel(window,monkeypatch):
    c=imported(window);before=c.active.image.copy();obj=c.raster_objects[c.active.id]
    dialog=PlacementDialog(obj,c.doc_size,c.active);dialog.w.setValue(160);assert dialog.h.value()==120
    dialog.flip_h.setChecked(True);dialog.rotation.setValue(35);dialog.opacity.setValue(65);dialog.reject()
    assert c.active.image==before and c.active.opacity==1
    def accept(d):d.w.setValue(160);d.rotation.setValue(35);d.opacity.setValue(65);return QDialog.DialogCode.Accepted
    monkeypatch.setattr(PlacementDialog,'exec',accept);window.edit_placement()
    assert c.active.opacity==.65 and c.raster_objects[c.active.id]['width']==160 and c.raster_objects[c.active.id]['rotation']==35


def test_v8_roundtrip_autosave_and_manual_snapshot(window,tmp_path):
    c=imported(window);c.add_mask(150);identifier=c.active.id;c.raster_objects[identifier]['repeat']=True;c.set_object(c.active,c.raster_objects[identifier])
    path=tmp_path/'photo.mpaint';c.save_project(path,backup=False)
    with zipfile.ZipFile(path) as z:assert json.loads(z.read('project.json'))['version']==8
    result=read_project(path);assert result.raster_objects[identifier]['source']==source() and result.masks
    c.apply_loaded_project(result);assert c.raster_objects[identifier]['repeat']
    snap=DocumentSnapshot.capture(c);c.raster_objects[identifier]['source'].fill(QColor('green'))
    assert dict(snap.raster_objects)[identifier]['source']==source()
    store=RecoveryStore(tmp_path/'recovery');record=store.write(snap,uuid.uuid4().hex,3)
    assert read_project(record.path).raster_objects[identifier]['source']==source()
    from safety import ManualWriteJob
    job=ManualWriteJob(snap,tmp_path/'manual.mpaint',dict(backup=False));job.run()
    assert read_project(tmp_path/'manual.mpaint').raster_objects[identifier]['source']==source()


@pytest.mark.parametrize('damage',['owner','duplicate','path','version','nan','zero','header','budget'])
def test_bad_v8_never_replaces_document(window,tmp_path,damage,monkeypatch):
    c=imported(window);path=tmp_path/'valid.mpaint';c.save_project(path,backup=False)
    with zipfile.ZipFile(path) as z:entries={n:z.read(n) for n in z.namelist()}
    manifest=json.loads(entries['project.json']);obj=manifest['raster_objects'][0]
    if damage=='owner':obj['node_id']='missing'
    elif damage=='duplicate':manifest['raster_objects'].append(dict(obj))
    elif damage=='path':obj['path']='../bad.png'
    elif damage=='version':manifest['version']=7
    elif damage=='nan':obj['rotation']=float('nan')
    elif damage=='zero':obj['width']=0
    elif damage=='header':entries[obj['path']]=b'broken'
    else:
        import project_manager
        monkeypatch.setattr(project_manager,'MAX_TOTAL_PIXELS',120001) # two layers fit, retained source exceeds it
    entries['project.json']=json.dumps(manifest).encode();bad=tmp_path/'bad.mpaint'
    with zipfile.ZipFile(bad,'w') as z:
        for n,data in entries.items():z.writestr(n,data)
    before=c.composite_image();before_id=c.active.id
    with pytest.raises(ValueError):c.load_project(bad)
    assert c.active.id==before_id and c.composite_image()==before and c.raster_objects


def test_import_multiple_drop_choice_and_cancel(window,tmp_path,monkeypatch):
    c=setup(window);paths=[]
    for index in range(2):
        path=tmp_path/f'photo{index}.png';source().save(str(path));paths.append(str(path))
    monkeypatch.setattr(ImportChoice,'exec',lambda d:QDialog.DialogCode.Rejected)
    window.import_paths(paths);assert len(c.layers)==1
    def accept(d):d.mode='layer';return QDialog.DialogCode.Accepted
    monkeypatch.setattr(ImportChoice,'exec',accept);window.import_paths(paths)
    assert len(c.layers)==3 and len(c.raster_objects)==2 and c.tool=='Перемещение'
    mime=QMimeData();mime.setUrls([QUrl.fromLocalFile(paths[0])]);event=QDragEnterEvent(QPoint(50,50),Qt.DropAction.CopyAction,mime,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier)
    window.dragEnterEvent(event);assert event.isAccepted()
    bad=QMimeData();bad.setUrls([QUrl('https://example.org/photo.png')]);event=QDragEnterEvent(QPoint(50,50),Qt.DropAction.CopyAction,bad,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier)
    window.dragEnterEvent(event);assert not event.isAccepted()


def test_new_photo_document_uses_own_size_and_original(window,tmp_path,monkeypatch):
    c=setup(window);path=tmp_path/'photo.png';source(90,50).save(str(path));monkeypatch.setattr(window,'confirm_document_change',lambda:True)
    window.import_paths([str(path)],'document');assert c.doc_size==(90,50) and len(c.layers)==1 and c.raster_objects and not window.dirty


def test_brush_edit_opens_current_settings_directly(window,monkeypatch):
    c=setup(window);window.set_tool('Кисть')
    def accept(d):
        assert d.pages.currentIndex()==1
        d.shape.setCurrentIndex(d.shape.findData('square'));d.color.color=QColor('red');d.color.refresh();d.color.colorChanged.emit()
        d.outline_check.setChecked(True);d.outline.setValue(4);d.size.setValue(30);return QDialog.DialogCode.Accepted
    monkeypatch.setattr(BrushDialog,'exec',accept);window.brush_edit_button.click()
    assert c.brush_shape=='square' and c.color==QColor('red') and c.brush_outline==4 and c.brush_size==30
    assert window.settings.value('brush/outline',type=int)==4
    window.set_tool('Выделение');assert not window.brush_edit_button.isEnabled()


def test_outlined_stroke_color_edge_opacity_and_undo(window):
    c=setup(window);window.set_tool('Кисть');c.brush_stabilizer=0;c.brush_size=30;c.brush_outline=4;c.color=QColor('red');c.brush_outline_color=QColor('blue');c.brush_opacity=50
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(40,100))
    for x in range(50,181,10):QTest.mouseMove(c,QPoint(x,100))
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(180,100))
    center=c.active.image.pixelColor(100,100);edge=c.active.image.pixelColor(100,87)
    assert center.red()>250 and center.blue()<3 and 126<=center.alpha()<=128
    assert edge.blue()>250 and edge.red()<3 and 126<=edge.alpha()<=128
    assert c._outlined_base is None
    c.undo();assert c.active.image==transparent_image(*c.doc_size)


def test_square_brush_shape_and_mask_support(window):
    c=setup(window);c.brush_shape='square';c.brush_size=20;c.brush_stabilizer=0;c.color=QColor('red')
    QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=QPoint(100,100));assert c.active.image.pixelColor(92,92)==QColor('red')
    c.add_mask();c.start_mask_edit();c.color=QColor('black');QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=QPoint(100,100))
    from masks import validate_mask
    validate_mask(c.masks[c.active.id],c.doc_size);assert c.masks[c.active.id].pixelColor(92,92).red()==0


def test_object_off_canvas_move_back_keeps_original_pixels(window):
    c=imported(window);before=c.active.image.copy();window.set_tool('Перемещение')
    c.move_selected_by(QPointF(500,0));assert c.active.image==transparent_image(*c.doc_size)
    c.move_selected_by(QPointF(-500,0));assert c.active.image==before


def test_only_one_brush_edit_button_in_tools_panel(window):
    from PySide6.QtWidgets import QPushButton
    buttons=[b for b in window.findChildren(QPushButton) if b.text()=='Редактировать кисть…']
    assert buttons==[window.brush_edit_button]
    assert window.tools_dock.isAncestorOf(window.brush_edit_button)


def test_source_budget_rejects_before_import_mutation(window,monkeypatch):
    c=setup(window);before=c.composite_image()
    import raster_objects
    monkeypatch.setattr(raster_objects,'LIMIT',120001)
    with pytest.raises(ValueError):c.import_object(source(),'Фото')
    assert len(c.layers)==1 and not c.raster_objects and c.composite_image()==before


def test_export_and_save_original_files_untouched(window,tmp_path):
    c=setup(window);original=tmp_path/'original.png';source().save(str(original));old=original.read_bytes()
    window.import_paths([str(original)],'layer');obj=clone_object(c.raster_objects[c.active.id])
    c.set_object(c.active,dict(obj,flip_h=True,rotation=25.))
    for ext in ['png','jpg','bmp','webp']:
        target=tmp_path/('result.'+ext);c.export_image(str(target));assert not QImage(str(target)).isNull()
    assert original.read_bytes()==old
    path=tmp_path/'project.mpaint';c.save_project(path,backup=False);loaded=read_project(path);c.apply_loaded_project(loaded)
    assert c.raster_objects[c.active.id]['flip_h'] and c.raster_objects[c.active.id]['rotation']==25


def test_canvas_resize_retains_placement_and_original(window,monkeypatch):
    c=imported(window);identifier=c.active.id;before=clone_object(c.raster_objects[identifier])
    original_exec=QDialog.exec
    def resize(d):
        from PySide6.QtWidgets import QSpinBox
        spins=d.findChildren(QSpinBox)
        if len(spins)==2:spins[0].setValue(400);spins[1].setValue(300);return QDialog.DialogCode.Accepted
        return original_exec(d)
    monkeypatch.setattr(QDialog,'exec',resize);window.resize_canvas()
    obj=c.raster_objects[identifier]
    assert c.doc_size==(400,300) and obj['x']==before['x']+50 and obj['y']==before['y']+50
    assert c.active.image==render_object(obj,c.doc_size)
    c.undo();assert c.doc_size==(300,200) and c.raster_objects[identifier]['x']==before['x']


def test_drop_on_canvas_imports_and_refused_transform_budget(window,tmp_path,monkeypatch):
    from PySide6.QtGui import QDropEvent
    c=setup(window);path=tmp_path/'photo.png';source().save(str(path))
    mime=QMimeData();mime.setUrls([QUrl.fromLocalFile(str(path))])
    def accept(d):d.mode='layer';return QDialog.DialogCode.Accepted
    monkeypatch.setattr(ImportChoice,'exec',accept)
    event=QDropEvent(QPointF(50,50),Qt.DropAction.CopyAction,mime,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier)
    c.dropEvent(event);assert len(c.raster_objects)==1 and event.isAccepted()
    c.new_document(300,200);c.active.image.fill(QColor('red'))
    import raster_objects
    monkeypatch.setattr(raster_objects,'LIMIT',60001)
    assert c.object_for_layer() is None and 'бюджета' in c._object_error


def test_brush_editor_disables_inapplicable_settings(window):
    dialog=BrushDialog(window.canvas);dialog.pick('Ластик',None)
    assert not dialog.color.isEnabled() and not dialog.outline_check.isEnabled() and not dialog.shape.isEnabled()
    assert not dialog.hardness.isEnabled() and not dialog.stabilizer.isEnabled()
    dialog.pick('Кисть',None);assert dialog.hardness.isEnabled() and dialog.color.isEnabled()
    dialog.outline_check.setChecked(True);assert not dialog.hardness.isEnabled() and dialog.outline.isEnabled()
    dialog.reject()
