import json
import uuid
import zipfile
import pytest
from PySide6.QtCore import Qt, QPoint, QPointF, QRectF, QMimeData
from PySide6.QtGui import QColor, QImage
from PySide6.QtTest import QTest
from canvas import PaintCanvas
from layers import Layer, transparent_image
from project_manager import read_project
from recovery import DocumentSnapshot, RecoveryStore
from layer_list import MIME
from pearl import AURORA_NAME, AURORA_PALETTE, accent_at
from themes import THEMES, ThemeDialog


def prepare(window, count=4):
    c=window.canvas;c.new_document(300,220)
    c.layers=[Layer(f'Слой {i+1}',transparent_image(300,220)) for i in range(count)]
    c.active_layer=count-1;c._selected_layer_ids={c.active.id}
    c.zoom=1.;c.pan=QPointF();c.history.clear();c.future.clear()
    window.refresh_layers()
    return c


def commit(c):
    c.commit_history(force=True)


def select_rect(window):
    c=window.canvas;window.set_tool('Выделение')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(20,20))
    QTest.mouseMove(c,QPoint(120,100))
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(120,100))
    return QRectF(20,20,100,80)


def test_selection_creation_resize_clear_and_reselect_undo(window):
    c=prepare(window,1);pixels=c.active.image.copy()
    rect=select_rect(window);assert c.selection==rect
    c.undo();assert c.selection is None
    c.redo();assert c.selection==rect
    point=c.selection_handles()['br'].toPoint()
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=point)
    QTest.mouseMove(c,point+QPoint(20,10))
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=point+QPoint(20,10))
    assert c.selection==QRectF(20,20,120,90)
    c.undo();assert c.selection==rect
    QTest.keyClick(c,Qt.Key.Key_D,Qt.KeyboardModifier.ControlModifier)
    assert c.selection is None and c.last_selection==rect and not c.drawing
    c.undo();assert c.selection==rect
    c.redo();assert c.selection is None
    QTest.keyClick(c,Qt.Key.Key_D,Qt.KeyboardModifier.ControlModifier|Qt.KeyboardModifier.ShiftModifier)
    assert c.selection==rect and c.active.image==pixels


def test_escape_during_marquee_does_not_leave_dragging(window):
    c=prepare(window,1);window.set_tool('Выделение')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(10,10))
    QTest.mouseMove(c,QPoint(90,80));QTest.keyClick(c,Qt.Key.Key_Escape)
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(150,140))
    assert c.selection is None and not c.drawing and c._interaction==''
    assert c.active.image==transparent_image(*c.doc_size)
    window.set_tool('Кисть');QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=QPoint(50,50))
    assert c.active.image.pixelColor(50,50).alpha()>0


def test_reselect_does_not_leak_between_documents(window):
    c=prepare(window,1);select_rect(window);c.cancel_selection();assert c.last_selection
    c.new_document(100,100);c.reselect();assert c.selection is None and c.last_selection is None


def test_native_ctrl_shift_multiselect_survives_refresh(window):
    c=prepare(window);view=window.layer_list
    def click(row,mod=Qt.KeyboardModifier.NoModifier):
        QTest.mouseClick(view.viewport(),Qt.MouseButton.LeftButton,mod,view.visualItemRect(view.item(row)).center())
    click(0);click(2,Qt.KeyboardModifier.ControlModifier)
    expected={view.item(i).data(Qt.ItemDataRole.UserRole+2) for i in (0,2)}
    assert c.selected_layer_ids()==expected
    for _ in range(5):window.refresh_layers()
    assert {i.data(Qt.ItemDataRole.UserRole+2) for i in view.selectedItems()}==expected
    click(0);click(3,Qt.KeyboardModifier.ShiftModifier)
    assert len(c.selected_layer_ids())==4
    assert all(l.visible for l in c.layers) and len(c.history)==0


def test_multiple_duplicate_delete_and_exact_undo(window):
    c=prepare(window);old=[l.id for l in c.layers]
    c.layers[1].image.setPixelColor(4,5,QColor('red'))
    text=dict(text='Кириллица',x=20,y=30,size=24,layer_id=c.layers[3].id)
    c.layers[3].kind='text';c.text_objects=[text]
    ids={old[1],old[3]};c.set_selected_layers(ids,old[3])
    before=c.composite_image();c.duplicate_layer();assert len(c.layers)==6 and len(c.selected_layers())==2
    assert len(c.text_objects)==2 and c.text_objects[1]['layer_id']!=text['layer_id']
    clones={l.id for l in c.selected_layers()}
    c.text_objects[1]['text']='Копия';assert c.text_objects[0]['text']=='Кириллица'
    c.undo();assert [l.id for l in c.layers]==old and c.composite_image()==before
    assert c.selected_layer_ids()==ids
    c.redo();assert c.selected_layer_ids()==clones
    c.delete_layer();assert [l.id for l in c.layers]==old and len(c.text_objects)==1
    c.undo();assert len(c.layers)==6 and c.selected_layer_ids()==clones


def test_delete_all_and_protected_bulk_are_atomic(window):
    c=prepare(window);old=[l.id for l in c.layers]
    c.set_selected_layers(old);c.delete_layer();assert [l.id for l in c.layers]==old and not c.history
    c.set_selected_layers(old[1:]);c.layers[2].locked=True;c.delete_layer()
    assert [l.id for l in c.layers]==old and not c.history


def test_bulk_move_raster_and_text_skips_locks_and_undo(window):
    c=prepare(window);ids=[l.id for l in c.layers]
    for l in c.layers:l.image.setPixelColor(10,10,QColor('red'))
    c.layers[1].position_locked=True;c.layers[2].locked=True
    c.text_objects=[dict(text='ABC',x=30,y=30,size=20,layer_id=ids[3])]
    c.set_selected_layers(ids,ids[3]);c.move_selected_by(QPointF(7,9))
    for i in (0,3):assert c.layers[i].image.pixelColor(17,19)==QColor('red')
    for i in (1,2):assert c.layers[i].image.pixelColor(10,10)==QColor('red')
    assert c.text_objects[0]['x']==37 and c.text_objects[0]['y']==39
    c.undo();assert c.text_objects[0]['x']==30 and all(l.image.pixelColor(10,10)==QColor('red') for l in c.layers)
    c.redo();assert c.text_objects[0]['x']==37


def test_multimove_by_drag_does_not_autoselect_one_layer(window):
    c=prepare(window,2);ids=[l.id for l in c.layers]
    for l in c.layers:l.image.setPixelColor(10,10,QColor('red'))
    c.set_selected_layers(ids);window.set_tool('Перемещение')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(10,10))
    QTest.mouseMove(c,QPoint(30,20));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(30,20))
    assert c.selected_layer_ids()==set(ids)
    assert all(l.image.pixelColor(30,20)==QColor('red') for l in c.layers)


@pytest.mark.parametrize('key',['locked','position_locked','alpha_locked','color_label'])
def test_flags_and_labels_undo_redo_roundtrip(window,tmp_path,key):
    c=prepare(window);ids=[l.id for l in c.layers];c.set_selected_layers(ids[1:3],ids[2])
    value='#719de0' if key=='color_label' else True
    c.set_selected_flag(key,value);commit(c)
    assert all(getattr(l,key)==value for l in c.layers[1:3])
    assert c.history_engine.statistics()['payload_bytes']==0
    c.undo();assert not any(getattr(l,key) for l in c.layers)
    c.redo();assert c.selected_layer_ids()==set(ids[1:3])
    path=tmp_path/'Слои.mpaint';c.save_project(path)
    loaded=read_project(path);assert [l.flags() for l in loaded[1]]==[l.flags() for l in c.layers]
    with zipfile.ZipFile(path) as z:assert json.loads(z.read('project.json'))['version']==4


def test_autosave_snapshot_preserves_independent_locks(window,tmp_path):
    c=prepare(window,2);c.active.locked=True;c.active.color_label='#ad8ed0'
    snap=DocumentSnapshot.capture(c);c.active.locked=False;c.active.color_label=''
    store=RecoveryStore(tmp_path/'recovery');record=store.write(snap,uuid.uuid4().hex,1)
    layer=store.read(record)[1][-1];assert layer.locked and layer.color_label=='#ad8ed0'


@pytest.mark.parametrize('tool',['Кисть','Ластик','Прямоугольник','Заливка'])
def test_locked_layer_cannot_be_modified_by_tool(window,tool):
    c=prepare(window,1);c.active.locked=True;window.set_tool(tool)
    before=c.active.image.copy()
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(20,20))
    QTest.mouseMove(c,QPoint(70,60));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(70,60))
    assert c.active.image==before and not c.history and c.fill_job is None


def test_locked_layer_blocks_delete_cut_filter_and_merge(window):
    c=prepare(window,2);c.active.image.fill(QColor('red'));c.active.locked=True
    c.selection=QRectF(0,0,30,30);before=c.active.image.copy();ids=[l.id for l in c.layers]
    QTest.keyClick(c,Qt.Key.Key_Delete);c.cut_selection();c.apply_filter('invert');c.merge_down();c.delete_layer()
    assert c.active.image==before and [l.id for l in c.layers]==ids and not c.history


def test_position_lock_blocks_text_handles_and_keyboard_move(window):
    c=prepare(window,1);c.active.kind='text';c.active.position_locked=True
    c.text_objects=[dict(text='Hello',size=30,x=40,y=40,layer_id=c.active.id)]
    c.select_text(0);window.set_tool('Текст');before=dict(c.text_objects[0])
    point=c.text_handles(c.text_objects[0])['size'].toPoint()
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=point)
    QTest.mouseMove(c,point+QPoint(30,30));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=point+QPoint(30,30))
    QTest.keyClick(c,Qt.Key.Key_Right)
    assert c.text_objects[0]==before and not c.history


def test_locked_text_cannot_be_changed_in_inspector(window):
    c=prepare(window,1);c.active.kind='text';c.active.locked=True
    c.text_objects=[dict(text='Hello',size=30,x=40,y=40,layer_id=c.active.id)]
    c.select_text(0);window.set_tool('Текст');before=dict(c.text_objects[0])
    window.text_controls.size.setValue(70)
    assert c.text_objects[0]==before and window.text_controls.size.value()==30 and not c.history


@pytest.mark.parametrize('tool',['Кисть','Маркер','Мягкая кисть','Прямоугольник','Ластик'])
def test_alpha_lock_preserves_all_alpha_and_prevents_expansion(window,tool):
    c=prepare(window,1);c.active.image.setPixelColor(30,30,QColor(10,30,60,111))
    before=c.active.image.copy();c.active.alpha_locked=True;c.brush_size=30;c.color=QColor('red');window.set_tool(tool)
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(20,20))
    QTest.mouseMove(c,QPoint(40,40));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(40,40))
    image=c.active.image
    assert image.pixelColor(30,30).alpha()==111
    assert all(image.pixelColor(x,y).alpha()==before.pixelColor(x,y).alpha() for y in range(15,46) for x in range(15,46))
    if tool=='Ластик':assert image==before
    elif tool!='Прямоугольник':assert image!=before
    c.undo();assert c.active.image==before


def test_alpha_lock_fill_in_background_preserves_transparency(window):
    c=prepare(window,1);c.active.image.setPixelColor(30,30,QColor(10,30,60,111))
    c.active.alpha_locked=True;c.color=QColor('red');c.fill_tolerance=255
    before=c.active.image.copy();c.flood_fill(30,30)
    for _ in range(200):
        QTest.qWait(10)
        if c.fill_job is None:break
    assert c.fill_job is None
    assert c.active.image.pixelColor(30,30).alpha()==111 and c.active.image.pixelColor(0,0).alpha()==0
    c.undo();assert c.active.image==before


def test_drag_drop_reorders_by_ids_preserving_flags_selection_and_undo(window):
    c=prepare(window);ids=[l.id for l in c.layers]
    c.layers[1].visible=False;c.layers[1].position_locked=True
    c.set_selected_layers({ids[1],ids[3]},ids[3]);window.refresh_layers()
    view=window.layer_list
    view.scrollToBottom();QTest.qWait(30)
    mime=QMimeData();mime.setData(MIME,json.dumps([ids[1],ids[3]]).encode())
    class Drop:
        accepted=False
        def source(self):return view
        def mimeData(self):return mime
        def position(self):return QPointF(10,view.viewport().height()-1)
        def setDropAction(self,action):assert action==Qt.DropAction.MoveAction
        def accept(self):self.accepted=True
        def ignore(self):self.accepted=False
    event=Drop();view.dropEvent(event)
    assert event.accepted and [l.id for l in c.layers]==[ids[1],ids[3],ids[0],ids[2]]
    assert c.selected_layer_ids()=={ids[1],ids[3]}
    assert not c.layers[0].visible and c.layers[0].position_locked
    c.undo();assert [l.id for l in c.layers]==ids and not c.layers[1].visible
    c.redo();assert c.selected_layer_ids()=={ids[1],ids[3]}


def test_discontiguous_layer_arrow_order_and_noop(window):
    c=prepare(window);ids=[l.id for l in c.layers];c.set_selected_layers({ids[0],ids[2]},ids[2])
    c.shift_selected_layers(1);assert [l.id for l in c.layers]==[ids[1],ids[0],ids[3],ids[2]]
    c.undo();assert [l.id for l in c.layers]==ids
    c.reorder_layers(list(reversed(ids)));commit(c);assert not c.history


def test_mixed_lock_controls_do_not_change_visibility(window):
    c=prepare(window,2);c.layers[0].locked=True;c.layers[0].visible=False
    c.set_selected_layers([l.id for l in c.layers]);window.refresh_layers()
    check=window.layer_locks['locked'];assert check.checkState()==Qt.CheckState.PartiallyChecked
    QTest.mouseClick(check,Qt.MouseButton.LeftButton)
    assert all(l.locked for l in c.layers) and not c.layers[0].visible
    c.undo();assert c.layers[0].locked and not c.layers[1].locked and not c.layers[0].visible


def test_aurora_theme_is_distinct_optional_and_pixel_safe(window,monkeypatch):
    c=prepare(window,1);c.active.image.setPixelColor(10,10,QColor('red'));before=c.active.image.copy()
    assert len(THEMES)==17
    window.apply_theme('Перламутр',False);pearl=c.workspace_brush.gradient().stops()
    window.apply_theme(AURORA_NAME,False);assert window._pearl.selected and window._pearl.timer.isActive()
    assert c.workspace_brush.gradient().stops()!=pearl
    calls=[];monkeypatch.setattr(window,'setStyleSheet',lambda *args:calls.append(args))
    for sec in (1,15,30,45,59):window._pearl.seconds=sec;window._pearl.paint_frame()
    assert not calls and c.active.image==before and not c.history
    window.settings.setValue('theme/motion',False);window.apply_theme(AURORA_NAME,False)
    assert not window._pearl.timer.isActive()
    from app import MainWindow
    other=MainWindow();assert other.theme_name==AURORA_NAME and not other._pearl.motion;other.close()
    dialog=ThemeDialog(AURORA_NAME,window);assert dialog.group.checkedButton().text()==AURORA_NAME;dialog.deleteLater()
    for i in range(600):
        a,b=accent_at(i/10,AURORA_PALETTE),accent_at((i+1)/10,AURORA_PALETTE)
        assert max(abs(x-y) for x,y in zip(a.getRgb(),b.getRgb()))<=1


@pytest.mark.parametrize('tool',['Кисть','Карандаш','Маркер','Мягкая кисть'])
def test_single_click_leaves_a_brush_dot_and_undo(window,tool):
    c=prepare(window,1);window.set_tool(tool)
    QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=QPoint(50,50))
    assert c.active.image.pixelColor(50,50).alpha()>0
    c.undo();assert c.active.image==transparent_image(*c.doc_size)
    c.redo();assert c.active.image.pixelColor(50,50).alpha()>0


def test_layer_drag_scroll_and_cleanup(window):
    c=prepare(window,24);view=window.layer_list;QTest.qWait(30)
    assert view.verticalScrollBar().maximum()>0
    view.verticalScrollBar().setValue(0);view._drag_y=view.viewport().height()-1
    view._scroll_timer.start();QTest.qWait(180)
    assert view.verticalScrollBar().value()>0 and view._insertion is not None
    view.clear_drag();assert not view._scroll_timer.isActive() and view._insertion is None


def test_inline_text_after_layer_command_starts_new_undo_action(window):
    c=prepare(window,1);c.active.kind='text'
    c.text_objects=[dict(text='Hello',size=30,x=40,y=40,layer_id=c.active.id)]
    c.select_text(0)
    window.text_controls.size.setValue(40)
    c.set_selected_flag('color_label','#719de0')
    window.text_controls.size.setValue(50)
    c.undo();assert c.text_objects[0]['size']==40 and c.active.color_label=='#719de0'
    c.undo();assert c.text_objects[0]['size']==40 and not c.active.color_label
    c.undo();assert c.text_objects[0]['size']==30


def test_legacy_v4_defaults_to_unlocked_and_rejects_malformed_flags(window,tmp_path):
    c=prepare(window,1);path=tmp_path/'legacy.mpaint';c.save_project(path)
    with zipfile.ZipFile(path) as z:resources={n:z.read(n) for n in z.namelist()}
    manifest=json.loads(resources['project.json'])
    for key in ('locked','position_locked','alpha_locked','color_label'):manifest['layers'][0].pop(key)
    def rewrite():
        resources['project.json']=json.dumps(manifest).encode()
        with zipfile.ZipFile(path,'w') as z:
            for name,data in resources.items():z.writestr(name,data)
    rewrite();assert read_project(path)[1][0].flags()==dict(locked=False,position_locked=False,alpha_locked=False,color_label='',blend_mode='normal')
    manifest['layers'][0]['locked']='false';rewrite()
    before=c.active.image.copy()
    with pytest.raises(ValueError):c.load_project(path)
    assert c.active.image==before
