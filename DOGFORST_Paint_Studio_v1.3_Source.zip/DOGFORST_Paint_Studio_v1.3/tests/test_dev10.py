import copy,json,threading,time
import numpy as np
import pytest
from PySide6.QtCore import Qt,QPointF,QPoint,QRectF,QSettings,QEvent
from PySide6.QtGui import QImage,QColor,QPainter,QMouseEvent
from PySide6.QtWidgets import QApplication,QColorDialog,QInputDialog,QFileDialog,QMessageBox
from PySide6.QtTest import QTest
from test_dev7 import setup,imported
from test_dev8 import triangle,clip_scene
from test_dev9 import scene
from layers import transparent_image
from gradients import GradientInput,GradientJob,render_gradient,validate_gradient,DEFAULT_GRADIENT
from color_palettes import PaletteStore,validate_palettes
from selection_tools import from_array,rect_mask,feather_mask,gray_array
from masks import validate_mask
from recovery import DocumentSnapshot
from project_manager import read_project


def parameters(**kwargs):return dict(kind='linear',opacity=100,stops=[(0.,'#ffff0000'),(1.,'#ff0000ff')],x1=20.,y1=40.,x2=180.,y2=40.,**{})|kwargs

def wait(c):
    deadline=time.monotonic()+8
    while time.monotonic()<deadline:
        s=c.gradient_session
        if s is None or s.error or (s.result is not None and s.rendered_version==s.version):return s
        QTest.qWait(10)
    raise AssertionError('Gradient did not complete')

def start(c,**kwargs):
    assert c.start_gradient(QPointF(20,40),QPointF(180,40));c.update_gradient(**kwargs);return wait(c)

def mouse_move(c,pos,modifiers=Qt.KeyboardModifier.NoModifier):
    pos=QPointF(pos);c.mouseMoveEvent(QMouseEvent(QEvent.Type.MouseMove,pos,pos,Qt.MouseButton.NoButton,Qt.MouseButton.LeftButton,modifiers))


def test_gradient_tool_drag_preview_handles_and_cancel(window):
    c=setup(window);window.set_tool('Градиент');assert window.gradient_dock.isVisible()
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(20,40));mouse_move(c,QPoint(180,100));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(180,100));s=wait(c)
    assert not s.error and s.parameters['x2']==180 and s.parameters['y2']==100
    assert c.active.image==transparent_image(*c.doc_size) and not c.history
    assert not window.tools_dock.isEnabled() and window.gradient_dock.isEnabled() and window.palette_dock.isEnabled()
    assert not window.gradient_panel.cancel.visibleRegion().isEmpty()
    end=c.gradient_handles()['b'].toPoint();QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=end);mouse_move(c,end+QPoint(10,30),Qt.KeyboardModifier.ShiftModifier)
    p=c.gradient_session.parameters;angle=np.degrees(np.arctan2(p['y2']-p['y1'],p['x2']-p['x1']));assert abs(angle/15-round(angle/15))<.00001
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=end+QPoint(10,30));QTest.keyClick(c,Qt.Key.Key_Escape)
    assert c.gradient_session is None and window.tools_dock.isEnabled() and not c.history


def test_apply_matches_preview_and_one_exact_undo_redo(window):
    c=setup(window);original=c.active.image.copy();s=start(c,**{k:v for k,v in parameters().items() if k not in ('x1','y1','x2','y2')});preview=c.composite_image(True)
    assert s.result.pixelColor(10,40).red()>240 and s.result.pixelColor(210,40).blue()>240
    assert c.apply_gradient() and c.composite_image()==preview
    c.undo();assert c.active.image==original and not c.history
    c.redo();assert c.composite_image()==preview


def test_cancel_keeps_redo_revision_and_snapshot_original(window):
    c=scene(window);c.push_history();c.active.image.setPixelColor(0,0,QColor('green'));c.changed.emit();c.undo();original=c.active.image.copy();revision=window._safety.revision;redo=len(c.future)
    start(c);assert DocumentSnapshot.capture(c).layers[0].image==original
    assert window._safety.revision==revision;c.cancel_gradient();assert c.active.image==original and len(c.future)==redo
    assert not c.history


@pytest.mark.parametrize('kind',['linear','radial'])
def test_transparent_multi_stop_gradients_and_radial_symmetry(qt,kind):
    raw=transparent_image(200,120);p=parameters(kind=kind,x1=100.,y1=60.,x2=160.,y2=60.,stops=[(0.,'#ffff0000'),(.5,'#ff00ff00'),(1.,'#000000ff')])
    result=render_gradient(GradientInput(raw),p,threading.Event())
    assert result.pixelColor(100,60).red()>220
    if kind=='radial':
        assert abs(result.pixelColor(125,60).green()-result.pixelColor(75,60).green())<12
        assert result.pixelColor(180,60).alpha()==0
    else:assert result.pixelColor(180,60).alpha()==0 and result.pixelColor(120,60).green()>100


def test_selection_holes_soft_edges_and_outside_exact(window):
    c=setup(window);c.active.image.fill(QColor('#355264'));values=np.zeros((200,300),np.uint8);values[20:100,20:200]=255;values[40:80,50:90]=0;values[20:30,20:200]=128;c.set_selection_mask(from_array(values));c.commit_history(force=True);c.history.clear();original=c.active.image.copy();mask=c.selection_mask.copy()
    s=start(c);assert s.result.pixelColor(10,10)==original.pixelColor(10,10) and s.result.pixelColor(60,60)==original.pixelColor(60,60)
    assert s.result.pixelColor(30,25)!=original.pixelColor(30,25);c.apply_gradient();assert c.selection_mask==mask
    c.undo();assert c.active.image==original and c.selection_mask==mask


def test_alpha_lock_preserves_every_alpha_byte(window):
    c=setup(window);c.active.image.setPixelColor(50,50,QColor(20,30,40,125));c.active.image.setPixelColor(70,60,QColor('red'));c.active.alpha_locked=True
    before=c.active.image.copy();start(c);c.apply_gradient()
    a=np.frombuffer(before.constBits(),np.uint32)>>24;b=np.frombuffer(c.active.image.constBits(),np.uint32)>>24
    assert np.array_equal(a,b) and c.active.image.pixelColor(70,60)!=QColor('red')
    c.undo();assert c.active.image==before


@pytest.mark.parametrize('group',[False,True])
def test_mask_gradient_stays_opaque_gray_and_pixels_unchanged(window,group):
    c=scene(window)
    if group:c.create_group()
    c.add_mask();c.start_mask_edit();identifier=c.editing_mask;original=c.layers[0].image.copy();old=c.masks[identifier].copy()
    s=start(c,stops=[(0.,'#ff000000'),(1.,'#ffffffff')]);assert not s.error;validate_mask(s.result,c.doc_size)
    preview=c.composite_image(True);c.apply_gradient();assert c.layers[0].image==original and c.masks[identifier]!=old and c.composite_image()==preview
    validate_mask(c.masks[identifier],c.doc_size);c.undo();assert c.masks[identifier]==old and c.layers[0].image==original


def test_clipping_blend_and_own_mask_preview_matches_committed(window):
    c,base,top=clip_scene(window);top.blend_mode='multiply';c.add_mask();identifier=c.active.id;mask=c.masks[identifier].copy();start(c,kind='radial');preview=c.composite_image(True);c.apply_gradient()
    assert c.composite_image()==preview and c.active.clipped and c.masks[identifier]==mask
    c.undo();assert c.masks[identifier]==mask


def test_text_model_preserved_cancel_and_restored_undo(window):
    from test_v03 import text_layer
    c=setup(window);text_layer(c);original=copy.deepcopy(c.text_objects);image=c.active.image.copy();start(c);c.cancel_gradient();assert c.text_objects==original and c.active.image==image
    start(c);c.apply_gradient();assert not c.text_objects and c.active.kind=='raster'
    c.undo();assert c.text_objects==original and c.active.image==image and c.active.kind=='text'


def test_photo_source_preserved_cancel_and_restored_undo(window):
    c=imported(window);identifier=c.active.id;source=c.raster_objects[identifier]['source'].copy();start(c);c.cancel_gradient();assert c.raster_objects[identifier]['source']==source
    start(c);c.apply_gradient();assert identifier not in c.raster_objects;c.undo();assert c.raster_objects[identifier]['source']==source


def test_superseded_requests_and_early_enter_use_latest_result(window):
    c=setup(window);c.start_gradient(QPointF(0,0),QPointF(200,0));c.launch_gradient_job()
    for n in range(25):c.update_gradient(opacity=n+20)
    assert not c.apply_gradient();deadline=time.monotonic()+8
    while c.gradient_session is not None and time.monotonic()<deadline:QTest.qWait(10)
    assert c.gradient_session is None and abs(c.active.image.pixelColor(20,20).alpha()-round(.44*255))<=1


def test_noop_and_zero_length_have_no_history(window):
    c=setup(window);window.mark_clean();start(c,opacity=0);c.apply_gradient();assert not c.history and not window.dirty
    c.start_gradient(QPointF(30,30),QPointF(30,30));wait(c);c.apply_gradient();assert not c.history and not window.dirty


def test_restart_after_cancel_discards_old_worker_and_new_document(window):
    c=setup(window);c.start_gradient(QPointF(1,1),QPointF(200,1));c.launch_gradient_job();c.cancel_gradient();start(c,opacity=30);assert c.gradient_session.parameters['opacity']==30
    c.new_document(100,80);deadline=time.monotonic()+5
    while c._gradient_job is not None and time.monotonic()<deadline:QTest.qWait(10)
    assert c.gradient_session is None and c.active.image==transparent_image(100,80)


def test_gradient_rejects_locks_multi_layer_and_pending_transform(window):
    c=scene(window);c.active.locked=True;assert not c.start_gradient(QPointF())
    c.active.locked=False;c.add_layer();c.set_selected_nodes({l.id for l in c.layers});assert not c.start_gradient(QPointF())
    c.set_selected_nodes({c.active.id});assert c.start_selection_transform();assert not c.start_gradient(QPointF());c.cancel_selection_transform()
    start(c);assert not c.start_selection_transform();c.active.opacity=.5;assert not c.apply_gradient();assert c.gradient_session is None


def test_worker_error_keeps_model_and_restores_controls(window,monkeypatch):
    import gradients
    c=setup(window);original=c.active.image.copy()
    def failed(*args):raise MemoryError()
    monkeypatch.setattr(gradients,'render_gradient',failed);s=start(c);assert 'памяти' in s.error and not window.gradient_panel.apply.isEnabled()
    c.cancel_gradient();assert c.active.image==original and window.tools_dock.isEnabled() and not c.history


def test_gradient_numeric_fields_and_return_commit_pending_input(window):
    c=setup(window);start(c);panel=window.gradient_panel;spin=panel.coordinates['x2'];spin.setFocus();spin.lineEdit().selectAll();QTest.keyClicks(spin,'220');QTest.keyClick(spin,Qt.Key.Key_Return)
    deadline=time.monotonic()+8
    while c.gradient_session is not None and time.monotonic()<deadline:QTest.qWait(10)
    assert c.gradient_session is None and c.gradient_options['opacity']==100
    c.undo();assert not c.history


def test_stop_editor_presets_reverse_add_remove_and_alpha(window):
    panel=window.gradient_panel;c=window.canvas;panel.preset(2);assert len(c.gradient_options['stops'])==3
    panel.add_stop();assert len(c.gradient_options['stops'])==4;panel.alpha.setValue(35);assert abs(QColor(c.gradient_options['stops'][panel.selected][1]).alphaF()-.35)<.01
    old=list(c.gradient_options['stops']);panel.reverse_stops();assert c.gradient_options['stops']==[(1-at,color) for at,color in reversed(old)]
    panel.remove_stop();assert len(c.gradient_options['stops'])==3
    panel.position.setValue(0);assert len({a for a,b in c.gradient_options['stops']})==3
    panel.preset(4);assert QColor(c.gradient_options['stops'][-1][1]).alpha()==0


def test_project_save_during_preview_original_after_apply_roundtrip(window,tmp_path):
    c=scene(window);original=c.active.image.copy();start(c);c.save_project(tmp_path/'original.mpaint',backup=False);assert read_project(tmp_path/'original.mpaint')[1][0].image==original
    c.apply_gradient();c.save_project(tmp_path/'applied.mpaint',backup=False);assert read_project(tmp_path/'applied.mpaint')[1][0].image==c.active.image


@pytest.mark.parametrize('change',[dict(kind='fake'),dict(opacity=-1),dict(x1=float('nan')),dict(stops=[(0,'red')]),dict(stops=[(0,'red'),(0,'blue')]),dict(stops=[(0,'wrong'),(1,'red')]),dict(stops=[(0,'red'),9])])
def test_invalid_gradient_parameters(change):
    with pytest.raises(ValueError):validate_gradient(parameters(**change))


def test_cancelled_pure_renderer_returns_without_changes(qt):
    raw=transparent_image(200,100);event=threading.Event();event.set();assert render_gradient(GradientInput(raw),parameters(),event) is None


def test_palette_store_roundtrip_limits_and_mru(qt,tmp_path):
    settings=QSettings(str(tmp_path/'palettes.ini'),QSettings.Format.IniFormat);store=PaletteStore(settings);index=store.add_palette('Моя палитра');store.add_color(index,'red');store.add_color(index,'#ff0000');assert store.palettes[index]['colors']==['#ff0000']
    store.rename(index,'Новая');
    for n in range(30):store.record(QColor(n,n+1,n+2))
    store.record(QColor(10,11,12));assert len(store.recent)==24 and len(set(store.recent))==24
    restored=PaletteStore(settings);assert restored.palettes==store.palettes and restored.recent==store.recent
    for name in ['', 'DOGFORST','x'*61]:
        before=copy.deepcopy(store.palettes)
        with pytest.raises(ValueError):store.add_palette(name)
        assert store.palettes==before


def test_palette_corrupted_preferences_fallback(qt,tmp_path):
    settings=QSettings(str(tmp_path/'bad.ini'),QSettings.Format.IniFormat);settings.setValue('colors/palettes_v1','broken');settings.setValue('colors/recent_v1','{}');store=PaletteStore(settings);assert len(store.palettes)==2 and store.recent==[]


def test_palette_import_atomic_and_name_conflicts(qt,tmp_path):
    store=PaletteStore(QSettings(str(tmp_path/'import.ini'),QSettings.Format.IniFormat));before=copy.deepcopy(store.palettes)
    for data in [{},dict(format='dogforst-palettes',version=1,palettes=[dict(name='Test',colors=['bad color'])])]:
        with pytest.raises(ValueError):store.import_data(data)
        assert store.palettes==before
    store.import_data(dict(format='dogforst-palettes',version=1,palettes=[before[0]]));assert store.palettes[-1]['name']=='DOGFORST (2)'


def test_palette_ui_create_color_remove_history_import_export(window,monkeypatch,tmp_path):
    panel=window.palette_panel;monkeypatch.setattr(QInputDialog,'getText',lambda *a,**kw:('Моя',True));panel.create();assert panel.choice.currentText()=='Моя'
    window.set_color(QColor('#32caff'));panel.add.click();assert panel.store.palettes[-1]['colors']==['#32caff'] and panel.store.recent[0]=='#32caff'
    panel.pick('#32caff');assert panel.remove.isEnabled();panel.remove.click();assert not panel.store.palettes[-1]['colors']
    path=tmp_path/'palette.json';monkeypatch.setattr(QFileDialog,'getSaveFileName',lambda *a:(str(path),'JSON'));panel.export_file();data=json.loads(path.read_text());assert data['format']=='dogforst-palettes'
    monkeypatch.setattr(QFileDialog,'getOpenFileName',lambda *a:(str(path),'JSON'));panel.import_file();assert any(p['name']=='Моя (2)' for p in panel.store.palettes)


def test_palette_and_recent_survive_window_restart(window):
    panel=window.palette_panel;index=panel.store.add_palette('Сохранить меня');panel.store.add_color(index,'#abcdef');window.set_color(QColor('#123456'))
    from app import MainWindow
    other=MainWindow();assert other.palette_panel.store.palettes[-1]['colors']==['#abcdef'] and other.palette_panel.store.recent[0]=='#123456';other.dirty=False;other.close();other.deleteLater()


def test_pending_gradient_pan_zoom_and_escape_from_focused_field(window):
    c=setup(window);start(c);before=c.active.image.copy();QTest.mousePress(c,Qt.MouseButton.MiddleButton,pos=QPoint(160,100));mouse_move(c,QPoint(180,115));QTest.mouseRelease(c,Qt.MouseButton.MiddleButton,pos=QPoint(180,115));assert c.pan==QPointF(20,15)
    c.set_zoom(1.4);assert c.gradient_session is not None and c.active.image==before
    spin=window.gradient_panel.coordinates['x2'];spin.setFocus();QTest.keyClick(spin,Qt.Key.Key_Escape);assert c.gradient_session is None and window.layers_dock.isEnabled()


@pytest.mark.parametrize('suffix',['png','jpg','bmp','webp'])
def test_committed_gradient_exports_all_formats(window,tmp_path,suffix):
    c=setup(window);start(c);c.apply_gradient();path=tmp_path/('gradient.'+suffix);c.export_image(path);image=QImage(str(path));assert not image.isNull() and image.size()==c.active.image.size()
    if suffix=='png':assert image.convertToFormat(c.composite_image().format())==c.composite_image()


def test_palette_checked_colour_and_theme_follow_foreground(window):
    panel=window.palette_panel;value=panel.store.palettes[0]['colors'][0];window.set_color(QColor(value))
    assert panel.remove.isEnabled() and any(panel.colors.itemAt(i).widget().isChecked() for i in range(panel.colors.count()))
    window.set_color(QColor('#137bad'));assert not panel.remove.isEnabled() and not any(panel.colors.itemAt(i).widget().isChecked() for i in range(panel.colors.count()))
    window.apply_theme('Soft',False)
    assert all(panel.colors.itemAt(i).widget().accent==QColor(window._theme_colors[5]) for i in range(panel.colors.count()))
