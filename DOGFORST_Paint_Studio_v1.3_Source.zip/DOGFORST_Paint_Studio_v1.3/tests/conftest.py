import os
import sys
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pytest
from PySide6.QtCore import QSettings,QCoreApplication,QEvent
from PySide6.QtWidgets import QApplication


@pytest.fixture(scope='session')
def qt(tmp_path_factory):
    app = QApplication.instance() or QApplication([])
    QSettings.setDefaultFormat(QSettings.Format.IniFormat)
    QSettings.setPath(QSettings.Format.NativeFormat,QSettings.Scope.UserScope,str(tmp_path_factory.mktemp('settings')))
    yield app


@pytest.fixture(autouse=True)
def no_qt_callback_errors(monkeypatch, tmp_path):
    # Keep test settings out of the user's registry on Windows as well as Linux.
    monkeypatch.setenv('DOGFORST_DATA_DIR',str(tmp_path/'application-data'))
    import app as app_module
    monkeypatch.setattr(app_module, 'QSettings', lambda *args: QSettings(str(tmp_path/'settings.ini'), QSettings.Format.IniFormat))
    errors=[]
    monkeypatch.setattr(sys,'excepthook',lambda *e:errors.append(e))
    yield
    assert not errors, repr(errors)


@pytest.fixture
def window(qt):
    from app import MainWindow
    w=MainWindow();w.show();qt.processEvents()
    yield w
    w.dirty=False;w.close();w.deleteLater();qt.processEvents();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);qt.processEvents()
