import math
import pytest
from PySide6.QtCore import Qt,QPoint,QPointF,QRectF,QEvent
from PySide6.QtGui import QColor,QPainter,QMouseEvent
from PySide6.QtWidgets import QDialog,QToolButton
from PySide6.QtTest import QTest
from layers import transparent_image
from shapes import SHAPES,DEFAULT_SHAPE,shape_path
from dialogs import ShapeDialog,ShapePicker
from brush_panel import BrushDialog
from brushes import stabilized_point,paint_soft_segment
from test_v03 import setup,text_layer


def test_back_from_shapes_retains_drafts_and_does_not_draw(window,monkeypatch):
    c=window.canvas;setup(c);before=c.composite_image();calls=[]
    def pick(d):d.selected='Звезда';return QDialog.DialogCode.Accepted
    def configure(d):
        calls.append(d.width.value())
        if len(calls)==1:
            d.width.setValue(13);d.points.setValue(9);d.back.click();return d.result()
        assert d.points.value()==9
        return QDialog.DialogCode.Accepted
    monkeypatch.setattr(ShapePicker,'exec',pick);monkeypatch.setattr(ShapeDialog,'exec',configure)
    window.choose_shape()
    assert calls==[4,13] and c.shape_options['stroke_width']==13
    assert c.shape_options['points']==9 and c.composite_image()==before


def test_cancel_after_back_keeps_canvas_options(window,monkeypatch):
    before=dict(window.canvas.shape_options);picks=[]
    def pick(d):picks.append(1);return QDialog.DialogCode.Accepted if len(picks)==1 else QDialog.DialogCode.Rejected
    def config(d):d.width.setValue(19);return ShapeDialog.Back
    monkeypatch.setattr(ShapePicker,'exec',pick);monkeypatch.setattr(ShapeDialog,'exec',config)
    window.choose_shape();assert window.canvas.shape_options==before


def test_brush_back_and_cancel_leave_document_unchanged(window):
    c=window.canvas;before=c.composite_image();d=BrushDialog(c)
    d.preset_buttons[1].click();assert d.pages.currentIndex()==1
    d.size.setValue(43);d.opacity.setValue(62);d.back.click()
    assert d.pages.currentIndex()==0 and not d.apply.isEnabled()
    d.edit.click();assert d.size.value()==43 and d.opacity.value()==62
    d.reject();assert c.brush_size==8 and c.composite_image()==before


def test_brush_apply_exact_and_settings(window,monkeypatch):
    def accept(d):
        d.pick('Кисть',None);d.size.setValue(31);d.opacity.setValue(76)
        d.hardness.setValue(53);d.stabilizer.setValue(48);return QDialog.DialogCode.Accepted
    monkeypatch.setattr(BrushDialog,'exec',accept);window.choose_brush()
    c=window.canvas
    assert (c.tool,c.brush_size,c.brush_opacity,c.brush_hardness,c.brush_stabilizer)==('Кисть',31,76,53,48)
    assert window.settings.value('brush/stabilizer',type=int)==48


def test_dark_checker_display_only_and_persists(window):
    c=window.canvas;setup(c);before=c.composite_image();window.set_checker_style('dark')
    assert window.settings.value('canvas/checker')=='dark'
    dark=c.grab().toImage();window.set_checker_style('light');light=c.grab().toImage()
    assert dark!=light and c.composite_image()==before
    window.set_checker_style('dark');window.settings.sync()
    from app import MainWindow
    other=MainWindow();assert other.canvas.checker_style=='dark'
    other.dirty=False;other.close();other.deleteLater()


def test_rotation_live_angle_shift_and_undo(window):
    c=window.canvas;setup(c);text_layer(c);window.set_tool('Текст')
    item=c.text_objects[0];point=c.text_handles(item)['rotate'].toPoint();messages=[];c.status.connect(messages.append)
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=point)
    QTest.mouseMove(c,point+QPoint(50,22))
    assert item['rotation']!=0 and any('Поворот текста:' in m for m in messages)
    assert c.drawing
    QTest.keyPress(c,Qt.Key.Key_Shift)
    target=QPointF(point+QPoint(70,36))
    event=QMouseEvent(QEvent.Type.MouseMove,target,target,Qt.MouseButton.NoButton,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.ShiftModifier)
    c.mouseMoveEvent(event);assert item['rotation']%15==0
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.ShiftModifier,pos=point+QPoint(70,36))
    QTest.keyRelease(c,Qt.Key.Key_Shift);c.undo();assert c.text_objects[0].get('rotation',0)==0


@pytest.mark.parametrize('tool',['Кисть','Мягкая кисть'])
def test_soft_stroke_falloff_endpoints_and_history(window,tool):
    c=window.canvas;setup(c);window.set_tool(tool);c.brush_size=30;c.brush_hardness=20;c.brush_stabilizer=65
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(50,100))
    for x in range(60,201,10):QTest.mouseMove(c,QPoint(x,100))
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(200,100))
    image=c.active.image.copy()
    assert image.pixelColor(100,100).alpha()>image.pixelColor(100,113).alpha()>0
    assert image.pixelColor(199,100).alpha()>0
    c.undo();assert c.active.image==transparent_image(*c.doc_size)
    c.redo();assert c.active.image==image


def test_dab_spacing_independent_of_event_count(qt):
    def render(points):
        image=transparent_image(180,70);p=QPainter(image);p.setRenderHint(QPainter.RenderHint.Antialiasing);remaining=0
        for a,b in zip(points,points[1:]):remaining=paint_soft_segment(p,a,b,20,QColor('#804020'),30,remaining)
        p.end();return image
    sparse=render([QPointF(20,35),QPointF(150,35)])
    dense=render([QPointF(x,35) for x in range(20,151)])
    assert sparse==dense


def test_stabilizer_reduces_small_jitter_and_zero_is_exact():
    a=QPointF(0,0);b=QPointF(1,2)
    assert stabilized_point(a,b,0)==b
    assert (stabilized_point(a,b,80)-a).manhattanLength()<(b-a).manhattanLength()


def test_mask_soft_brush_remains_valid_grayscale(window):
    c=window.canvas;setup(c);c.add_mask();c.start_mask_edit();c.brush_hardness=20;c.brush_size=35;c.color=QColor('black')
    c.mask_stroke(QPointF(50,50),QPointF(100,50))
    from masks import validate_mask
    validate_mask(c.masks[c.editing_mask],c.doc_size)
    pixel=c.masks[c.editing_mask].pixelColor(70,50);assert pixel.red()<100 and pixel.alpha()==255


def test_shape_picker_proportions_and_legacy_cross(qt):
    assert len(SHAPES)==20 and 'Крест' not in SHAPES
    picker=ShapePicker('Звезда');buttons=picker.findChildren(QToolButton)
    assert len(buttons)==20 and next(b for b in buttons if b.text()=='Звезда').isChecked()
    assert not shape_path('Крест',QRectF(0,0,40,40)).isEmpty()
    for name in SHAPES:assert not shape_path(name,QRectF(0,0,40,40)).isEmpty()
    assert shape_path('Звезда',QRectF(0,0,40,40),5)!=shape_path('Звезда',QRectF(0,0,40,40),9)
