import threading

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QImage, QKeySequence
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QDialog, QFileDialog, QMessageBox, QPushButton, QSpinBox

from app import MainWindow
from background_cut import BackgroundCutDialog, cut_background
from dialogs import ExportDialog
from fill import fill_image
from selection_tools import wand_mask
from tool_settings import FillSettingsDialog
from workspace_preferences import WorkspacePreferencesDialog


def test_resize_empty_canvas_closes_without_saving_but_drawing_prompts(window, monkeypatch):
    def set_size(dialog):
        fields = dialog.findChildren(QSpinBox)
        fields[0].setValue(320)
        fields[1].setValue(240)
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(QDialog, 'exec', set_size)
    prompts = []
    monkeypatch.setattr(QMessageBox, 'warning',
                        lambda *args: prompts.append(args) or QMessageBox.StandardButton.Cancel)
    window.resize_canvas()
    assert window.canvas.doc_size == (320, 240)
    assert window.confirm_document_change()
    assert not window.dirty and not prompts
    window.canvas.push_history()
    window.canvas.active.image.setPixelColor(3, 4, QColor('red'))
    assert not window.confirm_document_change()
    assert prompts


def test_fill_color_is_remembered_and_can_be_replaced_with_palette_color(window, monkeypatch):
    def apply_blue(dialog):
        dialog.set_color(QColor('deepskyblue'))
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(FillSettingsDialog, 'exec', apply_blue)
    window.edit_tool_settings('Заливка')
    window.set_color(QColor('green'))
    editor = FillSettingsDialog(window.canvas, window)
    assert editor.color.color == QColor('deepskyblue')
    button = next(item for item in editor.findChildren(QPushButton)
                  if item.text() == 'Использовать текущий цвет')
    button.click()
    assert editor.color.color == QColor('green')
    editor.deleteLater()
    another = MainWindow()
    assert another.canvas.last_fill_color == QColor('deepskyblue')
    another.close()


def test_export_chooses_first_unused_png_name(window, tmp_path, monkeypatch):
    window.canvas.new_document(24, 24)
    window.settings.setValue('export/directory', str(tmp_path))
    originals = {'Рисунок.png': b'original', 'Рисунок1.png': b'older'}
    for name, data in originals.items():
        (tmp_path / name).write_bytes(data)
    monkeypatch.setattr(ExportDialog, 'exec', lambda dialog: QDialog.DialogCode.Accepted)

    def save_as(owner, title, suggested, filters):
        assert suggested == str(tmp_path / 'Рисунок2.png')
        return suggested, filters

    monkeypatch.setattr(QFileDialog, 'getSaveFileName', save_as)
    window.export_image()
    assert not QImage(str(tmp_path / 'Рисунок2.png')).isNull()
    assert all((tmp_path / name).read_bytes() == data for name, data in originals.items())


def test_invisible_rgb_does_not_break_transparent_wand_or_fill():
    image = QImage(3, 1, QImage.Format.Format_ARGB32)
    image.setPixelColor(0, 0, QColor(240, 10, 90, 0))
    image.setPixelColor(1, 0, QColor(20, 180, 50, 0))
    image.setPixelColor(2, 0, QColor('blue'))
    mask = wand_mask(image, 0, 0, 0, True, threading.Event())
    assert [mask.pixelColor(x, 0).red() for x in range(3)] == [255, 255, 0]
    result = fill_image(image, 0, 0, QColor('red'), 0, 100)
    assert [result.pixelColor(x, 0) for x in range(3)] == [
        QColor('red'), QColor('red'), QColor('blue')]


def test_background_preview_connectivity_and_multiple_seeds(qt):
    image = QImage(5, 4, QImage.Format.Format_ARGB32)
    image.fill(QColor('white'))
    for y in range(image.height()):
        image.setPixelColor(2, y, QColor('red'))
    dialog = BackgroundCutDialog(image, 0)
    dialog.show()
    dialog.pick(0, 0, False)
    for _ in range(100):
        if dialog.result is not None:
            break
        QTest.qWait(20)
    assert dialog.result is not None
    assert dialog.result.pixelColor(0, 0).alpha() == 0
    assert dialog.result.pixelColor(4, 0) == QColor('white')
    dialog.pick(4, 0, True)
    for _ in range(100):
        if dialog.result is not None:
            break
        QTest.qWait(20)
    assert dialog.result is not None
    assert dialog.result.pixelColor(4, 0).alpha() == 0
    assert dialog.result.pixelColor(2, 0) == QColor('red')
    dialog.reject()
    dialog.deleteLater()


def test_background_apply_preserves_photo_placement_and_undo(window, monkeypatch):
    canvas = window.canvas
    canvas.new_document(40, 40)
    image = QImage(7, 7, QImage.Format.Format_ARGB32)
    image.fill(QColor('white'))
    image.setPixelColor(3, 3, QColor(230, 20, 10, 140))
    assert canvas.import_object(image, 'Тестовый спрайт')
    identifier = canvas.active.id
    original = dict(canvas.raster_objects[identifier])

    def apply(dialog):
        dialog.result = cut_background(dialog.source, [(0, 0)], 0, True, threading.Event())
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(BackgroundCutDialog, 'exec', apply)
    window.remove_background()
    updated = canvas.raster_objects[identifier]
    assert updated['source'].pixelColor(0, 0).alpha() == 0
    assert updated['source'].pixelColor(3, 3).alpha() == 140
    assert updated['x'] == original['x'] and updated['width'] == original['width']
    window.undo()
    assert canvas.raster_objects[identifier]['source'] == original['source']


def test_workspace_preferences_persist_and_prevent_shortcut_conflicts(window):
    dialog = WorkspacePreferencesDialog(window)
    dialog.shortcuts['Ctrl+Z'].setKeySequence(QKeySequence('Ctrl+S'))
    dialog.accept()
    assert dialog.error.text()
    assert window.shortcut_actions['Ctrl+Z'].shortcut() == QKeySequence('Ctrl+Z')
    dialog.shortcuts['Ctrl+Z'].setKeySequence(QKeySequence('Ctrl+Alt+Z'))
    dialog.style.setCurrentIndex(dialog.style.findData('icons'))
    dialog.movable.setChecked(False)
    dialog.order.setCurrentRow(0)
    dialog.move_button(1)
    dialog.accept()
    assert window.command_order[:2] == ['new', 'theme']
    assert window.command_buttons['undo'].toolButtonStyle() == Qt.ToolButtonStyle.ToolButtonIconOnly
    assert window.shortcut_actions['Ctrl+Z'].shortcut() == QKeySequence('Ctrl+Alt+Z')
    assert not window.command_toolbar.isMovable()
    another = MainWindow()
    assert another.command_order[:2] == ['new', 'theme']
    assert another.command_toolbar.widgetForAction(another.command_widget_actions['undo']) is not None
    assert another.shortcut_actions['Ctrl+Z'].shortcut() == QKeySequence('Ctrl+Alt+Z')
    another.close()


def test_indexed_png_keeps_transparency_through_import_and_export(window, tmp_path):
    source = QImage(20, 20, QImage.Format.Format_Indexed8)
    source.setColorTable([QColor(250, 200, 100, 0).rgba(), QColor(120, 30, 210, 128).rgba()])
    source.fill(0)
    source.setPixel(9, 11, 1)
    path = tmp_path / 'indexed.png'
    assert source.save(str(path))
    assert window.open_image_path(str(path))
    layer = window.canvas.active.image
    assert layer.pixelColor(0, 0).alpha() == 0
    assert layer.pixelColor(9, 11).alpha() == 128
    exported = tmp_path / 'export.png'
    window.canvas.export_image(str(exported))
    result = QImage(str(exported))
    assert result.pixelColor(0, 0).alpha() == 0
    assert result.pixelColor(9, 11).alpha() == 128
