import json,zipfile,uuid
import pytest
from PySide6.QtCore import Qt,QRectF,QPointF
from PySide6.QtGui import QColor,QPainter,QImage
from PySide6.QtWidgets import QDialog,QFileDialog,QWidget,QVBoxLayout,QSpinBox,QLineEdit
from PySide6.QtTest import QTest
from test_dev7 import setup,source,imported
from layers import transparent_image
from effects import DEFAULT_GLOW,apply_glow,validate_glow
from glow_dialog import GlowDialog
from dialogs import ExportDialog,TextControls,ShapeDialog,ColorButton
from shapes import DEFAULT_SHAPE
from themes import THEMES,theme_stylesheet
from project_manager import read_project
from recovery import DocumentSnapshot,RecoveryStore


def glow(c,**values):
    c.push_history();c.active.glow=dict(DEFAULT_GLOW,**values);c.changed.emit();return c.active.glow


def test_add_photo_button_and_remove_preserve_original(window,tmp_path,monkeypatch):
    c=setup(window);path=tmp_path/'photo.png';source().save(str(path));original=path.read_bytes()
    monkeypatch.setattr(QFileDialog,'getOpenFileName',lambda *a,**k:(str(path),'PNG'))
    window.photo_add_button.click();assert len(c.layers)==2 and c.raster_objects
    photo=c.active.id;window.photo_remove_button.click();assert len(c.layers)==1 and not c.raster_objects
    assert path.read_bytes()==original
    c.undo();assert c.active.id==photo and c.raster_objects
    c.redo();assert len(c.layers)==1 and not c.raster_objects


@pytest.mark.parametrize('via_layer_delete',[False,True])
def test_last_photo_delete_keeps_blank_canvas_and_undo(window,tmp_path,via_layer_delete):
    c=setup(window);path=tmp_path/'photo.png';source(100,80).save(str(path));c.load_image(path);before=c.active.image.copy();identifier=c.active.id
    if via_layer_delete:c.delete_layer()
    else:window.remove_photo()
    assert len(c.layers)==1 and c.doc_size==(100,80) and c.active.image==transparent_image(100,80)
    assert not c.raster_objects and not c.masks and c.active.glow is None
    c.undo();assert c.active.id==identifier and c.active.image==before and c.raster_objects
    c.redo();assert c.active.image==transparent_image(100,80)


def test_delete_last_photo_preserves_group_structure_and_locks(window,tmp_path):
    c=setup(window);path=tmp_path/'photo.png';source().save(str(path));c.load_image(path);c.create_group();gid=c.control_node().id
    c.set_selected_nodes({c.layers[0].id});c.groups[gid].locked=True
    window.remove_photo();assert c.raster_objects and len(c.layers)==1
    c.groups[gid].locked=False;window.remove_photo()
    assert gid in c.groups and c.groups[gid].children==[c.active.id]
    c.undo();assert c.raster_objects and gid in c.groups


def test_glow_parameters_preview_cancel_and_apply(window,monkeypatch):
    c=imported(window);before=c.active.image.copy();raw=c.composite_image()
    def cancel(d):d.radius.setValue(40);d.strength.setValue(220);return QDialog.DialogCode.Rejected
    monkeypatch.setattr(GlowDialog,'exec',cancel);window.edit_glow();assert c.active.glow is None and c.composite_image()==raw
    def accept(d):
        d.radius.setValue(25);d.spread.setValue(3);d.strength.setValue(170);d.color.color=QColor('#f070ff');d.preview.refresh()
        assert d.preview.result!=d.preview.source
        return QDialog.DialogCode.Accepted
    monkeypatch.setattr(GlowDialog,'exec',accept);window.edit_glow()
    assert c.active.glow['radius']==25 and c.active.glow['strength']==170
    assert c.active.image==before and c.composite_image()!=raw and c.raster_objects
    c.undo();assert c.active.glow is None and c.composite_image()==raw
    c.redo();assert c.active.glow['radius']==25


@pytest.mark.parametrize('enabled,strength',[(False,100),(True,0)])
def test_disabled_glow_keeps_settings_and_raw_pixels(window,enabled,strength):
    c=imported(window);before=c.composite_image();glow(c,enabled=enabled,strength=strength)
    assert c.composite_image()==before and c.active.glow is not None


def test_glow_text_remains_editable_and_updates(window):
    from test_v03 import text_layer
    c=setup(window,(500,360));text_layer(c);glow(c,radius=16,color='#00ffff')
    before=c.composite_image();raw=c.active.image.copy();c.text_objects[0]['text']='НОВЫЙ ТЕКСТ';c.changed.emit()
    assert c.composite_image()!=before and c.active.kind=='text' and c.active.image==raw
    assert c.text_objects[0]['text']=='НОВЫЙ ТЕКСТ'


@pytest.mark.parametrize('masked',[False,True])
def test_glow_tile_seams_match_full_layer_and_partial_render(window,masked):
    from group_render import paint_stack
    c=setup(window,(620,430));p=QPainter(c.active.image);p.fillRect(240,10,35,330,QColor('white'));p.fillRect(0,210,610,25,QColor('red'));p.end()
    if masked:
        c.add_mask();p=QPainter(c.masks[c.active.id]);p.fillRect(0,140,620,30,QColor('black'));p.end()
    glow(c,radius=23,spread=4,strength=180)
    full=c.composite_image().convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
    expected=c.layer_image(c.active).convertToFormat(full.format())
    assert full==expected
    part=transparent_image(*c.doc_size);p=QPainter(part);region=QRectF(250,30,40,300)
    paint_stack(p,c.layers,c.groups,c.layer_stack,c.text_objects,c.doc_size,region,masks=c.masks,disabled_masks=c.disabled_masks);p.end()
    assert part.copy(region.toAlignedRect()).convertToFormat(full.format())==full.copy(region.toAlignedRect())


def test_glow_group_opacity_and_mask(window):
    c=setup(window,(200,160));p=QPainter(c.active.image);p.fillRect(80,60,40,40,QColor('white'));p.end();identifier=c.active.id
    glow(c,radius=18);original=c.composite_image().pixelColor(75,80).alpha();assert original>0
    c.create_group();gid=c.control_node().id;c.groups[gid].opacity=.5;c.changed.emit()
    assert abs(c.composite_image().pixelColor(75,80).alpha()-original*.5)<=1
    c.add_mask(0);assert c.composite_image()==transparent_image(*c.doc_size)
    c.undo();assert c.layers[0].id==identifier and c.layers[0].glow


def test_glow_duplicate_merge_and_mask_apply_do_not_double_effect(window):
    c=setup(window,(180,140));p=QPainter(c.active.image);p.fillRect(60,40,40,40,QColor('white'));p.end();glow(c,radius=14)
    c.duplicate_layer();assert c.layers[0].glow==c.layers[1].glow and c.layers[0].glow is not c.layers[1].glow
    before=c.composite_image();c.merge_down();assert c.active.glow is None and c.composite_image()==before
    c.undo();assert len(c.layers)==2 and c.active.glow
    c.add_mask(150);before=c.composite_image();c.apply_current_mask()
    assert c.active.glow is not None and c.composite_image()==before
    c.undo();assert c.active.glow and c.active.id in c.masks


def test_glow_moves_and_scales_with_photo_and_export(window,tmp_path):
    c=imported(window);glow(c,radius=14);before=c.composite_image();obj=dict(c.raster_objects[c.active.id]);obj.update(width=120.,height=90.,x=30.,y=30.)
    c.set_object(c.active,obj);assert c.active.glow['radius']==14 and c.composite_image()!=before
    image=c.composite_image();target=tmp_path/'glow.png';c.export_image(str(target));assert QImage(str(target)).convertToFormat(image.format())==image


def test_v9_roundtrip_recovery_snapshot_and_disabled_setting(window,tmp_path):
    c=imported(window);glow(c,enabled=False,color='#ff6600',radius=32);identifier=c.active.id;path=tmp_path/'glow.mpaint';c.save_project(path,backup=False)
    with zipfile.ZipFile(path) as z:assert json.loads(z.read('project.json'))['version']==9
    loaded=read_project(path);assert loaded[1][c.active_layer].glow==c.active.glow and loaded.raster_objects
    snap=DocumentSnapshot.capture(c);c.active.glow['radius']=9
    assert snap.layers[c.active_layer].glow['radius']==32
    store=RecoveryStore(tmp_path/'recovery');record=store.write(snap,uuid.uuid4().hex,3)
    assert read_project(record.path)[1][c.active_layer].glow['radius']==32
    c.active.glow=None;c.save_project(tmp_path/'old.mpaint',backup=False)
    with zipfile.ZipFile(tmp_path/'old.mpaint') as z:assert json.loads(z.read('project.json'))['version']==8


@pytest.mark.parametrize('damage',['version','color','radius','spread','strength','enabled','extra'])
def test_bad_glow_file_never_replaces_document(window,tmp_path,damage):
    c=imported(window);glow(c);path=tmp_path/'valid.mpaint';c.save_project(path,backup=False)
    with zipfile.ZipFile(path) as z:entries={n:z.read(n) for n in z.namelist()}
    manifest=json.loads(entries['project.json']);effect=next(x['glow'] for x in manifest['layers'] if 'glow' in x)
    if damage=='version':manifest['version']=8
    elif damage=='color':effect['color']='invalid'
    elif damage=='radius':effect['radius']=float('nan')
    elif damage=='spread':effect['spread']=1000
    elif damage=='strength':effect['strength']=-1
    elif damage=='enabled':effect['enabled']='yes'
    else:effect['unknown']=12
    entries['project.json']=json.dumps(manifest).encode();bad=tmp_path/'bad.mpaint'
    with zipfile.ZipFile(bad,'w') as z:
        for name,data in entries.items():z.writestr(name,data)
    before=c.composite_image();identifier=c.active.id
    with pytest.raises(ValueError):c.load_project(bad)
    assert c.active.id==identifier and c.composite_image()==before


@pytest.mark.parametrize('theme',['Light','Dark','Soft','Neon'])
def test_png_quality_disabled_dark_and_editable_jpg(qt,theme):
    dialog=ExportDialog();dialog.setStyleSheet(theme_stylesheet(THEMES[theme]));dialog.show();qt.processEvents()
    assert not dialog.quality.isEnabled() and not dialog.background.isEnabled()
    disabled=dialog.quality.grab().toImage();color=disabled.pixelColor(5,disabled.height()//2)
    assert color.lightness()<65
    old=dialog.quality.value();QTest.keyClick(dialog.quality,Qt.Key.Key_Up);assert dialog.quality.value()==old
    dialog.format.setCurrentIndex(1);qt.processEvents();assert dialog.quality.isEnabled() and dialog.background.isEnabled()
    normal=dialog.quality.grab().toImage();assert normal.pixelColor(5,normal.height()//2)!=color
    dialog.format.setCurrentIndex(3);assert dialog.quality.isEnabled() and not dialog.background.isEnabled()
    dialog.close()


def test_text_background_and_locked_editor_are_disabled(window):
    controls=TextControls(dict(text='Text'));assert not controls.background_color.isEnabled()
    controls.background.setChecked(True);assert controls.background_color.isEnabled()
    controls.background.setChecked(False);assert not controls.background_color.isEnabled()
    from test_v03 import text_layer
    c=setup(window,(500,360));text_layer(c);c.select_text(0);assert window.text_controls.isEnabled()
    c.set_selected_flag('locked',True);assert not window.text_controls.isEnabled()
    c.set_selected_flag('locked',False);assert window.text_controls.isEnabled()


def test_shape_unused_fill_and_exact_size_disabled(qt):
    d=ShapeDialog('Прямоугольник',dict(DEFAULT_SHAPE,filled=False,exact=False))
    assert not d.fill.isEnabled() and not d.w.isEnabled() and not d.h.isEnabled()
    d.filled.setChecked(True);d.exact.setChecked(True);assert d.fill.isEnabled() and d.w.isEnabled() and d.h.isEnabled()
    d=ShapeDialog('Линия',dict(DEFAULT_SHAPE,filled=True));assert not d.filled.isEnabled() and not d.fill.isEnabled()


def test_glow_disabled_fields_and_delete_effect(window,monkeypatch):
    c=imported(window);glow(c)
    dialog=GlowDialog(c.active,c.layer_image(c.active,False),c.doc_size,window);dialog.enabled.setChecked(False)
    assert not dialog.radius.isEnabled() and not dialog.radius.slider.isEnabled() and not dialog.color.isEnabled()
    dialog.enabled.setChecked(True);assert dialog.radius.isEnabled()
    def remove(d):d.remove.click();return d.result()
    monkeypatch.setattr(GlowDialog,'exec',remove);window.edit_glow();assert c.active.glow is None
    c.undo();assert c.active.glow


def test_toolbar_parameters_follow_active_tool(window):
    window.set_tool('Перемещение')
    assert not window.size_spin.isEnabled() and not window.size_slider.isEnabled()
    assert not window.opacity_spin.isEnabled() and not window.fill_tolerance_spin.isEnabled()
    window.set_tool('Заливка')
    assert window.fill_tolerance_spin.isEnabled() and window.opacity_slider.isEnabled() and not window.size_spin.isEnabled()
    window.set_tool('Кисть')
    assert window.size_spin.isEnabled() and window.opacity_spin.isEnabled() and not window.fill_tolerance_spin.isEnabled()
    window.set_tool('Текст');assert not window.size_spin.isEnabled() and not window.opacity_spin.isEnabled()
