import copy,json,math
import pytest,numpy as np
from PySide6.QtCore import Qt,QPointF,QPoint,QSettings,QEvent
from PySide6.QtGui import QColor,QPainter,QImage,QMouseEvent
from PySide6.QtWidgets import QDialog,QDockWidget,QInputDialog,QColorDialog,QMenu,QApplication
from PySide6.QtTest import QTest
from test_dev7 import setup,imported
from test_dev8 import triangle
from layers import transparent_image
from selection_tools import from_array
from masks import validate_mask
from brush_panel import BrushDialog
from brush_presets import BrushPresetStore,validate_preset
from tool_settings import FillSettingsDialog
from ink_stroke import InkStroke,clip_segment
from project_manager import read_project

def move(c,pos):
    p=QPointF(pos);c.mouseMoveEvent(QMouseEvent(QEvent.Type.MouseMove,p,p,Qt.MouseButton.NoButton,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier))

def stroke(c,points):
    points=[QPoint(*p) for p in points];QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=points[0])
    for p in points[1:]:move(c,p)
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=points[-1])

@pytest.mark.parametrize('tool',['Кисть','Мягкая кисть','Карандаш','Маркер','Ластик'])
def test_large_stroke_opacity_does_not_dark_with_repeated_segments(window,tool):
    c=setup(window,(700,400));window.set_tool(tool);c.brush_size=220;c.brush_opacity=40;c.brush_stabilizer=0;c.color=QColor('red')
    if tool=='Ластик':c.active.image.fill(QColor('blue'))
    before=c.active.image.copy();stroke(c,[(140,200),(300,200),(500,200),(300,200),(140,200),(500,200)])
    color=c.active.image.pixelColor(320,200);expected=255-round(255*.4) if tool=='Ластик' else round(255*.4*(.35 if tool=='Маркер' else 1));assert abs(color.alpha()-expected)<=2
    image=c.active.image.copy();assert c._ink_stroke is None;c.undo();assert c.active.image==before;c.redo();assert c.active.image==image

@pytest.mark.parametrize('tool',['Кисть','Мягкая кисть','Карандаш','Маркер','Ластик'])
def test_stroke_starts_and_finishes_outside_canvas(window,tool):
    c=setup(window,(180,120));c.pan=QPointF(100,100);c.zoom=1;window.set_tool(tool);c.brush_size=28;c.brush_stabilizer=0;c.color=QColor('red')
    if tool=='Ластик':c.active.image.fill(QColor('blue'))
    before=c.active.image.copy();stroke(c,[(50,160),(330,160)])
    assert c.active.image.size()==before.size();assert c.active.image!=before
    if tool!='Ластик':assert c.active.image.pixelColor(0,60).alpha()>0 and c.active.image.pixelColor(179,60).alpha()>0
    else:assert c.active.image.pixelColor(0,60).alpha()<10
    c.undo();assert c.active.image==before


def test_fully_outside_and_zero_opacity_do_not_allocate_or_dirty(window):
    c=setup(window,(180,120));c.pan=QPointF(100,100);window.mark_clean();c.brush_size=12;c.brush_stabilizer=0
    stroke(c,[(10,20),(25,30)]);assert not c.history and not window.dirty and c._ink_stroke is None
    c.brush_opacity=0;stroke(c,[(120,120),(200,150)]);assert not c.history and not window.dirty


def test_tiles_are_sparse_and_no_seams_at_boundaries(window):
    c=setup(window,(1400,900));c.brush_size=90;c.brush_opacity=55;c.brush_stabilizer=0;c.color=QColor('red')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(40,100));move(c,QPoint(1000,100));buffer=c._ink_stroke
    assert 1<=len(buffer.tiles)<=8
    for x in (254,255,256,257,510,511,512,513):assert abs(c.active.image.pixelColor(x,100).alpha()-round(.55*255))<=1
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(1000,100));assert c._ink_stroke is None


def test_soft_selection_and_alpha_lock_remain_exact(window):
    c=setup(window,(400,250));values=np.zeros((250,400),np.uint8);values[30:220,20:370]=128;values[70:140,150:200]=0;c.set_selection_mask(from_array(values));c.brush_opacity=40;c.brush_size=160;c.brush_stabilizer=0;c.color=QColor('red')
    stroke(c,[(60,100),(300,100),(60,100)]);assert abs(c.active.image.pixelColor(80,100).alpha()-51)<=1 and c.active.image.pixelColor(170,100).alpha()==0
    c.selection=None;c.selection_mask=None;c.active.alpha_locked=True;before=c.active.image.copy();c.color=QColor('blue');stroke(c,[(60,100),(300,100)])
    a=np.frombuffer(before.constBits(),np.uint32)>>24;b=np.frombuffer(c.active.image.constBits(),np.uint32)>>24;assert np.array_equal(a,b)


@pytest.mark.parametrize('group',[False,True])
def test_mask_opacity_and_outside_gesture_stays_gray(window,group):
    c=setup(window,(220,160));c.pan=QPointF(80,80)
    if group:c.create_group()
    c.add_mask();c.start_mask_edit();identifier=c.editing_mask;before=c.masks[identifier].copy();c.brush_size=100;c.brush_opacity=50;c.brush_stabilizer=0;c.color=QColor('black')
    stroke(c,[(30,160),(350,160),(30,160)]);validate_mask(c.masks[identifier],c.doc_size);assert abs(c.masks[identifier].pixelColor(110,80).red()-128)<=1
    c.undo();assert c.masks[identifier]==before


def test_eraser_works_with_transparent_foreground(window):
    c=setup(window);c.active.image.fill(QColor('red'));window.set_tool('Ластик');c.color=QColor(0,0,0,0);c.brush_size=40;c.brush_opacity=100;c.brush_stabilizer=0;stroke(c,[(50,80),(180,80)]);assert c.active.image.pixelColor(100,80).alpha()==0


def test_flow_and_spacing_have_real_effects(window):
    c=setup(window,(400,250));c.brush_size=90;c.brush_hardness=20;c.brush_stabilizer=0;c.color=QColor('red');c.brush_flow=10;c.brush_spacing=50
    stroke(c,[(70,100),(330,100)]);light=c.active.image.pixelColor(100,100).alpha();c.undo();c.brush_flow=100;c.brush_spacing=5;stroke(c,[(70,100),(330,100)]);assert c.active.image.pixelColor(100,100).alpha()>light


def test_stroke_event_subdivision_preserves_spacing(window):
    c=setup(window,(400,250));c.brush_size=70;c.brush_hardness=20;c.brush_flow=25;c.brush_stabilizer=0;c.brush_spacing=17
    stroke(c,[(40,100),(340,100)]);one=c.active.image.copy();c.undo();stroke(c,[(x,100) for x in range(40,341,10)]);assert c.active.image==one


@pytest.mark.parametrize('tool,enabled',[('Кисть',True),('Мягкая кисть',True),('Карандаш',False),('Маркер',False),('Ластик',False),('Заливка',False),('Перемещение',False)])
def test_brush_edit_button_only_for_brushes(window,tool,enabled):
    window.set_tool(tool);assert window.brush_edit_button.isEnabled()==enabled


@pytest.mark.parametrize('tool',['Кисть','Карандаш','Маркер','Ластик','Мягкая кисть'])
def test_double_click_opens_matching_tool_settings(window,monkeypatch,tool):
    calls=[]
    def accept(dialog):calls.append(dialog.tool);assert dialog.pages.currentIndex()==1;dialog.size.setValue(57);return QDialog.DialogCode.Accepted
    monkeypatch.setattr(BrushDialog,'exec',accept);QTest.mouseDClick(window.tool_buttons[tool],Qt.MouseButton.LeftButton)
    assert calls==[tool] and window.canvas.tool==tool and window.canvas.brush_size==57


def test_double_fill_settings_apply_and_cancel(window,monkeypatch):
    before=window.canvas.active.image.copy()
    def accept(d):d.tolerance.setValue(80);d.opacity.setValue(38);d.color.color=QColor('green');return QDialog.DialogCode.Accepted
    monkeypatch.setattr(FillSettingsDialog,'exec',accept);QTest.mouseDClick(window.tool_buttons['Заливка'],Qt.MouseButton.LeftButton)
    assert window.canvas.fill_tolerance==80 and window.canvas.brush_opacity==38 and window.canvas.color==QColor('green') and window.canvas.active.image==before
    monkeypatch.setattr(FillSettingsDialog,'exec',lambda d:QDialog.DialogCode.Rejected);window.edit_tool_settings('Заливка');assert window.canvas.fill_tolerance==80


def test_background_button_changes_only_display_and_persists(window,tmp_path):
    c=window.canvas;before=c.snapshot();window.mark_clean();actions=window.background_button.menu().actions();dark=next(a for a in actions if a.data()=='dark');dark.trigger();assert c.checker_style=='dark' and c.show_checkerboard and c.active.image==before['layers'][0][1] and not window.dirty
    assert window.settings.value('canvas/checker')=='dark';c.export_image(tmp_path/'transparent.png');assert QImage(str(tmp_path/'transparent.png')).pixelColor(5,5).alpha()==0
    window.background_button.menu().aboutToShow.emit();assert dark.isChecked()


def test_closed_panels_return_and_layout_reset_does_not_edit_document(window):
    c=window.canvas;before=c.active.image.copy();window.mark_clean()
    for d in [window.tools_dock,window.layers_dock,window.color_dock,window.history_dock]:d.close()
    for d in [window.tools_dock,window.layers_dock]:d.toggleViewAction().trigger();assert not d.isHidden()
    window.restore_default_layout();QApplication.processEvents()
    for d in [window.tools_dock,window.layers_dock,window.color_dock,window.history_dock]:assert not d.isHidden() and not d.isFloating()
    assert c.active.image==before and not window.dirty
    for d in window.findChildren(QDockWidget):assert d.toggleViewAction() in window.panels_menu.actions()


def test_saved_layout_and_reset_survive_restart(window):
    window.tools_dock.close();window.persist_workspace()
    from app import MainWindow
    other=MainWindow();assert other.tools_dock.isHidden();other.restore_default_layout();assert not other.tools_dock.isHidden();other.dirty=False;other.close();other.deleteLater()


def test_workspace_double_click_menu_and_background_layer_undo(window,monkeypatch):
    c=setup(window,(160,100));c.pan=QPointF(80,80)
    QTest.mouseDClick(c,Qt.MouseButton.LeftButton,pos=QPoint(20,20));menu=window._workspace_popup
    assert 'Добавить слой фона…' in [a.text() for a in menu.actions()];menu.close()
    before=c.active.image.copy();window.create_background(QColor('#334466'));assert len(c.layers)==2 and c.layers[0].name=='Фон' and c.layers[0].image.pixelColor(0,0)==QColor('#334466')
    c.undo();assert len(c.layers)==1 and c.active.image==before


def test_layer_empty_space_double_click_and_row_rename_preserved(window,monkeypatch):
    calls=[];window.layer_list.backgroundDoubleClicked.connect(lambda p:calls.append(p));monkeypatch.setattr(QMenu,'exec',lambda *a:None)
    QTest.mouseDClick(window.layer_list.viewport(),Qt.MouseButton.LeftButton,pos=QPoint(50,120));assert calls


def test_custom_brush_preset_roundtrip_and_invalid_atomic(window,monkeypatch):
    d=BrushDialog(window.canvas,window);d.pick('Кисть',None);d.size.setValue(85);d.spacing.setValue(23);d.flow.setValue(37);d.opacity.setValue(46);monkeypatch.setattr(QInputDialog,'getText',lambda *a,**k:('Мой штрих',True));d.save_preset();d.reject()
    other=BrushDialog(window.canvas,window);other.saved.setCurrentText('Мой штрих');other.load_preset();assert other.size.value()==85 and other.dynamics()==dict(spacing=23,flow=37) and other.opacity.value()==46
    before=copy.deepcopy(other.preset_store.presets)
    with pytest.raises(ValueError):other.preset_store.save('Плохой',dict(before['Мой штрих'],size=900))
    assert other.preset_store.presets==before;other.delete_preset();assert 'Мой штрих' not in BrushPresetStore(window.settings).presets;other.reject()


def test_brush_dialog_disables_ignored_dynamics(window):
    d=BrushDialog(window.canvas,window);d.pick('Карандаш',None);assert not d.spacing.isEnabled() and d.flow.isEnabled();d.pick('Кисть',None);assert d.spacing.isEnabled();d.outline_check.setChecked(True);assert not d.spacing.isEnabled() and not d.flow.isEnabled();d.reject()


def test_055_project_and_photo_original_restore_undo(window,tmp_path):
    c=imported(window);identifier=c.active.id;source=c.raster_objects[identifier]['source'].copy();c.brush_size=80;c.brush_opacity=35;c.brush_stabilizer=0;stroke(c,[(40,70),(180,70)]);assert identifier not in c.raster_objects
    c.save_project(tmp_path/'new.mpaint',backup=False);assert read_project(tmp_path/'new.mpaint')[1][-1].image==c.active.image
    c.undo();assert c.raster_objects[identifier]['source']==source


def test_diagonal_eraser_uses_only_path_tiles(window):
    c=setup(window,(1800,1200));window.set_tool('Ластик');c.brush_size=30;c.brush_stabilizer=0;c.active.image.fill(QColor('red'))
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(50,50));move(c,QPoint(1600,1000));assert len(c._ink_stroke.tiles)<25
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(1600,1000))


def test_background_copy_menu_action_duplicates_real_layer(window):
    c=setup(window);c.active.image.fill(QColor('red'));menu=window.workspace_menu();action=next(a for a in menu.actions() if a.text()=='Дублировать выбранные слои');action.trigger();assert len(c.layers)==2 and c.layers[0].image==c.layers[1].image;c.undo();assert len(c.layers)==1;menu.deleteLater()
