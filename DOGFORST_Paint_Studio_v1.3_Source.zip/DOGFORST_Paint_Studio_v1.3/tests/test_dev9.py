import json,threading,time,uuid
import pytest
from PySide6.QtCore import Qt,QPointF,QPoint,QRectF,QEvent
from PySide6.QtGui import QColor,QPainter,QImage,QMouseEvent
from PySide6.QtWidgets import QDialog,QApplication
from PySide6.QtTest import QTest
from test_dev7 import setup,imported,source
from test_dev8 import triangle,clip_scene
from layers import transparent_image
from masks import validate_mask
from selection_tools import rect_mask,from_array,feather_mask
from selection_transform import TransformInput,render_transform,TransformJob,validate_parameters
from recovery import DocumentSnapshot,RecoveryStore
from project_manager import read_project


def scene(window):
    c=setup(window,(300,220));p=QPainter(c.active.image);p.fillRect(50,50,40,40,QColor('red'));p.fillRect(90,50,40,40,QColor('blue'));p.end()
    c.selection=QRectF(50,50,80,40);c.commit_history(force=True);c.history.clear();c.future.clear();window.mark_clean();return c

def wait_preview(c):
    deadline=time.monotonic()+8
    while time.monotonic()<deadline:
        s=c.selection_transform
        if s is None or s.error or (s.result is not None and s.rendered_version==s.version):return s
        QTest.qWait(10)
    raise AssertionError('Transform preview did not complete')

def wait_finished(c):
    deadline=time.monotonic()+8
    while c.selection_transform is not None and time.monotonic()<deadline:QTest.qWait(10)
    assert c.selection_transform is None

def move(c,point,modifiers=Qt.KeyboardModifier.NoModifier):
    p=QPointF(point);c.mouseMoveEvent(QMouseEvent(QEvent.Type.MouseMove,p,p,Qt.MouseButton.NoButton,Qt.MouseButton.LeftButton,modifiers))


def test_ctrl_t_routes_selection_to_transaction(window):
    c=scene(window);QTest.keyClick(c,Qt.Key.Key_T,Qt.KeyboardModifier.ControlModifier);assert c.selection_transform is not None
    assert window.transform_dock.isVisible() and not window.tools_dock.isEnabled()
    QApplication.processEvents();assert not window.transform_panel.cancel.visibleRegion().isEmpty()
    assert not window.photo_add_button.isEnabled() and not window.layers_dock.isEnabled()
    window.transform_panel.cancel.click();assert c.selection_transform is None and window.tools_dock.isEnabled()


def test_preview_is_not_model_and_cancel_keeps_redo(window):
    c=scene(window);c.push_history();c.active.image.setPixelColor(1,1,QColor('green'));c.changed.emit();c.undo();assert c.future
    before=c.active.image.copy();selection=QRectF(c.selection);revision=window._safety.revision;redo=len(c.future)
    assert c.start_selection_transform();c.update_selection_transform(x=150.);s=wait_preview(c)
    assert s.result['image']!=before and c.active.image==before and c.composite_image(True)!=c.composite_image()
    assert window._safety.revision==revision and len(c.future)==redo
    c.cancel_selection_transform();assert c.active.image==before and c.selection==selection and len(c.future)==redo
    assert not c.history


def test_apply_one_history_step_and_exact_undo_redo(window):
    c=scene(window);before=c.active.image.copy();assert c.start_selection_transform()
    c.update_selection_transform(x=140.,width=120.,height=60.,smooth=False);wait_preview(c);preview=c.composite_image(True)
    assert c.apply_selection_transform();assert c.composite_image()==preview and c.selection_mask is not None
    assert c.active.image.pixelColor(60,60).alpha()==0 and c.active.image.pixelColor(150,60).red()>200
    c.undo();assert c.active.image==before and c.selection==QRectF(50,50,80,40) and c.selection_mask is None and not c.history
    c.redo();assert c.composite_image()==preview and c.selection_mask is not None


def test_corner_and_side_handles_live_parameters(window):
    c=scene(window);c.start_selection_transform();wait_preview(c)
    point=c.selection_transform_handles()['br'].toPoint();QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=point);move(c,point+QPoint(40,20));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=point+QPoint(40,20))
    s=wait_preview(c);assert s.parameters['width']==120 and s.parameters['height']==60
    assert c.active.image.pixelColor(60,60)==QColor('red') # original remains unchanged
    point=c.selection_transform_handles()['mr'].toPoint();QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=point);move(c,point+QPoint(20,0));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=point+QPoint(20,0))
    assert c.selection_transform.parameters['width']==140 and c.selection_transform.parameters['height']==60
    QTest.keyClick(c,Qt.Key.Key_Escape);assert c.selection_transform is None


def test_rotation_handle_shift_live_and_apply(window):
    c=scene(window);c.start_selection_transform();wait_preview(c)
    point=c.selection_transform_handles()['rotate'].toPoint();QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=point);move(c,point+QPoint(70,40),Qt.KeyboardModifier.ShiftModifier)
    angle=c.selection_transform.parameters['rotation'];assert angle!=0 and angle%15==0
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.ShiftModifier,pos=point+QPoint(70,40));wait_preview(c)
    QTest.keyClick(c,Qt.Key.Key_Return);wait_finished(c);assert c.selection_mask is not None


@pytest.mark.parametrize('flip_h,flip_v',[(True,False),(False,True),(True,True)])
def test_reflection_uses_original_pixels(window,flip_h,flip_v):
    c=scene(window);p=QPainter(c.active.image);p.fillRect(50,50,40,20,QColor('green'));p.end();before=c.active.image.copy()
    c.start_selection_transform();c.update_selection_transform(flip_h=flip_h,flip_v=flip_v,smooth=False);s=wait_preview(c);expected=s.result['image'].copy();c.apply_selection_transform()
    assert c.active.image==expected
    expected_color=before.pixelColor(119 if flip_h else 60,79 if flip_v else 60)
    assert c.active.image.pixelColor(60,60)==expected_color
    c.undo();assert c.active.image==before


def test_shrink_then_return_to_identity_has_no_loss_or_history(window):
    c=scene(window);mask=feather_mask(rect_mask(c.doc_size,c.selection),7,threading.Event());c.set_selection_mask(mask);c.commit_history(force=True);c.history.clear();window.mark_clean();before=c.active.image.copy();original_mask=QImage(c.selection_mask)
    c.start_selection_transform();initial=dict(c.selection_transform.parameters)
    c.update_selection_transform(width=15.,height=8.);wait_preview(c)
    c.update_selection_transform(**initial);s=wait_preview(c);assert s.result['image']==before
    c.apply_selection_transform();assert c.active.image==before and c.selection_mask==original_mask and not c.history and not window.dirty


def test_latest_request_wins_and_enter_queues_latest_render(window):
    c=scene(window);c.start_selection_transform()
    for x in range(70,121,5):c.update_selection_transform(x=float(x))
    c.apply_selection_transform();wait_finished(c)
    assert c.selection.x()==120 and c.active.image.pixelColor(125,60).red()>200
    c.undo();assert c.selection.x()==50


def test_no_selection_multiple_layers_and_locks_reject(window):
    c=scene(window);c.selection=None;assert not c.start_selection_transform()
    c.selection=QRectF(50,50,80,40);c.active.position_locked=True;assert not c.start_selection_transform()
    c.active.position_locked=False;c.active.alpha_locked=True;assert not c.start_selection_transform()
    c.active.alpha_locked=False;c.add_layer();c.set_selected_nodes({l.id for l in c.layers});assert not c.start_selection_transform()
    c.set_selected_nodes({c.layers[0].id});c.create_group();assert not c.start_selection_transform()


def test_text_preview_stays_editable_until_apply_then_undo(window):
    from test_v03 import text_layer
    c=setup(window,(500,360));text_layer(c);triangle(c);original=dict(c.text_objects[0])
    images=[l.image.copy() for l in c.layers]
    c.start_selection_transform();c.update_selection_transform(x=190.);wait_preview(c)
    assert c.text_objects[0]==original and c.active.kind=='text'
    c.cancel_selection_transform()
    # Qt may warm its text path raster cache during a screen paint. Compare the
    # editable model and source buffers exactly, rather than cached edge AA.
    assert c.text_objects[0]==original and [l.image for l in c.layers]==images
    c.start_selection_transform();c.update_selection_transform(x=190.);wait_preview(c);c.apply_selection_transform()
    assert not c.text_objects and c.active.kind=='raster'
    c.undo();assert c.text_objects[0]==original and c.active.kind=='text'
    assert [l.image for l in c.layers]==images


def test_photo_source_preserved_on_cancel_and_restored_by_undo(window):
    c=imported(window);identifier=c.active.id;original=c.raster_objects[identifier]['source'].copy();c.selection=QRectF(110,70,60,40)
    c.start_selection_transform();c.update_selection_transform(rotation=30.);wait_preview(c);assert identifier in c.raster_objects
    c.cancel_selection_transform();assert c.raster_objects[identifier]['source']==original
    c.start_selection_transform();c.update_selection_transform(rotation=30.);wait_preview(c);c.apply_selection_transform();assert identifier not in c.raster_objects
    c.undo();assert c.raster_objects[identifier]['source']==original


def test_linked_mask_transforms_and_remains_valid(window):
    c=scene(window);c.add_mask();identifier=c.active.id;p=QPainter(c.masks[identifier]);p.fillRect(50,50,40,40,QColor('black'));p.end();before=c.masks[identifier].copy()
    c.start_selection_transform();c.update_selection_transform(x=150.,rotation=10.,smooth=False);s=wait_preview(c)
    assert c.masks[identifier]==before;validate_mask(s.result['linked'],c.doc_size)
    preview=c.composite_image(True);c.apply_selection_transform();validate_mask(c.masks[identifier],c.doc_size)
    assert c.masks[identifier]!=before and c.composite_image()==preview
    c.undo();assert c.masks[identifier]==before


@pytest.mark.parametrize('group',[False,True])
def test_mask_only_transform_never_changes_layer_pixels(window,group):
    c=scene(window)
    if group:c.create_group()
    c.add_mask();identifier=c.control_node().id;c.start_mask_edit();p=QPainter(c.masks[identifier]);p.fillRect(50,50,40,40,QColor('black'));p.end()
    image=c.layers[0].image.copy();before=c.masks[identifier].copy();assert c.start_selection_transform()
    c.update_selection_transform(x=160.,rotation=20.);wait_preview(c);c.apply_selection_transform()
    assert c.layers[0].image==image and c.masks[identifier]!=before;validate_mask(c.masks[identifier],c.doc_size)
    c.undo();assert c.layers[0].image==image and c.masks[identifier]==before


def test_snapshot_recovery_and_save_during_preview_contain_original(window,tmp_path):
    c=scene(window);before=c.active.image.copy();c.start_selection_transform();c.update_selection_transform(x=170.,rotation=30.);wait_preview(c)
    snap=DocumentSnapshot.capture(c);assert snap.layers[0].image==before
    store=RecoveryStore(tmp_path/'recovery');record=store.write(snap,uuid.uuid4().hex,1);assert read_project(record.path)[1][0].image==before
    path=tmp_path/'original.mpaint';c.save_project(path,backup=False);assert read_project(path)[1][0].image==before
    c.apply_selection_transform();c.save_project(tmp_path/'applied.mpaint',backup=False);assert read_project(tmp_path/'applied.mpaint')[1][0].image==c.active.image


def test_document_change_cancels_preview_and_stale_job_is_ignored(window):
    c=scene(window);c.start_selection_transform();c.update_selection_transform(rotation=45.);c.launch_selection_transform_job();c.new_document(100,80)
    deadline=time.monotonic()+5
    while c._selection_transform_job is not None and time.monotonic()<deadline:QTest.qWait(10)
    assert c.selection_transform is None and c.doc_size==(100,80) and c.active.image==transparent_image(100,80)


def test_cancel_and_immediate_restart_serializes_jobs(window):
    c=scene(window);c.start_selection_transform();c.update_selection_transform(rotation=35.);c.launch_selection_transform_job();c.cancel_selection_transform()
    assert c.start_selection_transform();c.update_selection_transform(x=180.);s=wait_preview(c)
    assert s.parameters['x']==180 and s.result['image'].pixelColor(185,60).red()>200


def test_off_canvas_preview_can_return_before_apply(window):
    c=scene(window);before=c.active.image.copy();c.start_selection_transform();original=dict(c.selection_transform.parameters)
    c.update_selection_transform(x=1000.);s=wait_preview(c);assert s.result['image']==transparent_image(*c.doc_size)
    c.update_selection_transform(**original);s=wait_preview(c);assert s.result['image']==before
    c.update_selection_transform(x=1000.);wait_preview(c);c.apply_selection_transform();assert c.selection is None
    c.undo();assert c.active.image==before


def test_numeric_controls_aspect_and_raw_enter_text(window):
    c=scene(window);c.start_selection_transform();wait_preview(c);panel=window.transform_panel
    panel.fields['width'].setValue(160);assert c.selection_transform.parameters['height']==80
    panel.aspect.setChecked(False);panel.fields['height'].setValue(30);assert c.selection_transform.parameters['width']==160
    panel.fields['x'].setFocus();panel.fields['x'].lineEdit().selectAll();QTest.keyClicks(panel.fields['x'],'175')
    QTest.keyClick(panel.fields['x'],Qt.Key.Key_Return);wait_finished(c)
    assert c.selection.x()==175


def test_pan_zoom_and_theme_during_preview_do_not_mutate_document(window):
    c=scene(window);c.start_selection_transform();c.update_selection_transform(rotation=15.);wait_preview(c);before=c.active.image.copy()
    point=QPoint(150,140);QTest.mousePress(c,Qt.MouseButton.MiddleButton,pos=point);QTest.mouseMove(c,point+QPoint(20,10));QTest.mouseRelease(c,Qt.MouseButton.MiddleButton,pos=point+QPoint(20,10))
    assert c.pan==QPointF(20,10);c.set_zoom(1.3);window.apply_theme('Soft',False)
    assert c.selection_transform is not None and c.active.image==before
    c.cancel_selection_transform();assert window.tools_dock.isEnabled()


def test_clipping_glow_and_flags_survive_apply(window):
    from effects import DEFAULT_GLOW
    c,base,top=clip_scene(window);top.glow=dict(DEFAULT_GLOW);c.selection=QRectF(50,30,90,100)
    c.start_selection_transform();c.update_selection_transform(rotation=20.);wait_preview(c);expected=c.composite_image(True);c.apply_selection_transform()
    assert c.active.clipped and c.active.glow==DEFAULT_GLOW and c.composite_image()==expected


def test_error_keeps_original_and_cancel_restores_ui(window,monkeypatch):
    import selection_transform
    c=scene(window);before=c.active.image.copy()
    def failed(*args,**kwargs):raise MemoryError()
    monkeypatch.setattr(selection_transform,'render_transform',failed);c.start_selection_transform();c.update_selection_transform(rotation=30.);s=wait_preview(c)
    assert 'памяти' in s.error and c.active.image==before and not window.transform_panel.apply.isEnabled()
    window.transform_panel.cancel.click();assert c.selection_transform is None and window.photo_add_button.isEnabled() and not c.history


def test_undo_pending_cancels_only_and_close_dock_cancels(window):
    c=scene(window);c.start_selection_transform();c.update_selection_transform(rotation=20.);wait_preview(c);c.undo();assert c.selection_transform is None and not c.future
    c.start_selection_transform();window.transform_dock.close();assert c.selection_transform is None and window.tools_dock.isEnabled()


def test_invalid_parameters_and_worker_error(qt):
    image=transparent_image(20,20);data=TransformInput((20,20),QRectF(2,2,10,10).toAlignedRect(),image,rect_mask((20,20),QRectF(2,2,10,10)))
    parameters=dict(x=2.,y=2.,width=10.,height=10.,rotation=float('nan'),flip_h=False,flip_v=False,smooth=True)
    with pytest.raises(ValueError):validate_parameters(parameters)
    received=[];job=TransformJob('test',0,data,parameters,None);job.signals.done.connect(lambda j,result,error:received.append((result,error)));job.run()
    assert received[0][0] is None and received[0][1]


def test_nonrectangular_hole_coverage_moves_without_touching_hole_pixels(qt):
    import numpy as np
    image=transparent_image(80,60);image.fill(QColor('#e25176'))
    values=np.zeros((60,80),np.uint8);values[10:30,10:30]=255;values[16:24,16:24]=0
    mask=from_array(values);rect=QRectF(10,10,20,20).toAlignedRect()
    p=dict(x=40.,y=10.,width=20.,height=20.,rotation=0.,flip_h=False,flip_v=False,smooth=False)
    result=render_transform(TransformInput((80,60),rect,image,mask),p,threading.Event())
    expected=np.zeros_like(values);expected[10:30,40:60]=values[10:30,10:30]
    assert result['coverage']==from_array(expected)
    assert result['image'].pixelColor(12,12).alpha()==0
    assert result['image'].pixelColor(18,18)==QColor('#e25176')
    assert result['image'].pixelColor(42,12)==QColor('#e25176')


def test_nearest_quarter_turn_matches_exact_pixel_rotation(qt):
    image=transparent_image(30,30)
    for y in range(6):
        for x in range(6):image.setPixelColor(8+x,8+y,QColor(x*40,y*40,100))
    rect=QRectF(8,8,6,6).toAlignedRect();mask=rect_mask((30,30),QRectF(rect))
    p=dict(x=8.,y=8.,width=6.,height=6.,rotation=90.,flip_h=False,flip_v=False,smooth=False)
    result=render_transform(TransformInput((30,30),rect,image,mask),p,threading.Event())
    for y in range(6):
        for x in range(6):assert result['image'].pixelColor(8+5-y,8+x)==image.pixelColor(8+x,8+y)
    assert result['coverage']==mask
