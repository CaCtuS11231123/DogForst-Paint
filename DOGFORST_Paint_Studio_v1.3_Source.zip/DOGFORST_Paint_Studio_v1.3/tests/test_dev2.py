import json
import random
import zlib
from pathlib import Path

import numpy as np
import pytest
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import QColor, QImage
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QMessageBox, QDialog
from canvas import PaintCanvas
from history import FullImage, SnapshotPoint
from history_dialog import HistorySettingsDialog
from layers import Layer, transparent_image
from release_notes import RELEASES, CURRENT_VERSION, UpdatesDialog
from pearl import PEARL_NAME, accent_at
from themes import THEMES, ThemeDialog


def clean(canvas, width=512, height=384):
    canvas.new_document(width,height)
    canvas.history.clear();canvas.future.clear()


def pixel_action(canvas, x, y, color):
    canvas.push_history()
    canvas.active.image.setPixelColor(x,y,QColor(color))
    canvas.changed.emit();canvas.commit_history(force=True)


def test_small_edit_retains_tiles_not_a_whole_layer(qt):
    c=PaintCanvas();clean(c,2048,2048)
    for i in range(20):pixel_action(c,20+i*2,20+i*2,'red')
    stats=c.history_engine.statistics()
    assert len(c.history)==20 and stats['pending'] is False
    assert stats['estimated_bytes'] < 200_000
    assert stats['payload_bytes'] < c.active.image.sizeInBytes()/100
    for _ in range(20):c.undo()
    assert c.active.image==transparent_image(2048,2048)
    for _ in range(20):c.redo()
    assert c.active.image.pixelColor(58,58)==QColor('red')


def test_random_overlapping_pixels_undo_redo_exactly(qt):
    c=PaintCanvas();clean(c,260,258);c.max_history=80
    rng=random.Random(42);states=[]
    for _ in range(40):
        states.append(c.active.image.copy())
        x,y=rng.randrange(20),rng.randrange(20)
        pixel_action(c,x,y,QColor(rng.randrange(256),rng.randrange(256),rng.randrange(256),rng.randrange(256)))
    final=c.active.image.copy()
    for image in reversed(states):c.undo();assert c.active.image==image
    for _ in states:c.redo()
    assert c.active.image==final


def test_metadata_history_has_no_pixel_payload(qt):
    c=PaintCanvas();clean(c);key=c.active.image.cacheKey()
    for i in range(20):
        c.push_history();c.active.name=f'Имя {i}';c.active.visible=bool(i%2);c.changed.emit();c.commit_history(force=True)
    assert c.history_engine.statistics()['payload_bytes']==0
    for _ in range(20):c.undo()
    assert c.active.name=='Слой 1' and c.active.visible
    assert c.active.image.cacheKey()==key


def test_metadata_undo_of_many_layers_does_not_scale_with_pixel_bytes(qt):
    c=PaintCanvas();clean(c,1024,1024)
    for _ in range(8):c.add_layer()
    c.history.clear();c.future.clear()
    c.set_layer_visible(2,False);c.commit_history(force=True)
    assert c.history_engine.statistics()['estimated_bytes'] < 12_000
    c.undo();assert c.layers[2].visible and len(c.layers)==9


def test_branching_discards_redo_without_altering_other_pixels(qt):
    c=PaintCanvas();clean(c)
    pixel_action(c,10,10,'red');pixel_action(c,11,11,'blue');c.undo()
    pixel_action(c,12,12,'green')
    assert not c.future and c.active.image.pixelColor(11,11).alpha()==0
    c.undo();assert c.active.image.pixelColor(10,10)==QColor('red')


def test_noop_is_not_an_undo_step(qt):
    c=PaintCanvas();clean(c)
    c.push_history();c.changed.emit();c.commit_history(force=True)
    assert not c.history and not c.future


def test_step_and_memory_limits_remain_valid_in_both_directions(qt):
    c=PaintCanvas();clean(c);c.max_history=5;c.history_engine.budget=4000
    for i in range(20):pixel_action(c,10+i,10+i,'blue')
    assert 1<=len(c.history)<=5
    stats=c.history_engine.statistics()
    assert stats['estimated_bytes']<=4000 or len(c.history)==1
    while c.history:c.undo()
    while c.future:c.redo()
    assert c.active.image.pixelColor(29,29)==QColor('blue')


@pytest.mark.parametrize('kind',['delete','resize','format'])
def test_structural_image_history_is_lossless(qt,kind):
    c=PaintCanvas();clean(c,35,29)
    pixel_action(c,3,4,QColor(170,80,90,53));before=c.active.image.copy();identifier=c.active.id
    c.push_history()
    if kind=='delete':
        c.layers=[Layer('Replacement',transparent_image(35,29))]
    elif kind=='resize':
        c.doc_size=(60,50);c.active.image=c.active.image.scaled(60,50)
    else:
        c.active.image=c.active.image.convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
    c.changed.emit();c.commit_history(force=True)
    after=c.active.image.copy()
    c.undo();assert c.active.id==identifier and c.active.image==before and c.doc_size==(35,29)
    c.redo();assert c.active.image==after


def test_non_32bit_images_use_full_fallback(qt):
    c=PaintCanvas();clean(c,31,23)
    c.active.image=QImage(31,23,QImage.Format.Format_RGB888);c.active.image.fill(QColor('red'))
    before=c.active.image.copy();pixel_action(c,4,5,'blue')
    c.undo();assert c.active.image==before
    c.redo();assert c.active.image.pixelColor(4,5)==QColor('blue')


def test_compaction_allocation_failure_keeps_undo(qt,monkeypatch):
    c=PaintCanvas();clean(c)
    def fail(*a,**k):raise MemoryError('allocation test')
    monkeypatch.setattr(zlib,'compress',fail)
    pixel_action(c,10,10,'red')
    assert isinstance(c.history_engine.undos[-1],SnapshotPoint)
    c.undo();assert c.active.image.pixelColor(10,10).alpha()==0
    c.redo();assert c.active.image.pixelColor(10,10)==QColor('red')


def test_failed_restore_does_not_pop_history_or_change_document(qt,monkeypatch):
    c=PaintCanvas();clean(c,64,64)
    before=c.active.image.copy();c.push_history();c.active.image.fill(QColor('red'));c.commit_history(force=True)
    def fail(self):raise MemoryError('decode test')
    original=FullImage.decode;monkeypatch.setattr(FullImage,'decode',fail)
    with pytest.raises(MemoryError):c.undo()
    assert len(c.history)==1 and not c.future and c.active.image.pixelColor(2,2)==QColor('red')
    monkeypatch.setattr(FullImage,'decode',original)
    c.undo();assert c.active.image==before


def test_saving_does_not_clear_undo_or_change_project_format(window,tmp_path):
    c=window.canvas;clean(c);pixel_action(c,4,5,'red');count=len(c.history)
    window.current_file=str(tmp_path/'Project.mpaint');assert window.save_project()
    assert len(c.history)==count
    import zipfile
    with zipfile.ZipFile(window.current_file) as archive:assert json.loads(archive.read('project.json'))['version']==4
    c.undo();assert c.active.image.pixelColor(4,5).alpha()==0
    c.redo();assert c.active.image.pixelColor(4,5)==QColor('red')


def test_text_edit_group_keeps_all_characters_on_redo_and_can_branch(window,monkeypatch):
    from dialogs import TextDialog
    c=window.canvas;clean(c)
    def create(dialog):dialog.controls.content.setPlainText('Start');return QDialog.DialogCode.Accepted
    monkeypatch.setattr(TextDialog,'exec',create);c.edit_text_dialog(None,QPointF(20,20))
    c.history.clear();c.future.clear()
    for text in ('O','On','One'):window.text_controls.content.setPlainText(text)
    QTest.qWait(720)
    assert len(c.history)==1
    window.undo();assert c.text_objects[0]['text']=='Start'
    window.redo();assert c.text_objects[0]['text']=='One'
    window.text_controls.content.setPlainText('Two')
    window.undo();assert c.text_objects[0]['text']=='One'
    window.text_controls.content.setPlainText('Branch')
    QTest.qWait(720)
    assert not c.future
    window.undo();assert c.text_objects[0]['text']=='One'


def test_history_settings_persist_without_changing_pixels(window,monkeypatch):
    c=window.canvas;clean(c);pixel_action(c,3,4,'red');before=c.active.image.copy()
    def choose(dialog):dialog.steps.setValue(60);dialog.memory.setValue(64);return QDialog.DialogCode.Accepted
    monkeypatch.setattr(HistorySettingsDialog,'exec',choose);window.show_history_settings()
    assert c.max_history==60 and c.history_engine.budget==64*1024*1024 and c.active.image==before
    from app import MainWindow
    other=MainWindow();assert other.canvas.max_history==60 and other.canvas.history_engine.budget==64*1024*1024;other.close()


def test_update_catalog_and_version_selection(qt):
    dialog=UpdatesDialog()
    assert dialog.versions.currentData()==CURRENT_VERSION
    assert RELEASES[0]['title'] in dialog.details.toPlainText()
    assert dialog.versions.count()==len(RELEASES)==21
    assert len({r['version'] for r in RELEASES})==len(RELEASES)
    for i,release in enumerate(RELEASES):
        dialog.versions.setCurrentIndex(i)
        content=dialog.details.toPlainText()
        assert release['title'] in content and release['description'] in content
        assert all(item in content for item in release['changes'])
    dialog.deleteLater()


def test_pearl_theme_is_extra_and_motion_is_optional(window,qt):
    assert PEARL_NAME in THEMES and len(THEMES)==17
    c=window.canvas;clean(c);pixel_action(c,3,4,'black');before=c.active.image.copy();count=len(c.history)
    window.settings.setValue('theme/motion',False);window.apply_theme(PEARL_NAME,False)
    QTest.qWait(150)
    assert not window._pearl.timer.isActive() and c.workspace_brush is not None
    assert c.active.image==before and len(c.history)==count
    from app import MainWindow
    other=MainWindow();assert other.theme_name==PEARL_NAME and not other._pearl.motion;other.close()
    dialog=ThemeDialog(PEARL_NAME,window);assert not dialog.motion.isChecked();dialog.deleteLater()


def test_pearl_frames_never_reapply_global_styles_or_touch_pixels(window,monkeypatch):
    c=window.canvas;clean(c);pixel_action(c,4,5,'red')
    window.apply_theme(PEARL_NAME,False);before=c.snapshot();key=c.active.image.cacheKey()
    calls=[];monkeypatch.setattr(window,'setStyleSheet',lambda *a:calls.append(a))
    for seconds in (0,5,15,23,40,59):window._pearl.seconds=seconds;window._pearl.paint_frame()
    assert not calls and c.active.image.cacheKey()==key and c.active.image==before['layers'][0][1]
    assert len(c.history)==1
    window._pearl.set_theme('Dark');assert not window._pearl.timer.isActive() and c.workspace_brush is None


def test_pearl_motion_stops_when_hidden_or_minimized(window):
    window.apply_theme(PEARL_NAME,False);QTest.qWait(40);assert window._pearl.timer.isActive()
    window.hide();QTest.qWait(30);assert not window._pearl.timer.isActive()
    window.show();QTest.qWait(30);assert window._pearl.timer.isActive()
    window.showMinimized();QTest.qWait(30);assert not window._pearl.timer.isActive()
    window.showNormal();QTest.qWait(30);assert window._pearl.timer.isActive()


def test_pearl_color_changes_are_slow_and_loop_without_flash():
    for i in range(600):
        a,b=accent_at(i/10).getRgb(),accent_at((i+1)/10).getRgb()
        assert max(abs(x-y) for x,y in zip(a,b))<=1
    assert accent_at(0)==accent_at(60)


def test_bad_history_preferences_fall_back_to_defaults(window):
    window.settings.setValue('history/steps','bad');window.settings.setValue('history/mib',None)
    from app import MainWindow
    other=MainWindow();assert other.canvas.max_history==35 and other.canvas.history_engine.budget==256*1024*1024;other.close()
