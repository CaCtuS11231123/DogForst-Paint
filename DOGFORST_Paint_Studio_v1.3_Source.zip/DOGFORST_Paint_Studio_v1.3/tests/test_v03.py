import json,zipfile
import pytest
from PySide6.QtCore import Qt,QPointF,QRectF,QPoint
from PySide6.QtGui import QColor,QImage,QPainter
from PySide6.QtWidgets import QDialog,QMessageBox,QFileDialog
from PySide6.QtTest import QTest
from layers import Layer,transparent_image
from canvas import PaintCanvas
from shapes import SHAPES,DEFAULT_SHAPE,draw_shape
from dialogs import TextDialog,ShapeDialog,ShapePicker,ExportDialog
from themes import THEMES,ThemeDialog
from project_manager import png_bytes


def setup(c):
    c.new_document(500,360);c.zoom=1.;c.pan=QPointF()


def text_layer(c,text='Hello',x=40,y=40,size=30):
    layer=Layer('Текст · '+text,transparent_image(*c.doc_size),kind='text');c.layers.append(layer)
    c.text_objects.append(dict(text=text,x=x,y=y,size=size,font='Sans',color='#ff0000',layer_id=layer.id,rotation=0,width_scale=1,stroke_width=0))
    c.active_layer=len(c.layers)-1;c.select_text(len(c.text_objects)-1)
    return layer


def test_equal_buttons_and_hover_geometry(window):
    rects={name:button.geometry() for name,button in window.tool_buttons.items()}
    sizes={tuple((b.width(),b.height())) for b in window.tool_buttons.values()}
    assert sizes=={(118,72)} and 'Фигуры' in rects
    assert not any(name in window.tool_buttons for name in SHAPES)
    for button in window.tool_buttons.values():
        QTest.mouseMove(button,button.rect().center());QTest.qWait(12)
    assert rects=={name:button.geometry() for name,button in window.tool_buttons.items()}


def test_new_text_owns_layer_and_undo(window,monkeypatch):
    c=window.canvas;setup(c);initial=len(c.layers)
    def accept(dialog):dialog.controls.content.setPlainText('Новый текст');return QDialog.DialogCode.Accepted
    monkeypatch.setattr(TextDialog,'exec',accept)
    c.edit_text_dialog(None,QPointF(30,30))
    assert len(c.layers)==initial+1 and c.active.kind=='text'
    assert c.text_objects[0]['layer_id']==c.active.id
    c.undo();assert len(c.layers)==initial and not c.text_objects
    c.redo();assert len(c.layers)==initial+1 and c.text_objects[0]['layer_id']==c.active.id


def test_text_layer_visibility_opacity_delete_and_reorder(window):
    c=window.canvas;setup(c);layer=text_layer(c)
    rendered=c.composite_image();assert rendered!=transparent_image(*c.doc_size)
    c.set_layer_visible(c.active_layer,False);assert c.composite_image()==transparent_image(*c.doc_size)
    c.undo();assert c.composite_image()==rendered
    c.set_layer_opacity(c.active_layer,0);assert c.composite_image()==transparent_image(*c.doc_size)
    c.undo();c.delete_layer();assert not c.text_objects
    c.undo();assert c.text_objects[0]['layer_id'] in {l.id for l in c.layers}
    # An opaque layer above text must cover it; moving it below must reveal it.
    c.add_layer();c.active.image.fill(QColor('blue'));covered=c.composite_image()
    window.reorder_layer(-1);assert c.composite_image()!=covered


def test_single_click_inspector_without_modal(window,monkeypatch):
    c=window.canvas;setup(c);text_layer(c);window.set_tool('Текст')
    def forbidden(*args):raise AssertionError('Existing text should use the inspector on one click')
    monkeypatch.setattr(TextDialog,'exec',forbidden)
    QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=QPoint(53,55))
    assert c.selected_text==0 and window.text_dock.isVisible()
    window.text_controls.stroke_width.setValue(4);window.text_controls.italic.setChecked(True)
    assert c.text_objects[0]['stroke_width']==4 and c.text_objects[0]['italic']


@pytest.mark.parametrize('handle,key',[('size','size'),('width','width_scale'),('rotate','rotation')])
def test_text_transform_handles_and_undo(window,handle,key):
    c=window.canvas;setup(c);text_layer(c);window.set_tool('Текст');before=c.text_objects[0].get(key,0)
    point=c.text_handles(c.text_objects[0])[handle].toPoint()
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=point)
    target=point+QPoint(40,30)
    QTest.mouseMove(c,target);QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=target)
    assert c.text_objects[0][key]!=before
    c.undo();assert c.text_objects[0].get(key,0)==before
    c.redo();assert c.text_objects[0][key]!=before


def test_move_all_visible_keeps_image_text_together(window):
    c=window.canvas;setup(c);c.layers[0].image.setPixelColor(5,5,QColor('blue'));text_layer(c)
    c.move_all_visible=True;window.set_tool('Перемещение');c.selected_text=-1
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(5,5))
    QTest.mouseMove(c,QPoint(25,15));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(25,15))
    assert c.layers[0].image.pixelColor(25,15)==QColor('blue')
    assert c.text_objects[0]['x']==60 and c.text_objects[0]['y']==50
    c.undo();assert c.text_objects[0]['x']==40 and c.layers[0].image.pixelColor(5,5)==QColor('blue')


def test_move_text_click_autoselect_and_nudge(window):
    window.auto_select_check.setChecked(True)
    c=window.canvas;setup(c);layer=text_layer(c);c.active_layer=0;c.selected_text=-1;window.set_tool('Перемещение')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(53,55));QTest.mouseMove(c,QPoint(73,65));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(73,65))
    assert c.active.id==layer.id and c.text_objects[0]['x']==60
    QTest.keyClick(c,Qt.Key.Key_Right,Qt.KeyboardModifier.ShiftModifier)
    assert c.text_objects[0]['x']==70


def test_selection_resize_move_and_crop(window):
    c=window.canvas;setup(c);window.set_tool('Выделение')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(20,20));QTest.mouseMove(c,QPoint(120,100));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(120,100))
    assert c.selection==QRectF(20,20,100,80)
    point=c.selection_handles()['br'].toPoint()
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=point);QTest.mouseMove(c,point+QPoint(30,20));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=point+QPoint(30,20))
    assert c.selection==QRectF(20,20,130,100)
    c.crop_selection();assert c.doc_size==(130,100)
    c.undo();assert c.doc_size==(500,360)


@pytest.mark.parametrize('name',SHAPES)
def test_every_shape_renders_fill_outline_and_options(qt,name):
    image=transparent_image(200,180);p=QPainter(image)
    draw_shape(p,name,QRectF(30,30,120,100),dict(DEFAULT_SHAPE,filled=True,stroke_width=3,rotation=7,shear=10))
    p.end();assert image!=transparent_image(200,180)


def test_shapes_picker_parameters_and_exact_size(window,monkeypatch):
    c=window.canvas;setup(c)
    def pick(dialog):dialog.selected='Звезда';return QDialog.DialogCode.Accepted
    def config(dialog):dialog.filled.setChecked(True);dialog.exact.setChecked(True);dialog.w.setValue(90);dialog.h.setValue(70);return QDialog.DialogCode.Accepted
    monkeypatch.setattr(ShapePicker,'exec',pick);monkeypatch.setattr(ShapeDialog,'exec',config)
    window.choose_shape();assert c.tool=='Звезда' and c.shape_options['filled']
    QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=QPoint(50,50))
    assert c.active.image!=transparent_image(*c.doc_size)
    c.undo();assert c.active.image==transparent_image(*c.doc_size)


def test_all_17_themes_in_same_dialog(qt):
    assert len(THEMES)==17
    for name in THEMES:
        dialog=ThemeDialog(name)
        assert len(dialog.group.buttons())==17 and dialog.group.checkedButton().text()==name
        dialog.deleteLater()


def test_v4_roundtrip_ids_text_style_and_legacy_migration(window,tmp_path):
    c=window.canvas;setup(c);layer=text_layer(c)
    c.text_objects[0].update(stroke_width=5,stroke_color='#123456',italic=True,width_scale=1.7)
    file=tmp_path/'styled.mpaint';c.save_project(file);before=c.composite_image();ids=[l.id for l in c.layers]
    loaded=PaintCanvas();loaded.load_project(file)
    assert loaded.composite_image()==before and [l.id for l in loaded.layers]==ids
    assert loaded.text_objects==c.text_objects
    with zipfile.ZipFile(file) as z:assert json.loads(z.read('project.json'))['version']==4
    legacy=tmp_path/'legacy.mpaint'
    with zipfile.ZipFile(legacy,'w') as z:
        z.writestr('layers/base.png',png_bytes(transparent_image(100,100)))
        z.writestr('project.json',json.dumps(dict(version=3,width=100,height=100,layers=[dict(name='Old',path='layers/base.png')],text_objects=[dict(text='Old text',size=20,x=5,y=5)])))
    loaded.load_project(legacy)
    assert len(loaded.layers)==2 and loaded.layers[-1].kind=='text'
    assert loaded.text_objects[0]['layer_id']==loaded.layers[-1].id
    loaded.save_project(legacy);loaded.load_project(legacy);assert len(loaded.layers)==2


def test_duplicate_and_merge_preserve_editable_text(window):
    c=window.canvas;setup(c);text_layer(c);before=c.composite_image()
    c.duplicate_layer();assert len(c.text_objects)==2 and c.text_objects[0]['layer_id']!=c.text_objects[1]['layer_id']
    c.undo();assert len(c.text_objects)==1 and c.composite_image()==before
    c.active_layer=1;c.merge_down();assert len(c.layers)==1 and not c.text_objects and c.composite_image()==before
    c.undo();assert len(c.text_objects)==1


def test_copy_paste_cut_filter_preserve_alpha(window):
    c=window.canvas;setup(c);c.active.image.setPixelColor(20,20,QColor(10,30,50,150));c.selection=QRectF(10,10,30,30)
    c.copy_selection()
    from PySide6.QtWidgets import QApplication
    image=QApplication.clipboard().image();assert image.width()==30 and image.pixelColor(10,10).alpha()==150
    c.paste_image(image);assert len(c.layers)==2 and c.active.image.pixelColor(10,10).alpha()==150
    c.selection=None;c.apply_filter('invert');assert c.active.image.pixelColor(10,10)==QColor(245,225,205,150)
    c.undo();c.cut_selection();assert c.active.image==transparent_image(*c.doc_size)
    c.undo();assert c.active.image.pixelColor(10,10).alpha()==150


def test_export_mini_dialog_png_jpg_quality_and_background(window,monkeypatch,tmp_path):
    c=window.canvas;setup(c)
    def choose(dialog):dialog.format.setCurrentIndex(1);dialog.background.color=QColor('#ff0000');dialog.quality.setValue(90);return QDialog.DialogCode.Accepted
    monkeypatch.setattr(ExportDialog,'exec',choose)
    monkeypatch.setattr(QFileDialog,'getSaveFileName',lambda *a,**k:(str(tmp_path/'Result'),'JPEG (*.jpg *.jpeg)'))
    window.export_image();image=QImage(str(tmp_path/'Result.jpg'))
    assert not image.isNull() and image.pixelColor(200,200).red()>245 and image.pixelColor(200,200).green()<10


def test_space_pan_does_not_paint(window):
    c=window.canvas;setup(c);before=c.active.image.copy();old=QPointF(c.pan)
    QTest.keyPress(c,Qt.Key.Key_Space);QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(100,100));QTest.mouseMove(c,QPoint(130,120));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(130,120));QTest.keyRelease(c,Qt.Key.Key_Space)
    assert c.pan!=old and c.active.image==before and not c._space_down


def test_typing_in_inspector_does_not_switch_tools_and_new_document_disables_it(window):
    c=window.canvas;setup(c);text_layer(c);window.set_tool('Текст')
    edit=window.text_controls.content;edit.setFocus();edit.selectAll()
    QTest.keyClicks(edit,'Brush is great')
    assert c.tool=='Текст' and c.text_objects[0]['text']=='Brush is great'
    c.new_document(500,360)
    assert not window.text_controls.isEnabled()
