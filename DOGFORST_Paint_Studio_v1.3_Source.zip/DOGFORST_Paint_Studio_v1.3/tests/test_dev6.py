import json,uuid,zipfile
import pytest
from PySide6.QtCore import Qt,QPoint,QPointF,QRectF
from PySide6.QtGui import QColor,QImage,QPainter
from PySide6.QtWidgets import QDialog,QSpinBox,QMessageBox
from PySide6.QtTest import QTest
from layers import Layer,transparent_image
from canvas import PaintCanvas
from masks import mask_image,validate_mask
from recovery import DocumentSnapshot,RecoveryStore
from project_manager import read_project
from themes import ThemeDialog
from readability import THEME_NOTICE,readable_colors


def prepare(window,count=3,size=(100,80)):
    c=window.canvas;c.new_document(*size)
    c.layers=[Layer(f'Слой {i}',transparent_image(*size)) for i in range(count)]
    c.active_layer=count-1;c.sync_groups();c.set_selected_nodes([c.active.id]);c.zoom=1.;c.pan=QPointF()
    c.history.clear();c.future.clear();window.refresh_layers();return c


def test_full_picture_mode_ignores_marquee_and_moves_text_on_click(window):
    c=prepare(window);ids=[l.id for l in c.layers]
    for layer in c.layers:layer.image.setPixelColor(10,10,QColor('red'))
    c.text_objects=[dict(text='HELLO',x=30,y=20,size=24,layer_id=ids[1])]
    c.selection=QRectF(0,0,2,2);window.move_scope.setCurrentIndex(2);window.set_tool('Перемещение')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(40,30));QTest.mouseMove(c,QPoint(50,37));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(50,37))
    assert all(l.image.pixelColor(20,17)==QColor('red') for l in c.layers)
    assert c.text_objects[0]['x']==40 and c.text_objects[0]['y']==27
    c.undo();assert c.text_objects[0]['x']==30 and all(l.image.pixelColor(10,10)==QColor('red') for l in c.layers)


def test_visible_and_all_layer_scopes_and_locks(window):
    c=prepare(window,4)
    for layer in c.layers:layer.image.setPixelColor(10,10,QColor('red'))
    c.layers[0].visible=False;c.layers[1].position_locked=True
    window.move_scope.setCurrentIndex(1);c.move_selected_by(QPointF(5,0))
    assert c.layers[0].image.pixelColor(10,10)==QColor('red') and c.layers[1].image.pixelColor(10,10)==QColor('red')
    assert all(l.image.pixelColor(15,10)==QColor('red') for l in c.layers[2:])
    c.undo();window.move_scope.setCurrentIndex(2);c.move_selected_by(QPointF(5,0))
    assert c.layers[0].image.pixelColor(15,10)==QColor('red') and c.layers[1].image.pixelColor(10,10)==QColor('red')


def test_select_all_layer_button_selects_roots_and_does_not_create_area(window):
    c=prepare(window);ids=[l.id for l in c.layers];c.set_selected_nodes(ids[1:]);c.create_group()
    c.selection=QRectF(0,0,2,2)
    window.select_all_layers_ui()
    assert c.selected_layer_ids()==set(ids) and c.selection is None
    assert not c.auto_select_layer and c.tool=='Перемещение'


def test_outline_button_enables_medium_width_then_editing_and_undo(window):
    c=prepare(window,1);c.active.kind='text';c.text_objects=[dict(text='Обводка',x=10,y=10,size=32,layer_id=c.active.id)]
    c.select_text(0);controls=window.text_controls
    assert controls.stroke_width.value()==0 and not controls.outline_button.isChecked()
    QTest.mouseClick(controls.outline_button,Qt.MouseButton.LeftButton)
    assert c.text_objects[0]['stroke_width']==4 and controls.outline_panel.isVisible()
    controls.stroke_width.setValue(7);controls.stroke.color=QColor('blue');controls.stroke.colorChanged.emit()
    assert c.text_objects[0]['stroke_width']==7 and c.text_objects[0]['stroke_color']=='#0000ff'
    c.undo();assert c.text_objects[0].get('stroke_width',0)==0
    c.redo();assert c.text_objects[0]['stroke_width']==7


def test_white_black_gray_masks_are_non_destructive_and_undo(window):
    c=prepare(window,1);c.active.image.fill(QColor('red'));original=c.active.image.copy();identifier=c.active.id
    c.add_mask();assert c.composite_image()==original
    c.fill_mask(0);assert c.composite_image().pixelColor(20,20).alpha()==0 and c.active.image==original
    c.fill_mask(128);assert 127<=c.composite_image().pixelColor(20,20).alpha()<=128
    c.undo();assert c.masks[identifier].pixelColor(20,20).red()==0
    c.undo();assert c.masks[identifier].pixelColor(20,20).red()==255
    c.undo();assert not c.masks and c.active.image==original
    c.redo();assert identifier in c.masks


def test_mask_brush_eraser_clip_and_history_never_edit_pixels(window):
    c=prepare(window,1);c.active.image.fill(QColor('red'));before=c.active.image.copy();identifier=c.active.id
    c.add_mask();c.start_mask_edit();c.selection=QRectF(20,20,20,20);c.brush_size=20
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(20,30));QTest.mouseMove(c,QPoint(60,30));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(60,30))
    assert c.masks[identifier].pixelColor(30,30).red()==0 and c.masks[identifier].pixelColor(45,30).red()==255
    assert c.active.image==before
    c.undo();assert c.masks[identifier].pixelColor(30,30).red()==255
    c.redo();window.set_tool('Ластик');QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=QPoint(30,30))
    assert c.masks[identifier].pixelColor(30,30).red()==255 and c.active.image==before
    validate_mask(c.masks[identifier],c.doc_size)


def test_mask_fill_is_background_and_cancel_safe(window):
    c=prepare(window,1);c.active.image.fill(QColor('red'));c.add_mask();c.start_mask_edit();before=c.active.image.copy()
    c.flood_fill(10,10)
    for _ in range(200):
        QTest.qWait(10)
        if c.fill_job is None:break
    assert c.fill_job is None and c.composite_image().pixelColor(10,10).alpha()==0 and c.active.image==before
    c.undo();assert c.masks[c.active.id].pixelColor(10,10).red()==255


def test_mask_invert_disable_delete_and_undo(window):
    c=prepare(window,1);c.active.image.fill(QColor('red'));c.add_mask();identifier=c.active.id
    c.invert_mask();assert c.composite_image().pixelColor(10,10).alpha()==0
    c.set_mask_enabled(False);assert c.composite_image()==c.active.image
    c.undo();assert identifier not in c.disabled_masks
    c.delete_mask();assert not c.masks and c.composite_image()==c.active.image
    c.undo();assert c.masks[identifier].pixelColor(10,10).red()==0


def test_mask_on_text_and_group_preserves_editability(window):
    c=prepare(window,2);ids=[l.id for l in c.layers]
    c.layers[1].image.fill(QColor('red'));c.layers[1].kind='text';c.text_objects=[dict(text='Hello',x=10,y=10,size=24,layer_id=ids[1])]
    c.create_group();gid=c.control_node().id;c.add_mask(128)
    before=dict(c.text_objects[0]);assert c.composite_image().pixelColor(20,20).alpha()<=128
    c.set_selected_nodes([ids[1]]);c.add_mask(128)
    assert c.composite_image().pixelColor(20,20).alpha()<=65 and c.text_objects[0]==before
    assert gid in c.masks and ids[1] in c.masks


def test_mask_moves_with_whole_group_and_duplicates_independently(window):
    c=prepare(window,2);c.active.image.fill(QColor('red'));c.create_group();gid=c.control_node().id
    c.add_mask(0);c.masks[gid].setPixelColor(20,20,QColor('white'))
    window.move_scope.setCurrentIndex(2);c.move_selected_by(QPointF(8,6))
    assert c.masks[gid].pixelColor(28,26)==QColor('white') and c.masks[gid].pixelColor(20,20)==QColor('black')
    c.undo();assert c.masks[gid].pixelColor(20,20)==QColor('white')
    c.set_selected_nodes([gid]);c.duplicate_layer();clone=c.control_node().id
    assert c.masks[clone]==c.masks[gid]
    c.masks[clone].fill(QColor('white'));assert c.masks[gid].pixelColor(0,0)==QColor('black')
    c.undo();assert clone not in c.masks and gid in c.masks


def test_raster_mask_duplicate_delete_and_restore(window):
    c=prepare(window,2);c.add_mask(90);original=c.active.id;c.duplicate_layer();clone=c.active.id
    assert c.masks[clone]==c.masks[original]
    c.delete_layer();assert clone not in c.masks
    c.undo();assert clone in c.masks


def test_apply_text_mask_bakes_once_and_undo_restores_objects(window):
    c=prepare(window,1);c.active.kind='text';c.active.image.fill(QColor('red'))
    c.text_objects=[dict(text='A',x=10,y=10,size=24,layer_id=c.active.id)]
    c.add_mask(128);before=c.composite_image();c.apply_current_mask()
    assert not c.masks and not c.text_objects and c.active.kind=='raster'
    assert c.composite_image()==before
    c.undo();assert c.masks and c.text_objects and c.active.kind=='text' and c.composite_image()==before


def test_resize_and_crop_masks_keep_alignment_and_undo(window,monkeypatch):
    c=prepare(window,1);c.add_mask(0);identifier=c.active.id;c.masks[identifier].setPixelColor(20,20,QColor('white'))
    def choose(dialog):
        if dialog.windowTitle()=='Настроить размер холста':
            spins=dialog.findChildren(QSpinBox);spins[0].setValue(120);spins[1].setValue(100)
        return QDialog.DialogCode.Accepted
    monkeypatch.setattr(QDialog,'exec',choose);window.resize_canvas()
    assert c.masks[identifier].pixelColor(30,30)==QColor('white') and c.masks[identifier].size().toTuple()==(120,100)
    c.undo();assert c.doc_size==(100,80) and c.masks[identifier].pixelColor(20,20)==QColor('white')
    c.selection=QRectF(10,10,50,40);c.crop_selection()
    assert c.masks[identifier].pixelColor(10,10)==QColor('white') and c.doc_size==(50,40)
    c.undo();assert c.doc_size==(100,80) and c.masks[identifier].pixelColor(20,20)==QColor('white')


def test_mask_history_uses_lossless_tiles(window):
    c=prepare(window,1,size=(1024,1024));c.add_mask();c.history.clear();identifier=c.active.id
    for i in range(15):
        c.push_history();c.masks[identifier].setPixelColor(20+i,30+i,QColor(30+i,30+i,30+i));c.changed.emit();c.commit_history(force=True)
    final=c.masks[identifier].copy();assert c.history_engine.statistics()['estimated_bytes']<150000
    for _ in range(15):c.undo()
    assert c.masks[identifier]==mask_image(c.doc_size)
    for _ in range(15):c.redo()
    assert c.masks[identifier]==final


def test_v7_masks_roundtrip_disabled_group_and_editable_text(window,tmp_path):
    c=prepare(window,2);c.active.kind='text';c.text_objects=[dict(text='Test',x=10,y=10,size=24,layer_id=c.active.id)]
    c.active.blend_mode='screen';c.add_mask(170);leaf=c.active.id;c.set_mask_enabled(False)
    c.create_group();gid=c.control_node().id;c.add_mask(110)
    path=tmp_path/'Маски.mpaint';c.save_project(path);before=c.composite_image();c.load_project(path)
    assert set(c.masks)=={leaf,gid} and leaf in c.disabled_masks and c.text_objects[0]['text']=='Test'
    assert c.composite_image()==before
    with zipfile.ZipFile(path) as z:assert json.loads(z.read('project.json'))['version']==7
    c.save_project(path);c.load_project(path);assert c.composite_image()==before


def test_autosave_and_manual_save_capture_mask_snapshots(window,tmp_path):
    c=prepare(window,1);c.add_mask(80);identifier=c.active.id;snapshot=DocumentSnapshot.capture(c)
    c.masks[identifier].fill(QColor('white'))
    store=RecoveryStore(tmp_path/'recovery');record=store.write(snapshot,uuid.uuid4().hex,1)
    assert read_project(record.path).masks[identifier].pixelColor(10,10).red()==80
    window.current_file=str(tmp_path/'Saved.mpaint');assert window.save_project()
    assert read_project(window.current_file).masks[identifier].pixelColor(10,10).red()==255


@pytest.mark.parametrize('damage',['owner','duplicate','size','color','alpha','enabled','version'])
def test_invalid_mask_file_never_replaces_document(window,tmp_path,damage):
    from project_manager import png_bytes
    c=prepare(window,1);c.add_mask();path=tmp_path/'Bad.mpaint';c.save_project(path)
    with zipfile.ZipFile(path) as z:entries={n:z.read(n) for n in z.namelist()}
    manifest=json.loads(entries['project.json']);item=manifest['masks'][0]
    if damage=='owner':item['node_id']='missing'
    elif damage=='duplicate':manifest['masks'].append(dict(item))
    elif damage=='enabled':item['enabled']='yes'
    elif damage=='version':manifest['version']=6
    else:
        mask=mask_image((5,5) if damage=='size' else c.doc_size)
        if damage=='color':mask.setPixelColor(1,1,QColor('red'))
        if damage=='alpha':mask.setPixelColor(1,1,QColor(0,0,0,10))
        entries[item['path']]=png_bytes(mask)
    entries['project.json']=json.dumps(manifest).encode()
    with zipfile.ZipFile(path,'w') as z:
        for name,data in entries.items():z.writestr(name,data)
    before=c.masks[c.active.id].copy();pixels=c.active.image.copy()
    with pytest.raises(ValueError):c.load_project(path)
    assert c.masks[c.active.id]==before and c.active.image==pixels


def test_mask_locked_target_and_editing_shortcuts_protect_source(window):
    c=prepare(window,1);c.active.image.fill(QColor('red'));c.add_mask();identifier=c.active.id;c.start_mask_edit()
    original=c.active.image.copy();c.selection=QRectF(10,10,40,40);c.move_selected_by(QPointF(10,0))
    assert c.active.image==original
    c.active.locked=True;before=c.masks[identifier].copy();c.mask_stroke(QPointF(10,10),QPointF(40,40));c.invert_mask();c.delete_mask()
    assert c.masks[identifier]==before and c.active.image==original


def test_mask_copy_paste_and_delete_target_mask_only(window):
    c=prepare(window,1);c.active.image.fill(QColor('red'));c.add_mask();c.start_mask_edit();original=c.active.image.copy()
    image=transparent_image(30,30);image.fill(QColor('black'));c.paste_image(image)
    assert c.masks[c.active.id].pixelColor(10,10)==QColor('black') and len(c.layers)==1
    c.selection=QRectF(40,40,10,10);QTest.keyClick(c,Qt.Key.Key_Delete)
    assert c.masks[c.active.id].pixelColor(45,45)==QColor('black') and c.active.image==original


def test_mask_export_and_mask_only_preview_do_not_change_file(window,tmp_path):
    c=prepare(window,1);c.active.image.fill(QColor('red'));c.add_mask(128);c.start_mask_edit();c.show_mask=True
    before=c.composite_image();path=tmp_path/'Mask.png';c.export_image(path)
    assert QImage(str(path)).convertToFormat(before.format())==before and 127<=before.pixelColor(20,20).alpha()<=128


def test_comfort_preset_is_explicit_and_cancel_leaves_preferences(window,monkeypatch):
    c=prepare(window,1);pixels=c.active.image.copy();theme=window.theme_name
    def cancel(dialog):dialog.comfort_preset();return QDialog.DialogCode.Rejected
    monkeypatch.setattr(ThemeDialog,'exec',cancel);window.choose_theme()
    assert window.theme_name==theme and not window.reduce_motion and not window.large_text
    def accept(dialog):dialog.comfort_preset();dialog.contrast_check.setChecked(True);return QDialog.DialogCode.Accepted
    monkeypatch.setattr(ThemeDialog,'exec',accept);window.choose_theme()
    assert window.theme_name=='Soft' and window.reduce_motion and window.large_text and window.high_contrast
    assert not window._pearl.timer.isActive() and not c._marquee_timer.isActive() and c.active.image==pixels
    assert 'font-size: 12pt' in window.styleSheet()
    from app import MainWindow
    other=MainWindow();assert other.reduce_motion and other.large_text and other.high_contrast;other.close()


def test_reduced_motion_keeps_numeric_values_exact(window):
    window.reduce_motion=True;window.apply_theme('Аврора',True)
    window.size_slider.setValue(67);assert window.canvas.brush_size==67 and window.size_slider.visual_value==67
    assert not window.size_slider.animation.state().value and not window._theme_animation.state().value and not window._pearl.timer.isActive()


def test_about_dialog_includes_requested_theme_notice(window,monkeypatch):
    calls=[];monkeypatch.setattr(QMessageBox,'about',lambda parent,title,body:calls.append(body));window.show_about()
    assert THEME_NOTICE in calls[0] and 'не гарантируют защиту зрения' in calls[0]


def test_cancel_mask_fill_preserves_history_mask_and_source(window):
    c=prepare(window,1);c.active.image.fill(QColor('red'));c.add_mask();c.start_mask_edit();c.history.clear();c.future.clear()
    before=c.masks[c.active.id].copy();pixels=c.active.image.copy()
    c.flood_fill(10,10);c.fill_job.cancelled.set()
    for _ in range(200):
        QTest.qWait(10)
        if c.fill_job is None:break
    assert c.fill_job is None and c.masks[c.active.id]==before and c.active.image==pixels and not c.history


def test_layer_merge_consumes_masks_and_undo_restores_them(window):
    c=prepare(window,3);c.layers[1].image.fill(QColor('blue'));c.active.image.fill(QColor('red'));top=c.active.id
    c.add_mask(110);before=c.composite_image();c.merge_down()
    assert len(c.layers)==2 and top not in c.masks and c.composite_image()==before
    c.undo();assert len(c.layers)==3 and top in c.masks and c.composite_image()==before


def test_mask_edit_undo_restores_white_brush_and_original_color(window):
    c=prepare(window,1);c.color=QColor('red');c.add_mask(0);c.start_mask_edit();c.color=QColor('white')
    c.push_history();c.mask_stroke(QPointF(20,20),QPointF(30,20));c.changed.emit();c.commit_history(force=True)
    c.undo();assert c.editing_mask==c.active.id and c.color==QColor('white')
    c.stop_mask_edit();assert c.color==QColor('red')


def test_readability_contrast_keeps_text_legible_in_both_palettes():
    def luminance(value):
        color=QColor(value);channels=[color.redF(),color.greenF(),color.blueF()]
        return sum(weight*(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4) for weight,v in zip((.2126,.7152,.0722),channels))
    from themes import THEMES
    for name in ('Light','Dark'):
        palette=readable_colors(THEMES[name],True);fg=luminance(palette[1])
        for background in (palette[0],palette[2],palette[3],palette[4]):
            bg=luminance(background);assert (max(fg,bg)+.05)/(min(fg,bg)+.05)>=7
