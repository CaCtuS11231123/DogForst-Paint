import json,copy,threading,time,zipfile,hashlib,uuid
from pathlib import Path
import numpy as np
import pytest
from PySide6.QtCore import Qt,QPointF,QPoint,QRect,QRectF,QTimer
from PySide6.QtGui import QColor,QImage,QPainter
from PySide6.QtWidgets import QDialog,QApplication
from PySide6.QtTest import QTest
from test_dev7 import setup,imported
from test_v055 import stroke,move
from test_v056 import make_shape
from retouch import RETOUCH_TOOLS,RetouchInput,process_patch,RetouchJob
from layers import transparent_image
from selection_tools import from_array
from masks import validate_mask
from project_manager import read_project,png_bytes
from recovery import DocumentSnapshot,RecoveryStore
from integrity import verify_installation,verify_project_file,strict_json,IntegrityError,archive_preflight
from security_dialog import SecurityDialog
from versioning import Version


def wait(c):
    end=time.monotonic()+20
    while c.retouch_session is not None and time.monotonic()<end:QTest.qWait(10)
    assert c.retouch_session is None,'Retouch did not finish'

def retouch(window,tool,points):
    c=window.canvas;window.set_tool(tool);stroke(c,points);wait(c)

def patterned(c):
    p=QPainter(c.active.image);p.fillRect(20,30,90,100,QColor('#ed425c'));p.fillRect(110,30,90,100,QColor('#3179ca'));p.fillRect(30,150,100,25,QColor('#677b86'));p.end()


@pytest.mark.parametrize('tool',RETOUCH_TOOLS)
def test_each_tool_changes_real_pixels_and_exact_undo_redo(window,tool):
    c=setup(window,(300,220));patterned(c);before=c.active.image.copy();c.brush_size=60;c.brush_opacity=100;c.retouch_options.update(strength=70,hardness=75)
    window.set_tool(tool)
    if tool=='Штамп':assert c.set_clone_source(QPointF(60,70));points=[(220,70),(250,70)]
    elif tool=='Палец':points=[(85,70),(150,70)]
    else:points=[(105,70),(125,70)]
    stroke(c,points);wait(c);assert c.active.image!=before,tool;after=c.active.image.copy();c.undo();assert c.active.image==before;c.redo();assert c.active.image==after


def test_preview_is_not_model_snapshot_and_escape_cancels(window):
    c=setup(window);patterned(c);before=c.active.image.copy();window.mark_clean();window.set_tool('Размытие');c.brush_size=90
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(110,60));end=time.monotonic()+5
    while c.retouch_session and c.retouch_session.changes==0 and time.monotonic()<end:QTest.qWait(10)
    assert c.retouch_session and c.retouch_session.changes>0 and c.active.image==before and c.composite_image(True)!=c.composite_image()
    assert DocumentSnapshot.capture(c).layers[0].image==before and not window.dirty and not c.history
    QTest.keyClick(c,Qt.Key.Key_Escape);assert c.retouch_session is None and c.active.image==before and not window.dirty and window.tools_dock.isEnabled()


def test_clone_alt_source_and_aligned_offset(window):
    c=setup(window,(320,220));patterned(c);window.set_tool('Штамп');c.brush_size=20;c.retouch_options.update(strength=100,hardness=100,aligned=True)
    QTest.mouseClick(c,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.AltModifier,pos=QPoint(60,60));assert c.clone_anchor is not None
    stroke(c,[(230,60),(240,60)]);wait(c);assert c.active.image.pixelColor(232,60).red()>200;delta=QPointF(c.clone_delta)
    stroke(c,[(260,60),(270,60)]);wait(c);assert c.clone_delta==delta
    c.add_layer();assert not c.start_retouch(QPointF(50,50))


@pytest.mark.parametrize('tool',['Размытие','Резкость','Штамп','Палец'])
def test_selection_hole_and_alpha_lock_preserved(window,tool):
    c=setup(window,(300,220));patterned(c);values=np.zeros((220,300),np.uint8);values[20:180,20:260]=128;values[55:85,100:125]=0;c.set_selection_mask(from_array(values));c.commit_history(force=True);c.history.clear();before=c.active.image.copy();c.active.alpha_locked=True;c.brush_size=90;c.retouch_options['strength']=80;window.set_tool(tool)
    if tool=='Штамп':c.set_clone_source(QPointF(50,60))
    stroke(c,[(90,70),(150,70)]);wait(c);a=np.frombuffer(before.constBits(),np.uint32);b=np.frombuffer(c.active.image.constBits(),np.uint32);assert np.array_equal(a>>24,b>>24)
    assert c.active.image.pixelColor(110,70)==before.pixelColor(110,70) and c.active.image.pixelColor(5,5)==before.pixelColor(5,5)


@pytest.mark.parametrize('group',[False,True])
@pytest.mark.parametrize('tool',['Размытие','Осветление','Затемнение','Палец','Штамп'])
def test_mask_tools_remain_opaque_gray(window,group,tool):
    c=setup(window,(240,180));patterned(c)
    if group:c.create_group()
    c.add_mask(100);c.start_mask_edit();identifier=c.editing_mask;p=QPainter(c.masks[identifier]);p.fillRect(30,30,70,90,QColor('black'));p.end();before=c.layers[0].image.copy();mask=c.masks[identifier].copy();window.set_tool(tool);c.brush_size=50;c.retouch_options['strength']=75
    if tool=='Штамп':c.set_clone_source(QPointF(50,50))
    stroke(c,[(85,70),(150,70)]);wait(c);validate_mask(c.masks[identifier],c.doc_size);assert c.layers[0].image==before
    if c.masks[identifier]!=mask:c.undo();assert c.masks[identifier]==mask


def test_text_and_photo_rasterize_after_apply_and_undo_restores(window):
    c=imported(window);identifier=c.active.id;source=c.raster_objects[identifier]['source'].copy();c.brush_size=80;c.retouch_options['strength']=80;retouch(window,'Затемнение',[(120,80),(140,80)]);assert identifier not in c.raster_objects;c.undo();assert c.raster_objects[identifier]['source']==source
    from test_v03 import text_layer
    c=setup(window,(300,220));text_layer(c);c.set_selected_nodes({c.active.id},c.active.id);before=copy.deepcopy(c.text_objects);retouch(window,'Осветление',[(65,65),(90,65)]);assert not c.text_objects;c.undo();assert c.text_objects==before


def test_editable_shape_and_flags_restored_by_undo(window):
    c=setup(window);make_shape(window,filled=True,fill='#b088dd');identifier=c.active.id;recipe=copy.deepcopy(c.raster_objects[identifier]['shape']);c.active.glow=dict(enabled=True,color='#aa77ff',radius=10,spread=1,strength=80);c.brush_size=60;c.retouch_options['strength']=80
    retouch(window,'Затемнение',[(80,80),(130,80)]);assert identifier not in c.raster_objects and c.active.glow;c.undo();assert c.raster_objects[identifier]['shape']==recipe and c.active.glow


def test_cancel_restart_ignores_old_worker_and_document_switch(window):
    c=setup(window);patterned(c);window.set_tool('Размытие');c.brush_size=160;c.start_retouch(QPointF(110,60));c.cancel_retouch();assert c.start_retouch(QPointF(120,70));c.finish_retouch();wait(c)
    c.start_retouch(QPointF(110,60));c.new_document(80,60);end=time.monotonic()+5
    while c._retouch_job is not None and time.monotonic()<end:QTest.qWait(10)
    assert c.retouch_session is None and c.doc_size==(80,60) and c.active.image==transparent_image(80,60)


def test_stale_document_and_memory_error_do_not_overwrite(window,monkeypatch):
    c=setup(window);patterned(c);window.set_tool('Размытие');c.start_retouch(QPointF(100,60));c.active.image.fill(QColor('yellow'));c.finish_retouch();wait(c);assert c.active.image.pixelColor(1,1)==QColor('yellow')
    import retouch as module
    def failed(*args):raise MemoryError()
    monkeypatch.setattr(module,'process_patch',failed);before=c.active.image.copy();c.start_retouch(QPointF(50,50));c.finish_retouch();wait(c);assert c.active.image==before and window.layers_dock.isEnabled()


def test_noops_keep_redo_and_clone_without_source_rejects(window):
    c=setup(window);c.add_layer();c.undo();assert c.future;window.set_tool('Палец');stroke(c,[(40,40)]);wait(c);assert c.future
    window.set_tool('Штамп');assert not c.start_retouch(QPointF(40,40));window.set_tool('Размытие');c.retouch_options['strength']=0;assert not c.start_retouch(QPointF(40,40)) and c.future


def test_outside_gesture_clipped_and_panel_control_settings(window):
    c=setup(window,(180,120));c.active.image.fill(QColor('#888888'));c.pan=QPointF(80,80);window.set_tool('Осветление');window.retouch_panel.fields['size'].setValue(70);window.retouch_panel.fields['strength'].setValue(60)
    stroke(c,[(30,140),(320,140)]);wait(c);assert c.active.image.pixelColor(0,60).red()>136 and c.active.image.size()==QImage(180,120,QImage.Format.Format_ARGB32).size()
    assert window.settings.value('retouch/strength',type=int)==60


def test_blur_premultiplied_alpha_avoids_black_halo(qt):
    image=transparent_image(60,60);p=QPainter(image);p.fillRect(15,15,30,30,QColor('blue'));p.end();data=RetouchInput(image,QRect(0,0,60,60),QPointF(30,30),60,100,100,100,'Размытие');out=process_patch(data,threading.Event());sample=out.pixelColor(14,30);assert sample.alpha()>0 and sample.blue()>245 and sample.red()<3


def test_worker_validation_and_cancellation(qt):
    image=transparent_image(20,20);data=RetouchInput(image,QRect(0,0,20,20),QPointF(10,10),20,50,100,60,'wrong');received=[];job=RetouchJob('x',QRect(0,0,20,20),data);job.signals.done.connect(lambda j,p,e:received.append((p,e)));job.run();assert received[0][0] is None and received[0][1]
    event=threading.Event();event.set();data=RetouchInput(image,QRect(0,0,20,20),QPointF(10,10),20,50,100,60,'Размытие');assert process_patch(data,event) is None


def test_project_hashes_verify_and_legacy_without_hashes_loads(window,tmp_path):
    c=setup(window);patterned(c);path=tmp_path/'hash.mpaint';c.save_project(path,backup=False);report=verify_project_file(path);assert report['checksums'] and report['checked']==1
    with zipfile.ZipFile(path) as z:payload={n:z.read(n) for n in z.namelist()}
    p=json.loads(payload['project.json']);assert p['checksums'];p.pop('checksums');payload['project.json']=json.dumps(p).encode();old=tmp_path/'old.mpaint'
    with zipfile.ZipFile(old,'w') as z:
        for n,data in payload.items():z.writestr(n,data)
    assert not verify_project_file(old)['checksums'] and read_project(old)[1][0].image==c.active.image


@pytest.mark.parametrize('resource_kind',['layer','mask','source'])
def test_tampered_resource_is_rejected_and_document_is_safe(window,tmp_path,resource_kind):
    c=imported(window);c.add_mask();path=tmp_path/'safe.mpaint';c.save_project(path,backup=False)
    with zipfile.ZipFile(path) as z:payload={n:z.read(n) for n in z.namelist()}
    manifest=json.loads(payload['project.json']);key={'layer':'layers','mask':'masks','source':'raster_objects'}[resource_kind];name=manifest[key][0]['path'];image=QImage.fromData(payload[name]);image.setPixelColor(0,0,QColor('yellow'));payload[name]=png_bytes(image)
    bad=tmp_path/'bad.mpaint'
    with zipfile.ZipFile(bad,'w') as z:
        for n,data in payload.items():z.writestr(n,data)
    before=c.active.image.copy()
    with pytest.raises(IntegrityError):c.load_project(bad)
    with pytest.raises(IntegrityError):verify_project_file(bad)
    assert c.active.image==before


@pytest.mark.parametrize('text',['{"x":1,"x":2}','{"x":NaN}','{"x":Infinity}'])
def test_strict_project_json_rejects_ambiguous_data(text):
    with pytest.raises(IntegrityError):strict_json(text)


@pytest.mark.parametrize('name',['../file','/abs/file','dir/../../x','dir\\x','C:/file','dir//x'])
def test_project_archive_rejects_unsafe_paths(tmp_path,name):
    path=tmp_path/'bad.zip'
    # ZipInfo(name) sanitizes separators on Windows. Store a genuinely unsafe name.
    info=zipfile.ZipInfo(name);info.filename=name
    with zipfile.ZipFile(path,'w') as z:z.writestr(info,b'data')
    with zipfile.ZipFile(path) as z:
        with pytest.raises(IntegrityError):archive_preflight(z)


def installation(tmp_path):
    root=tmp_path/'install';root.mkdir();(root/'app.py').write_text('print(1)');data=(root/'app.py').read_bytes();manifest=dict(format='dogforst-release-sha256',schema=1,version='1.00',mode='source',critical=['app.py'],files={'app.py':dict(size=len(data),sha256=hashlib.sha256(data).hexdigest())});(root/'release_integrity.json').write_text(json.dumps(manifest));return root,manifest


def test_installation_manifest_detects_changed_missing_and_cancellation(tmp_path):
    root,p=installation(tmp_path);assert verify_installation(root)['ok'];(root/'app.py').write_text('print(2)');assert not verify_installation(root)['ok'];(root/'app.py').unlink();assert not verify_installation(root)['ok']
    (root/'app.py').write_text('print(1)');event=threading.Event();event.set()
    with pytest.raises(IntegrityError):verify_installation(root,event)


def test_installation_manifest_cannot_hash_outside_root(tmp_path):
    root,p=installation(tmp_path);p['files']['../secret']=p['files'].pop('app.py');p['critical']=['../secret'];(root/'release_integrity.json').write_text(json.dumps(p))
    with pytest.raises(IntegrityError):verify_installation(root)


def test_security_dialog_background_check_is_real(window,tmp_path):
    root,p=installation(tmp_path);d=SecurityDialog(window);d.start(verify_installation,root);end=time.monotonic()+5
    while d.job is not None and time.monotonic()<end:QTest.qWait(10)
    assert d.job is None and 'Контрольные суммы совпали' in d.output.toPlainText() and 'не используется' in d.output.toPlainText();d.reject()


def test_release_version_numbering():
    v=Version.parse('1.00');assert v.next_update().display()=='1.1' and v.next_fix().display()=='1.00.1';assert Version.parse('1.15.2').next_fix().display()=='1.15.3'
    with pytest.raises(ValueError):Version.parse('release')


def test_archive_duplicate_entries_are_rejected(tmp_path):
    import warnings
    path=tmp_path/'duplicate.mpaint'
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',UserWarning)
        with zipfile.ZipFile(path,'w') as z:z.writestr('project.json','{}');z.writestr('project.json','{}')
    with zipfile.ZipFile(path) as z:
        with pytest.raises(IntegrityError):archive_preflight(z)


def test_installation_rejects_symlink_escape(tmp_path):
    import os
    if os.name=='nt':pytest.skip('Symlinks can require Windows privileges')
    outside=tmp_path/'outside.py';outside.write_text('outside');root=tmp_path/'app';root.mkdir();(root/'link.py').symlink_to(outside)
    manifest=dict(format='dogforst-release-sha256',schema=1,version='1.00',mode='source',critical=['link.py'],files={'link.py':dict(size=7,sha256=hashlib.sha256(b'outside').hexdigest())})
    (root/'release_integrity.json').write_text(json.dumps(manifest))
    with pytest.raises(IntegrityError):verify_installation(root)


def test_pending_retouch_project_save_uses_original_then_applied(window,tmp_path):
    c=setup(window);patterned(c);before=c.active.image.copy();window.set_tool('Затемнение');c.brush_size=80;c.start_retouch(QPointF(90,65));end=time.monotonic()+5
    while c.retouch_session and c.retouch_session.changes==0 and time.monotonic()<end:QTest.qWait(10)
    assert c.retouch_session and c.retouch_session.changes
    snap=DocumentSnapshot.capture(c);path=tmp_path/'held.mpaint';__import__('project_manager').save_project(path,snap.size,snap.layers,snap.active_layer,list(snap.texts),backup=False);assert read_project(path)[1][0].image==before
    c.finish_retouch();wait(c);c.save_project(str(path),backup=False);assert read_project(path)[1][0].image==c.active.image and c.active.image!=before


def test_archive_rejects_raw_name_hidden_by_windows_normalization(tmp_path):
    path=tmp_path/'raw-name.zip'
    with zipfile.ZipFile(path,'w') as z:z.writestr('dir/x',b'data')
    with zipfile.ZipFile(path) as z:
        # Reproduce ZipInfo after Windows has normalized the displayed name.
        z.infolist()[0].orig_filename='dir\\x'
        with pytest.raises(IntegrityError):archive_preflight(z)
