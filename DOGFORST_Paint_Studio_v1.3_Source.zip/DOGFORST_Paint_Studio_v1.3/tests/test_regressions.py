import json
import zipfile
import time
import threading
from pathlib import Path
import pytest
from PySide6.QtCore import Qt,QPoint,QPointF,QRectF,QTimer
from PySide6.QtGui import QColor,QImage,QPainter,QTransform
from PySide6.QtWidgets import QFileDialog,QMessageBox,QDialog,QSpinBox,QTextEdit
from PySide6.QtTest import QTest
from canvas import PaintCanvas
from project_manager import read_project,save_project
from layers import Layer,transparent_image
from fill import fill_image
from themes import THEMES,ThemeDialog


def small(canvas,w=64,h=48):
    canvas.new_document(w,h);canvas.zoom=1.;canvas.pan=QPointF(0,0)


def test_layer_selection_visibility_and_rename(window, qt):
    c=window.canvas;small(c);c.add_layer();c.add_layer()
    for row in range(3):
        window.layer_list.setCurrentRow(row)
        assert c.active_layer==2-row
        assert all(l.visible for l in c.layers)
    item=window.layer_list.item(1);item.setCheckState(Qt.CheckState.Unchecked)
    assert [l.visible for l in c.layers]==[True,False,True]
    item.setText('Переименован');assert c.layers[1].name=='Переименован'
    window.set_tool('Ластик');window.apply_theme('Light',False)
    assert [l.visible for l in c.layers]==[True,False,True]
    c.undo();assert c.layers[1].name!='Переименован'
    c.undo();assert all(l.visible for l in c.layers)
    c.redo();assert not c.layers[1].visible


def test_reorder_arrows_preserve_active_content(window):
    small(window.canvas);window.canvas.add_layer();window.canvas.add_layer()
    layer=window.canvas.layers[1];window.canvas.active_layer=1
    window.reorder_layer(1);assert window.canvas.layers[2] is layer
    window.canvas.undo();assert window.canvas.active_layer==1


@pytest.mark.parametrize('version',[1,2,3])
def test_project_roundtrip_versions(qt,tmp_path,version):
    c=PaintCanvas();small(c);c.active.image.setPixelColor(4,5,QColor('#cc33aa'))
    c.add_layer();c.active.visible=False;c.active.opacity=.37
    c.text_objects=[dict(text='Привет',x=8,y=3,font='Sans',size=16,bold=True,color='#123456',rotation=45)]
    target=tmp_path/'Русская папка'/'Тест.mpaint';c.save_project(target)
    # Represent legacy manifests without changing their image payloads.
    with zipfile.ZipFile(target) as z: payload={n:z.read(n) for n in z.namelist()}
    manifest=json.loads(payload['project.json']);manifest['version']=version
    payload['project.json']=json.dumps(manifest).encode()
    with zipfile.ZipFile(target,'w') as z:
        for name,data in payload.items():z.writestr(name,data)
    loaded=PaintCanvas();loaded.load_project(target)
    assert loaded.doc_size==(64,48) and loaded.active_layer==1
    assert loaded.layers[0].image.pixelColor(4,5)==QColor('#cc33aa')
    assert not loaded.active.visible and loaded.active.opacity==.37
    assert [{k:v for k,v in t.items() if k!='layer_id'} for t in loaded.text_objects]==[{k:v for k,v in t.items() if k!='layer_id'} for t in c.text_objects]
    assert loaded.text_objects[0]['layer_id'] in [layer.id for layer in loaded.layers]
    loaded.save_project(target);loaded.load_project(target)
    assert loaded.layers[0].image.pixelColor(4,5)==QColor('#cc33aa')


def test_atomic_save_failure_preserves_file(qt,tmp_path,monkeypatch):
    import project_manager as pm
    c=PaintCanvas();small(c);target=tmp_path/'safe.mpaint';c.save_project(target);old=target.read_bytes()
    def fail(*args):raise OSError('Диск заполнен')
    monkeypatch.setattr(pm,'png_bytes',fail)
    with pytest.raises(OSError):c.save_project(target)
    assert target.read_bytes()==old
    assert not list(tmp_path.glob('.dogforst-*.tmp'))


def test_corrupt_project_does_not_replace_document(qt,tmp_path):
    c=PaintCanvas();small(c);c.active.image.setPixelColor(1,1,QColor('red'))
    target=tmp_path/'empty.mpaint'
    with zipfile.ZipFile(target,'w'):pass
    with pytest.raises(ValueError,match='project.json'):c.load_project(target)
    assert c.active.image.pixelColor(1,1)==QColor('red')
    assert c.doc_size==(64,48)


@pytest.mark.parametrize('extension',['png','jpg','bmp','webp'])
def test_exports(qt,tmp_path,extension):
    c=PaintCanvas();small(c);c.active.image.setPixelColor(8,8,QColor('red'))
    file=tmp_path/f'Экспорт.{extension}';c.export_image(str(file));image=QImage(str(file))
    assert not image.isNull() and (image.width(),image.height())==(64,48)
    if extension in ('bmp','jpg'):assert image.pixelColor(0,0).lightness()>245
    if extension=='png':assert image.pixelColor(0,0).alpha()==0
    if extension in ('bmp','png'):assert image.pixelColor(8,8)==QColor('red')


def test_stroke_undo_redo(window,qt):
    c=window.canvas;small(c);window.set_tool('Кисть');window.set_color(QColor('red'))
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(10,10))
    QTest.mouseMove(c,QPoint(30,10));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(30,10))
    assert c.active.image.pixelColor(20,10).red()==255
    c.undo();assert c.active.image.pixelColor(20,10).alpha()==0
    c.redo();assert c.active.image.pixelColor(20,10).alpha()>0


def test_opacity_gesture_single_undo(window):
    c=window.canvas;small(c);before=len(c.history)
    c.begin_opacity_edit();c.set_layer_opacity(0,80);c.set_layer_opacity(0,40);c.end_opacity_edit()
    assert len(c.history)==before+1 and c.active.opacity==.4
    c.undo();assert c.active.opacity==1.
    c.redo();assert c.active.opacity==.4


def test_move_selection_uses_original_rectangle(window):
    c=window.canvas;small(c);c.active.image.fill(Qt.GlobalColor.transparent)
    for x in range(10,15):
        for y in range(10,15):c.active.image.setPixelColor(x,y,QColor('red'))
    c.selection=QRectF(10,10,5,5);window.set_tool('Перемещение')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(12,12))
    QTest.mouseMove(c,QPoint(20,12));QTest.mouseMove(c,QPoint(25,12))
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(25,12))
    assert c.selection==QRectF(23,10,5,5)
    assert c.active.image.pixelColor(23,10)==QColor('red')
    assert c.active.image.pixelColor(10,10).alpha()==0
    c.undo();assert c.active.image.pixelColor(10,10)==QColor('red')


def test_text_drag_and_rotated_hit(window):
    c=window.canvas;small(c,240,160)
    c.text_objects=[dict(text='TEXT',x=60.,y=40.,size=24,font='Sans',rotation=90)]
    assert c._text_hit(QPointF(50,50))==0
    window.set_tool('Текст')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(50,50))
    QTest.mouseMove(c,QPoint(70,70));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(70,70))
    assert c.text_objects[0]['x']==80
    c.undo();assert c.text_objects[0]['x']==60
    c.redo();assert c.text_objects[0]['y']==60


def test_negative_slope_line(window):
    c=window.canvas;small(c);window.set_tool('Линия')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(40,10))
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(10,40))
    assert c.active.image.pixelColor(40,10).alpha()>0
    assert c.active.image.pixelColor(10,10).alpha()==0


def test_canvas_resize_moves_text_with_pixels(window,monkeypatch):
    c=window.canvas;small(c,64,48)
    c.active.image.setPixelColor(1,1,QColor('red'));c.text_objects=[dict(text='X',x=10,y=10,size=16)]
    def accept(dialog):
        spins=dialog.findChildren(QSpinBox);spins[0].setValue(84);spins[1].setValue(68)
        return QDialog.DialogCode.Accepted
    monkeypatch.setattr(QDialog,'exec',accept)
    window.resize_canvas()
    assert c.doc_size==(84,68) and c.text_objects[0]['x']==20
    assert c.active.image.pixelColor(11,11)==QColor('red')
    c.undo();assert c.doc_size==(64,48) and c.text_objects[0]['x']==10


def test_fill_connectivity_tolerance_opacity(qt):
    image=transparent_image(10,8);image.fill(QColor('#202020'))
    for y in range(8):image.setPixelColor(5,y,QColor('white'))
    image.setPixelColor(1,1,QColor('#252525'))
    result=fill_image(image,0,0,QColor('red'),5,50)
    assert result.pixelColor(1,1)==QColor(255,0,0,128)
    assert result.pixelColor(8,1)==QColor('#202020')
    assert result.pixelColor(5,1)==QColor('white')
    assert image.pixelColor(0,0)==QColor('#202020')
    event=threading.Event();event.set()
    assert fill_image(image,0,0,QColor('red'),5,100,event) is None


def test_async_fill_undo_and_heartbeat(window,qt):
    c=window.canvas;small(c,1800,1200);ticks=[]
    timer=QTimer();timer.setInterval(2);timer.timeout.connect(lambda:ticks.append(1));timer.start()
    c.color=QColor('blue');c.flood_fill(0,0)
    start=time.perf_counter()
    while c.fill_job is not None and time.perf_counter()-start<15:QTest.qWait(5)
    timer.stop()
    assert c.fill_job is None and len(ticks)>1
    assert c.active.image.pixelColor(500,500)==QColor('blue')
    c.undo();assert c.active.image.pixelColor(500,500).alpha()==0
    c.redo();assert c.active.image.pixelColor(500,500)==QColor('blue')


def test_theme_dialog_and_persistence_tools(window,qt):
    c=window.canvas;small(c);c.active.image.setPixelColor(1,1,QColor('red'));original=c.active.image.copy()
    window.set_tool('Пипетка');cursor=c.cursor().pixmap().cacheKey()
    for name in ('Light','Dark','Neon','Soft'):
        dialog=ThemeDialog(name,window)
        assert dialog.selected==name and dialog.group.checkedButton().text()==name
        window.apply_theme(name);QTest.qWait(240)
        assert window.settings.value('theme')==name and c.tool=='Пипетка'
        assert c.cursor().pixmap().cacheKey()==cursor and c.active.image==original
        dialog.deleteLater()
    from app import MainWindow
    second=MainWindow();assert second.theme_name=='Soft';second.close()


def test_all_tools_cursor_and_exact_slider(window):
    c=window.canvas
    for tool in c.TOOLS:
        window.set_tool(tool)
        from shapes import SHAPES
        button=window.tool_buttons['Фигуры' if tool in SHAPES else tool]
        assert c.tool==tool and button.isChecked()
        assert not button.icon().isNull()
    window.set_tool('Кисть');before=c.cursor().pixmap().size()
    window.size_spin.setValue(50);assert c.cursor().pixmap().size()!=before
    window.opacity_slider.setValue(37)
    assert c.brush_opacity==37 and window.opacity_spin.value()==37
    window.set_color(QColor('black'))
    assert c.color==QColor('black')


def test_save_as_and_resave_ui(window,tmp_path,monkeypatch):
    c=window.canvas;small(c)
    target=tmp_path/'Работа.mpaint'
    monkeypatch.setattr(QFileDialog,'getSaveFileName',lambda *a,**k:(str(target),'Проекты DOGFORST (*.mpaint)'))
    assert window.save_project_as() is True and not window.dirty
    c.add_layer();assert window.dirty
    assert window.save_project() is True and not window.dirty
    assert len(read_project(target)[1])==2


def test_failed_save_and_cancel_prevent_close(window,monkeypatch):
    window.mark_dirty()
    monkeypatch.setattr(QMessageBox,'warning',lambda *a,**k:QMessageBox.StandardButton.Cancel)
    assert not window.confirm_document_change()
    monkeypatch.setattr(QMessageBox,'warning',lambda *a,**k:QMessageBox.StandardButton.Save)
    monkeypatch.setattr(QFileDialog,'getSaveFileName',lambda *a,**k:('',''))
    assert not window.confirm_document_change() and window.dirty


def test_text_create_edit_delete_dialog(window,monkeypatch):
    c=window.canvas;small(c,200,150);window.set_tool('Текст')
    def accept(dialog):
        edit=dialog.findChild(QTextEdit);edit.setPlainText('Новый текст')
        return QDialog.DialogCode.Accepted
    monkeypatch.setattr(QDialog,'exec',accept)
    c.edit_text_dialog(None,QPointF(20,20))
    assert len(c.text_objects)==1 and c.text_objects[0]['text']=='Новый текст'
    def edit(dialog):
        dialog.findChild(QTextEdit).setPlainText('Изменён')
        return QDialog.DialogCode.Accepted
    monkeypatch.setattr(QDialog,'exec',edit)
    c.edit_text_dialog(0)
    assert c.text_objects[0]['text']=='Изменён'
    QTest.keyClick(c,Qt.Key.Key_Delete);assert not c.text_objects
    c.undo();assert c.text_objects[0]['text']=='Изменён'
    c.undo();assert c.text_objects[0]['text']=='Новый текст'


def test_cancelled_async_fill_leaves_history_unchanged(window,qt):
    c=window.canvas;small(c,1800,1200);before=len(c.history)
    c.color=QColor('green');c.flood_fill(0,0);c.fill_job.cancelled.set()
    start=time.perf_counter()
    while c.fill_job is not None and time.perf_counter()-start<15:QTest.qWait(5)
    assert c.fill_job is None and len(c.history)==before
    assert c.active.image.pixelColor(500,500).alpha()==0


def test_eraser_opacity_and_zoom_anchor(window):
    c=window.canvas;small(c,200,150);c.active.image.fill(QColor('red'))
    window.set_tool('Ластик');c.brush_opacity=50;c.brush_size=20
    c._stroke(QPointF(50,50),QPointF(60,50))
    assert 120 <= c.active.image.pixelColor(55,50).alpha() <= 135
    anchor=QPointF(75,60);before=c.doc_point(anchor);c.set_zoom(2.,anchor)
    assert c.doc_point(anchor)==before


def test_selection_clips_brush_and_shapes(window):
    c=window.canvas;small(c);c.selection=QRectF(10,10,15,15)
    c.brush_size=8;c.color=QColor('red');c._stroke(QPointF(0,15),QPointF(40,15))
    assert c.active.image.pixelColor(15,15)==QColor('red')
    assert c.active.image.pixelColor(5,15).alpha()==0
    window.set_tool('Линия')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(0,20))
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(40,20))
    assert c.active.image.pixelColor(5,20).alpha()==0


def test_black_swatch_stays_black(window):
    black=next(b for b in window.swatch_buttons if b.color==QColor('black'))
    black.click()
    assert black.isChecked() and black.color==QColor('black')
    assert window.canvas.color==QColor('black')


def test_fill_clips_selection(qt):
    image=transparent_image(20,20)
    result=fill_image(image,8,8,QColor('blue'),0,100,bounds=(5,5,10,10))
    assert result.pixelColor(8,8)==QColor('blue')
    assert result.pixelColor(4,8).alpha()==0
    assert fill_image(image,1,1,QColor('blue'),0,100,bounds=(5,5,10,10)) is None


def test_actual_checkbox_click_does_not_toggle_other_layers(window,qt):
    c=window.canvas;small(c);c.add_layer();c.add_layer();qt.processEvents()
    item=window.layer_list.item(1);rect=window.layer_list.visualItemRect(item)
    QTest.mouseClick(window.layer_list.viewport(),Qt.MouseButton.LeftButton,pos=QPoint(rect.left()+18,rect.center().y()))
    assert [l.visible for l in c.layers]==[True,False,True]
    window.layer_list.setCurrentRow(2);window.layer_list.setCurrentRow(0)
    assert [l.visible for l in c.layers]==[True,False,True]
