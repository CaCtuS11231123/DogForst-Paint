import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import uuid
import zipfile

import pytest
from PySide6.QtCore import QLockFile, QTimer
from PySide6.QtGui import QColor
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QDialog, QFileDialog, QMessageBox
from canvas import PaintCanvas
from project_manager import read_project
from recovery import DocumentSnapshot, RecoveryStore
from storage import list_versions, backup_directory, OperationCancelled
from safety_dialogs import SafetySettingsDialog, ProjectCopiesDialog


def wait_for(predicate, seconds=8):
    start = time.monotonic()
    while not predicate() and time.monotonic() - start < seconds:
        QTest.qWait(5)
    assert predicate(), 'Background operation did not complete'


def prepare(window):
    window.canvas.new_document(32, 24)
    window.current_file = None
    window.mark_clean()
    window.start_document_session()
    return window.canvas, window._safety


def paint(canvas, color):
    canvas.push_history()
    canvas.active.image.setPixelColor(3, 4, QColor(color))
    canvas.changed.emit()


def images_in(controller, session=None):
    directory = controller.store.session_directory(session or controller.session)
    return sorted(directory.glob('*.mpaint'))


def test_previous_project_preserved_in_versions(qt, tmp_path):
    c = PaintCanvas()
    c.new_document(32, 24)
    target = tmp_path / 'Русская папка' / 'Рисунок.mpaint'
    paint(c, 'red')
    c.save_project(target)
    old = target.read_bytes()
    paint(c, 'blue')
    c.save_project(target)
    versions = list_versions(target)
    assert len(versions) == 1 and versions[0].read_bytes() == old
    assert read_project(target)[1][0].image.pixelColor(3, 4) == QColor('blue')
    assert read_project(versions[0])[1][0].image.pixelColor(3, 4) == QColor('red')


def test_backup_failure_never_replaces_main_file(qt, tmp_path, monkeypatch):
    import project_manager as pm
    c = PaintCanvas()
    c.new_document(32, 24)
    target = tmp_path / 'safe.mpaint'
    c.save_project(target)
    old = target.read_bytes()
    def fail(*_):
        raise PermissionError('Backup directory not writable')
    monkeypatch.setattr(pm, 'create_backup', fail)
    paint(c, 'red')
    with pytest.raises(PermissionError):
        c.save_project(target)
    assert target.read_bytes() == old
    assert not list(tmp_path.glob('.dogforst-*.tmp'))


def test_replace_failure_keeps_previous_file_and_backup(qt, tmp_path, monkeypatch):
    import project_manager as pm
    c = PaintCanvas()
    c.new_document(32, 24)
    target = tmp_path / 'safe.mpaint'
    c.save_project(target)
    old = target.read_bytes()
    replace = pm.os.replace
    def fail_only_main(source, destination):
        if Path(destination) == target:
            raise OSError('Main file is locked')
        return replace(source, destination)
    monkeypatch.setattr(pm.os, 'replace', fail_only_main)
    paint(c, 'blue')
    with pytest.raises(OSError):
        c.save_project(target)
    assert target.read_bytes() == old
    assert list_versions(target)[0].read_bytes() == old


def test_retention_does_not_delete_unmanaged_files(qt, tmp_path):
    c = PaintCanvas()
    c.new_document(32, 24)
    target = tmp_path / 'versions.mpaint'
    c.save_project(target)
    folder = backup_directory(target)
    folder.mkdir(parents=True, exist_ok=True)
    other = folder / 'My-important-file.mpaint'
    other.write_bytes(b'preserve')
    for color in ('red', 'blue', 'green', 'black'):
        paint(c, color)
        c.save_project(target, backup_limit=2)
    assert len(list_versions(target)) == 2
    assert other.read_bytes() == b'preserve'


def test_project_versions_survive_moving_project_folder(qt, tmp_path):
    c = PaintCanvas()
    c.new_document(32, 24)
    old = tmp_path / 'Before'
    target = old / 'Drawing.mpaint'
    paint(c, 'red')
    c.save_project(target)
    paint(c, 'blue')
    c.save_project(target)
    new = tmp_path / 'After'
    old.rename(new)
    moved = new / target.name
    versions = list_versions(moved)
    assert len(versions) == 1
    assert read_project(versions[0])[1][0].image.pixelColor(3, 4) == QColor('red')
    paint(c, 'green')
    c.save_project(moved)
    assert len(list_versions(moved)) == 2


def test_cancel_mid_save_leaves_main_and_history_unchanged(qt, tmp_path):
    c = PaintCanvas()
    c.new_document(32, 24)
    c.add_layer()
    target = tmp_path / 'safe.mpaint'
    c.save_project(target)
    old = target.read_bytes()
    event = threading.Event()
    def progress(*_):
        event.set()
    with pytest.raises(OperationCancelled):
        c.save_project(target, cancelled=event, progress=progress)
    assert target.read_bytes() == old and not list_versions(target)


def test_snapshot_detaches_pixels_text_and_layer_properties(qt, tmp_path):
    c = PaintCanvas()
    c.new_document(32, 24)
    paint(c, 'red')
    c.text_objects = [dict(text='Before', x=1, y=1, size=12)]
    snapshot = DocumentSnapshot.capture(c)
    paint(c, 'blue')
    c.active.name = 'After'
    c.text_objects[0]['text'] = 'Changed'
    store = RecoveryStore(tmp_path / 'recovery')
    record = store.write(snapshot, uuid.uuid4().hex, 1)
    size, layers, _, texts = store.read(record)
    assert size == (32, 24) and layers[0].image.pixelColor(3, 4) == QColor('red')
    assert layers[0].name != 'After' and texts[0]['text'] == 'Before'
    assert texts[0]['layer_id'] == layers[-1].id


def test_store_generations_metadata_and_cancellation(qt, tmp_path):
    c = PaintCanvas()
    c.new_document(32, 24)
    store = RecoveryStore(tmp_path / 'recovery')
    session = uuid.uuid4().hex
    source = str(tmp_path / 'Original.mpaint')
    for revision, color in enumerate(('red', 'green', 'blue'), 1):
        paint(c, color)
        store.write(DocumentSnapshot.capture(c), session, revision, source)
    records = store.candidates()
    assert [r.revision for r in records] == [3, 2]
    assert records[0].source == source
    latest = records[0].path.read_bytes()
    event = threading.Event()
    event.set()
    with pytest.raises(OperationCancelled):
        store.write(DocumentSnapshot.capture(c), session, 4, source, event)
    assert records[0].path.read_bytes() == latest
    assert len(store.candidates()) == 2


@pytest.mark.parametrize('metadata', ['missing', 'broken'])
def test_complete_project_recoverable_without_metadata(qt, tmp_path, metadata):
    c = PaintCanvas()
    c.new_document(32, 24)
    store = RecoveryStore(tmp_path / 'recovery')
    record = store.write(DocumentSnapshot.capture(c), uuid.uuid4().hex, 1)
    meta = record.path.with_suffix('.json')
    if metadata == 'missing':
        meta.unlink()
    else:
        meta.write_text('{broken')
    records = store.candidates()
    assert len(records) == 1 and store.read(records[0])[0] == (32, 24)


def test_live_session_not_offered_for_recovery(qt, tmp_path):
    c = PaintCanvas()
    c.new_document(32, 24)
    store = RecoveryStore(tmp_path / 'recovery')
    session = uuid.uuid4().hex
    record = store.write(DocumentSnapshot.capture(c), session, 1)
    lock = QLockFile(str(record.path.parent / '.lock'))
    lock.setStaleLockTime(0)
    assert lock.tryLock(0)
    assert store.candidates() == []
    lock.unlock()
    assert len(store.candidates()) == 1


def test_recovery_cannot_delete_user_project(qt, tmp_path):
    from recovery import RecoveryRecord
    store = RecoveryStore(tmp_path / 'recovery')
    outside = tmp_path / 'Original.mpaint'
    outside.write_bytes(b'never delete')
    with pytest.raises(ValueError):
        store.remove(RecoveryRecord(outside, uuid.uuid4().hex, 1, None, ''))
    assert outside.read_bytes() == b'never delete'


def test_autosave_is_background_copy_and_keeps_document_dirty(window):
    c, controller = prepare(window)
    paint(c, 'red')
    ticks = []
    timer = QTimer()
    timer.setInterval(1)
    timer.timeout.connect(lambda: ticks.append(1))
    timer.start()
    assert controller.request_autosave(force=True)
    wait_for(lambda: controller.job is None)
    timer.stop()
    assert ticks and window.dirty and window.current_file is None
    assert read_project(images_in(controller)[0])[1][0].image.pixelColor(3, 4) == QColor('red')
    assert controller.progress.value() == 100
    assert not controller.request_autosave()


def delayed_writer(monkeypatch, controller):
    started, release = threading.Event(), threading.Event()
    original = controller.store.write
    def delayed(*args, **kwargs):
        started.set()
        release.wait(3)
        return original(*args, **kwargs)
    monkeypatch.setattr(controller.store, 'write', delayed)
    return started, release


def test_edits_during_autosave_not_lost_or_marked_clean(window, monkeypatch):
    c, controller = prepare(window)
    paint(c, 'red')
    started, release = delayed_writer(monkeypatch, controller)
    assert controller.request_autosave(force=True)
    wait_for(started.is_set)
    try:
        paint(c, 'blue')
    finally:
        release.set()
    wait_for(lambda: controller.job is None)
    assert window.dirty and c.active.image.pixelColor(3, 4) == QColor('blue')
    assert read_project(images_in(controller)[0])[1][0].image.pixelColor(3, 4) == QColor('red')
    assert controller.request_autosave()
    wait_for(lambda: controller.job is None)
    assert read_project(images_in(controller)[-1])[1][0].image.pixelColor(3, 4) == QColor('blue')


def test_manual_save_prevents_obsolete_autosave_reappearing(window, monkeypatch, tmp_path):
    c, controller = prepare(window)
    paint(c, 'red')
    started, release = delayed_writer(monkeypatch, controller)
    controller.request_autosave(force=True)
    wait_for(started.is_set)
    try:
        window.current_file = str(tmp_path / 'Manual.mpaint')
        assert window.save_project()
    finally:
        release.set()
    wait_for(lambda: controller.job is None)
    assert not images_in(controller) and not window.dirty
    assert read_project(window.current_file)[1][0].image.pixelColor(3, 4) == QColor('red')


def test_new_document_never_receives_previous_autosave_result(window, monkeypatch):
    c, controller = prepare(window)
    paint(c, 'red')
    old_session = controller.session
    started, release = delayed_writer(monkeypatch, controller)
    controller.request_autosave(force=True)
    wait_for(started.is_set)
    try:
        c.new_document(32, 24)
        window.mark_clean()
        window.start_document_session()
        paint(c, 'green')
    finally:
        release.set()
    wait_for(lambda: controller.job is None)
    assert controller.session != old_session and window.dirty
    assert c.active.image.pixelColor(3, 4) == QColor('green')
    assert not images_in(controller, old_session) and controller.last_autosaved == -1


def test_cancelled_autosave_retains_last_complete_generation(window, monkeypatch):
    c, controller = prepare(window)
    paint(c, 'red')
    controller.request_autosave(force=True)
    wait_for(lambda: controller.job is None)
    first = images_in(controller)[0].read_bytes()
    paint(c, 'blue')
    started, release = delayed_writer(monkeypatch, controller)
    controller.request_autosave(force=True)
    wait_for(started.is_set)
    controller.cancel()
    release.set()
    wait_for(lambda: controller.job is None)
    assert len(images_in(controller)) == 1 and images_in(controller)[0].read_bytes() == first
    assert window.dirty


def test_restore_is_unsaved_copy_and_preserves_original(window, tmp_path):
    c, controller = prepare(window)
    paint(c, 'red')
    source = tmp_path / 'Original.mpaint'
    c.save_project(source)
    old = source.read_bytes()
    paint(c, 'blue')
    record = controller.store.write(DocumentSnapshot.capture(c), uuid.uuid4().hex, 2, str(source))
    window.mark_clean()
    assert controller.restore(record)
    assert window.current_file is None and window.dirty
    assert c.active.image.pixelColor(3, 4) == QColor('blue')
    assert source.read_bytes() == old and record.path.exists()
    window.current_file = str(tmp_path / 'Restored.mpaint')
    assert window.save_project()
    assert not record.path.exists() and source.read_bytes() == old


def test_corrupt_restore_does_not_replace_visible_document(window, tmp_path, monkeypatch):
    from recovery import RecoveryRecord
    c, controller = prepare(window)
    paint(c, 'red')
    window.mark_clean()
    broken = tmp_path / 'Broken.mpaint'
    broken.write_bytes(b'not a zip')
    monkeypatch.setattr(QMessageBox, 'warning', lambda *a, **k: QMessageBox.StandardButton.Ok)
    assert not controller.restore(RecoveryRecord(broken, '', -1, None, ''), recovery=False)
    assert c.active.image.pixelColor(3, 4) == QColor('red') and not window.dirty


def test_settings_persist_interval_and_backup_count(window, monkeypatch):
    _, controller = prepare(window)
    def accept(dialog):
        dialog.enabled.setChecked(False)
        dialog.minutes.setValue(3)
        dialog.backups.setValue(4)
        return QDialog.DialogCode.Accepted
    monkeypatch.setattr(SafetySettingsDialog, 'exec', accept)
    controller.show_settings()
    assert not controller.timer.isActive() and controller.timer.interval() == 180_000
    assert controller.backup_limit == 4
    from app import MainWindow
    second = MainWindow()
    assert not second._safety.enabled and second._safety.minutes == 3
    assert second._safety.backup_limit == 4
    second.close()


def test_idle_or_partial_gesture_is_not_autosaved(window):
    c, controller = prepare(window)
    assert not controller.request_autosave(force=True)
    paint(c, 'red')
    c.drawing = True
    assert not controller.request_autosave()
    c.drawing = False
    c._opacity_edit = True
    assert not controller.request_autosave()
    c._opacity_edit = False


def test_recovery_after_real_process_kill_ignores_partial_write(qt, tmp_path):
    module_root = str(Path(__file__).resolve().parents[1])
    store_path, ready = tmp_path / 'recovery', tmp_path / 'ready'
    session = uuid.uuid4().hex
    code = '''
import sys,time
from pathlib import Path
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QLockFile
from PySide6.QtGui import QColor
from canvas import PaintCanvas
from recovery import RecoveryStore,DocumentSnapshot
import project_manager as pm
app=QApplication([])
store=RecoveryStore(sys.argv[1]);session=sys.argv[2]
directory=store.session_directory(session);directory.mkdir(parents=True)
lock=QLockFile(str(directory/'.lock'));lock.setStaleLockTime(0);assert lock.tryLock(0)
c=PaintCanvas();c.new_document(32,24);c.active.image.setPixelColor(3,4,QColor('red'))
store.write(DocumentSnapshot.capture(c),session,1)
c.active.image.setPixelColor(3,4,QColor('blue'))
original=pm.png_bytes
def blocked(image):
 Path(sys.argv[3]).write_text('ready');time.sleep(30);return original(image)
pm.png_bytes=blocked
store.write(DocumentSnapshot.capture(c),session,2)
'''
    env = dict(os.environ)
    env['PYTHONPATH'] = module_root + os.pathsep + env.get('PYTHONPATH', '')
    proc = subprocess.Popen([sys.executable, '-c', code, str(store_path), session, str(ready)],
                            env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        wait_for(ready.exists, 12)
        proc.kill()
        proc.communicate(timeout=5)
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.communicate(timeout=5)
    assert proc.returncode != 0
    store = RecoveryStore(store_path)
    records = store.candidates()
    assert len(records) == 1 and records[0].revision == 1
    assert store.read(records[0])[1][0].image.pixelColor(3, 4) == QColor('red')


@pytest.mark.parametrize('kind', ['manifest-list', 'duplicate-path', 'png-size', 'nan-opacity', 'orphan-text'])
def test_integrity_errors_preserve_document(qt, tmp_path, kind):
    c = PaintCanvas()
    c.new_document(32, 24)
    paint(c, 'red')
    target = tmp_path / 'invalid.mpaint'
    c.save_project(target)
    with zipfile.ZipFile(target) as archive:
        payload = {n: archive.read(n) for n in archive.namelist()}
    manifest = json.loads(payload['project.json'])
    if kind == 'manifest-list':
        manifest = []
    elif kind == 'png-size':
        raw = bytearray(payload['layers/layer_0.png'])
        raw[16:20] = (1_000_000).to_bytes(4, 'big')
        payload['layers/layer_0.png'] = raw
    elif kind == 'nan-opacity':
        manifest['layers'][0]['opacity'] = float('nan')
    elif kind == 'orphan-text':
        manifest['text_objects'] = [dict(text='orphan', size=12, layer_id='missing')]
    payload['project.json'] = json.dumps(manifest).encode()
    with zipfile.ZipFile(target, 'w') as archive:
        for name, data in payload.items():
            archive.writestr(name, data)
        if kind == 'duplicate-path':
            with pytest.warns(UserWarning):
                archive.writestr('project.json', payload['project.json'])
    with pytest.raises(ValueError):
        c.load_project(target)
    assert c.doc_size == (32, 24) and c.active.image.pixelColor(3, 4) == QColor('red')


def test_local_error_log_rotation_and_exception_hook(tmp_path, monkeypatch):
    from diagnostics import configure_logging, install_exception_hooks
    import logging
    root = tmp_path / 'logs'
    logger = configure_logging(root, 'test')
    handler = logger.handlers[0]
    handler.maxBytes = 180
    for index in range(20):
        logger.error('Diagnostic event %s', index)
    notices = []
    monkeypatch.setattr(sys, 'excepthook', sys.excepthook)
    monkeypatch.setattr(threading, 'excepthook', threading.excepthook)
    install_exception_hooks(logger, lambda: notices.append(True))
    try:
        raise RuntimeError('test failure')
    except RuntimeError:
        sys.excepthook(*sys.exc_info())
    assert notices and len(list(root.glob('errors.log*'))) <= 4
    assert 'RuntimeError: test failure' in (root / 'errors.log').read_text()
    for handler in list(logger.handlers):
        handler.close()
        logger.removeHandler(handler)


def test_external_project_change_is_not_silently_overwritten(window, tmp_path, monkeypatch):
    from storage import project_fingerprint
    c, _ = prepare(window)
    paint(c, 'red')
    target = tmp_path / 'Shared.mpaint'
    c.save_project(target)
    window.current_file = str(target)
    window._file_token = project_fingerprint(target)
    window._file_token_path = str(target.absolute())
    other = PaintCanvas()
    other.new_document(32, 24)
    paint(other, 'green')
    other.save_project(target)
    external = target.read_bytes()
    paint(c, 'blue')
    monkeypatch.setattr(QMessageBox, 'critical', lambda *a, **k: QMessageBox.StandardButton.Ok)
    assert not window.save_project() and window.dirty
    assert target.read_bytes() == external
    assert read_project(target)[1][0].image.pixelColor(3, 4) == QColor('green')


def test_two_concurrent_writers_do_not_overwrite_each_other(qt, tmp_path, monkeypatch):
    from concurrent.futures import ThreadPoolExecutor
    import project_manager as pm
    from storage import ProjectConflictError
    c = PaintCanvas()
    c.new_document(32, 24)
    target = tmp_path / 'Shared.mpaint'
    paint(c, 'red')
    c.save_project(target)
    paint(c, 'blue')
    blue = DocumentSnapshot.capture(c)
    paint(c, 'green')
    green = DocumentSnapshot.capture(c)
    barrier = threading.Barrier(2)
    original = pm.png_bytes
    def synchronize(image):
        barrier.wait(timeout=5)
        return original(image)
    monkeypatch.setattr(pm, 'png_bytes', synchronize)
    def save(snapshot):
        try:
            pm.save_project(target, snapshot.size, snapshot.layers, snapshot.active_layer,
                            list(snapshot.texts))
            return 'saved'
        except ProjectConflictError:
            return 'conflict'
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(save, (blue, green)))
    assert sorted(results) == ['conflict', 'saved']
    assert read_project(target)[1][0].image.pixelColor(3, 4) in (QColor('blue'), QColor('green'))
    assert read_project(list_versions(target)[0])[1][0].image.pixelColor(3, 4) == QColor('red')


def test_close_waits_for_cancelled_worker_before_destroying_widgets(window, monkeypatch):
    c, controller = prepare(window)
    paint(c, 'red')
    started, release = delayed_writer(monkeypatch, controller)
    controller.request_autosave(force=True)
    wait_for(started.is_set)
    window.dirty = False
    window.close()
    assert controller.closing and not controller.closed
    release.set()
    wait_for(lambda: controller.closed)
    assert controller.job is None and not window.isVisible()


def test_cancel_close_keeps_recovery_copy(window, monkeypatch):
    c, controller = prepare(window)
    paint(c, 'red')
    controller.request_autosave(force=True)
    wait_for(lambda: controller.job is None)
    monkeypatch.setattr(QMessageBox, 'warning', lambda *a, **k: QMessageBox.StandardButton.Cancel)
    window.close()
    assert window.isVisible() and not controller.closed and images_in(controller)


def test_previous_version_opens_as_copy_without_overwriting_current(window, tmp_path, monkeypatch):
    c, controller = prepare(window)
    paint(c, 'red')
    window.current_file = str(tmp_path / 'Versions.mpaint')
    assert window.save_project()
    paint(c, 'blue')
    assert window.save_project()
    current = Path(window.current_file)
    before = current.read_bytes()
    def choose(dialog):
        dialog.selected_record = dialog.records[0]
        return QDialog.DialogCode.Accepted
    monkeypatch.setattr(ProjectCopiesDialog, 'exec', choose)
    controller.show_versions()
    assert window.current_file is None and window.dirty
    assert c.active.image.pixelColor(3, 4) == QColor('red')
    assert current.read_bytes() == before


def test_restoring_oldest_backup_survives_save_and_retention_cleanup(window, tmp_path, monkeypatch):
    from recovery import RecoveryRecord
    c, controller = prepare(window)
    controller.backup_limit = 1
    window.current_file = str(tmp_path / 'Versions.mpaint')
    paint(c, 'red')
    assert window.save_project()
    paint(c, 'blue')
    assert window.save_project()
    original = Path(window.current_file)
    selected = list_versions(original)[0]
    paint(c, 'green')
    monkeypatch.setattr(QMessageBox, 'warning', lambda *a, **k: QMessageBox.StandardButton.Save)
    assert controller.restore(RecoveryRecord(selected, '', -1, str(original), ''), recovery=False)
    assert not selected.exists()  # The save created a newer backup and pruned this one.
    assert read_project(original)[1][0].image.pixelColor(3, 4) == QColor('green')
    assert c.active.image.pixelColor(3, 4) == QColor('red')
    assert window.current_file is None and window.dirty


def test_manual_save_runs_in_background_and_keeps_newer_changes(window, tmp_path, monkeypatch):
    import project_manager as pm
    c, controller = prepare(window)
    paint(c, 'red')
    window.current_file = str(tmp_path / 'Async.mpaint')
    original = pm.png_bytes
    release = threading.Event()
    def paused(image):
        release.wait(3)
        return original(image)
    monkeypatch.setattr(pm, 'png_bytes', paused)
    ticks = []
    timer = QTimer()
    timer.setInterval(5)
    timer.timeout.connect(lambda: ticks.append(1))
    timer.start()
    def edit_and_release():
        paint(c, 'blue')
        release.set()
    QTimer.singleShot(80, edit_and_release)
    monkeypatch.setattr(QMessageBox, 'warning', lambda *a, **k: QMessageBox.StandardButton.Save)
    try:
        assert not window.confirm_document_change()  # Saved snapshot, but newer changes must veto closing.
    finally:
        release.set()
        timer.stop()
    assert len(ticks) > 2 and window.dirty
    assert c.active.image.pixelColor(3, 4) == QColor('blue')
    assert read_project(window.current_file)[1][0].image.pixelColor(3, 4) == QColor('red')
    assert controller.clean_revision < controller.revision


def test_cancel_manual_save_keeps_original_and_unsaved_changes(window, tmp_path, monkeypatch):
    import project_manager as pm
    c, controller = prepare(window)
    window.current_file = str(tmp_path / 'Async.mpaint')
    paint(c, 'red')
    assert window.save_project()
    original_file = Path(window.current_file).read_bytes()
    paint(c, 'blue')
    original = pm.png_bytes
    release = threading.Event()
    def paused(image):
        release.wait(3)
        return original(image)
    monkeypatch.setattr(pm, 'png_bytes', paused)
    def cancel_and_release():
        controller.manual_job.cancelled.set()
        release.set()
    QTimer.singleShot(50, cancel_and_release)
    try:
        assert not window.save_project()
    finally:
        release.set()
    assert controller.manual_job is None and window.dirty
    assert Path(window.current_file).read_bytes() == original_file
    assert c.active.image.pixelColor(3, 4) == QColor('blue')
