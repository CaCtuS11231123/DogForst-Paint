import json,zipfile,uuid,threading,time
import numpy as np
import pytest
from PySide6.QtCore import Qt,QPoint,QPointF,QRectF
from PySide6.QtGui import QColor,QPainter,QImage,QMouseEvent
from PySide6.QtWidgets import QDialog,QApplication
from PySide6.QtTest import QTest
from test_dev7 import setup,source,imported
from layers import transparent_image,Layer
from selection_tools import polygon_mask,rect_mask,gray_array,from_array,combine_masks,wand_mask,feather_mask,blend_selection
from project_manager import read_project
from recovery import DocumentSnapshot,RecoveryStore
from effects import DEFAULT_GLOW
from tools import tool_pixmap,tool_cursor


def triangle(c):
    mask=polygon_mask(c.doc_size,[QPointF(20,20),QPointF(150,20),QPointF(20,150)])
    c.set_selection_mask(mask);return mask

def wait_job(c,attribute='wand_job'):
    deadline=time.monotonic()+8
    while getattr(c,attribute) is not None and time.monotonic()<deadline:QTest.qWait(10)
    assert getattr(c,attribute) is None

def rect(c,x=20,y=20,w=80,h=60):return rect_mask(c.doc_size,QRectF(x,y,w,h))


def test_polygon_lasso_clicks_enter_cancel_and_backspace(window):
    c=setup(window,(240,180));window.set_tool('Лассо')
    for x,y in [(20,20),(150,20),(20,150),(40,100)]:QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=QPoint(x,y))
    QTest.keyClick(c,Qt.Key.Key_Backspace);assert len(c._lasso_points)==3
    QTest.keyClick(c,Qt.Key.Key_Return)
    assert c.selection_mask is not None and c.selection_contains(QPointF(40,40)) and not c.selection_contains(QPointF(140,140))
    before=QImage(c.selection_mask);QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=QPoint(80,80));QTest.keyClick(c,Qt.Key.Key_Escape)
    assert not c._lasso_points and c.selection_mask==before
    c.undo();assert c.selection is None
    c.redo();assert c.selection_mask==before


def test_lasso_double_click_and_tool_change_cancel(window):
    c=setup(window,(240,180));window.set_tool('Лассо')
    for p in [QPoint(20,20),QPoint(120,20),QPoint(20,120)]:QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=p)
    QTest.mouseDClick(c,Qt.MouseButton.LeftButton,pos=QPoint(20,120));assert c.selection_mask is not None
    QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=QPoint(90,90));window.set_tool('Кисть');assert not c._lasso_points


@pytest.mark.parametrize('mode,inside_old,inside_new,overlap',[('add',True,True,True),('subtract',True,False,False),('intersect',False,False,True)])
def test_rectangle_modes_respect_true_regions(window,mode,inside_old,inside_new,overlap):
    c=setup(window,(220,180));c.selection=QRectF(20,20,80,80);c.selection_mode=mode;window.set_tool('Выделение')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(60,60));QTest.mouseMove(c,QPoint(140,140));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(140,140))
    assert c.selection_contains(QPointF(30,30))==inside_old
    assert c.selection_contains(QPointF(130,130))==inside_new
    assert c.selection_contains(QPointF(70,70))==overlap


def test_empty_intersect_subtract_and_exact_undo(window):
    c=setup(window,(220,180));c.set_selection_mask(rect(c),mode='intersect');assert c.selection is None
    triangle(c);original=QImage(c.selection_mask);c.invert_selection()
    assert not c.selection_contains(QPointF(40,40)) and c.selection_contains(QPointF(190,150))
    c.cancel_selection();assert c.selection is None;c.reselect();assert c.selection_contains(QPointF(190,150))
    c.undo();assert c.selection is None;c.undo();assert c.selection_contains(QPointF(190,150));c.undo();assert c.selection_mask==original


def test_wand_contiguous_and_tolerance_alpha():
    image=transparent_image(80,50);image.fill(QColor('white'));p=QPainter(image)
    p.fillRect(5,5,15,15,QColor(100,80,90));p.fillRect(40,5,15,15,QColor(105,80,90));p.end()
    mask=wand_mask(image,10,10,10,True,threading.Event());assert mask.pixelColor(45,10).red()==0
    mask=wand_mask(image,10,10,10,False,threading.Event());assert mask.pixelColor(45,10).red()==255
    mask=wand_mask(image,10,10,0,False,threading.Event());assert mask.pixelColor(45,10).red()==0
    cancelled=threading.Event();cancelled.set();assert wand_mask(image,10,10,10,False,cancelled) is None


def test_wand_ui_async_merged_and_cancel(window):
    c=setup(window,(220,180));c.active.image.fill(QColor('white'));c.add_layer();p=QPainter(c.active.image);p.fillRect(20,20,60,50,QColor('red'));p.end()
    window.set_tool('Волшебная палочка');QTest.mouseClick(c,Qt.MouseButton.LeftButton,pos=QPoint(40,40));wait_job(c)
    assert c.selection_contains(QPointF(30,30)) and not c.selection_contains(QPointF(120,120))
    c.cancel_selection();c.wand_merged=True;c.select_wand(QPointF(120,120),Qt.KeyboardModifier.NoModifier);wait_job(c)
    assert c.selection_contains(QPointF(150,140)) and not c.selection_contains(QPointF(30,30))
    before=QImage(c.selection_mask);c.select_wand(QPointF(30,30),Qt.KeyboardModifier.NoModifier);c.wand_job.cancelled.set();wait_job(c)
    assert c.selection_mask==before


def test_feather_async_exact_values_undo_redo(window):
    c=setup(window,(240,180));c.selection=QRectF(40,40,80,80);c.feather_selection(9);wait_job(c)
    original=QImage(c.selection_mask);assert 1<c.selection_mask.pixelColor(40,70).red()<254
    assert c.selection_mask.pixelColor(70,70).red()==255
    c.undo();assert c.selection==QRectF(40,40,80,80) and c.selection_mask is None
    c.redo();assert c.selection_mask==original


def test_polygon_brush_shape_fill_filter_and_outside_exact(window):
    c=setup(window,(220,180));c.active.image.fill(QColor(30,60,90,180));triangle(c);outside=c.active.image.pixelColor(140,140)
    window.set_tool('Кисть');c.brush_size=35;c.brush_stabilizer=0;c.color=QColor('red')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(50,50));QTest.mouseMove(c,QPoint(140,140));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(140,140))
    assert c.active.image.pixelColor(50,50).red()>180 and c.active.image.pixelColor(140,140)==outside
    c.apply_filter('invert');assert c.active.image.pixelColor(140,140)==outside
    window.set_tool('Прямоугольник');c.shape_options.update(filled=True,fill='#00ff00',stroke='#00ff00',stroke_width=2);c._shape_configured=True
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(30,30));QTest.mouseMove(c,QPoint(160,160));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(160,160))
    assert c.active.image.pixelColor(50,50).green()>200 and c.active.image.pixelColor(140,140)==outside
    c.flood_fill(50,50);wait_job(c,'fill_job');assert c.active.image.pixelColor(140,140)==outside


def test_soft_selection_brush_does_not_accumulate_coverage(window):
    c=setup(window,(220,180));mask=rect(c,10,10,190,150);array=np.zeros((180,220),dtype=np.uint8);array[10:160,10:200]=128
    c.set_selection_mask(from_array(array));window.set_tool('Кисть');c.brush_size=30;c.brush_stabilizer=0;c.color=QColor('red')
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(40,80))
    for x in range(45,181,5):QTest.mouseMove(c,QPoint(x,80))
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(180,80))
    assert 127<=c.active.image.pixelColor(90,80).alpha()<=129
    assert 127<=c.active.image.pixelColor(150,80).alpha()<=129
    c.undo();assert c.active.image==transparent_image(*c.doc_size)


def test_selection_respects_alpha_lock_for_shapes(window):
    c=setup(window,(220,180));p=QPainter(c.active.image);p.fillRect(30,30,80,70,QColor('red'));p.end();c.active.alpha_locked=True;triangle(c)
    before=c.active.image.copy();window.set_tool('Прямоугольник');c.shape_options.update(filled=True,fill='#00ff00');c._shape_configured=True
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(20,20));QTest.mouseMove(c,QPoint(140,140));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(140,140))
    assert c.active.image.pixelColor(50,50).green()>100 and c.active.image.pixelColor(25,25).alpha()==0
    assert c.active.image.pixelColor(110,110).alpha()==before.pixelColor(110,110).alpha()


def test_copy_cut_paste_move_nonrect_and_history(window):
    c=setup(window,(240,180));c.active.image.fill(QColor('red'));triangle(c);before=c.active.image.copy();originalmask=QImage(c.selection_mask)
    c.copy_selection();clip=QApplication.clipboard().image();assert clip.pixelColor(110,110).alpha()==0
    c.cut_selection();assert c.active.image.pixelColor(40,40).alpha()==0 and c.active.image.pixelColor(140,140)==QColor('red')
    c.undo();assert c.active.image==before and c.selection_mask==originalmask
    window.set_tool('Перемещение');c.move_selected_by(QPointF(20,0))
    assert c.active.image.pixelColor(25,30).alpha()==0 and c.selection_contains(QPointF(60,40))
    c.undo();assert c.active.image==before and c.selection_mask==originalmask
    c.cut_selection();c.paste_image(QApplication.clipboard().image());assert c.layers[-1].image.pixelColor(40,40)==QColor('red')


def test_complex_selection_text_rasterizes_only_when_pixels_edited(window):
    from test_v03 import text_layer
    c=setup(window,(500,360));text_layer(c);triangle(c);assert c.text_objects
    c.apply_filter('invert');assert not c.text_objects and c.active.kind=='raster'
    c.undo();assert c.text_objects and c.active.kind=='text' and c.selection_mask is not None


def test_selection_on_mask_fill_stroke_delete(window):
    c=setup(window,(240,180));c.active.image.fill(QColor('red'));c.add_mask();c.start_mask_edit();triangle(c);window.set_tool('Кисть');c.color=QColor('black');c.brush_size=25;c.brush_stabilizer=0
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(40,40));QTest.mouseMove(c,QPoint(140,140));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(140,140))
    mask=c.masks[c.active.id];assert mask.pixelColor(40,40).red()<30 and mask.pixelColor(140,140).red()==255
    c.fill_mask(0,True);assert c.masks[c.active.id].pixelColor(140,140).red()==255
    from masks import validate_mask
    validate_mask(c.masks[c.active.id],c.doc_size)
    c.undo();assert c.masks[c.active.id].pixelColor(140,140).red()==255


def test_selection_pixel_blend_preserves_nonselected_bytes():
    a=transparent_image(10,10);a.fill(QColor(110,40,170,37));b=transparent_image(10,10);b.fill(QColor('red'))
    mask=rect_mask((10,10),QRectF(0,0,5,5));result=blend_selection(a,b,mask)
    assert result.pixelColor(8,8)==a.pixelColor(8,8) and result.pixelColor(2,2)==b.pixelColor(2,2)


def test_no_edit_outside_selected_wand_region_with_hole(window):
    c=setup(window,(220,180));c.active.image.fill(QColor('white'));p=QPainter(c.active.image);p.fillRect(80,50,40,60,QColor('black'));p.end()
    c.select_wand(QPointF(30,30),Qt.KeyboardModifier.NoModifier);wait_job(c);c.color=QColor('red');c.flood_fill(20,20);wait_job(c,'fill_job')
    assert c.active.image.pixelColor(100,70)==QColor('black') and c.active.image.pixelColor(30,30)==QColor('red')


def clip_scene(window):
    c=setup(window,(220,180));p=QPainter(c.active.image);p.fillRect(60,40,70,80,QColor('white'));p.end();base=c.active
    c.add_layer();c.active.image.fill(QColor('red'));top=c.active;c.set_clipping(True);return c,base,top


def test_live_clipping_base_alpha_text_and_hide(window):
    c,base,top=clip_scene(window)
    assert c.composite_image().pixelColor(80,80)==QColor('red') and c.composite_image().pixelColor(20,20).alpha()==0
    base.image.fill(Qt.GlobalColor.transparent);c.text_objects=[dict(text='DOG',x=30,y=30,size=50,color='#ffffff',layer_id=base.id)];base.kind='text';before=c.composite_image()
    c.text_objects[0]['text']='DOGFORST';assert c.composite_image()!=before and c.text_objects[0]['text']=='DOGFORST'
    base.visible=False;assert c.composite_image()==transparent_image(*c.doc_size)
    base.visible=True;base.opacity=.3;assert c.composite_image().pixelColor(20,20).alpha()==0


def test_clipping_chain_mask_glow_and_group(window):
    c,base,top=clip_scene(window);c.add_layer();c.active.image.fill(QColor('blue'));c.set_clipping(True)
    assert c.composite_image().pixelColor(80,80)==QColor('blue') and c.composite_image().pixelColor(20,20).alpha()==0
    top.glow=dict(DEFAULT_GLOW);c.set_selected_nodes({base.id});c.add_mask(0)
    assert c.composite_image()==transparent_image(*c.doc_size)
    c.undo();c.set_selected_nodes({base.id,top.id,c.layers[-1].id});c.create_group()
    assert c.composite_image().pixelColor(80,80)==QColor('blue') and c.composite_image().pixelColor(20,20).alpha()==0


def test_clipping_base_opacity_and_no_base_safe(window):
    c,base,top=clip_scene(window);base.opacity=.5;top.opacity=.5
    image=c.composite_image();assert image.pixelColor(80,80).alpha()<255 and image.pixelColor(20,20).alpha()==0
    c.set_selected_nodes({base.id});c.set_clipping(True);assert not base.clipped
    c.set_selected_nodes({top.id});c.set_clipping(False);assert c.composite_image().pixelColor(20,20).alpha()>0
    c.undo();assert c.active.clipped


def test_clipping_merge_preview_bakes_without_double_alpha(window,monkeypatch):
    from merge_dialog import MergePreviewDialog
    c,base,top=clip_scene(window);before=c.composite_image()
    monkeypatch.setattr(MergePreviewDialog,'exec',lambda d:QDialog.DialogCode.Accepted)
    c.merge_down();assert len(c.layers)==1 and not c.active.clipped and c.composite_image()==before
    c.undo();assert len(c.layers)==2 and c.active.clipped


def test_v10_clipping_roundtrip_recovery_and_export(window,tmp_path):
    c,base,top=clip_scene(window);path=tmp_path/'clipping.mpaint';c.save_project(path,backup=False)
    with zipfile.ZipFile(path) as z:assert json.loads(z.read('project.json'))['version']==10
    result=read_project(path);assert result[1][-1].clipped
    snap=DocumentSnapshot.capture(c);store=RecoveryStore(tmp_path/'recovery');record=store.write(snap,uuid.uuid4().hex,2);assert read_project(record.path)[1][-1].clipped
    for extension in ['png','jpg','bmp','webp']:
        target=tmp_path/('export.'+extension);c.export_image(str(target));assert not QImage(str(target)).isNull()
    c.apply_loaded_project(result);assert c.composite_image().pixelColor(20,20).alpha()==0


@pytest.mark.parametrize('damage',['type','version'])
def test_bad_clipping_file_does_not_replace_project(window,tmp_path,damage):
    c,base,top=clip_scene(window);path=tmp_path/'valid.mpaint';c.save_project(path,backup=False)
    with zipfile.ZipFile(path) as z:entries={n:z.read(n) for n in z.namelist()}
    manifest=json.loads(entries['project.json'])
    if damage=='type':manifest['layers'][-1]['clipped']='yes'
    else:manifest['version']=9
    entries['project.json']=json.dumps(manifest).encode();bad=tmp_path/'bad.mpaint'
    with zipfile.ZipFile(bad,'w') as z:
        for name,data in entries.items():z.writestr(name,data)
    before=c.composite_image()
    with pytest.raises(ValueError):c.load_project(bad)
    assert c.composite_image()==before and c.active.id==top.id


def test_selection_panel_icons_and_contextual_disabled_controls(window):
    window.set_tool('Лассо');assert window.selection_dock.isVisible() and not window.selection_panel.tolerance.isEnabled()
    window.set_tool('Волшебная палочка');assert window.selection_panel.tolerance.isEnabled()
    for name in ['Лассо','Волшебная палочка']:
        assert tool_pixmap(name).toImage()!=tool_pixmap('unknown').toImage();assert not tool_cursor(name).pixmap().isNull()


def test_cancelled_feather_and_document_change_never_apply_stale_result(window):
    c=setup(window,(240,180));triangle(c);before=QImage(c.selection_mask)
    c.feather_selection(25);c.wand_job.cancelled.set();wait_job(c);assert c.selection_mask==before
    c.select_wand(QPointF(30,30),Qt.KeyboardModifier.NoModifier);c.new_document(120,90);wait_job(c)
    assert c.doc_size==(120,90) and c.selection is None and not c._lasso_points
    window.set_tool('Лассо');c.lasso_click(QPointF(20,20),Qt.KeyboardModifier.NoModifier);c.new_document(130,100);assert not c._lasso_points


def test_gray_selection_history_many_operations_is_lossless(window):
    c=setup(window,(160,120));states=[]
    for index in range(12):
        mask=rect(c,10+index*2,20,50,50);c.set_selection_mask(mask);c.commit_history(force=True);states.append(QImage(c.selection_mask))
    assert c.history_engine.statistics()['estimated_bytes']<150000
    for index in reversed(range(11)):
        c.undo();assert c.selection_mask==states[index]
    for index in range(1,12):c.redo();assert c.selection_mask==states[index]


def test_feathered_mask_move_copy_and_soft_fill(window):
    c=setup(window,(220,180));c.active.image.fill(QColor('red'));c.add_mask();c.start_mask_edit();triangle(c)
    c.feather_selection(6);wait_job(c);mask=QImage(c.selection_mask)
    c.color=QColor('black');c.start_mask_fill(40,40);wait_job(c,'fill_job')
    assert c.masks[c.active.id].pixelColor(140,140).red()==255
    c.stop_mask_edit();window.set_tool('Перемещение');before=c.composite_image();c.move_selected_by(QPointF(10,5))
    from masks import validate_mask
    validate_mask(c.masks[c.active.id],c.doc_size)
    c.undo();assert c.selection_mask==mask and c.composite_image()==before


def test_clipping_base_group_and_reorder_stay_live(window):
    c,base,top=clip_scene(window);c.set_selected_nodes({base.id});c.create_group();group=c.control_node()
    c.set_selected_nodes({top.id});assert c.clipping_base().id==group.id
    assert c.composite_image().pixelColor(20,20).alpha()==0
    group.visible=False;assert c.composite_image()==transparent_image(*c.doc_size)
    group.visible=True;c.set_clipping(False);assert c.composite_image().pixelColor(20,20)==QColor('red')


def test_selection_delete_rasterizes_text_with_undo(window):
    from test_v03 import text_layer
    c=setup(window,(500,360));text_layer(c);triangle(c);before=c.composite_image()
    QTest.keyClick(c,Qt.Key.Key_Delete);assert not c.text_objects
    c.undo();assert c.text_objects and c.composite_image()==before and c.selection_mask is not None


def test_invalid_clipping_save_preserves_existing_file(window,tmp_path):
    c,base,top=clip_scene(window);target=tmp_path/'safe.mpaint';c.save_project(target,backup=False);original=target.read_bytes()
    c.active.clipped='bad'
    with pytest.raises(ValueError):c.save_project(target,backup=False)
    assert target.read_bytes()==original


@pytest.mark.parametrize('kind',['selection','fill'])
def test_worker_memory_error_has_a_readable_message(qt,monkeypatch,kind):
    def failed(*args,**kwargs):raise MemoryError()
    received=[]
    if kind=='selection':
        from selection_tools import SelectionJob
        job=SelectionJob(failed,());job.signals.done.connect(lambda job,mask,error:received.append((mask,error)))
    else:
        import fill
        monkeypatch.setattr(fill,'fill_image',failed)
        job=fill.FillJob(transparent_image(10,10),0,0,QColor('red'),0,100);job.signals.done.connect(lambda mask,error:received.append((mask,error)))
    job.run();assert received[0][0] is None and 'памяти' in received[0][1]


def test_selection_controls_visible_after_tool_switch(window,qt):
    window.set_tool('Лассо');QTest.qWait(50)
    assert window.selection_panel.isVisible() and not window.selection_panel.visibleRegion().isEmpty()
    assert callable(window.selection_panel.window)
    window.set_tool('Волшебная палочка');assert window.selection_panel.tolerance.isEnabled()
