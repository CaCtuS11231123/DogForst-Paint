import copy,json,time,uuid,zipfile
import pytest,numpy as np
from PySide6.QtCore import Qt,QPoint,QPointF,QRectF
from PySide6.QtGui import QColor,QImage,QPainter
from PySide6.QtWidgets import QDialog,QColorDialog,QApplication
from PySide6.QtTest import QTest
from test_dev7 import setup,imported
from test_v055 import stroke,move
from layers import transparent_image
from shapes import DEFAULT_SHAPE
from dialogs import ShapeDialog,ShapePicker,ColorButton
from glow_dialog import GlowDialog
from raster_objects import clone_object,render_object
from project_manager import read_project
from recovery import DocumentSnapshot,RecoveryStore
from selection_tools import from_array
from interactive_render import interactive_image

def make_shape(window,name='Эллипс',start=(40,40),end=(160,120),**options):
    c=window.canvas;window.set_tool(name);c.shape_options=dict(DEFAULT_SHAPE,**options);c._shape_configured=True
    stroke(c,[start,end]);assert 'shape' in c.raster_objects[c.active.id];return c.raster_objects[c.active.id]


def test_shape_exact_mode_then_handles_allow_another_size(window):
    c=setup(window,(400,280));obj=make_shape(window,filled=True,exact=True,width=180,height=100)
    assert (obj['width'],obj['height'])==(180,100) and c.tool=='Перемещение' and not c.shape_options['exact']
    p=c.object_handles()['br'].toPoint();QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=p);move(c,p+QPoint(60,30));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=p+QPoint(60,30));assert c.raster_objects[c.active.id]['width']>180
    c.undo();assert c.raster_objects[c.active.id]['width']==180


def test_two_shapes_have_independent_selected_layers_and_editable_copy(window):
    c=setup(window,(400,280));first=make_shape(window,filled=True,fill='#ff0000');first_id=c.active.id;second=make_shape(window,'Прямоугольник',start=(190,60),end=(280,160),filled=True,fill='#0000ff');second_id=c.active.id
    assert first_id!=second_id and len(c.layers)==2
    c.duplicate_layer();new=c.active.id;assert new not in (first_id,second_id) and c.raster_objects[new]['shape']==second['shape']
    obj=clone_object(c.raster_objects[new]);obj.update(width=200.,height=200.);c.set_object(c.active,obj);assert c.raster_objects[second_id]['width']==90 and c.raster_objects[new]['width']==200


def test_shape_editor_double_click_sets_xy_size_and_style(window,monkeypatch):
    c=setup(window,(420,280));make_shape(window,filled=True);identifier=c.active.id;calls=[]
    def accept(d):
        calls.append(d);assert d.placement is not None and d.w.isEnabled();d.x.setValue(100.5);d.y.setValue(100.);d.w.setValue(220.);d.h.setValue(90.);d.fill.color=QColor('#32aacc');return QDialog.DialogCode.Accepted
    monkeypatch.setattr(ShapeDialog,'exec',accept);QTest.mouseDClick(c,Qt.MouseButton.LeftButton,pos=QPoint(100,80));obj=c.raster_objects[identifier]
    assert len(calls)==1 and obj['x']==100.5 and obj['y']==100 and obj['width']==220 and obj['shape']['options']['fill']=='#32aacc'
    c.undo();assert c.raster_objects[identifier]['x']==40


def test_shape_style_shared_across_tools_and_persists(window,monkeypatch):
    c=setup(window);c.shape_options.update(filled=True,stroke='#000000',fill='#aabbcc');window.set_color(QColor('#ff2222'));assert c.shape_options['stroke']=='#000000' and c.shape_options['fill']=='#ff2222'
    window._shape_drafts['Прямоугольник']=dict(DEFAULT_SHAPE,fill='#0000ff',stroke='#0000ff')
    def accept(d):assert d.outline.color==QColor('black') and d.fill.color==QColor('#ff2222');return QDialog.DialogCode.Accepted
    monkeypatch.setattr(ShapeDialog,'exec',accept);window.shape_settings('Прямоугольник')
    from app import MainWindow
    other=MainWindow();assert other.canvas.shape_options['fill']=='#ff2222' and other.canvas.shape_options['stroke']=='#000000';other.dirty=False;other.close();other.deleteLater()


def test_shape_project_v11_and_old_plain_min_version(window,tmp_path):
    c=setup(window,(320,240));make_shape(window,filled=True);path=tmp_path/'shape.mpaint';c.save_project(path,backup=False)
    with zipfile.ZipFile(path) as z:assert json.loads(z.read('project.json'))['version']==11
    loaded=read_project(path);identifier=c.active.id;assert loaded.raster_objects[identifier]['shape']==c.raster_objects[identifier]['shape'];c.apply_loaded_project(loaded)
    obj=clone_object(c.raster_objects[identifier]);obj.update(width=250.,height=180.);assert c.set_object(c.active,obj);assert c.raster_objects[identifier]['width']==250
    c.new_document(100,80);plain=tmp_path/'plain.mpaint';c.save_project(plain,backup=False)
    with zipfile.ZipFile(plain) as z:assert json.loads(z.read('project.json'))['version']==4


def test_shape_snapshot_recovery_and_metadata_are_immutable(window,tmp_path):
    c=setup(window);make_shape(window,filled=True,fill='#ff0000');identifier=c.active.id;snap=DocumentSnapshot.capture(c);obj=clone_object(c.raster_objects[identifier]);obj['shape']['options']['fill']='#0000ff';c.set_object(c.active,obj)
    assert dict(snap.raster_objects)[identifier]['shape']['options']['fill']=='#ff0000'
    record=RecoveryStore(tmp_path/'recovery').write(snap,uuid.uuid4().hex,1);loaded=read_project(record.path);assert loaded.raster_objects[identifier]['shape']['options']['fill']=='#ff0000'
    c.undo();assert c.raster_objects[identifier]['shape']['options']['fill']=='#ff0000';c.redo();assert c.raster_objects[identifier]['shape']['options']['fill']=='#0000ff'


@pytest.mark.parametrize('damage',['name','color','width','version'])
def test_invalid_shape_project_rejected_without_document_loss(window,tmp_path,damage):
    c=setup(window);make_shape(window,filled=True);path=tmp_path/'good.mpaint';c.save_project(path,backup=False)
    with zipfile.ZipFile(path) as z:entries={n:z.read(n) for n in z.namelist()}
    p=json.loads(entries['project.json']);recipe=p['raster_objects'][0]['shape']
    if damage=='name':recipe['name']='Fake'
    elif damage=='color':recipe['options']['fill']='wrong colour'
    elif damage=='width':recipe['options']['stroke_width']=float('nan')
    else:p['version']=10
    entries['project.json']=json.dumps(p).encode();bad=tmp_path/'bad.mpaint'
    with zipfile.ZipFile(bad,'w') as z:
        for n,data in entries.items():z.writestr(n,data)
    before=c.active.image.copy()
    with pytest.raises(ValueError):c.load_project(bad)
    assert c.active.image==before and c.raster_objects


def test_shape_pixel_edit_rasterizes_and_undo_restores_recipe(window):
    c=setup(window);make_shape(window,filled=True);identifier=c.active.id;before=clone_object(c.raster_objects[identifier]);window.set_tool('Кисть');c.brush_stabilizer=0;c.brush_size=35;stroke(c,[(50,50),(180,50)]);assert identifier not in c.raster_objects
    c.undo();assert c.raster_objects[identifier]['shape']==before['shape']


def test_selected_layers_merge_and_undo_preserve_vectors(window):
    c=setup(window,(400,280));make_shape(window,filled=True,fill='#ff0000');a=c.active.id;make_shape(window,'Прямоугольник',start=(190,50),end=(290,150),filled=True,fill='#0000ff');b=c.active.id
    c.set_selected_nodes({a,b});window.refresh_layers();assert window.merge_selected_button.isEnabled();before=c.composite_image();assert c.merge_selected();assert len(c.layers)==1 and c.composite_image()==before and not c.raster_objects
    c.undo();assert len(c.layers)==2 and set(c.raster_objects)=={a,b};c.redo();assert len(c.layers)==1


def test_nonadjacent_merge_cancel_does_not_change_document(window,monkeypatch):
    from merge_dialog import MergePreviewDialog
    c=setup(window);c.active.image.fill(QColor('red'));a=c.active.id;c.add_layer();c.active.image.fill(QColor('blue'));c.add_layer();p=QPainter(c.active.image);p.fillRect(40,40,80,60,QColor('green'));p.end();b=c.active.id;c.set_selected_nodes({a,b});before=c.snapshot();monkeypatch.setattr(MergePreviewDialog,'exec',lambda d:QDialog.DialogCode.Rejected)
    assert not c.merge_selected();assert [l.id for l in c.layers]==[l[4] for l in before['layers']]


def test_merge_respects_locks_and_groups(window):
    c=setup(window);a=c.active.id;c.add_layer();b=c.active.id;c.set_selected_nodes({a,b});c.active.locked=True;assert not c.merge_selected() and len(c.layers)==2
    c.active.locked=False;c.create_group(True);assert not c.merge_selected()


def test_undo_choose_other_layer_and_redo_replays_correct_uid(window):
    c=setup(window);a=c.active.id;c.add_layer();b=c.active.id;c.history.clear();window.set_tool('Кисть');c.brush_stabilizer=0;c.color=QColor('red');stroke(c,[(40,80),(180,80)]);painted=c.active.image.copy();c.undo();assert c.future
    c.set_selected_nodes({a});assert c.future;QTest.keyClick(c,Qt.Key.Key_Y,Qt.KeyboardModifier.ControlModifier)
    assert c.node(b).image==painted and c.node(a).image==transparent_image(*c.doc_size)


def test_noop_and_layer_navigation_do_not_consume_redo(window):
    c=setup(window);c.add_layer();c.undo();assert c.future;c.push_history();c.select_text(-1);c.commit_history(force=True);assert c.future
    c.redo();assert len(c.layers)==2


def test_redo_during_stroke_does_not_commit_half_stroke(window):
    c=setup(window);c.brush_stabilizer=0;QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(40,60));move(c,QPoint(100,60));c.redo();assert c.history_engine.pending is not None
    move(c,QPoint(190,60));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(190,60));c.undo();assert c.active.image==transparent_image(*c.doc_size)


def test_live_foreground_color_and_cancel_restore_without_mru_pollution(window,monkeypatch):
    original=QColor(window.canvas.color);recent=list(window.palette_panel.store.recent);seen=[]
    def reject(d):d.setCurrentColor(QColor('#ef1267'));seen.append(window.canvas.color==QColor('#ef1267'));return QDialog.DialogCode.Rejected
    monkeypatch.setattr(QColorDialog,'exec',reject);window.choose_color();assert seen==[True] and window.canvas.color==original and window.palette_panel.store.recent==recent
    def accept(d):d.setCurrentColor(QColor('#34aa89'));assert window.canvas.color==QColor('#34aa89');return QDialog.DialogCode.Accepted
    monkeypatch.setattr(QColorDialog,'exec',accept);window.choose_color();assert window.palette_panel.store.recent[0]=='#34aa89'


def test_color_button_live_updates_shape_preview_and_cancel_reverts(window,monkeypatch):
    d=ShapeDialog('Эллипс',dict(DEFAULT_SHAPE,filled=True),window);before=d.fill.color
    def reject(picker):picker.setCurrentColor(QColor('red'));assert d.preview.options['fill']=='#ff0000';return QDialog.DialogCode.Rejected
    monkeypatch.setattr(QColorDialog,'exec',reject);d.fill.choose();assert d.fill.color==before and d.preview.options['fill']==before.name();d.reject()


def test_empty_glow_has_sample_and_light_dark_scale(window):
    c=setup(window,(320,240));d=GlowDialog(c.active,c.layer_image(c.active,False),c.doc_size,window);assert d.sample_mode.currentIndex()==1 and not d.preview.source.isNull() and d.preview.result!=d.preview.source
    original=c.active.image.copy();d.sample_text.setText('Привет!');d.preview_background.setCurrentIndex(1);d.preview_zoom.setValue(200);d.preview.refresh();assert d.preview.background=='dark' and d.preview.zoom==200 and c.active.image==original;d.reject()


def test_glow_crops_small_art_in_large_canvas_for_readable_preview(window):
    c=setup(window,(2200,1600));p=QPainter(c.active.image);p.fillRect(1000,700,30,25,QColor('red'));p.end();d=GlowDialog(c.active,c.layer_image(c.active,False),c.doc_size,window)
    assert d.preview.layer_source.width()<300 and d.preview.layer_source.height()<300 and d.preview.source.width()>=300;d.reject()


def test_shape_preview_zoom_does_not_change_actual_geometry(window):
    d=ShapeDialog('Звезда',dict(DEFAULT_SHAPE,exact=True,width=400,height=300),window);before=d.values();d.preview_zoom.setValue(170);d.preview_background.setCurrentIndex(1);assert d.values()==before and d.preview.zoom==170 and d.preview.background=='dark';d.reject()


def test_proxy_drawing_is_bounded_and_does_not_modify_document(window):
    c=setup(window,(2200,1600));c.active.image.fill(QColor('#ff0000'));c.zoom=.35;before=c.snapshot();proxy=interactive_image(c);assert proxy.width()<=1400 and proxy.height()<=1000 and c.active.image==before['layers'][0][1]
    assert c.composite_image().size()==c.active.image.size();window.set_tool('Кисть');c.brush_stabilizer=0;stroke(c,[(40,80),(180,80)]);assert not c.drawing and c.composite_image().width()==2200


def test_shape_dialog_edits_fractional_and_large_placements(window):
    c=setup(window);obj=make_shape(window,filled=True);obj=clone_object(obj);obj.update(x=100.5,width=18000.,rotation=720.);d=ShapeDialog('Эллипс',dict(obj['shape']['options'],width=obj['width'],height=obj['height'],rotation=obj['rotation']),window,placement=obj)
    assert d.x.value()==100.5 and d.w.value()==18000 and d.rotation.value()==720;d.reject()


def test_text_color_picker_cancel_preserves_redo(window,monkeypatch):
    from test_v03 import text_layer
    c=setup(window);text_layer(c);original=copy.deepcopy(c.text_objects);c.push_history();c.text_objects[0]['text']='Другое';c.changed.emit();c.undo();assert c.future
    def cancel(d):d.setCurrentColor(QColor('red'));return QDialog.DialogCode.Rejected
    monkeypatch.setattr(QColorDialog,'exec',cancel);window.text_controls.color.choose();assert c.text_objects==original and c.future;c.redo();assert c.text_objects[0]['text']=='Другое'


def test_shape_inside_group_merge_and_masked_transform(window):
    c=setup(window,(400,280));c.create_group(False);gid=c.control_node().id;make_shape(window,filled=True);a=c.active.id;make_shape(window,'Прямоугольник',start=(200,40),end=(300,150),filled=True);b=c.active.id
    assert c.parent_id(a)==gid and c.parent_id(b)==gid;c.add_mask();mask=c.masks[b].copy();obj=clone_object(c.raster_objects[b]);obj['x']+=30;c.set_object(c.active,obj);assert c.masks[b].size()==mask.size()
    c.set_selected_nodes({a,b});before=c.composite_image();assert c.merge_selected();assert gid in c.groups and c.parent_id(c.active.id)==gid and c.composite_image()==before;c.undo();assert set(c.raster_objects)=={a,b}


@pytest.mark.parametrize('suffix',['png','jpg','bmp','webp'])
def test_vector_shapes_export_formats_and_no_preview_scale_loss(window,tmp_path,suffix):
    c=setup(window,(400,280));make_shape(window,filled=True,fill='#ef3956');c.zoom=.25;c.drawing=True;proxy=interactive_image(c);assert proxy is not None;c.drawing=False
    path=tmp_path/('shape.'+suffix);c.export_image(path);image=QImage(str(path));assert not image.isNull() and image.width()==400 and image.height()==280


@pytest.mark.parametrize('name',['Линия','Стрелка'])
def test_horizontal_shapes_stay_horizontal_after_copy_and_move(window,name):
    c=setup(window,(400,280));obj=make_shape(window,name,start=(40,70),end=(210,70));assert obj['shape']['options']['flat_y'] and obj['height']==1
    before=c.active.image.copy();c.duplicate_layer();c.move_selected_by(QPointF(0,50));assert c.raster_objects[c.active.id]['shape']['options']['flat_y'];c.undo();assert c.active.image==before


def test_gradient_stop_picker_is_live_and_cancel_restores_rgba(window,monkeypatch):
    panel=window.gradient_panel;before=copy.deepcopy(window.canvas.gradient_options['stops'])
    def cancel(d):d.setCurrentColor(QColor(20,60,90,125));assert QColor(window.canvas.gradient_options['stops'][panel.selected][1]).alpha()==125;return QDialog.DialogCode.Rejected
    monkeypatch.setattr(QColorDialog,'exec',cancel);panel.pick_color();assert window.canvas.gradient_options['stops']==before


def test_text_color_cancel_restores_dirty_revision_and_defers_autosave(window,monkeypatch):
    from test_v03 import text_layer
    c=setup(window);text_layer(c);window.mark_clean();before=copy.deepcopy(c.text_objects);revision=window._safety.revision
    def cancel(d):
        d.setCurrentColor(QColor('blue'));assert window.dirty and not window._safety.request_autosave(force=True) and window._safety.job is None;return QDialog.DialogCode.Rejected
    monkeypatch.setattr(QColorDialog,'exec',cancel);window.text_controls.color.choose();assert c.text_objects==before and not window.dirty and window._safety.revision==revision


def test_text_same_color_accept_does_not_drop_redo(window,monkeypatch):
    from test_v03 import text_layer
    c=setup(window);text_layer(c);c.push_history();c.text_objects[0]['text']='Правка';c.changed.emit();c.undo();assert c.future
    monkeypatch.setattr(QColorDialog,'exec',lambda d:QDialog.DialogCode.Accepted);window.text_controls.color.choose();assert c.future;c.redo();assert c.text_objects[0]['text']=='Правка'
