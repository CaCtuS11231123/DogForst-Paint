import copy
import json
import uuid
import zipfile
import pytest
from PySide6.QtCore import Qt,QPoint,QPointF,QRectF,QMimeData
from PySide6.QtGui import QColor,QImage,QPainter
from PySide6.QtTest import QTest
from canvas import PaintCanvas
from layers import Layer,transparent_image
from groups import group_data,validate_tree,MAX_DEPTH
from recovery import DocumentSnapshot,RecoveryStore
from project_manager import read_project
from dialogs import TextDialog
from layer_list import MIME


def prepare(window,count=4,size=(320,280)):
    c=window.canvas;c.new_document(*size)
    c.layers=[Layer(f'Слой {i}',transparent_image(*size)) for i in range(count)]
    c.active_layer=count-1;c.sync_groups();c.set_selected_layers({c.active.id})
    c.zoom=1.;c.pan=QPointF();c.history.clear();c.future.clear();window.refresh_layers()
    return c


def group(c,ids):
    c.set_selected_nodes(ids);c.create_group();return c.control_node().id


def state(c):
    return group_data(c.groups),list(c.layer_stack),[l.id for l in c.layers],list(c.text_objects)


def test_grouping_changes_structure_without_pixels_and_undo(window):
    c=prepare(window);ids=[l.id for l in c.layers]
    c.layers[1].image.fill(QColor('red'));c.layers[2].image.setPixelColor(40,40,QColor('blue'))
    before=c.composite_image();gid=group(c,ids[1:3]);after=state(c)
    assert c.groups[gid].children==ids[1:3] and c.layer_stack==[ids[0],gid,ids[3]]
    assert c.composite_image()==before and len(c.selected_layer_ids())==2
    assert all(len(layer)==6 for layer in c.snapshot()['layers'])
    c.undo();assert not c.groups and c.layer_stack==ids and c.composite_image()==before
    c.redo();assert state(c)==after and c.selected_node_ids()=={gid}


def test_isolated_group_opacity_not_per_layer_alpha(window):
    c=prepare(window,3);ids=[l.id for l in c.layers]
    c.layers[1].image.fill(QColor('red'));c.layers[2].image.fill(QColor('red'))
    gid=group(c,ids[1:]);c.set_current_opacity(50)
    pixel=c.composite_image().pixelColor(40,40)
    assert pixel.red()==255 and 126<=pixel.alpha()<=128
    assert all(l.opacity==1 for l in c.layers)
    c.undo();assert c.groups[gid].opacity==1 and c.composite_image().pixelColor(40,40).alpha()==255
    c.redo();assert c.groups[gid].opacity==.5


def test_tile_renderer_matches_full_canvas_reference_with_text(window):
    from text_model import draw_text
    c=prepare(window,3,size=(600,420));ids=[l.id for l in c.layers]
    c.layers[1].image.fill(QColor(20,90,180,130))
    p=QPainter(c.layers[2].image);p.fillRect(230,20,70,350,QColor(220,40,60,170));p.end()
    text=dict(text='Проверка кириллицы ABC',size=34,x=210,y=240,color='#ffffff',layer_id=ids[2],stroke_width=2)
    c.text_objects=[text];gid=group(c,ids[1:]);c.set_current_opacity(63)
    full=transparent_image(*c.doc_size).convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
    p=QPainter(full);p.drawImage(0,0,c.layers[1].image);p.drawImage(0,0,c.layers[2].image);draw_text(p,text);p.end()
    expected=transparent_image(*c.doc_size);p=QPainter(expected);p.setOpacity(.63);p.drawImage(0,0,full);p.end()
    assert c.composite_image()==expected


def test_nested_group_opacity_and_visibility_preserve_child_flags(window):
    c=prepare(window,3);ids=[l.id for l in c.layers];c.layers[2].image.fill(QColor('red'))
    inner=group(c,[ids[2]]);c.set_current_opacity(50)
    outer=group(c,[ids[1],inner]);c.set_current_opacity(50)
    assert 62<=c.composite_image().pixelColor(20,20).alpha()<=64
    child_flags=[(l.visible,l.opacity) for l in c.layers]
    c.set_node_visible(outer,False);assert c.composite_image()==transparent_image(*c.doc_size)
    assert [(l.visible,l.opacity) for l in c.layers]==child_flags
    c.undo();assert c.node_visible(c.layers[-1])
    c.set_node_visible(inner,False);assert not c.node_visible(c.layers[-1])


def test_collapse_does_not_hide_or_unselect_group_members(window):
    c=prepare(window);ids=[l.id for l in c.layers];gid=group(c,ids[1:])
    count=window.layer_list.count();image=c.composite_image();selected=c.selected_layer_ids()
    c.toggle_group(gid)
    assert window.layer_list.count()==count-3 and c.selected_layer_ids()==selected
    assert c.composite_image()==image and c.selected_node_ids()=={gid}
    row=next(i for i in range(window.layer_list.count()) if window.layer_list.item(i).data(Qt.ItemDataRole.UserRole+2)==gid)
    point=window.layer_list.visualItemRect(window.layer_list.item(row)).center();point.setX(50)
    QTest.mouseClick(window.layer_list.viewport(),Qt.MouseButton.LeftButton,pos=point)
    assert not c.groups[gid].collapsed and window.layer_list.count()==count


def test_move_between_groups_root_and_order_undo(window):
    c=prepare(window,5);ids=[l.id for l in c.layers]
    a=group(c,ids[1:3]);b=group(c,ids[3:5]);before=state(c)
    c.move_nodes([ids[2]],b)
    assert c.groups[a].children==[ids[1]] and c.groups[b].children==[ids[3],ids[4],ids[2]]
    assert [l.id for l in c.layers]==[ids[0],ids[1],ids[3],ids[4],ids[2]]
    c.undo();assert state(c)==before
    c.redo();assert c.parent_id(ids[2])==b
    c.move_nodes([ids[2]],None);assert c.layer_stack[-1]==ids[2]
    c.undo();assert c.parent_id(ids[2])==b


def test_invalid_self_drop_depth_and_foreign_ids_are_atomic(window):
    c=prepare(window,2);ids=[l.id for l in c.layers];outer=group(c,[ids[1]])
    inner=group(c,[ids[1]]);before=state(c);count=len(c.history)
    c.move_nodes([outer],inner);assert state(c)==before and len(c.history)==count
    with pytest.raises(ValueError):c.move_nodes(['missing'],inner)
    with pytest.raises(ValueError):c.move_nodes([ids[0]],'missing')
    assert state(c)==before
    # Build exactly the supported depth, then reject a ninth empty level.
    c.set_selected_nodes([inner])
    for _ in range(MAX_DEPTH-2):c.create_group(False)
    before=state(c);count=len(c.history)
    with pytest.raises(ValueError):c.create_group(False)
    assert state(c)==before and len(c.history)==count


def test_nested_duplicate_gets_independent_ids_text_and_flags(window):
    c=prepare(window,4);ids=[l.id for l in c.layers]
    c.layers[2].kind='text';c.text_objects=[dict(text='Привет',x=30,y=20,size=25,layer_id=ids[2])]
    inner=group(c,[ids[2]]);outer=group(c,[ids[1],inner])
    c.groups[outer].opacity=.7;c.groups[inner].color_label='#ad8ed0';c.groups[inner].collapsed=True
    old_layers={l.id for l in c.layers};old_groups=set(c.groups)
    c.duplicate_layer();clone=c.control_node().id
    assert clone not in old_groups and len(c.groups)==4 and len(c.layers)==6
    assert c.groups[clone].opacity==.7 and set(c.descendant_layers(clone)).isdisjoint(old_layers)
    new_inner=next(identifier for identifier in c.groups[clone].children if identifier in c.groups)
    assert c.groups[new_inner].collapsed and c.groups[new_inner].color_label=='#ad8ed0'
    assert c.text_objects[0]['layer_id']!=c.text_objects[1]['layer_id']
    c.text_objects[1]['text']='Другая';assert c.text_objects[0]['text']=='Привет'
    c.undo();assert set(c.groups)==old_groups and len(c.layers)==4 and len(c.text_objects)==1
    c.redo();assert len(c.groups)==4 and c.selected_node_ids()=={clone}


def test_delete_group_and_undo_preserves_pixels_and_text(window):
    c=prepare(window,3);ids=[l.id for l in c.layers]
    c.layers[1].image.setPixelColor(40,40,QColor('red'))
    c.text_objects=[dict(text='Delete me',x=10,y=10,size=20,layer_id=ids[2])]
    gid=group(c,ids[1:]);before=c.composite_image();c.delete_layer()
    assert len(c.layers)==1 and not c.text_objects and not c.groups
    c.undo();assert gid in c.groups and c.composite_image()==before and c.selected_node_ids()=={gid}
    c.redo();assert len(c.layers)==1 and not c.groups


def test_empty_group_add_layer_insert_image_and_text(window,monkeypatch):
    c=prepare(window,1);c.create_group(False);gid=c.control_node().id
    assert not c.groups[gid].children
    before=c.layers[0].image.copy();assert not c.can_edit() and c.layers[0].image==before
    c.add_layer();assert c.parent_id(c.active.id)==gid
    c.set_selected_nodes([gid]);image=transparent_image(30,30);image.fill(QColor('red'))
    c.paste_image(image);assert c.parent_id(c.active.id)==gid
    c.set_selected_nodes([gid])
    def accept(dialog):dialog.controls.content.setPlainText('В группе');return 1
    monkeypatch.setattr(TextDialog,'exec',accept);c.edit_text_dialog(None,QPointF(40,40))
    assert c.parent_id(c.text_objects[-1]['layer_id'])==gid
    c.undo();assert not c.text_objects


@pytest.mark.parametrize('command',['brush','fill','text','cut','filter','delete','insert','reparent'])
def test_group_lock_protects_descendants_and_membership(window,command):
    c=prepare(window,3);ids=[l.id for l in c.layers];gid=group(c,ids[1:])
    c.layers[-1].image.fill(QColor('red'));c.groups[gid].locked=True
    c.set_selected_nodes([ids[2]]);before=state(c);pixels=c.active.image.copy()
    c.history.clear();c.future.clear()
    if command=='brush':c._stroke(QPointF(5,5),QPointF(15,15))
    elif command=='fill':c.flood_fill(10,10)
    elif command=='text':
        c.text_objects=[dict(text='A',size=20,x=10,y=10,layer_id=ids[2])];c.select_text(0)
        old=dict(c.text_objects[0]);window.text_controls.size.setValue(45);assert c.text_objects[0]==old
    elif command=='cut':c.cut_selection()
    elif command=='filter':c.apply_filter('invert')
    elif command=='delete':c.delete_layer()
    elif command=='insert':c.add_layer()
    else:c.move_nodes([ids[2]],None)
    assert c.active.image==pixels and c.groups[gid].children==ids[1:] and len(c.layers)==3
    assert not c.history and c.fill_job is None


def test_group_position_lock_move_skipped_while_color_edits_allowed(window):
    c=prepare(window,3);ids=[l.id for l in c.layers]
    c.layers[1].image.setPixelColor(20,20,QColor('red'));gid=group(c,ids[1:])
    c.set_selected_flag('position_locked',True);before=c.composite_image()
    c.move_selected_by(QPointF(10,10));assert c.composite_image()==before
    c.set_selected_nodes([ids[1]]);c.color=QColor('blue');c._stroke(QPointF(20,20),QPointF(30,30))
    assert c.composite_image()!=before


def test_ungroup_keeps_children_and_undo_restores_properties(window):
    c=prepare(window);ids=[l.id for l in c.layers];gid=group(c,ids[1:3]);c.set_current_opacity(40)
    c.groups[gid].collapsed=True;before=state(c);c.ungroup_selected()
    assert not c.groups and [l.id for l in c.layers]==ids
    c.undo();assert state(c)==before and c.groups[gid].opacity==.4


def test_group_roundtrip_v5_and_flat_documents_still_v4(window,tmp_path):
    c=prepare(window);ids=[l.id for l in c.layers];c.layers[1].image.fill(QColor('red'))
    gid=group(c,ids[1:3]);c.set_current_opacity(60);c.groups[gid].collapsed=True
    c.groups[gid].color_label='#719de0';c.groups[gid].position_locked=True
    path=tmp_path/'Папки.mpaint';c.save_project(path);before=c.composite_image()
    loaded=PaintCanvas();loaded.load_project(path)
    assert group_data(loaded.groups)==group_data(c.groups) and loaded.layer_stack==c.layer_stack
    assert loaded.composite_image()==before
    with zipfile.ZipFile(path) as z:assert json.loads(z.read('project.json'))['version']==5
    loaded.save_project(path);loaded.load_project(path);assert loaded.composite_image()==before
    c.set_selected_nodes([gid]);c.ungroup_selected();c.save_project(path)
    with zipfile.ZipFile(path) as z:assert json.loads(z.read('project.json'))['version']==4


def test_autosave_group_snapshot_independent_from_later_structure(window,tmp_path):
    c=prepare(window);ids=[l.id for l in c.layers];gid=group(c,ids[1:3]);c.set_current_opacity(50)
    snap=DocumentSnapshot.capture(c);c.groups[gid].name='Изменена';c.move_nodes([ids[1]],None)
    store=RecoveryStore(tmp_path/'recovery');record=store.write(snap,uuid.uuid4().hex,1)
    loaded=PaintCanvas();loaded.apply_loaded_project(store.read(record))
    assert loaded.groups[gid].name!='Изменена' and loaded.groups[gid].children==ids[1:3]
    assert loaded.groups[gid].opacity==.5


def test_manual_background_save_preserves_groups(window,tmp_path):
    c=prepare(window);ids=[l.id for l in c.layers];gid=group(c,ids[1:3]);c.set_current_opacity(67)
    window.current_file=str(tmp_path/'saved.mpaint');assert window.save_project()
    loaded=read_project(window.current_file);assert loaded.groups[gid].opacity==.67
    c.undo();assert c.groups[gid].opacity==1


@pytest.mark.parametrize('damage',['cycle','duplicate','orphan','unknown','opacity','badflag','missingtree'])
def test_malformed_v5_never_replaces_current_document(window,tmp_path,damage):
    c=prepare(window,3);ids=[l.id for l in c.layers];gid=group(c,ids[1:])
    path=tmp_path/'bad.mpaint';c.save_project(path)
    with zipfile.ZipFile(path) as z:resources={n:z.read(n) for n in z.namelist()}
    data=json.loads(resources['project.json']);entry=data['groups'][0]
    if damage=='cycle':entry['children'].append(gid)
    elif damage=='duplicate':entry['children'].append(ids[1])
    elif damage=='orphan':entry['children'].pop()
    elif damage=='unknown':entry['children'].append('absent')
    elif damage=='opacity':entry['opacity']=float('nan')
    elif damage=='badflag':entry['locked']='false'
    else:data.pop('layer_stack')
    resources['project.json']=json.dumps(data).encode()
    with zipfile.ZipFile(path,'w') as z:
        for name,contents in resources.items():z.writestr(name,contents)
    before=state(c);image=c.composite_image()
    with pytest.raises(ValueError):c.load_project(path)
    assert state(c)==before and c.composite_image()==image


def test_ui_group_visibility_and_slider_do_not_rewrite_children(window):
    c=prepare(window,3);ids=[l.id for l in c.layers];gid=group(c,ids[1:]);before=[(l.visible,l.opacity) for l in c.layers]
    window.layer_opacity.setValue(42);assert c.groups[gid].opacity==.42
    row=next(i for i in range(window.layer_list.count()) if window.layer_list.item(i).data(Qt.ItemDataRole.UserRole+2)==gid)
    window.layer_list.item(row).setCheckState(Qt.CheckState.Unchecked)
    assert not c.groups[gid].visible and [(l.visible,l.opacity) for l in c.layers]==before
    c.undo();assert c.groups[gid].visible


def test_group_drag_handler_moves_layer_into_folder_with_history(window):
    c=prepare(window,3);ids=[l.id for l in c.layers];gid=group(c,[ids[1]])
    c.set_selected_nodes([ids[2]]);window.refresh_layers();view=window.layer_list
    row=next(i for i in range(view.count()) if view.item(i).data(Qt.ItemDataRole.UserRole+2)==gid)
    view.scrollToItem(view.item(row));QTest.qWait(30)
    point=view.visualItemRect(view.item(row)).center()
    mime=QMimeData();mime.setData(MIME,json.dumps([ids[2]]).encode())
    class Drop:
        def source(self):return view
        def mimeData(self):return mime
        def position(self):return QPointF(point)
        def setDropAction(self,action):pass
        def accept(self):pass
        def ignore(self):raise AssertionError('Drop rejected')
    view.dropEvent(Drop());assert c.groups[gid].children==ids[1:]
    c.undo();assert c.parent_id(ids[2]) is None


def test_isolated_buffers_are_bounded_and_group_creation_keeps_pixel_buffers(window,monkeypatch):
    import group_render
    c=prepare(window,3,size=(800,600));ids=[l.id for l in c.layers]
    keys=[l.image.cacheKey() for l in c.layers];gid=group(c,ids[1:]);assert [l.image.cacheKey() for l in c.layers]==keys
    c.set_current_opacity(50);sizes=[];original=group_render.transparent_image
    def capture(w,h):sizes.append((w,h));return original(w,h)
    monkeypatch.setattr(group_render,'transparent_image',capture);c.composite_image()
    assert sizes and all(w<=256 and h<=256 for w,h in sizes)
    c.commit_history(force=True);assert c.history_engine.statistics()['payload_bytes']==0


def test_dragging_group_text_keeps_raster_and_both_texts_together(window):
    c=prepare(window,4);ids=[l.id for l in c.layers]
    c.layers[1].image.setPixelColor(20,20,QColor('blue'))
    c.text_objects=[dict(text='HELLO',x=40,y=40,size=24,layer_id=ids[2]),
                    dict(text='WORLD',x=160,y=60,size=24,layer_id=ids[3])]
    gid=group(c,ids[1:]);window.set_tool('Перемещение');c.selected_text=-1
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(52,52))
    QTest.mouseMove(c,QPoint(72,62));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(72,62))
    assert c.selected_node_ids()=={gid}
    assert c.text_objects[0]['x']==60 and c.text_objects[1]['x']==180
    assert c.layers[1].image.pixelColor(40,30)==QColor('blue')
    c.undo();assert c.text_objects[0]['x']==40 and c.text_objects[1]['x']==160


def test_collapsing_ancestor_promotes_hidden_selected_leaf(window):
    c=prepare(window,3);ids=[l.id for l in c.layers];gid=group(c,ids[1:])
    c.set_selected_nodes([ids[1]]);c.toggle_group(gid)
    assert c.selected_node_ids()=={gid} and c.control_node().id==gid
    assert any(item.data(Qt.ItemDataRole.UserRole+2)==gid for item in window.layer_list.selectedItems())


def test_group_export_matches_composite_after_save_load(window,tmp_path):
    c=prepare(window,3);ids=[l.id for l in c.layers];c.layers[-1].image.fill(QColor('red'))
    gid=group(c,ids[1:]);c.set_current_opacity(55);expected=c.composite_image()
    path=tmp_path/'groups.mpaint';c.save_project(path);c.load_project(path)
    out=tmp_path/'export.png';c.export_image(out)
    assert QImage(str(out)).convertToFormat(expected.format())==expected


def test_loading_collapsed_folder_highlights_visible_ancestor(window,tmp_path):
    c=prepare(window,3);ids=[l.id for l in c.layers];gid=group(c,ids[1:])
    c.set_selected_nodes([ids[2]]);c.groups[gid].collapsed=True
    path=tmp_path/'collapsed.mpaint';c.save_project(path);c.load_project(path)
    assert c.control_node().id==gid and c.selected_node_ids()=={gid}
    assert any(item.data(Qt.ItemDataRole.UserRole+2)==gid for item in window.layer_list.selectedItems())
