import copy,json,math,uuid,zipfile
import numpy as np
import pytest
from PySide6.QtCore import Qt,QPoint,QPointF
from PySide6.QtGui import QColor,QImage,QPainter
from PySide6.QtWidgets import QDialog
from PySide6.QtTest import QTest
from canvas import PaintCanvas
from layers import Layer,transparent_image
from groups import group_data
from blending import MODES
from recovery import DocumentSnapshot,RecoveryStore
from project_manager import read_project
from merge_dialog import MergePreviewDialog


def prepare(window,count=3,size=(80,60)):
    c=window.canvas;c.new_document(*size)
    c.layers=[Layer(f'Слой {i}',transparent_image(*size)) for i in range(count)]
    c.active_layer=count-1;c.sync_groups();c.set_selected_layers([c.active.id])
    c.history.clear();c.future.clear();c.zoom=1;c.pan=QPointF();window.refresh_layers()
    return c


def reference(bottom,top,mode,opacity):
    """Independent scalar blend equations on unassociated sRGB components."""
    cb=np.array(bottom[:3])/255.;cs=np.array(top[:3])/255.
    ab=bottom[3]/255.;a=top[3]/255.*opacity
    if mode=='add':return np.r_[np.minimum(ab*cb+a*cs,1),min(ab+a,1)]*255
    if mode=='normal':b=cs
    elif mode=='multiply':b=cb*cs
    elif mode=='screen':b=cb+cs-cb*cs
    elif mode=='overlay':b=np.where(cb<=.5,2*cb*cs,1-2*(1-cb)*(1-cs))
    elif mode=='hard_light':b=np.where(cs<=.5,2*cb*cs,1-2*(1-cb)*(1-cs))
    elif mode=='darken':b=np.minimum(cb,cs)
    elif mode=='lighten':b=np.maximum(cb,cs)
    elif mode=='difference':b=np.abs(cb-cs)
    elif mode=='exclusion':b=cb+cs-2*cb*cs
    else:
        d=np.where(cb<=.25,((16*cb-12)*cb+4)*cb,np.sqrt(cb))
        b=np.where(cs<=.5,cb-(1-2*cs)*cb*(1-cb),cb+(2*cs-1)*(d-cb))
    result=(1-a)*ab*cb+(1-ab)*a*cs+ab*a*b
    return np.r_[result,a+ab*(1-a)]*255


@pytest.mark.parametrize('mode',MODES)
@pytest.mark.parametrize('alpha,opacity',[(255,1.),(137,.63),(0,.4)])
def test_modes_match_independent_rgba_equations(qt,mode,alpha,opacity):
    c=PaintCanvas();c.new_document(1,1);c.history.clear()
    rng=np.random.default_rng(374)
    for _ in range(18):
        bottom=tuple(int(v) for v in rng.integers(0,256,3))+(int(rng.choice([0,81,203,255])),)
        top=tuple(int(v) for v in rng.integers(0,256,3))+(alpha,)
        a=transparent_image(1,1);a.fill(QColor(*bottom))
        b=transparent_image(1,1);b.fill(QColor(*top))
        c.layers=[Layer('B',a),Layer('S',b,opacity=opacity,blend_mode=mode)];c.active_layer=1;c.sync_groups()
        result=c.composite_image().convertToFormat(QImage.Format.Format_RGBA8888_Premultiplied)
        actual=np.frombuffer(result.constBits(),dtype=np.uint8)[:4]
        expected=reference(bottom,top,mode,opacity)
        assert np.max(np.abs(actual.astype(float)-expected))<=3,(mode,bottom,top,actual,expected)
    c.deleteLater()


def test_modes_are_metadata_only_and_bulk_undo_redo(window):
    c=prepare(window);ids=[l.id for l in c.layers];keys=[l.image.cacheKey() for l in c.layers]
    c.set_selected_nodes(ids[1:]);c.set_selected_blend('multiply');c.commit_history(force=True)
    assert [l.blend_mode for l in c.layers]==['normal','multiply','multiply']
    assert c.history_engine.statistics()['payload_bytes']==0 and [l.image.cacheKey() for l in c.layers]==keys
    c.undo();assert all(l.blend_mode=='normal' for l in c.layers)
    c.redo();assert all(l.blend_mode=='multiply' for l in c.layers[1:])
    c.undo();c.set_selected_blend('screen');assert not c.future


def test_mixed_ui_selection_and_mode_choice(window):
    c=prepare(window);ids=[l.id for l in c.layers];c.layers[1].blend_mode='screen'
    c.set_selected_nodes(ids[1:]);window.refresh_layers();choice=window.blend_choice
    assert choice.currentData() is None
    index=choice.findData('overlay');choice.setCurrentIndex(index);choice.activated.emit(index)
    assert all(l.blend_mode=='overlay' for l in c.layers[1:])
    c.undo();assert c.layers[1].blend_mode=='screen' and c.layers[2].blend_mode=='normal'


def test_non_normal_text_and_raster_are_one_source(window):
    c=prepare(window,2,size=(200,100));c.layers[0].image.fill(QColor('blue'));c.active.image.fill(QColor('red'))
    c.text_objects=[dict(text='HELLO',x=30,y=20,size=32,color='#ffffff',layer_id=c.active.id)]
    source=c.layer_image(c.active);c.active.blend_mode='multiply'
    expected=transparent_image(*c.doc_size);p=QPainter(expected);p.drawImage(0,0,c.layers[0].image)
    p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Multiply);p.drawImage(0,0,source);p.end()
    assert c.composite_image()==expected
    assert any(source.pixelColor(x,y)==QColor('white') for y in range(20,65) for x in range(30,160))


def test_text_layer_opacity_applies_once_over_raster_marks(window):
    c=prepare(window,1,size=(200,100));c.active.image.fill(QColor('red'))
    c.text_objects=[dict(text='HELLO',x=30,y=20,size=32,color='#ffffff',layer_id=c.active.id)]
    c.active.opacity=.5;image=c.composite_image()
    assert all(126<=image.pixelColor(x,y).alpha()<=128 for y in range(20,65) for x in range(30,160))


def test_group_normal_isolates_children_and_group_mode_applies_to_result(window):
    c=prepare(window,2);ids=[l.id for l in c.layers]
    c.layers[0].image.fill(QColor('blue'));c.layers[1].image.fill(QColor('red'))
    c.active.blend_mode='screen';c.create_group();gid=c.control_node().id
    assert c.composite_image().pixelColor(20,20)==QColor('red')
    c.set_selected_blend('multiply');assert c.composite_image().pixelColor(20,20)==QColor('black')
    c.undo();assert c.groups[gid].blend_mode=='normal' and c.active.blend_mode=='screen'
    c.redo();assert c.groups[gid].blend_mode=='multiply'


def test_nested_modes_and_opacity_survive_group_duplicate(window):
    c=prepare(window);ids=[l.id for l in c.layers]
    c.layers[0].image.fill(QColor('#1f7a96'));c.layers[-1].image.fill(QColor('#c84359'))
    c.set_selected_nodes(ids[1:]);c.create_group();inner=c.control_node().id;c.set_selected_blend('screen');c.set_current_opacity(60)
    c.create_group();outer=c.control_node().id;c.set_selected_blend('overlay')
    before=c.composite_image();c.duplicate_layer();clone=c.control_node().id
    assert c.groups[clone].blend_mode=='overlay'
    child=c.groups[clone].children[0];assert c.groups[child].blend_mode=='screen' and c.groups[child].opacity==.6
    c.undo();assert c.composite_image()==before and clone not in c.groups
    c.redo();assert c.groups[clone].blend_mode=='overlay'


def test_canvas_blends_document_before_checkerboard(window):
    c=prepare(window,1,size=(60,60));c.pan=QPointF(20,20);c.active.image.fill(QColor(255,0,0,128))
    c.active.visible=False;QTest.qWait(20);base=c.grab().toImage().pixelColor(32,24)
    c.active.visible=True;c.active.blend_mode='multiply';c.update();QTest.qWait(20)
    shown=c.grab().toImage().pixelColor(32,24)
    result=c.composite_image();expected=QImage(1,1,QImage.Format.Format_RGB32);expected.fill(base)
    p=QPainter(expected);p.drawImage(0,0,result.copy(12,4,1,1));p.end()
    assert shown==expected.pixelColor(0,0)


def test_shape_preview_matches_committed_blend_and_group_opacity(window):
    c=prepare(window,2,size=(100,100));c.layers[0].image.fill(QColor('#416bac'));c.active.blend_mode='multiply'
    c.create_group();c.set_current_opacity(60);c.set_selected_nodes([c.active.id])
    window.set_tool('Прямоугольник');c.shape_options.update(filled=True,fill='#dd7733',stroke='#dd7733',stroke_width=3)
    c._shape_configured=True;keys=[l.image.cacheKey() for l in c.layers]
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(20,20));QTest.mouseMove(c,QPoint(70,70));QTest.qWait(15)
    preview=c.grab().toImage().pixelColor(45,45)
    assert [l.image.cacheKey() for l in c.layers]==keys
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(70,70));QTest.qWait(15)
    assert c.grab().toImage().pixelColor(45,45)==preview


def test_partial_repaint_and_full_export_use_identical_tiles(window):
    from compositor import paint_tiles
    from PySide6.QtCore import QRectF
    c=prepare(window,2,size=(620,410));c.layers[0].image.fill(QColor(50,120,170,130));c.active.image.fill(QColor(200,80,50,180));c.active.blend_mode='soft_light'
    expected=c.composite_image();partial=transparent_image(*c.doc_size);p=QPainter(partial)
    p.setClipRect(QRectF(247,51,280,290));paint_tiles(p,c.layers,{},c.layer_stack,[],c.doc_size,QRectF(247,51,280,290));p.end()
    assert partial.copy(247,51,280,290)==expected.copy(247,51,280,290)


@pytest.mark.parametrize('group_mode',[False,True])
def test_v6_roundtrip_and_unchanged_legacy_versions(window,tmp_path,group_mode):
    c=prepare(window,2);c.active.image.fill(QColor('#bc4e27'))
    if group_mode:c.create_group()
    c.set_selected_blend('screen');path=tmp_path/'Наложение.mpaint';c.save_project(path)
    with zipfile.ZipFile(path) as z:assert json.loads(z.read('project.json'))['version']==6
    before=c.composite_image();c.load_project(path);assert c.composite_image()==before
    assert any(l.blend_mode=='screen' for l in c.layers) or any(g.blend_mode=='screen' for g in c.groups.values())
    c.save_project(path);c.load_project(path);assert c.composite_image()==before
    for layer in c.layers:layer.blend_mode='normal'
    for group in c.groups.values():group.blend_mode='normal'
    c.save_project(path)
    with zipfile.ZipFile(path) as z:assert json.loads(z.read('project.json'))['version']==(5 if group_mode else 4)


def test_background_snapshot_and_recovery_keep_independent_modes(window,tmp_path):
    c=prepare(window,2);c.active.blend_mode='multiply';c.create_group();gid=c.control_node().id;c.set_selected_blend('screen')
    snapshot=DocumentSnapshot.capture(c);c.active.blend_mode='normal';c.groups[gid].blend_mode='normal'
    store=RecoveryStore(tmp_path/'recovery');record=store.write(snapshot,uuid.uuid4().hex,1)
    loaded=read_project(record.path);assert loaded.groups[gid].blend_mode=='screen' and loaded[1][-1].blend_mode=='multiply'


def test_manual_save_and_png_export_keep_modes(window,tmp_path):
    c=prepare(window,2);c.layers[0].image.fill(QColor('#204080'));c.active.image.fill(QColor('#a09020'));c.active.blend_mode='overlay'
    before=c.composite_image();window.current_file=str(tmp_path/'Project.mpaint');assert window.save_project()
    assert read_project(window.current_file)[1][-1].blend_mode=='overlay'
    out=tmp_path/'Result.png';c.export_image(out);assert QImage(str(out)).convertToFormat(before.format())==before


@pytest.mark.parametrize('value',['future_mode',None,17,[]])
def test_unknown_layer_modes_do_not_replace_document(window,tmp_path,value):
    c=prepare(window,2);c.active.blend_mode='multiply';path=tmp_path/'bad.mpaint';c.save_project(path)
    with zipfile.ZipFile(path) as z:resources={n:z.read(n) for n in z.namelist()}
    manifest=json.loads(resources['project.json']);manifest['layers'][-1]['blend_mode']=value
    resources['project.json']=json.dumps(manifest).encode()
    with zipfile.ZipFile(path,'w') as z:
        for name,data in resources.items():z.writestr(name,data)
    keys=[l.image.cacheKey() for l in c.layers];before=c.snapshot()
    with pytest.raises(ValueError):c.load_project(path)
    assert [l.image.cacheKey() for l in c.layers]==keys and c.snapshot()['layer_flags']==before['layer_flags']


def test_invalid_mode_save_preserves_existing_project_and_history(window,tmp_path):
    c=prepare(window,1);path=tmp_path/'safe.mpaint';c.save_project(path);original=path.read_bytes();count=len(c.history)
    with pytest.raises(ValueError):c.set_selected_blend('unknown')
    assert len(c.history)==count
    c.active.blend_mode='unknown'
    with pytest.raises(ValueError):c.save_project(path)
    assert path.read_bytes()==original


@pytest.mark.parametrize('accept',[False,True])
def test_non_normal_merge_requires_preview_and_undo(window,tmp_path,monkeypatch,accept):
    c=prepare(window,3);c.layers[0].image.fill(QColor('#123456'));c.layers[1].image.fill(QColor(200,40,70,130));c.active.image.fill(QColor(30,180,100,150));c.active.blend_mode='multiply'
    before=c.composite_image();ids=[l.id for l in c.layers];count=len(c.history);dialogs=[]
    def choose(dialog):
        dialogs.append(dialog)
        return QDialog.DialogCode.Accepted if accept else QDialog.DialogCode.Rejected
    monkeypatch.setattr(MergePreviewDialog,'exec',choose);c.merge_down();assert len(dialogs)==1
    if accept:
        assert len(c.layers)==2 and c.active.blend_mode=='normal'
        c.undo();assert [l.id for l in c.layers]==ids and c.composite_image()==before and c.active.blend_mode=='multiply'
        c.redo();assert len(c.layers)==2
    else:assert [l.id for l in c.layers]==ids and c.composite_image()==before and len(c.history)==count


def test_compositor_buffers_are_bounded_and_render_does_not_modify_sources(window,monkeypatch):
    import compositor
    c=prepare(window,3,size=(800,620));c.layers[1].blend_mode='overlay';c.active.blend_mode='screen'
    c.set_selected_nodes([c.active.id]);c.create_group();c.set_selected_blend('multiply')
    keys=[l.image.cacheKey() for l in c.layers];original=compositor.transparent_image;sizes=[]
    def capture(w,h):sizes.append((w,h));return original(w,h)
    monkeypatch.setattr(compositor,'transparent_image',capture);c.composite_image()
    assert sizes and max(w*h for w,h in sizes)<=256*256
    assert keys==[l.image.cacheKey() for l in c.layers]


@pytest.mark.parametrize('outer_mode',['normal','multiply'])
def test_normal_nested_sibling_after_blended_child_is_rendered(window,outer_mode):
    c=prepare(window,4);ids=[l.id for l in c.layers]
    c.layers[0].image.fill(QColor('blue'));c.layers[1].image.fill(QColor('red'));c.layers[2].image.fill(QColor('green'))
    c.layers[1].blend_mode='screen'
    c.set_selected_nodes(ids[2:]);c.create_group();sibling=c.control_node().id
    c.set_selected_nodes([ids[1],sibling]);c.create_group();outer=c.control_node().id
    c.set_current_opacity(88);c.set_selected_blend(outer_mode)
    image=c.composite_image();pixel=image.pixelColor(20,20)
    # QColor('green') is RGB(0,128,0); root backdrop is blue.
    assert abs(pixel.blue()-31)<=2 and pixel.red()==0
    assert abs(pixel.green()-(113 if outer_mode=='normal' else 0))<=2


def test_group_modes_match_single_complete_source_for_all_modes(window):
    c=prepare(window,2);c.layers[0].image.fill(QColor(100,150,230,170));c.active.image.fill(QColor(230,140,40,190))
    sources=[]
    for mode in MODES:
        c.active.blend_mode=mode;c.active.opacity=.63;sources.append(c.composite_image())
    c.active.blend_mode='normal';c.active.opacity=1;c.create_group()
    c.set_current_opacity(63)
    for (mode,result) in zip(MODES,sources):
        c.set_selected_blend(mode);assert c.composite_image()==result,mode


@pytest.mark.parametrize('value',['unknown',None,{}])
def test_invalid_group_mode_is_rejected_before_replacing_document(window,tmp_path,value):
    c=prepare(window,2);c.create_group();c.set_selected_blend('screen')
    path=tmp_path/'badgroup.mpaint';c.save_project(path)
    with zipfile.ZipFile(path) as z:entries={name:z.read(name) for name in z.namelist()}
    metadata=json.loads(entries['project.json']);metadata['groups'][0]['blend_mode']=value
    entries['project.json']=json.dumps(metadata).encode()
    with zipfile.ZipFile(path,'w') as z:
        for name,data in entries.items():z.writestr(name,data)
    before=group_data(c.groups);pixels=c.composite_image()
    with pytest.raises(ValueError):c.load_project(path)
    assert group_data(c.groups)==before and c.composite_image()==pixels


def test_detached_layer_panel_uses_extra_height_and_docks_back(window):
    prepare(window)
    window.layers_dock.setFloating(True);window.layers_dock.resize(470,700);QTest.qWait(30)
    assert window.layer_list.height()>140
    window.layers_dock.setFloating(False);QTest.qWait(30)
    assert window.layer_list.maximumHeight()==140


@pytest.mark.parametrize('size',[(1,12000),(12000,1)])
def test_merge_preview_handles_one_pixel_wide_or_high_canvas(qt,size):
    from compositor import render_image
    image=transparent_image(*size);image.fill(QColor('red'))
    layer=Layer('Thin',image,blend_mode='screen')
    preview=render_image(size,[layer],{},[layer.id],[],(390,300))
    assert not preview.isNull() and min(preview.width(),preview.height())==1
    assert preview.pixelColor(0,0)==QColor('red')
