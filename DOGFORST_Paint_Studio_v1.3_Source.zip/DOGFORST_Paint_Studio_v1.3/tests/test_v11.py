import copy,threading,time,json,zipfile
import numpy as np
import pytest
from PySide6.QtCore import Qt,QPointF,QRectF,QPoint,QTimer
from PySide6.QtGui import QImage,QColor,QPainter
from PySide6.QtWidgets import QDialog
from PySide6.QtTest import QTest
from adjustments import (DEFAULT_ADJUSTMENT,EFFECTS,PRESETS,AdjustmentInput,render_adjustment,
    validate_adjustment,AdjustmentJob,pixels)
from adjustment_dialog import AdjustmentDialog
from test_dev7 import setup,imported
from test_v056 import make_shape
from project_manager import read_project
from recovery import DocumentSnapshot
from selection_tools import from_array
from masks import validate_mask
from versioning import Version


def specimen(w=127,h=91):
    values=np.random.default_rng(4).integers(0,256,(h,w,4),dtype=np.uint8);values[:,:,3]=255;values[0,:,3]=0;values[1,:,3]=127
    return QImage(values.data,w,h,w*4,QImage.Format.Format_RGBA8888).copy().convertToFormat(QImage.Format.Format_ARGB32)

def rendered(image,**params):return render_adjustment(AdjustmentInput(image),dict(DEFAULT_ADJUSTMENT,**params),threading.Event())

def ready(c):
    deadline=time.monotonic()+15
    while c.adjustment_session is not None and c.adjustment_session.rendered_version!=c.adjustment_session.version and time.monotonic()<deadline:QTest.qWait(10)
    assert c.adjustment_session is not None and not c.adjustment_session.error and c.adjustment_session.rendered_version==c.adjustment_session.version
    return c.adjustment_session

def start(window,**params):
    c=setup(window,(260,180));c.active.image=specimen(260,180);c.commit_history(force=True);c.history.clear();c.future.clear();window.mark_clean();assert c.start_adjustment();c.update_adjustment(**params);return c


@pytest.mark.parametrize('effect',EFFECTS)
def test_filters_preserve_alpha_and_hidden_rgb_and_change_real_pixels(effect):
    before=specimen();result=rendered(before,effect=effect,amount=EFFECTS[effect][3],brightness=10 if effect=='none' else 0)
    ai=before.convertToFormat(QImage.Format.Format_RGBA8888);bi=result.convertToFormat(QImage.Format.Format_RGBA8888);a=pixels(ai).copy();b=pixels(bi).copy()
    assert np.array_equal(a[:,:,3],b[:,:,3]);assert np.array_equal(a[0],b[0]);assert result!=before


@pytest.mark.parametrize('key,value',[('brightness',20),('contrast',20),('gamma',150),('saturation',-40),('hue',80),('temperature',25),('tint',25),('grayscale',True),('sepia',True),('invert',True)])
def test_each_colour_control_changes_pixels(key,value):
    raw=specimen();assert rendered(raw,**{key:value})!=raw


@pytest.mark.parametrize('effect',['blur','sharpen','pixelate','noise','vignette','posterize'])
def test_tile_boundaries_are_exact_and_noise_is_repeatable(effect):
    raw=specimen(147,103);p=dict(DEFAULT_ADJUSTMENT,effect=effect,amount=3 if effect in ('blur','posterize') else 12,temperature=17,hue=35)
    a=render_adjustment(AdjustmentInput(raw),p,threading.Event(),tile_width=31,tile_height=17)
    b=render_adjustment(AdjustmentInput(raw),p,threading.Event(),tile_width=113,tile_height=63);assert a==b


def test_identity_zero_strength_and_hsv_reference():
    raw=specimen();assert rendered(raw)==raw and rendered(raw,invert=True,strength=0)==raw
    red=QImage(1,1,QImage.Format.Format_ARGB32);red.fill(QColor('red'));green=rendered(red,hue=120).pixelColor(0,0);assert green.green()==255 and green.red()==0 and green.blue()==0


@pytest.mark.parametrize('params',[{'brightness':True},{'gamma':0},{'hue':181},{'strength':101},{'effect':'unknown'},{'effect':'posterize','amount':1},{'grayscale':1}])
def test_bad_parameters_reject(params):
    with pytest.raises(ValueError):validate_adjustment(params)


def test_selection_exact_holes_partial_coverage_and_cancellation():
    raw=specimen();values=np.full((raw.height(),raw.width()),128,np.uint8);values[:,20:40]=0;mask=from_array(values);data=AdjustmentInput(raw,mask)
    result=render_adjustment(data,dict(DEFAULT_ADJUSTMENT,invert=True),threading.Event());assert result.copy(20,0,20,raw.height())==raw.copy(20,0,20,raw.height())
    event=threading.Event();event.set();assert render_adjustment(data,DEFAULT_ADJUSTMENT,event) is None
    event.clear();assert render_adjustment(data,dict(DEFAULT_ADJUSTMENT,brightness=1),event,lambda n:event.set(),tile_width=12,tile_height=12) is None


def test_preview_original_snapshot_save_and_apply_undo_redo(window,tmp_path):
    c=start(window,contrast=20,temperature=15);before=c.active.image.copy();ready(c);assert c.composite_image(True)!=c.composite_image() and c.active.image==before and not window.dirty and not c.history
    assert DocumentSnapshot.capture(c).layers[0].image==before
    c.show_adjustment_original(True);assert c.composite_image(True)==c.composite_image();c.show_adjustment_original(False)
    path=tmp_path/'held.mpaint';c.save_project(str(path),backup=False);assert read_project(path)[1][0].image==before
    assert c.apply_adjustment();after=c.active.image.copy();assert after!=before and len(c.history)==1
    c.undo();assert c.active.image==before;c.redo();assert c.active.image==after
    c.save_project(str(path),backup=False);assert read_project(path)[1][0].image==after


def test_noop_cancel_and_redo_survive(window):
    c=start(window,invert=True);ready(c);c.apply_adjustment();c.undo();assert c.future
    assert c.start_adjustment();ready(c);assert c.apply_adjustment();assert c.future
    before=c.active.image.copy();assert c.start_adjustment();c.update_adjustment(brightness=30);c.cancel_adjustment();assert c.active.image==before and c.future


@pytest.mark.parametrize('group',[False,True])
def test_mask_correction_and_flags(window,group):
    c=setup(window,(180,120));c.active.image=specimen(180,120)
    if group:c.create_group()
    c.add_mask(40);c.start_mask_edit();identifier=c.editing_mask;before=c.masks[identifier].copy();images=[QImage(l.image) for l in c.layers]
    assert c.start_adjustment();c.update_adjustment(invert=True);ready(c);c.apply_adjustment();validate_mask(c.masks[identifier],c.doc_size);assert c.masks[identifier]!=before and [l.image for l in c.layers]==images
    c.undo();assert c.masks[identifier]==before


def test_photo_and_shape_source_restore_and_layer_flags(window):
    c=imported(window);identifier=c.active.id;obj=dict(c.raster_objects[identifier],source=QImage(c.raster_objects[identifier]['source']));c.active.alpha_locked=True;c.active.opacity=.6;flags=c.active.flags()
    assert c.start_adjustment();c.update_adjustment(contrast=20);ready(c);c.apply_adjustment();assert identifier not in c.raster_objects and c.active.flags()==flags
    c.undo();assert c.raster_objects[identifier]['source']==obj['source']
    c=setup(window);make_shape(window,filled=True,fill='#8888aa');identifier=c.active.id;recipe=copy.deepcopy(c.raster_objects[identifier]['shape']);assert c.start_adjustment();c.update_adjustment(brightness=25);ready(c);c.apply_adjustment();assert identifier not in c.raster_objects;c.undo();assert c.raster_objects[identifier]['shape']==recipe


def test_text_rasterizes_only_on_commit_and_undo_restores(window):
    from test_v03 import text_layer
    c=setup(window);text_layer(c);c.set_selected_nodes({c.active.id},c.active.id);before=copy.deepcopy(c.text_objects)
    assert c.start_adjustment();c.update_adjustment(hue=120);ready(c);assert c.text_objects==before;c.apply_adjustment();assert not c.text_objects;c.undo();assert c.text_objects==before


def test_stale_document_and_new_document_do_not_overwrite(window):
    c=start(window,brightness=50);c.active.image.fill(QColor('yellow'));deadline=time.monotonic()+5
    while c.adjustment_session is not None and time.monotonic()<deadline:QTest.qWait(10)
    assert c.adjustment_session is None and c.active.image.pixelColor(10,10)==QColor('yellow')
    assert c.start_adjustment();c.update_adjustment(effect='blur',amount=25);c.new_document(60,40);QTest.qWait(150);assert c.adjustment_session is None and c.doc_size==(60,40)


def test_cancel_and_restart_ignores_stale_worker(window):
    c=start(window,effect='blur',amount=20);c.launch_adjustment_job();c.cancel_adjustment();assert c.start_adjustment();c.update_adjustment(invert=True);s=ready(c);assert s.parameters['invert'];expected=rendered(s.data.raw,invert=True);assert s.result==expected;c.cancel_adjustment()


def test_apply_waits_for_latest_and_changes_are_not_accumulated(window):
    c=start(window,brightness=30);c.launch_adjustment_job();c.update_adjustment(brightness=-20);c.apply_adjustment();deadline=time.monotonic()+10
    while c.adjustment_session is not None and time.monotonic()<deadline:QTest.qWait(10)
    assert c.adjustment_session is None and c.active.image==rendered(specimen(260,180),brightness=-20)


def test_memory_error_keeps_original(window,monkeypatch):
    import adjustments
    c=start(window,brightness=50);before=c.active.image.copy()
    def fail(*args,**kwargs):raise MemoryError()
    monkeypatch.setattr(adjustments,'render_adjustment',fail);deadline=time.monotonic()+5
    while not c.adjustment_session.error and time.monotonic()<deadline:QTest.qWait(10)
    assert 'памяти' in c.adjustment_session.error and c.active.image==before and not c.apply_adjustment();c.cancel_adjustment()


def test_preview_modes_exclude_each_other_and_group_selection_rejects(window):
    c=start(window,brightness=10);assert not c.start_gradient(QPointF(0,0));window.set_tool('Размытие');assert c.adjustment_session is None
    c.start_retouch(QPointF(30,30));assert not c.start_adjustment();c.cancel_retouch()
    c.create_group();assert not c.start_adjustment()


def test_dialog_controls_presets_disabled_filter_and_escape(window):
    c=start(window);window.reduce_motion=True;d=AdjustmentDialog(window);assert d.reduce_motion;d.show();QTest.qWait(20)
    assert not d.fields['amount'].isEnabled();d.fields['brightness'].setValue(17);assert c.adjustment_session.parameters['brightness']==17 and d.sliders['brightness'].value()==17
    d.effects.setCurrentIndex(d.effects.findData('posterize'));assert d.fields['amount'].minimum()==2 and d.fields['amount'].isEnabled()
    d.apply_preset(d.presets.findText('Негатив'));assert c.adjustment_session.parameters['invert'] and c.adjustment_session.parameters['effect']=='none'
    d.background.setCurrentIndex(1);assert d.preview.dark;d.original.setChecked(True);assert c.adjustment_session.show_original
    QTest.keyClick(d,Qt.Key.Key_Escape);assert c.adjustment_session is None and d.result()==QDialog.DialogCode.Rejected;d.deleteLater()


def test_dialog_apply_commits_latest_and_mask_colour_controls_disabled(window):
    c=start(window);d=AdjustmentDialog(window);d.show();d.fields['brightness'].setValue(20);d.apply.click();deadline=time.monotonic()+10
    while c.adjustment_session and time.monotonic()<deadline:QTest.qWait(10)
    assert c.adjustment_session is None and d.result()==QDialog.DialogCode.Accepted;d.deleteLater()
    c.add_mask(50);c.start_mask_edit();assert c.start_adjustment();d=AdjustmentDialog(window);assert not d.fields['hue'].isEnabled() and not d.checks['sepia'].isEnabled();d.reject();d.deleteLater()


def test_version_user_numbering_and_windows_preflight():
    assert Version.parse('1.00').next_update().display()=='1.1';assert Version.parse('1.1').next_update().display()=='1.2';assert Version.parse('1.1').next_fix().display()=='1.1.1'
    from scripts.check_build_environment import main
    assert main()==0
