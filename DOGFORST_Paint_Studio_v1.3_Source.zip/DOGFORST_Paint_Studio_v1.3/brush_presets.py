"""User brush presets, validated before replacing preferences."""
import json,copy
from PySide6.QtGui import QColor
TOOLS=('Кисть','Мягкая кисть','Карандаш','Маркер','Ластик')
def validate_preset(p):
    if not isinstance(p,dict) or p.get('tool') not in TOOLS or p.get('shape') not in ('round','square'):raise ValueError('Неверный пресет кисти.')
    for key,lo,hi in [('size',1,512),('opacity',0,100),('hardness',0,100),('stabilizer',0,100),('outline',0,30),('spacing',1,50),('flow',1,100)]:
        v=p.get(key)
        if type(v) is not int or not lo<=v<=hi:raise ValueError('Некорректный параметр кисти: '+key)
    for key in ('color','outline_color'):
        if not isinstance(p.get(key),str) or not QColor(p[key]).isValid():raise ValueError('Некорректный цвет кисти.')
    return {k:p[k] for k in ('tool','shape','size','opacity','hardness','stabilizer','outline','spacing','flow','color','outline_color')}
class BrushPresetStore:
    def __init__(self,settings):
        self.settings=settings;self.presets={}
        try:
            value=json.loads(settings.value('brush/presets_055','{}'))
            if not isinstance(value,dict) or len(value)>100:raise ValueError()
            for name,p in value.items():
                if not isinstance(name,str) or not name.strip() or len(name)>60:raise ValueError()
                self.presets[name]=validate_preset(p)
        except (ValueError,TypeError):self.presets={}
    def save(self,name,p):
        if not isinstance(name,str) or not name.strip() or len(name)>60:raise ValueError('Введите название до 60 символов.')
        if name.strip() not in self.presets and len(self.presets)>=100:raise ValueError('Сохранено 100 пресетов.')
        candidate=dict(self.presets);candidate[name.strip()]=validate_preset(p);self.presets=candidate;self.persist()
    def delete(self,name):
        self.presets.pop(name,None);self.persist()
    def persist(self):self.settings.setValue('brush/presets_055',json.dumps(self.presets,ensure_ascii=False));self.settings.sync()
