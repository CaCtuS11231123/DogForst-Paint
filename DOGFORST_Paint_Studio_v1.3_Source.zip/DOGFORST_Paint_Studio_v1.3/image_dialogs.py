"""Photo/texture import choice and non-destructive placement controls."""
from pathlib import Path
from PySide6.QtCore import Qt,QRectF,QSignalBlocker
from PySide6.QtGui import QColor,QPainter
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QFormLayout,QLabel,QPushButton,
    QDoubleSpinBox,QSpinBox,QCheckBox,QComboBox,QDialogButtonBox,QFileDialog,QMessageBox,QWidget)
from raster_objects import clone_object,paint_object,read_image
from blending import MODES

class ImportChoice(QDialog):
    def __init__(self,paths,parent=None):
        super().__init__(parent);self.setWindowTitle('Добавить фотографии');self.mode=None
        layout=QVBoxLayout(self);layout.addWidget(QLabel(f'Файлов: {len(paths)} · '+Path(paths[0]).name))
        layout.addWidget(QLabel('Слоем — добавить к текущему рисунку с подгонкой размера.\nНовым документом — открыть фото с его собственным размером холста.'))
        for title,mode in [('Добавить отдельным слоем','layer'),('Как новый документ','document'),('Добавить текстурой','texture')]:
            b=QPushButton(title);b.setEnabled(mode!='document' or len(paths)==1)
            b.clicked.connect(lambda checked=False,m=mode:self.pick(m));layout.addWidget(b)
        cancel=QPushButton('Отмена');cancel.clicked.connect(self.reject);layout.addWidget(cancel)
    def pick(self,mode):self.mode=mode;self.accept()

class PlacementPreview(QWidget):
    def __init__(self,dialog):super().__init__();self.dialog=dialog;self.setMinimumSize(310,270)
    def paintEvent(self,event):
        p=QPainter(self);p.fillRect(self.rect(),QColor('#242936'))
        size=self.dialog.size;factor=min((self.width()-24)/size[0],(self.height()-24)/size[1]);w,h=size[0]*factor,size[1]*factor
        p.translate((self.width()-w)/2,(self.height()-h)/2)
        rect=QRectF(0,0,w,h);p.fillRect(rect,QColor('#e4e9f1'));p.setClipRect(rect)
        p.scale(factor,factor);p.setOpacity(self.dialog.opacity.value()/100);paint_object(p,self.dialog.values());p.end()

class PlacementDialog(QDialog):
    def __init__(self,obj,size,layer,parent=None):
        super().__init__(parent);self.setWindowTitle('Изображение / эффект · параметры');self.resize(790,600)
        self.obj=clone_object(obj);self.size=size;self.source=self.obj['source'];self._ratio=obj['width']/obj['height']
        root=QVBoxLayout(self);root.addWidget(QLabel('Изменения применяются к выбранному слою. Исходник хранится в проекте.'))
        row=QHBoxLayout();root.addLayout(row);form=QFormLayout();row.addLayout(form)
        self.x=self.number(-100000,100000,obj['x']);self.y=self.number(-100000,100000,obj['y'])
        self.w=self.number(1,24000,obj['width']);self.h=self.number(1,24000,obj['height'])
        self.rotation=self.number(-36000,36000,obj['rotation'],'°')
        self.aspect=QCheckBox('Сохранять пропорции');self.aspect.setChecked(True)
        self.flip_h=QCheckBox('По горизонтали');self.flip_h.setChecked(obj['flip_h'])
        self.flip_v=QCheckBox('По вертикали');self.flip_v.setChecked(obj['flip_v'])
        self.repeat=QCheckBox('Повторять текстуру');self.repeat.setChecked(obj['repeat'])
        self.tile_scale=self.number(5,800,obj['tile_scale'],' %')
        self.opacity=QSpinBox();self.opacity.setRange(0,100);self.opacity.setValue(round(layer.opacity*100));self.opacity.setSuffix(' %')
        self.blend=QComboBox()
        for key,(label,tip,_) in MODES.items():self.blend.addItem(label,key);self.blend.setItemData(self.blend.count()-1,tip,Qt.ItemDataRole.ToolTipRole)
        self.blend.setCurrentIndex(self.blend.findData(layer.blend_mode))
        for label,control in [('X',self.x),('Y',self.y),('Ширина',self.w),('Высота',self.h),('',self.aspect),('Поворот',self.rotation),('Отразить',self.flip_h),('',self.flip_v),('',self.repeat),('Масштаб узора',self.tile_scale),('Непрозрачность',self.opacity),('Наложение',self.blend)]:form.addRow(label,control)
        self.replace=QPushButton('Заменить фото / текстуру…');self.replace.clicked.connect(self.replace_source);form.addRow(self.replace)
        self.source_label=QLabel(f'{self.source.width()} × {self.source.height()} px · встроенный исходник');form.addRow(self.source_label)
        side=QVBoxLayout();row.addLayout(side,1);self.preview=PlacementPreview(self);side.addWidget(self.preview)
        note=QLabel('Предпросмотр выбранного слоя.\nНаложение на другие слои оценивайте на холсте.\n\nУглы рамки: размер с сохранением пропорций.\nShift при изменении размера — свободные пропорции.\nКруг над рамкой: поворот; Shift — шаг 15°.');note.setWordWrap(True);side.addWidget(note)
        self.w.valueChanged.connect(lambda value:self.sync_aspect(value,True));self.h.valueChanged.connect(lambda value:self.sync_aspect(value,False))
        self.aspect.toggled.connect(lambda checked:setattr(self,'_ratio',self.w.value()/self.h.value()))
        for c in (self.x,self.y,self.w,self.h,self.rotation,self.tile_scale,self.opacity):c.valueChanged.connect(self.preview.update)
        for c in (self.flip_h,self.flip_v,self.repeat):c.toggled.connect(self.preview.update)
        self.repeat.toggled.connect(self.tile_scale.setEnabled);self.tile_scale.setEnabled(self.repeat.isChecked())
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText('Применить');buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена')
        buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);root.addWidget(buttons)
    def number(self,lo,hi,value,suffix=' px'):
        spin=QDoubleSpinBox();spin.setRange(lo,hi);spin.setDecimals(1);spin.setValue(value);spin.setSuffix(suffix);return spin
    def sync_aspect(self,value,width):
        if not self.aspect.isChecked():return
        other=self.h if width else self.w
        with QSignalBlocker(other):other.setValue(value/self._ratio if width else value*self._ratio)
    def values(self):return dict(self.obj,source=self.source,x=self.x.value(),y=self.y.value(),width=self.w.value(),height=self.h.value(),rotation=self.rotation.value(),repeat=self.repeat.isChecked(),tile_scale=self.tile_scale.value(),flip_h=self.flip_h.isChecked(),flip_v=self.flip_v.isChecked())
    def replace_source(self):
        filename,_=QFileDialog.getOpenFileName(self,'Заменить исходник','','Изображения (*.png *.jpg *.jpeg *.bmp *.webp)')
        if not filename:return
        try:self.source=read_image(filename)
        except (ValueError,MemoryError) as e:QMessageBox.warning(self,'Изображение',str(e));return
        self.source_label.setText(f'{self.source.width()} × {self.source.height()} px · '+Path(filename).name);self.preview.update()
