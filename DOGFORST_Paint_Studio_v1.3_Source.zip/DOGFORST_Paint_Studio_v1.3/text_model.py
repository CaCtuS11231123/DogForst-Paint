"""Shared editable text geometry for the canvas, previews and export."""
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import QFont, QFontMetricsF, QPainterPath, QColor, QPen, QTransform


def text_font(item):
    font = QFont(str(item.get('font','Segoe UI')))
    font.setPixelSize(max(1,min(1600,int(item.get('size',32)))))
    font.setBold(bool(item.get('bold',False)))
    font.setItalic(bool(item.get('italic',False)))
    font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing,float(item.get('letter_spacing',0)))
    return font


def text_geometry(item):
    font=text_font(item);metrics=QFontMetricsF(font)
    lines=str(item.get('text','')).split('\n')
    width=max([metrics.horizontalAdvance(line) for line in lines]+[20.])
    line_height=metrics.height()*float(item.get('line_spacing',1.15))
    height=max(metrics.height(),line_height*(len(lines)-1)+metrics.height())
    path=QPainterPath()
    for i,line in enumerate(lines):
        advance=metrics.horizontalAdvance(line)
        x={'left':0.,'center':(width-advance)/2,'right':width-advance}.get(item.get('align','left'),0.)
        path.addText(QPointF(x,metrics.ascent()+i*line_height),font,line)
    margin=max(4.,float(item.get('stroke_width',0))/2+2)
    # Include italic overhangs, descenders and outline in hit/handle bounds.
    rect=QRectF(0,0,width,height).united(path.boundingRect()).adjusted(-margin,-margin,margin,margin)
    return path,rect


def text_transform(item):
    return QTransform().translate(float(item.get('x',0)),float(item.get('y',0))).rotate(float(item.get('rotation',0))).scale(float(item.get('width_scale',1)),1.)


def draw_text(painter,item):
    path,rect=text_geometry(item)
    painter.save();painter.setTransform(text_transform(item),True)
    painter.setRenderHint(painter.RenderHint.Antialiasing)
    if item.get('background_enabled',False):
        painter.fillRect(rect,QColor(item.get('background','#ffffff')))
    width=float(item.get('stroke_width',0))
    painter.setPen(QPen(QColor(item.get('stroke_color','#000000')),width,Qt.PenStyle.SolidLine,
                        Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin) if width>0 else Qt.PenStyle.NoPen)
    painter.setBrush(QColor(item.get('color','#202020')));painter.drawPath(path);painter.restore()
