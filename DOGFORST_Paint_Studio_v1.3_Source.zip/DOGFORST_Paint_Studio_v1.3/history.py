"""Lossless reverse patches. One open action may temporarily share full QImages.

Completed small pixel edits retain compressed 128px tiles; metadata-only edits retain
no pixels. Structural operations use a compressed full image where necessary.
"""
import copy
import json
import logging
import zlib
from dataclasses import dataclass

import numpy as np
from PySide6.QtCore import QRectF
from PySide6.QtGui import QImage

LOG = logging.getLogger('dogforst')


NAVIGATION={'active_layer','selected_text','selected_layers','selected_nodes','current_node','editing_mask','mask_color','before_mask_color'}
def document_metadata(value):return {k:v for k,v in value.items() if k not in NAVIGATION}

def metadata(snapshot):
    selection = snapshot['selection']
    return dict(doc_size=tuple(snapshot['doc_size']), active_layer=snapshot['active_layer'],
        layers=[(name, visible, opacity, identifier, kind)
                for name, image, visible, opacity, identifier, kind in snapshot['layers']],
        selection=(selection.x(), selection.y(), selection.width(), selection.height()) if selection else None,
        selection_mask=snapshot.get('selection_mask') is not None,
        text_objects=copy.deepcopy(snapshot['text_objects']), selected_text=snapshot['selected_text'],
        layer_flags=copy.deepcopy(snapshot.get('layer_flags',{})),
        raster_objects={i:copy.deepcopy({k:v for k,v in obj.items() if k!='source'}) for i,obj in snapshot.get('raster_objects',{}).items()},
        selected_layers=list(snapshot.get('selected_layers',[])),
        groups=copy.deepcopy(snapshot.get('groups',[])),layer_stack=list(snapshot.get('layer_stack',[])),
        selected_nodes=list(snapshot.get('selected_nodes',[])),current_node=snapshot.get('current_node'),
        mask_ids=list(snapshot.get('masks',{})),disabled_masks=list(snapshot.get('disabled_masks',[])),editing_mask=snapshot.get('editing_mask'),
        mask_color=snapshot.get('mask_color'),before_mask_color=snapshot.get('before_mask_color'))


def image_table(snapshot):
    images={layer[4]:layer[1] for layer in snapshot['layers']}
    images.update({'@mask/'+identifier:image for identifier,image in snapshot.get('masks',{}).items()})
    images.update({'@source/'+identifier:obj['source'] for identifier,obj in snapshot.get('raster_objects',{}).items()})
    if snapshot.get('selection_mask') is not None:images['@selection']=snapshot['selection_mask']
    return images


def pixels(image, writable=False):
    data = image.bits() if writable else image.constBits()
    if data is None:
        raise MemoryError('Недостаточно памяти для восстановления истории.')
    return np.frombuffer(data, dtype=np.uint32).reshape(image.height(), image.bytesPerLine() // 4)[:, :image.width()]


@dataclass(frozen=True)
class FullImage:
    size: tuple
    stride: int
    format: object
    dpr: float
    dpi: tuple
    colors: tuple
    color_space: object
    data: bytes

    @classmethod
    def encode(cls, image):
        return cls((image.width(), image.height()), image.bytesPerLine(), image.format(),
            image.devicePixelRatio(), (image.dotsPerMeterX(), image.dotsPerMeterY()),
            tuple(image.colorTable()), image.colorSpace(), zlib.compress(bytes(image.constBits()), 1))

    def decode(self):
        raw = zlib.decompress(self.data)
        image = QImage(raw, *self.size, self.stride, self.format).copy()
        if image.isNull():
            raise MemoryError('Недостаточно памяти для восстановления слоя.')
        image.setDevicePixelRatio(self.dpr)
        image.setDotsPerMeterX(self.dpi[0]); image.setDotsPerMeterY(self.dpi[1])
        if self.colors:
            image.setColorTable(list(self.colors))
        if self.color_space.isValid():
            image.setColorSpace(self.color_space)
        return image


@dataclass(frozen=True)
class Tile:
    x: int
    y: int
    width: int
    height: int
    data: bytes

    @classmethod
    def encode(cls, array, x, y, width, height):
        return cls(x, y, width, height, zlib.compress(array[y:y+height, x:x+width].tobytes(), 1))


def reverse_patch(before, after, tile_size=128):
    if before.cacheKey()==after.cacheKey():return None
    if (before.size() != after.size() or before.format() != after.format() or
        before.depth() != 32 or after.depth() != 32):
        return None if before==after else FullImage.encode(before)
    if before.cacheKey() == after.cacheKey():
        return None
    a, b = pixels(before), pixels(after)
    width, height = before.width(), before.height()
    areas = []
    # Bounded comparison blocks avoid an image-sized RGBA boolean temporary.
    for y in range(0, height, tile_size):
        h = min(tile_size, height-y)
        changed = a[y:y+h] != b[y:y+h]
        columns = np.flatnonzero(changed.any(axis=0))
        if not len(columns):
            continue
        left = int(columns[0]) // tile_size * tile_size
        right = int(columns[-1]) // tile_size * tile_size
        for x in range(left, right+1, tile_size):
            w = min(tile_size, width-x)
            if changed[:, x:x+w].any():
                areas.append((x, y, w, h))
    if not areas:
        return None
    if sum(w*h*4 for x, y, w, h in areas) >= before.sizeInBytes() * .7:
        return FullImage.encode(before)
    return tuple(Tile.encode(a, *area) for area in areas)


class RestorePoint:
    def __init__(self, target, changes):
        self.target = target
        self.changes = changes
        self.payload_bytes = sum(len(p.data) if isinstance(p, FullImage) else
                                 sum(len(tile.data) for tile in p) for p in changes.values())
        self.estimated_bytes = self.payload_bytes + len(json.dumps(target, ensure_ascii=False,
            default=str).encode('utf-8')) + 256 + sum(128 if isinstance(p, FullImage) else
            len(p)*96 for p in changes.values())

    @classmethod
    def between(cls, before, after):
        old, new = metadata(before), metadata(after)
        after_images = image_table(after)
        changes = {}
        for identifier,image in image_table(before).items():
            patch = (reverse_patch(image, after_images[identifier]) if identifier in after_images
                     else FullImage.encode(image))
            if patch is not None:
                changes[identifier] = patch
        if document_metadata(old)==document_metadata(new) and not changes:
            return None
        return cls(old, changes)

    def apply(self, current):
        existing = image_table(current)
        inverse = {}
        target_ids = {layer[3] for layer in self.target['layers']}|{'@mask/'+identifier for identifier in self.target.get('mask_ids',[])}|{'@source/'+identifier for identifier in self.target.get('raster_objects',{})}
        if self.target.get('selection_mask'):target_ids.add('@selection')
        def restore_image(identifier):
            patch = self.changes.get(identifier)
            image = existing.get(identifier)
            if isinstance(patch, FullImage):
                if image is not None:
                    inverse[identifier] = FullImage.encode(image)
                restored = patch.decode()
            elif patch:
                if image is None:
                    raise RuntimeError('Нет слоя для восстановления участков истории.')
                old = pixels(image)
                inverse[identifier] = tuple(Tile.encode(old, t.x, t.y, t.width, t.height) for t in patch)
                restored = QImage(image)
                output = pixels(restored, writable=True)
                for tile in patch:
                    block = np.frombuffer(zlib.decompress(tile.data), dtype=np.uint32).reshape(tile.height, tile.width)
                    output[tile.y:tile.y+tile.height, tile.x:tile.x+tile.width] = block
                del output
            else:
                if image is None:
                    raise RuntimeError('В истории отсутствуют данные слоя.')
                restored = QImage(image)
            return restored
        result_layers=[(name,restore_image(identifier),visible,opacity,identifier,kind)
                       for name,visible,opacity,identifier,kind in self.target['layers']]
        masks={identifier:restore_image('@mask/'+identifier) for identifier in self.target.get('mask_ids',[])}
        for identifier, image in existing.items():
            if identifier not in target_ids:
                inverse[identifier] = FullImage.encode(image)
        target = self.target
        result = dict(doc_size=target['doc_size'], active_layer=target['active_layer'],
            raster_objects={i:dict(obj,source=restore_image('@source/'+i)) for i,obj in self.target.get('raster_objects',{}).items()},
            selection_mask=restore_image('@selection') if self.target.get('selection_mask') else None,
            layers=result_layers, selection=QRectF(*target['selection']) if target['selection'] else None,
            text_objects=copy.deepcopy(target['text_objects']), selected_text=target['selected_text'],
            layer_flags=copy.deepcopy(target.get('layer_flags',{})),
            selected_layers=list(target.get('selected_layers',[])),
            groups=copy.deepcopy(target.get('groups',[])),layer_stack=list(target.get('layer_stack',[])),
            selected_nodes=list(target.get('selected_nodes',[])),current_node=target.get('current_node'),
            masks=masks,disabled_masks=list(target.get('disabled_masks',[])),editing_mask=target.get('editing_mask'),
            mask_color=target.get('mask_color'),before_mask_color=target.get('before_mask_color'))
        return result, RestorePoint(metadata(current), inverse)


class SnapshotPoint:
    """Allocation-pressure fallback: keep the already captured pre-action QImages."""
    def __init__(self, snapshot):
        self.snapshot = snapshot
        self.payload_bytes = sum(image.sizeInBytes() for image in image_table(snapshot).values())
        self.estimated_bytes = self.payload_bytes + 1024

    def apply(self, current):
        return self.snapshot, SnapshotPoint(current)


class StackView:
    def __init__(self, engine, future=False):
        self.engine, self.future = engine, future

    def __len__(self):
        if self.future and self.engine.pending is not None and self.engine.redos:
            provider=getattr(self.engine,'current_state',None)
            if provider is not None:
                before=self.engine.pending;current=provider()
                if document_metadata(metadata(before))!=document_metadata(metadata(current)):return 0
                a,b=image_table(before),image_table(current)
                if a.keys()!=b.keys() or any(a[i].cacheKey()!=b[i].cacheKey() for i in a):return 0
        return len(self.engine.redos) if self.future else len(self.engine.undos)+(self.engine.pending is not None)

    def __bool__(self):
        return len(self) > 0

    def clear(self):
        if self.future:
            self.engine.redos.clear()
        else:
            self.engine.undos.clear()
            self.engine.pending = None


class HistoryEngine:
    def __init__(self, max_steps=35, budget=256*1024*1024):
        self.max_steps, self.budget = max_steps, budget
        self.undos, self.redos, self.pending = [], [], None
        self.undo_view, self.redo_view = StackView(self), StackView(self, True)

    def begin(self, before):
        self.commit(before)
        self.pending = before

    def commit(self, after):
        if self.pending is None:
            return
        try:
            point = RestorePoint.between(self.pending, after)
        except MemoryError:
            LOG.warning('History compaction could not allocate memory; keeping captured snapshot')
            point = SnapshotPoint(self.pending)
        self.pending = None
        if point:
            self.redos.clear()
            self.undos.append(point)
        self.trim()

    def trim(self):
        # Keep at least the most recent available action, even when it alone exceeds budget.
        while len(self.undos)+len(self.redos) > 1 and (
            len(self.undos)+len(self.redos) > self.max_steps or
            sum(p.estimated_bytes for p in self.undos+self.redos) > self.budget):
            (self.undos if self.undos else self.redos).pop(0)

    def undo(self, current):
        self.commit(current)
        if not self.undos:
            return None
        # Leave the old entry intact until the inverse and restored state both exist.
        result, inverse = self.undos[-1].apply(current)
        self.undos.pop(); self.redos.append(inverse); self.trim()
        return result

    def redo(self, current):
        self.commit(current)
        if not self.redos:
            return None
        result, inverse = self.redos[-1].apply(current)
        self.redos.pop(); self.undos.append(inverse); self.trim()
        return result

    def statistics(self):
        points = self.undos+self.redos
        return dict(undo=len(self.undo_view), redo=len(self.redo_view),
            payload_bytes=sum(p.payload_bytes for p in points),
            estimated_bytes=sum(p.estimated_bytes for p in points), budget_bytes=self.budget,
            pending=self.pending is not None,
            pending_image_bytes=sum(image.sizeInBytes() for image in image_table(self.pending).values()) if self.pending else 0)
