"""Modeless numeric transform controls. Enter commits field text before applying."""
from PySide6.QtCore import Qt,QSignalBlocker
from PySide6.QtWidgets import QWidget,QDockWidget,QVBoxLayout,QFormLayout,QLabel,QDoubleSpinBox,QCheckBox,QComboBox,QPushButton,QHBoxLayout,QApplication

class TransformDock(QDockWidget):
    def __init__(self,owner):super().__init__('Трансформация области',owner);self.owner=owner
    def closeEvent(self,event):self.owner.canvas.cancel_selection_transform();super().closeEvent(event)

class TransformPanel(QWidget):
    def __init__(self,owner):
        super().__init__();self.owner=owner;root=QVBoxLayout(self);root.addWidget(QLabel('Изменяется выбранная часть одного слоя.'))
        self.target=QLabel();self.target.setWordWrap(True);root.addWidget(self.target);form=QFormLayout();root.addLayout(form);self.fields={}
        for key,label,lo,hi in [('x','X рамки',-100000,100000),('y','Y рамки',-100000,100000),('width','Ширина',1,24000),('height','Высота',1,24000),('rotation','Угол',-36000,36000)]:
            spin=QDoubleSpinBox();spin.setDecimals(1);spin.setRange(lo,hi);spin.setSuffix('°' if key=='rotation' else ' px');spin.setKeyboardTracking(False)
            spin.valueChanged.connect(lambda value,k=key:self.change_number(k,value));form.addRow(label,spin);self.fields[key]=spin
        self.aspect=QCheckBox('Сохранять пропорции углов');self.aspect.toggled.connect(self.set_aspect);root.addWidget(self.aspect)
        self.flip_h=QCheckBox('Отразить по горизонтали');self.flip_v=QCheckBox('Отразить по вертикали')
        self.flip_h.toggled.connect(lambda v:self.owner.canvas.update_selection_transform(flip_h=v));self.flip_v.toggled.connect(lambda v:self.owner.canvas.update_selection_transform(flip_v=v));root.addWidget(self.flip_h);root.addWidget(self.flip_v)
        self.quality=QComboBox();self.quality.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon);self.quality.setMinimumContentsLength(8);self.quality.addItems(['Плавно — фото и рисунки','Чётко — пиксельная графика']);self.quality.currentIndexChanged.connect(lambda index:self.owner.canvas.update_selection_transform(smooth=index==0));form.addRow('Интерполяция',self.quality)
        self.status=QLabel();self.status.setWordWrap(True);root.addWidget(self.status)
        self.actions=QWidget();row=QHBoxLayout(self.actions);row.setContentsMargins(0,0,0,0);self.apply=QPushButton('Применить');self.cancel=QPushButton('Отменить');self.apply.setToolTip("Применить трансформацию · Enter");self.cancel.setToolTip("Отменить предпросмотр · Esc");self.apply.clicked.connect(self.apply_values);self.cancel.clicked.connect(owner.canvas.cancel_selection_transform);row.addWidget(self.apply);row.addWidget(self.cancel);root.addWidget(self.actions)
        note=QLabel('Углы — размер, боковые квадраты — одна ось. Круг — поворот. Внутри рамки — перенос.\n\nShift переключает пропорции углов, даёт шаг поворота 15° или ровный перенос. Колесо с Ctrl — масштаб, средняя кнопка/Space — рука.\n\nПиксельная правка текста и фото растрирует выбранный слой после применения. До применения исходник не меняется.');note.setWordWrap(True);root.addWidget(note);root.addStretch()
    def change_number(self,key,value):
        s=self.owner.canvas.selection_transform
        if s is None:return
        values={key:value}
        if s.keep_aspect and key in ('width','height'):
            old=s.parameters;scale=value/old[key];scale=max(max(1/old['width'],1/old['height']),min(scale,24000/old['width'],24000/old['height']))
            values.update(width=old['width']*scale,height=old['height']*scale)
        self.owner.canvas.update_selection_transform(**values)
    def set_aspect(self,value):
        s=self.owner.canvas.selection_transform
        if s is not None:s.keep_aspect=value
    def apply_values(self):
        for spin in self.fields.values():spin.interpretText()
        self.owner.run_canvas_action(self.owner.canvas.apply_selection_transform)
    def refresh(self):
        s=self.owner.canvas.selection_transform
        if s is None:return
        node=self.owner.canvas.node(s.node_id);self.target.setText(('Маска: ' if s.mask_id else 'Слой: ')+(node.name if node else '—'))
        focus=QApplication.focusWidget()
        for key,spin in self.fields.items():
            if spin.hasFocus() or (focus is not None and spin.isAncestorOf(focus)):continue
            with QSignalBlocker(spin):spin.setValue(s.parameters[key])
        for widget,value in [(self.aspect,s.keep_aspect),(self.flip_h,s.parameters['flip_h']),(self.flip_v,s.parameters['flip_v'])]:
            with QSignalBlocker(widget):widget.setChecked(value)
        with QSignalBlocker(self.quality):self.quality.setCurrentIndex(0 if s.parameters['smooth'] else 1)
        busy=s.rendered_version!=s.version
        self.status.setText(s.error or 'Пересчёт предпросмотра… Отмена доступна.' if busy else 'Предпросмотр готов. Исходные пиксели ещё не изменены.')
        self.apply.setEnabled(not busy and not s.error)
