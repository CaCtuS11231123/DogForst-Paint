"""Non-destructive glow controls with bounded, debounced layer preview."""
from PySide6.QtCore import Qt,QTimer,QSize,QRectF
from PySide6.QtGui import QPainter,QColor,QImage
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QFormLayout,QLabel,QCheckBox,QSpinBox,QSlider,QDialogButtonBox,QWidget,QPushButton,QComboBox,QLineEdit
from dialogs import ColorButton
from effects import DEFAULT_GLOW,apply_glow

class GlowPreview(QWidget):
    def __init__(self,dialog,source,size):
        super().__init__();self.dialog=dialog;self.setMinimumSize(380,320);self.zoom=100;self.background='light'
        from raster_objects import alpha_bounds
        bounds=alpha_bounds(source)
        if bounds is not None:
            region=bounds.adjusted(-90,-90,90,90).toAlignedRect().intersected(source.rect());self.layer_source=QImage(source) if region==source.rect() else source.copy(region);self.layer_factor=min(1.,480/max(1,region.width()),360/max(1,region.height()))
        else:self.layer_source=QImage();self.layer_factor=1.
        self.source=QImage();self.result=QImage();self.factor=1.
        self.timer=QTimer(self);self.timer.setSingleShot(True);self.timer.setInterval(50);self.timer.timeout.connect(self.refresh)
    def schedule(self,*_):self.timer.start()
    def refresh(self):
        sample=self.dialog.sample_mode.currentIndex()==1 or self.layer_source.isNull()
        self.dialog.sample_text.setEnabled(sample)
        if sample:
            from layers import transparent_image
            from text_model import draw_text
            image=transparent_image(520,260);p=QPainter(image);draw_text(p,dict(text=self.dialog.sample_text.text() or 'Привет',x=65,y=75,size=64,font='Sans',bold=True,color='#f1f5ff' if self.background=='dark' else '#202a3b'));p.end();self.source=image;self.factor=1.
        else:
            self.source=self.layer_source.scaled(480,360,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation);self.factor=self.source.width()/self.layer_source.width()
        value=self.dialog.values();value['radius']=max(.5,value['radius']*self.factor);value['spread']=max(0,value['spread']*self.factor)
        self.result=apply_glow(self.source,value);self.update()
    def paintEvent(self,event):
        from preview_support import paint_checker
        p=QPainter(self);paint_checker(p,self.rect(),self.background)
        if not self.result.isNull():
            factor=min((self.width()-20)/self.result.width(),(self.height()-20)/self.result.height())*self.zoom/100
            w,h=self.result.width()*factor,self.result.height()*factor;p.drawImage(QRectF((self.width()-w)/2,(self.height()-h)/2,w,h),self.result)
        p.end()

class GlowDialog(QDialog):
    def __init__(self,layer,source,size,parent=None):
        super().__init__(parent);self.setWindowTitle('Внешнее свечение · '+layer.name);self.resize(900,640)
        root=QVBoxLayout(self);root.addWidget(QLabel('Свечение по прозрачности слоя — для текста, штрихов, фигур и фотографий.'))
        row=QHBoxLayout();root.addLayout(row,1);form=QFormLayout();row.addLayout(form)
        value=dict(DEFAULT_GLOW,**(layer.glow or {}))
        self.enabled=QCheckBox('Включить свечение');self.enabled.setChecked(value['enabled']);form.addRow(self.enabled)
        self.color=ColorButton(value['color'],'Цвет света');form.addRow(self.color)
        self.radius=self.control(form,'Радиус',1,64,value['radius'],' px')
        self.spread=self.control(form,'Расширение',0,16,value['spread'],' px')
        self.strength=self.control(form,'Сила',0,300,value['strength'],' %')
        self.remove=QPushButton('Удалить эффект');self.remove.clicked.connect(self.remove_effect);self.remove.setEnabled(layer.glow is not None);form.addRow(self.remove)
        note=QLabel('У фотографии без прозрачности свет появится вокруг её прямоугольных краёв.\n\nПоказывается выбранный слой крупным планом или образец текста. Фон и масштаб примера не меняют рисунок.');note.setWordWrap(True);form.addRow(note)
        self.sample_mode=QComboBox();self.sample_mode.addItems(['Выбранный слой','Образец текста']);form.addRow('Показать',self.sample_mode)
        self.sample_text=QLineEdit('Привет');self.sample_text.setMaxLength(60);form.addRow('Текст примера',self.sample_text)
        self.preview_background=QComboBox();self.preview_background.addItems(['Светлая шахматка','Тёмная шахматка']);form.addRow('Фон примера',self.preview_background)
        self.preview_zoom=QSlider(Qt.Orientation.Horizontal);self.preview_zoom.setRange(25,300);self.preview_zoom.setValue(100);form.addRow('Масштаб примера',self.preview_zoom)
        self.preview=GlowPreview(self,source,size);row.addWidget(self.preview,1)
        if self.preview.layer_source.isNull():self.sample_mode.setCurrentIndex(1)
        self.sample_mode.currentIndexChanged.connect(self.preview.schedule);self.sample_text.textChanged.connect(self.preview.schedule)
        self.preview_background.currentIndexChanged.connect(lambda i:(setattr(self.preview,'background','dark' if i else 'light'),self.preview.schedule()));self.preview_zoom.valueChanged.connect(lambda v:(setattr(self.preview,'zoom',v),self.preview.update()))
        self.deleted=False
        for control in (self.radius,self.spread,self.strength):control.valueChanged.connect(self.preview.schedule)
        self.color.colorChanged.connect(self.preview.schedule);self.enabled.toggled.connect(self.sync);self.enabled.toggled.connect(self.preview.schedule)
        self.sync();self.preview.refresh()
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText('Применить');buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена')
        buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);root.addWidget(buttons)
    def control(self,form,label,lo,hi,value,suffix):
        row=QHBoxLayout();slider=QSlider(Qt.Orientation.Horizontal);slider.setRange(lo,hi)
        spin=QSpinBox();spin.setRange(lo,hi);spin.setSuffix(suffix);spin.setValue(round(value));slider.setValue(spin.value())
        slider.valueChanged.connect(spin.setValue);spin.valueChanged.connect(slider.setValue);spin.slider=slider
        row.addWidget(slider);row.addWidget(spin);form.addRow(label,row);return spin
    def sync(self,*_):
        enabled=self.enabled.isChecked();self.color.setEnabled(enabled)
        for control in (self.radius,self.spread,self.strength):control.setEnabled(enabled);control.slider.setEnabled(enabled)
    def values(self):return dict(enabled=self.enabled.isChecked(),color=self.color.color.name(),radius=self.radius.value(),spread=self.spread.value(),strength=self.strength.value())
    def remove_effect(self):self.deleted=True;self.accept()
