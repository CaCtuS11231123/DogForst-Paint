"""Project release numbering: 1.00 -> 1.1; fixes: 1.00.1."""
import re
from dataclasses import dataclass
@dataclass(frozen=True)
class Version:
    major:int
    minor:int
    patch:int=0
    @classmethod
    def parse(cls,value):
        if not isinstance(value,str) or not re.fullmatch(r'\d{1,3}\.\d{1,3}(?:\.\d{1,3})?',value):raise ValueError('Версия должна иметь вид 1.00 или 1.00.1.')
        parts=list(map(int,value.split('.')));return cls(parts[0],parts[1],parts[2] if len(parts)>2 else 0)
    def display(self):return f'{self.major}.{self.minor if self.minor else "00"}'+(f'.{self.patch}' if self.patch else '')
    def next_update(self):return Version(self.major,self.minor+1)
    def next_fix(self):return Version(self.major,self.minor,self.patch+1)
