"""Stable project IDs, native raster modes and Russian explanations."""
from PySide6.QtGui import QPainter

MODES = {
    'normal': ('Обычный · Normal', 'Обычное наложение с учётом прозрачности.', 'SourceOver'),
    'multiply': ('Умножение · Multiply', 'Тени и затемнение; белый не меняет нижние цвета.', 'Multiply'),
    'screen': ('Экран · Screen', 'Свет и блики; чёрный не меняет нижние цвета.', 'Screen'),
    'overlay': ('Перекрытие · Overlay', 'Усиление контраста с опорой на нижние цвета.', 'Overlay'),
    'soft_light': ('Мягкий свет · Soft Light', 'Мягкое тонирование и изменение контраста.', 'SoftLight'),
    'hard_light': ('Жёсткий свет · Hard Light', 'Контрастный свет с опорой на цвета верхнего слоя.', 'HardLight'),
    'add': ('Добавление · Add', 'Суммирует цвет и альфу: яркое свечение с ограничением до максимума.', 'Plus'),
    'darken': ('Темнее · Darken', 'Выбирает более тёмные компоненты цветов.', 'Darken'),
    'lighten': ('Светлее · Lighten', 'Выбирает более светлые компоненты цветов.', 'Lighten'),
    'difference': ('Разница · Difference', 'Разность цветов для эффектов и сравнения.', 'Difference'),
    'exclusion': ('Исключение · Exclusion', 'Мягче, чем разница; подходит для цветовых экспериментов.', 'Exclusion'),
}


def validate_mode(value):
    if not isinstance(value,str) or value not in MODES:
        raise ValueError('Неизвестный режим наложения. Файл не открыт во избежание неверного изображения.')
    return value


def composition_mode(value):
    return getattr(QPainter.CompositionMode,'CompositionMode_'+MODES[validate_mode(value)][2])


def requires_composite(layers,groups,texts):
    from effects import active_glow
    if any(active_glow(layer) or getattr(layer,'clipped',False) for layer in layers):return True
    owners={t.get('layer_id') for t in texts}
    return any(n.blend_mode!='normal' for n in [*layers,*groups.values()]) or any(
        layer.opacity!=1 and layer.id in owners for layer in layers)
