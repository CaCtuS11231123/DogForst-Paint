"""Small atomic filesystem operations. No editor objects or UI in this module."""
import hashlib
import os
import re
import shutil
import tempfile
import time
import uuid
from pathlib import Path


class OperationCancelled(Exception):
    pass


class ProjectConflictError(OSError):
    pass


def project_fingerprint(target):
    """Filesystem generation identity, not a hash of document contents."""
    try:
        stat = Path(target).stat()
        return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns
    except FileNotFoundError:
        return None


def check_cancelled(event):
    if event is not None and event.is_set():
        raise OperationCancelled('Операция отменена.')


def atomic_copy(source, target):
    source, target = Path(source), Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.dogforst-copy-', dir=target.parent)
    try:
        with os.fdopen(fd, 'wb') as output, source.open('rb') as input_file:
            shutil.copyfileobj(input_file, output, 1024 * 1024)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return target


def atomic_bytes(target, data):
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.dogforst-meta-', dir=target.parent)
    try:
        with os.fdopen(fd, 'wb') as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)


def backup_directory(target):
    target = Path(target).absolute()
    # The parent already separates projects. A filename key survives moving the whole folder.
    key = hashlib.sha256(os.path.normcase(target.name).encode('utf-8')).hexdigest()[:12]
    return target.parent / 'DOGFORST_Backups' / (target.stem[:40] + '-' + key)


def create_backup(target):
    target = Path(target)
    if not target.exists():
        return None
    name = f'rev-{time.time_ns():020d}-{uuid.uuid4().hex}.mpaint'
    return atomic_copy(target, backup_directory(target) / name)


def list_versions(target):
    folder = backup_directory(target)
    if not folder.exists():
        return []
    return sorted((p for p in folder.iterdir() if p.is_file() and
                   re.fullmatch(r'rev-\d{20}-[a-f0-9]{32}\.mpaint', p.name)),
                  key=lambda p: p.name, reverse=True)


def prune_versions(target, limit=10):
    # Called only after the new main project was successfully committed.
    for path in list_versions(target)[max(1, int(limit)):]:
        path.unlink(missing_ok=True)
