"""Version 1–11 .mpaint IO. Validate completely before replacing the document."""
import json
import hashlib
from integrity import strict_json,archive_preflight,checksum_table,check_payload
import math
import logging
import struct
import os
import tempfile
import zipfile
from pathlib import Path
from PySide6.QtCore import QByteArray, QBuffer, QIODevice, QLockFile
from PySide6.QtGui import QImage
from layers import Layer, transparent_image
from storage import check_cancelled, create_backup, prune_versions, project_fingerprint, ProjectConflictError

_UNSET = object()

PROJECT_VERSION = 4


class LoadedProject(tuple):
    def __new__(cls,size,layers,active,texts,groups,stack,masks=None,disabled_masks=(),raster_objects=None):
        obj=super().__new__(cls,(size,layers,active,texts))
        obj.raster_objects=raster_objects or {};obj.groups=groups;obj.layer_stack=stack;obj.masks=masks or {};obj.disabled_masks=set(disabled_masks)
        return obj
MAX_PIXELS = 60_000_000
MAX_TOTAL_PIXELS = 120_000_000


def checked_resource(archive,table,name):
    data=archive.read(name);check_payload(table,name,data);return data

def png_bytes(image):
    data = QByteArray()
    buffer = QBuffer(data)
    if not buffer.open(QIODevice.OpenModeFlag.WriteOnly):
        raise ValueError("Не удалось открыть буфер слоя.")
    try:
        if not image.save(buffer, "PNG"):
            raise ValueError("Не удалось записать слой PNG.")
    finally:
        buffer.close()
    return bytes(data)


def save_project(filename, size, layers, active_layer, text_objects, *, backup=True, backup_limit=10, cancelled=None, progress=None, expected_fingerprint=_UNSET, return_token=False, groups=None, layer_stack=None,masks=None,disabled_masks=(),raster_objects=None):
    from groups import read_groups
    from raster_objects import validate_object,object_metadata
    raster_objects=raster_objects or {}
    from masks import validate_mask
    masks=masks or {};disabled_masks=set(disabled_masks)
    groups=groups or []
    layer_stack=list(layer_stack) if layer_stack is not None else [l.id for l in layers]
    read_groups(groups,layer_stack,{l.id for l in layers})
    from blending import validate_mode
    modes=[validate_mode(layer.blend_mode) for layer in layers]+[validate_mode(group.get('blend_mode','normal')) for group in groups]
    from effects import validate_glow
    for layer in layers:
        validate_glow(layer.glow)
        if not isinstance(layer.clipped,bool):raise ValueError("Некорректная обтравка слоя.")
    version=11 if any("shape" in o for o in raster_objects.values()) else 10 if any(layer.clipped for layer in layers) else 9 if any(layer.glow is not None for layer in layers) else 8 if raster_objects else 7 if masks else 6 if any(mode!='normal' for mode in modes) else 5 if groups else PROJECT_VERSION
    known={l.id for l in layers}|{group['id'] for group in groups}
    if not isinstance(masks,dict) or set(masks)-known or disabled_masks-set(masks):raise ValueError('Некорректные ссылки масок.')
    for image in masks.values():validate_mask(image,size)
    if not isinstance(raster_objects,dict) or set(raster_objects)-{l.id for l in layers}:raise ValueError("Некорректные ссылки исходников.")
    for obj in raster_objects.values():validate_object(obj)
    if len(layers)+len(masks)+len(raster_objects)+1>4096:raise ValueError('В проекте слишком много ресурсов для безопасного сохранения.')
    source_pixels=sum(o["source"].width()*o["source"].height() for o in raster_objects.values())
    check_cancelled(cancelled)
    if not layers or (len(layers)+len(masks))*size[0]*size[1]+source_pixels > MAX_TOTAL_PIXELS:
        raise ValueError('Превышен предел памяти слоёв или в документе нет слоёв.')
    if len({l.id for l in layers}) != len(layers):
        raise ValueError('Повторяющиеся идентификаторы слоёв.')
    if any((l.image.width(), l.image.height()) != tuple(size) or l.image.isNull() for l in layers):
        raise ValueError('Размер слоя не совпадает с холстом.')
    target = Path(filename)
    if target.suffix.lower() != ".mpaint":
        target = target.with_suffix(".mpaint")
    target.parent.mkdir(parents=True, exist_ok=True)
    expected = project_fingerprint(target) if expected_fingerprint is _UNSET else expected_fingerprint
    manifest = dict(version=version, width=size[0], height=size[1],
                    active_layer=active_layer, text_objects=text_objects, layers=[],checksums={})
    if version>=5:manifest.update(groups=groups,layer_stack=layer_stack)
    fd, temporary = tempfile.mkstemp(prefix=".dogforst-", suffix=".tmp", dir=target.parent)
    try:
        with os.fdopen(fd, "w+b") as stream:
            with zipfile.ZipFile(stream, "w", zipfile.ZIP_STORED) as archive:
                for i, layer in enumerate(layers):
                    check_cancelled(cancelled)
                    name = f"layers/layer_{i}.png"
                    payload=png_bytes(layer.image);archive.writestr(name,payload);manifest['checksums'][name]=hashlib.sha256(payload).hexdigest()
                    manifest['layers'].append(dict(name=layer.name, visible=layer.visible,
                                                   opacity=layer.opacity, path=name, id=layer.id, kind=layer.kind, **layer.flags()))
                    if progress:
                        progress(round((i+1)*90/len(layers)), f'Слой {i+1} из {len(layers)}')
                if masks:
                    manifest['masks']=[]
                    for index,(identifier,image) in enumerate(masks.items()):
                        check_cancelled(cancelled);resource=f'masks/mask_{index}.png'
                        payload=png_bytes(image);archive.writestr(resource,payload);manifest['checksums'][resource]=hashlib.sha256(payload).hexdigest()
                        manifest['masks'].append(dict(node_id=identifier,path=resource,enabled=identifier not in disabled_masks))
                if raster_objects:
                    manifest['raster_objects']=[]
                    for index,(identifier,obj) in enumerate(raster_objects.items()):
                        check_cancelled(cancelled);resource=f'originals/source_{index}.png'
                        payload=png_bytes(obj['source']);archive.writestr(resource,payload);manifest['checksums'][resource]=hashlib.sha256(payload).hexdigest()
                        manifest['raster_objects'].append(dict(node_id=identifier,path=resource,**object_metadata(obj)))
                check_cancelled(cancelled)
                archive.writestr("project.json", json.dumps(manifest, ensure_ascii=False, allow_nan=False))
            stream.flush()
            os.fsync(stream.fileno())
        check_cancelled(cancelled)
        lock = QLockFile(str(target) + '.dogforst.lock')
        lock.setStaleLockTime(0)
        if not lock.tryLock(0):
            raise ProjectConflictError('Не удалось получить доступ для записи проекта. Проверьте права на папку и другие открытые окна.')
        try:
            if project_fingerprint(target) != expected:
                raise ProjectConflictError('Файл проекта изменён другой программой. Используйте «Сохранить как», чтобы сохранить свою копию.')
            if backup:
                create_backup(target)  # If backup fails, the old main project is untouched.
            check_cancelled(cancelled)
            os.replace(temporary, target)
            committed_token = project_fingerprint(target)
        finally:
            lock.unlock()
        if progress:
            progress(100, 'Запись завершена')
        if backup:
            try:
                prune_versions(target, backup_limit)
            except OSError:
                logging.getLogger('dogforst').exception('Could not prune old project backups')
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return (str(target), committed_token) if return_token else str(target)


def read_project(filename):
    try:
        with zipfile.ZipFile(filename) as archive:
            if "project.json" not in archive.namelist():
                raise ValueError("В архиве отсутствует project.json. Слои из такого файла восстановить нельзя.")
            archive_preflight(archive)
            if archive.getinfo('project.json').file_size > 4_000_000:
                raise ValueError("Слишком большое описание проекта.")
            names=archive.namelist()
            if len(names)!=len(set(names)):
                raise ValueError('В архиве повторяются имена файлов.')
            manifest = strict_json(archive.read('project.json'))
            if not isinstance(manifest, dict):
                raise ValueError('Некорректное описание проекта.')
            if manifest.get('version') not in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11):
                raise ValueError("Версия проекта не поддерживается (поддерживаются 1–11).")
            table=checksum_table(manifest)
            if type(manifest.get('version')) is not int or type(manifest.get('width')) is not int or type(manifest.get('height')) is not int:raise ValueError('Некорректные размеры/версия проекта.')
            w, h = manifest['width'],manifest['height']
            items = manifest['layers']
            if not (1 <= w <= 12000 and 1 <= h <= 12000) or w*h > MAX_PIXELS:
                raise ValueError("Недопустимый размер холста (максимум 60 млн пикселей).")
            if not isinstance(items, list) or not items or len(items)*w*h > MAX_TOTAL_PIXELS:
                raise ValueError("Нет слоёв или превышен предел памяти слоёв (120 млн пикселей).")
            layers = []
            for item in items:
                if not isinstance(item, dict):
                    raise ValueError('Некорректное описание слоя.')
                resource=item.get('path')
                if not isinstance(resource,str) or resource.startswith(('/', '\\')) or '..' in resource.replace('\\','/').split('/'):
                    raise ValueError('Некорректный путь изображения слоя.')
                info = archive.getinfo(item['path'])
                if info.file_size > w*h*4 + 1_000_000:
                    raise ValueError("Размер данных слоя превышает ожидаемый.")
                data=archive.read(info);check_payload(table,resource,data)
                if len(data)<24 or data[:8]!=b'\x89PNG\r\n\x1a\n' or data[12:16]!=b'IHDR' or struct.unpack('>II',data[16:24])!=(w,h):
                    raise ValueError('Размер PNG слоя не совпадает с холстом.')
                image = QImage.fromData(data, 'PNG')
                if image.isNull() or (image.width(), image.height()) != (w,h):
                    raise ValueError("Повреждены данные слоя.")
                opacity = float(item.get('opacity', 1.0))
                if not math.isfinite(opacity):
                    raise ValueError("Некорректная непрозрачность слоя.")
                layers.append(Layer(str(item['name']), image.convertToFormat(QImage.Format.Format_ARGB32),
                                    bool(item.get('visible', True)), max(0., min(1., opacity)), str(item.get('id') or '') or None, str(item.get('kind','raster'))))
                for flag in ('locked','position_locked','alpha_locked'):
                    value = item.get(flag,False)
                    if not isinstance(value,bool):
                        raise ValueError('Некорректная блокировка слоя.')
                    setattr(layers[-1],flag,value)
                from layer_actions import LABELS
                label = item.get('color_label','')
                if label not in LABELS:
                    raise ValueError('Некорректная метка слоя.')
                layers[-1].color_label = label
                from blending import validate_mode
                layers[-1].blend_mode=validate_mode(item.get('blend_mode','normal'))
                from effects import validate_glow
                layers[-1].glow=validate_glow(item.get('glow'))
                clipped=item.get('clipped',False)
                if not isinstance(clipped,bool) or (clipped and manifest['version']<10):raise ValueError('Некорректная обтравка или версия проекта.')
                layers[-1].clipped=clipped
                if layers[-1].glow is not None and manifest['version']<9:raise ValueError('Свечение требует формата v9.')
                if manifest['version']<6 and layers[-1].blend_mode!='normal':raise ValueError('Режим наложения требует формата v6.')
            texts = manifest.get('text_objects', [])
            if not isinstance(texts, list):
                raise ValueError("Повреждены текстовые объекты.")
            for text in texts:
                if not isinstance(text, dict) or not isinstance(text.get('text',''),str):
                    raise ValueError("Повреждён текстовый объект.")
                for key in ('x', 'y', 'rotation', 'size', 'stroke_width', 'width_scale', 'line_spacing', 'letter_spacing'):
                    if not math.isfinite(float(text.get(key, 0))):
                        raise ValueError("Некорректные параметры текста.")
                if not 1 <= int(text.get('size', 32)) <= 1600:
                    raise ValueError("Некорректный размер текста.")
            ids=[layer.id for layer in layers]
            if len(ids)!=len(set(ids)):
                raise ValueError('Повторяющиеся идентификаторы слоёв.')
            for text in texts:
                if not .2 <= float(text.get('width_scale',1)) <= 5 or not 0 <= float(text.get('stroke_width',0)) <= 60:
                    raise ValueError('Некорректная геометрия текста.')
                if not .5 <= float(text.get('line_spacing',1.15)) <= 3:
                    raise ValueError('Некорректный межстрочный интервал.')
            known={layer.id for layer in layers}
            for text in texts:
                if text.get('layer_id') not in known:
                    if manifest['version'] >= 4:
                        raise ValueError('Текст ссылается на отсутствующий слой.')
                    layer=Layer('Текст · '+str(text.get('text',''))[:22],transparent_image(w,h),kind='text')
                    if (len(layers)+1)*w*h > MAX_TOTAL_PIXELS:
                        raise ValueError('Недостаточно бюджета памяти для переноса старых текстовых слоёв.')
                    layers.append(layer);text['layer_id']=layer.id;known.add(layer.id)
                    text.setdefault('line_spacing',1.0)
            active = max(0, min(int(manifest.get('active_layer', 0)), len(layers)-1))
            from groups import read_groups
            if manifest['version']>=5:
                groups,stack=read_groups(manifest.get('groups'),manifest.get('layer_stack'),known)
                if manifest['version']<6 and any(g.blend_mode!='normal' for g in groups.values()):raise ValueError('Наложение группы требует формата v6.')
            else:
                groups,stack={},[l.id for l in layers]
            masks={};disabled=set();mask_items=manifest.get('masks',[])
            if not isinstance(mask_items,list) or (mask_items and manifest['version']<7):raise ValueError('Некорректная версия масок.')
            if (len(layers)+len(mask_items))*w*h>MAX_TOTAL_PIXELS:raise ValueError('Превышен бюджет слоёв и масок.')
            owners=known|set(groups)
            from masks import validate_mask
            for entry in mask_items:
                if not isinstance(entry,dict) or not isinstance(entry.get('node_id'),str):raise ValueError('Некорректная маска.')
                identifier=entry['node_id'];resource=entry.get('path')
                if identifier not in owners or identifier in masks or not isinstance(entry.get('enabled',True),bool):raise ValueError('Некорректный владелец или состояние маски.')
                if not isinstance(resource,str) or resource.startswith(('/', '\\')) or '..' in resource.replace('\\','/').split('/'):raise ValueError('Некорректный путь маски.')
                info=archive.getinfo(resource)
                if info.file_size>w*h*4+1_000_000:raise ValueError('Слишком большие данные маски.')
                data=archive.read(info);check_payload(table,resource,data)
                if len(data)<24 or data[:8]!=b'\x89PNG\r\n\x1a\n' or data[12:16]!=b'IHDR' or struct.unpack('>II',data[16:24])!=(w,h):raise ValueError('Некорректный размер PNG маски.')
                image=QImage.fromData(data,'PNG').convertToFormat(QImage.Format.Format_ARGB32)
                validate_mask(image,(w,h));masks[identifier]=image
                if not entry.get('enabled',True):disabled.add(identifier)
            raster_objects={};entries=manifest.get('raster_objects',[])
            if not isinstance(entries,list) or (entries and manifest['version']<8):raise ValueError('Некорректная версия исходников.')
            from raster_objects import validate_object,DEFAULTS
            total=(len(layers)+len(masks))*w*h
            resources=set()
            for entry in entries:
                if not isinstance(entry,dict) or entry.get('node_id') not in known or entry['node_id'] in raster_objects:raise ValueError('Некорректный владелец исходника.')
                identifier=entry['node_id'];resource=entry.get('path')
                if not isinstance(resource,str) or not resource.startswith('originals/') or '\\' in resource or '..' in resource.split('/') or resource in resources:raise ValueError('Некорректный путь исходника.')
                resources.add(resource);info=archive.getinfo(resource)
                if info.file_size>60_000_000*4+1_000_000:raise ValueError('Слишком большой исходник.')
                with archive.open(resource) as stream:header=stream.read(24)
                if len(header)<24 or header[:8]!=b'\x89PNG\r\n\x1a\n' or header[12:16]!=b'IHDR':raise ValueError('Исходник не является PNG.')
                sw,sh=struct.unpack('>II',header[16:24]);total+=sw*sh
                if not 1<=sw<=12000 or not 1<=sh<=12000 or sw*sh>MAX_PIXELS or total>MAX_TOTAL_PIXELS or info.file_size>sw*sh*4+1_000_000:raise ValueError('Превышен бюджет исходников.')
                image=QImage.fromData(checked_resource(archive,table,resource),'PNG').convertToFormat(QImage.Format.Format_ARGB32)
                obj={k:entry.get(k,v) for k,v in DEFAULTS.items()};obj['source']=image
                if 'shape' in entry:
                    if manifest['version']<11:raise ValueError('Редактируемая фигура требует формата v11.')
                    from shape_objects import validate_shape
                    obj['shape']=validate_shape(entry['shape'])
                validate_object(obj)
                if (image.width(),image.height())!=(sw,sh):raise ValueError('Повреждён размер исходника.')
                if any(t.get('layer_id')==identifier for t in texts):raise ValueError('Исходник не может заменять редактируемый текст.')
                raster_objects[identifier]=obj
            return LoadedProject((w,h),layers,active,[dict(t) for t in texts],groups,stack,masks,disabled,raster_objects)
    except (zipfile.BadZipFile, KeyError, TypeError, UnicodeDecodeError, json.JSONDecodeError, OverflowError, struct.error) as error:
        raise ValueError("Файл .mpaint повреждён или имеет неверную структуру.") from error
