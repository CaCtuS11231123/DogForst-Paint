"""Non-destructive opaque grayscale masks, indexed by persistent layer/group IDs."""
import numpy as np
from PySide6.QtCore import Qt,QPointF,QRectF
from PySide6.QtGui import QImage,QColor,QPainter,QPen
from layers import transparent_image


def mask_image(size,value=255):
    image=transparent_image(*size);image.fill(QColor(value,value,value));return image


def validate_mask(image,size):
    if image.isNull() or (image.width(),image.height())!=tuple(size):raise ValueError('Размер маски не совпадает с холстом.')
    rgba=image.convertToFormat(QImage.Format.Format_RGBA8888)
    data=np.frombuffer(rgba.constBits(),dtype=np.uint8).reshape(rgba.height(),rgba.bytesPerLine())[:,:rgba.width()*4].reshape(rgba.height(),rgba.width(),4)
    for y in range(0,rgba.height(),128):
        block=data[y:y+128]
        if not (np.all(block[:,:,3]==255) and np.array_equal(block[:,:,0],block[:,:,1]) and np.array_equal(block[:,:,0],block[:,:,2])):
            raise ValueError('Маска должна содержать непрозрачные оттенки серого.')


def apply_mask(image,mask,rect=None):
    """Return a masked copy; a tile rect selects the corresponding document mask."""
    result=QImage(image)
    alpha=mask.copy(rect).convertToFormat(QImage.Format.Format_RGBA8888) if rect is not None else mask.convertToFormat(QImage.Format.Format_RGBA8888)
    values=np.frombuffer(alpha.bits(),dtype=np.uint8).reshape(alpha.height(),alpha.bytesPerLine())[:,:alpha.width()*4].reshape(alpha.height(),alpha.width(),4)
    gray=values[:,:,0].copy();values[:,:,:3]=255;values[:,:,3]=gray
    del values
    painter=QPainter(result)
    try:
        painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationIn)
        painter.drawImage(0,0,alpha)
    finally:painter.end()
    return result


class MaskActionsMixin:
    def sync_masks(self):
        known={l.id for l in self.layers}|set(self.groups)
        self.masks={i:m for i,m in self.masks.items() if i in known}
        self.disabled_masks.intersection_update(self.masks)
        if self.editing_mask not in self.masks:self.stop_mask_edit()

    def clear_masks(self):
        self.stop_mask_edit();self.masks={};self.disabled_masks=set()

    def can_edit_mask(self,identifier=None):
        node=self.node(identifier or self.editing_mask or self.control_node().id)
        if node is None:return False
        if self.node_locked(node):self.status.emit('Слой или его группа защищены от правок.');return False
        return True

    def add_mask(self,value=255):
        identifier=self.control_node().id
        if identifier in self.masks:return
        if not self.can_edit_mask(identifier):return
        if (len(self.layers)+len(self.masks)+1)*self.doc_size[0]*self.doc_size[1]+self.source_pixels()>120_000_000:
            raise ValueError('Маска превысит бюджет слоёв и масок (120 млн пикселей).')
        image=mask_image(self.doc_size,value);self.push_history();self.masks[identifier]=image
        self.changed.emit();self.update()

    def start_mask_edit(self):
        identifier=self.control_node().id
        if identifier not in self.masks or not self.can_edit_mask(identifier):return
        self.stop_mask_edit();self._before_mask_color=QColor(self.color)
        self.editing_mask=identifier;self.selected_text=-1;self.textSelected.emit(-1)
        self.color=QColor('black');self.colorChanged.emit(self.color)
        self.changed.emit();self.status.emit('Маска: чёрный скрывает, белый возвращает. Рисунок не стирается.');self.update()

    def stop_mask_edit(self):
        self.editing_mask=None;self.show_mask=False
        if getattr(self,'_before_mask_color',None) is not None:
            self.color=QColor(self._before_mask_color);self._before_mask_color=None
            self.colorChanged.emit(self.color)

    def set_mask_enabled(self,enabled):
        identifier=self.control_node().id
        if identifier not in self.masks or (identifier not in self.disabled_masks)==bool(enabled):return
        self.push_history()
        if enabled:self.disabled_masks.discard(identifier)
        else:self.disabled_masks.add(identifier)
        self.changed.emit();self.update()

    def delete_mask(self):
        identifier=self.control_node().id
        if identifier not in self.masks or not self.can_edit_mask(identifier):return
        self.push_history();del self.masks[identifier];self.disabled_masks.discard(identifier)
        self.stop_mask_edit();self.changed.emit();self.update()

    def fill_mask(self,value,selected_only=False):
        identifier=self.editing_mask or self.control_node().id
        if identifier not in self.masks or not self.can_edit_mask(identifier):return
        before=QImage(self.masks[identifier]);self.push_history();painter=QPainter(self.masks[identifier])
        painter.fillRect(self.selection if selected_only and self.selection else QRectF(0,0,*self.doc_size),QColor(value,value,value));painter.end()
        if selected_only and self.selection_mask is not None:
            from selection_tools import blend_selection
            self.masks[identifier]=blend_selection(before,self.masks[identifier],self.selection_mask,self.selection)
        self.changed.emit();self.update()

    def invert_mask(self):
        identifier=self.editing_mask or self.control_node().id
        if identifier not in self.masks or not self.can_edit_mask(identifier):return
        result=self.masks[identifier].convertToFormat(QImage.Format.Format_RGBA8888)
        values=np.frombuffer(result.bits(),dtype=np.uint8).reshape(result.height(),result.bytesPerLine())[:,:result.width()*4].reshape(result.height(),result.width(),4)
        values[:,:,:3]=255-values[:,:,:3];del values
        self.push_history();self.masks[identifier]=result.convertToFormat(QImage.Format.Format_ARGB32)
        self.changed.emit();self.update()

    def mask_stroke(self,a,b):
        if not self.can_edit_mask():return
        return self.buffered_ink_segment(a,b,True)

    def _mask_stroke_raw(self,a,b):
        if self.editing_mask not in self.masks or not self.can_edit_mask():return
        gray=255 if self.tool=='Ластик' else round(.299*self.color.red()+.587*self.color.green()+.114*self.color.blue())
        painter=QPainter(self.masks[self.editing_mask]);painter.setRenderHint(QPainter.RenderHint.Antialiasing,self.smoothing)
        if self.selection:painter.setClipRect(self.selection)
        painter.setOpacity(self.brush_opacity/100*(.35 if self.tool=='Маркер' else 1))
        painter.setPen(QPen(QColor(gray,gray,gray),self.brush_size,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin))
        if self.tool=='Мягкая кисть' or (self.tool=='Кисть' and (self.brush_hardness<100 or self.brush_shape=='square')):
            from brushes import paint_soft_segment
            painter.setOpacity(1);color=QColor(gray,gray,gray);color.setAlphaF(self.brush_opacity/100)
            hardness=min(35,self.brush_hardness) if self.tool=='Мягкая кисть' else self.brush_hardness
            self._dab_remaining=paint_soft_segment(painter,a,b,self.brush_size,color,hardness,getattr(self,'_dab_remaining',0.),self.brush_shape)
        else:painter.drawPoint(a) if a==b else painter.drawLine(a,b)
        painter.end()

    def start_mask_fill(self,x,y):
        from fill import FillJob
        from PySide6.QtCore import QThreadPool
        from PySide6.QtWidgets import QProgressDialog
        if self.fill_job is not None or not self.can_edit_mask() or not (0<=x<self.doc_size[0] and 0<=y<self.doc_size[1]):return
        identifier=self.editing_mask;gray=round(.299*self.color.red()+.587*self.color.green()+.114*self.color.blue())
        self._fill_mask_id=identifier;self._fill_key=self.masks[identifier].cacheKey()
        rect=self.selection.toAlignedRect() if self.selection else None
        bounds=(rect.left(),rect.top(),rect.right()+1,rect.bottom()+1) if rect else None
        self.fill_job=FillJob(QImage(self.masks[identifier]),x,y,QColor(gray,gray,gray),self.fill_tolerance,self.brush_opacity,bounds,selection=self.selection_mask)
        self.fill_dialog=QProgressDialog('Заливка маски…','Отмена',0,0,self.window())
        self.fill_dialog.setWindowModality(Qt.WindowModality.ApplicationModal);self.fill_dialog.setMinimumDuration(150)
        self.fill_dialog.canceled.connect(self.fill_job.cancelled.set);self.fill_job.signals.done.connect(self._finish_fill)
        self.fill_dialog.show();QThreadPool.globalInstance().start(self.fill_job)

    def paste_mask_image(self,image):
        if image.isNull() or not self.can_edit_mask():return
        gray=image.convertToFormat(QImage.Format.Format_RGBA8888)
        values=np.frombuffer(gray.bits(),dtype=np.uint8).reshape(gray.height(),gray.bytesPerLine())[:,:gray.width()*4].reshape(gray.height(),gray.width(),4)
        luma=np.rint(values[:,:,:3].astype(float)@np.array([.299,.587,.114])).astype(np.uint8)
        values[:,:,:3]=luma[:,:,None];del values
        before=QImage(self.masks[self.editing_mask]);self.push_history();p=QPainter(self.masks[self.editing_mask])
        if self.selection:p.setClipRect(self.selection)
        p.drawImage(0,0,gray);p.end()
        if self.selection_mask is not None:
            from selection_tools import blend_selection
            self.masks[self.editing_mask]=blend_selection(before,self.masks[self.editing_mask],self.selection_mask,self.selection)
        self.changed.emit();self.update()

    def apply_current_mask(self):
        node=self.control_node();identifier=node.id
        if identifier not in self.masks or not self.can_edit_mask(identifier):return
        if node.kind=='group':self.status.emit('Маска папки остаётся неразрушающей; применить можно маску отдельного слоя.');return
        if identifier in self.disabled_masks:self.status.emit('Сначала включите маску.');return
        image=self.layer_image(node,include_effects=False) # bake only the mask; keep the glow independently editable.
        self.push_history();node.image=image;node.kind='raster'
        self.text_objects=[t for t in self.text_objects if t.get('layer_id')!=identifier]
        del self.masks[identifier];self.disabled_masks.discard(identifier);self.stop_mask_edit()
        self.selected_text=-1;self.textSelected.emit(-1);self.changed.emit();self.update()

    def transform_masks(self,size,offset=None,crop=None):
        result={}
        for identifier,image in self.masks.items():
            if crop is not None:result[identifier]=image.copy(crop);continue
            target=mask_image(size);p=QPainter(target);p.drawImage(offset or QPointF(),image);p.end();result[identifier]=target
        self.masks=result
