"""Internal layer drag/drop: reorder by persistent IDs, never by checkbox updates."""
import json
from PySide6.QtCore import Qt, QMimeData, Signal, QTimer, QPoint
from PySide6.QtGui import QDrag, QPainter, QPen, QColor
from PySide6.QtWidgets import QListWidget, QAbstractItemView

MIME = 'application/x-dogforst-layer-ids'


class LayerList(QListWidget):
    backgroundDoubleClicked=Signal(QPoint)
    def mouseDoubleClickEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton and self.itemAt(event.position().toPoint()) is None:
            self.backgroundDoubleClicked.emit(event.globalPosition().toPoint());event.accept();return
        super().mouseDoubleClickEvent(event)

    orderDropped = Signal(list)
    nodesDropped = Signal(list,object,str)
    groupToggled = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
        self.setDragEnabled(True); self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDefaultDropAction(Qt.DropAction.MoveAction)
        self._insertion = None
        self.group_mode = False
        self._drop_group = None
        self._drag_y = None
        self._scroll_timer = QTimer(self)
        self._scroll_timer.setInterval(60)
        self._scroll_timer.timeout.connect(self.scroll_during_drag)

    def ids(self):
        return [self.item(i).data(Qt.ItemDataRole.UserRole+2) for i in range(self.count())]

    def startDrag(self, actions):
        selected = [identifier for identifier,item in zip(self.ids(),
                    [self.item(i) for i in range(self.count())]) if item.isSelected()]
        if not selected:
            return
        mime = QMimeData(); mime.setData(MIME,json.dumps(selected).encode())
        drag = QDrag(self); drag.setMimeData(mime)
        try:
            drag.exec(Qt.DropAction.MoveAction)
        finally:
            self.clear_drag()
            drag.deleteLater()

    def dragEnterEvent(self,event):
        if event.source() is self and event.mimeData().hasFormat(MIME):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self,event):
        if event.source() is self and event.mimeData().hasFormat(MIME):
            self._drag_y = event.position().y()
            self._scroll_timer.start()
            self._insertion = self.insertion_at(event.position().toPoint())
            self._drop_group = None
            index=self.indexAt(event.position().toPoint())
            if self.group_mode and index.isValid():
                item=self.item(index.row());rect=self.visualRect(index)
                fraction=(event.position().y()-rect.top())/max(1,rect.height())
                if item.data(Qt.ItemDataRole.UserRole+3)=='group' and .25<=fraction<=.75:
                    self._drop_group=index.row()
            self.viewport().update()
            event.acceptProposedAction()
        else:
            event.ignore()

    def insertion_at(self, point):
        index = self.indexAt(point)
        if not index.isValid():
            return self.count()
        return index.row() + (point.y() > self.visualRect(index).center().y())

    def dragLeaveEvent(self,event):
        self.clear_drag()
        event.accept()

    def clear_drag(self):
        self._scroll_timer.stop()
        self._drag_y = None
        self._insertion = None
        self._drop_group = None
        self.viewport().update()

    def scroll_during_drag(self):
        if self._drag_y is None:
            return
        direction = -1 if self._drag_y < 24 else 1 if self._drag_y > self.viewport().height()-24 else 0
        if direction:
            bar = self.verticalScrollBar()
            bar.setValue(bar.value()+direction*bar.singleStep())
            from PySide6.QtCore import QPoint
            self._insertion = self.insertion_at(QPoint(10,int(self._drag_y)))
            self.viewport().update()

    def paintEvent(self,event):
        super().paintEvent(event)
        if self._drop_group is not None:
            painter=QPainter(self.viewport());painter.setPen(QPen(QColor('#83c8e8'),2))
            painter.drawRect(self.visualItemRect(self.item(self._drop_group)).adjusted(2,1,-3,-2));painter.end()
            return
        if self._insertion is not None and self.count():
            row = min(self._insertion,self.count()-1)
            rect = self.visualItemRect(self.item(row))
            y = rect.top() if self._insertion < self.count() else rect.bottom()
            painter = QPainter(self.viewport())
            painter.setPen(QPen(QColor('#83c8e8'),3))
            painter.drawLine(5,y,self.viewport().width()-5,y)
            painter.end()

    def moved_order(self, selected, insertion):
        order = self.ids()
        selected = set(selected)
        moving = [identifier for identifier in order if identifier in selected]
        before = sum(1 for identifier in order[:insertion] if identifier not in selected)
        remaining = [identifier for identifier in order if identifier not in selected]
        return remaining[:before]+moving+remaining[before:]

    def dropEvent(self,event):
        self.clear_drag()
        if event.source() is not self or not event.mimeData().hasFormat(MIME):
            event.ignore(); return
        try:
            selected = json.loads(bytes(event.mimeData().data(MIME)))
            if not isinstance(selected,list) or not selected or any(x not in self.ids() for x in selected):
                raise ValueError('Invalid layer IDs')
        except (ValueError,TypeError):
            event.ignore(); return
        insertion = self.insertion_at(event.position().toPoint())
        if self.group_mode:
            index=self.indexAt(event.position().toPoint());target=None;mode='below'
            if index.isValid():
                item=self.item(index.row());rect=self.visualRect(index)
                fraction=(event.position().y()-rect.top())/max(1,rect.height())
                target=item.data(Qt.ItemDataRole.UserRole+2)
                mode='inside' if item.data(Qt.ItemDataRole.UserRole+3)=='group' and .25<=fraction<=.75 else 'above' if fraction<.5 else 'below'
            self.nodesDropped.emit(selected,target,mode)
        else:
            self.orderDropped.emit(self.moved_order(selected,insertion))
        event.setDropAction(Qt.DropAction.MoveAction)
        event.accept()

    def mousePressEvent(self,event):
        item=self.itemAt(event.position().toPoint())
        if item is not None and item.data(Qt.ItemDataRole.UserRole+3)=='group':
            # The checkbox keeps its own click area; the folder icon toggles expansion.
            if event.button()==Qt.MouseButton.LeftButton and 35<=event.position().x()<=77:
                self.groupToggled.emit(item.data(Qt.ItemDataRole.UserRole+2));event.accept();return
        super().mousePressEvent(event)
