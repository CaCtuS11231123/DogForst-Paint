"""Document tree and group validation. IDs, never row indexes, define ownership."""
import copy
import math
import uuid
from dataclasses import dataclass, field, asdict

MAX_GROUPS = 256
MAX_DEPTH = 8


@dataclass
class LayerGroup:
    name: str = 'Группа'
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    children: list = field(default_factory=list)
    visible: bool = True
    opacity: float = 1.
    locked: bool = False
    position_locked: bool = False
    color_label: str = ''
    collapsed: bool = False
    blend_mode: str = 'normal'

    kind = 'group'
    alpha_locked = False

    def data(self):
        return asdict(self)


def group_data(groups):
    return [group.data() for group in groups.values()]


def read_groups(records, stack, layer_ids):
    from layer_actions import LABELS
    from blending import validate_mode
    if not isinstance(records,list) or len(records)>MAX_GROUPS or not isinstance(stack,list):
        raise ValueError('Некорректная структура групп.')
    groups={}
    for item in records:
        if not isinstance(item,dict):raise ValueError('Некорректная группа.')
        identifier=item.get('id')
        if not isinstance(identifier,str) or not identifier or identifier in groups or identifier in layer_ids:
            raise ValueError('Повторяющийся или некорректный ID группы.')
        if not isinstance(item.get('name'),str) or not isinstance(item.get('children'),list):
            raise ValueError('Некорректное имя или содержимое группы.')
        for key in ('visible','locked','position_locked','collapsed'):
            if not isinstance(item.get(key,False if key!='visible' else True),bool):
                raise ValueError('Некорректные параметры группы.')
        opacity=float(item.get('opacity',1))
        if not math.isfinite(opacity) or not 0<=opacity<=1:raise ValueError('Некорректная непрозрачность группы.')
        label=item.get('color_label','')
        if not isinstance(label,str) or label not in LABELS:raise ValueError('Некорректная метка группы.')
        groups[identifier]=LayerGroup(name=item['name'],id=identifier,children=list(item['children']),
            visible=item.get('visible',True),opacity=opacity,locked=item.get('locked',False),
            position_locked=item.get('position_locked',False),color_label=label,collapsed=item.get('collapsed',False),
            blend_mode=validate_mode(item.get('blend_mode','normal')))
    validate_tree(groups,stack,layer_ids)
    return groups,list(stack)


def validate_tree(groups, stack, layer_ids):
    if len(groups)>MAX_GROUPS:raise ValueError('Максимум 256 групп.')
    known=set(layer_ids)|set(groups);seen=set()
    def visit(ids,depth):
        if depth>MAX_DEPTH:raise ValueError('Максимальная вложенность — 8 групп.')
        for identifier in ids:
            if not isinstance(identifier,str) or identifier not in known or identifier in seen:
                raise ValueError('В дереве есть цикл, повторение или отсутствующий слой.')
            seen.add(identifier)
            if identifier in groups:visit(groups[identifier].children,depth+1)
    visit(stack,0)
    if seen!=known:raise ValueError('Не все слои и группы включены в дерево.')


class GroupActionsMixin:
    def node(self,identifier):
        return self.groups.get(identifier) or next((l for l in self.layers if l.id==identifier),None)

    def parent_id(self,identifier):
        return next((g.id for g in self.groups.values() if identifier in g.children),None)

    def ancestors(self,identifier):
        result=[];seen=set()
        while (identifier:=self.parent_id(identifier)) is not None:
            if identifier in seen:raise ValueError('Цикл в структуре групп.')
            seen.add(identifier);result.append(self.groups[identifier])
        return result

    def child_ids(self,parent=None):
        return self.groups[parent].children if parent is not None else self.layer_stack

    def descendant_layers(self,identifier):
        if identifier not in self.groups:return [identifier]
        return [leaf for child in self.groups[identifier].children for leaf in self.descendant_layers(child)]

    def flatten_stack(self):
        return [leaf for identifier in self.layer_stack for leaf in self.descendant_layers(identifier)]

    def sync_groups(self):
        """Reconcile old raster commands (insert/delete) without losing group ownership."""
        if not self.groups:
            self.layer_stack=[l.id for l in self.layers]
            return
        active=self.active.id;live={l.id for l in self.layers};known=live|set(self.groups)
        for children in [self.layer_stack]+[g.children for g in self.groups.values()]:
            children[:]=[identifier for identifier in children if identifier in known]
        present=set(self.layer_stack)
        for group in self.groups.values():present.update(group.children)
        for layer in self.layers:
            if layer.id not in present:self.layer_stack.append(layer.id)
        mapping={l.id:l for l in self.layers}
        self.layers=[mapping[identifier] for identifier in self.flatten_stack()]
        self.active_layer=next((i for i,l in enumerate(self.layers) if l.id==active),0)

    def select_all_layer_nodes(self):
        self.sync_groups();self.stop_mask_edit()
        self.set_selected_nodes(self.layer_stack,self.layer_stack[-1]);self.changed.emit()

    def selected_node_ids(self):
        if not self.groups:return super().selected_layer_ids()
        ids={identifier for identifier in getattr(self,'_selected_nodes',()) if self.node(identifier)}
        return ids or {self.active.id}

    def selected_layer_ids(self):
        if not self.groups:return super().selected_layer_ids()
        return {leaf for identifier in self.selected_node_ids() for leaf in self.descendant_layers(identifier)}

    def selected_nodes(self):
        return [self.node(identifier) for identifier in self.selected_node_ids()]

    def set_selected_nodes(self,ids,active=None):
        self.cancel_pending_preview()
        ids={identifier for identifier in ids if self.node(identifier)}
        if not ids:ids={self.active.id}
        # A parent and its children are a single command target, even after Shift selection.
        ids={identifier for identifier in ids if not any(g.id in ids for g in self.ancestors(identifier))}
        active=active if active in ids else next(iter(ids))
        if self.editing_mask is not None and active!=self.editing_mask:self.stop_mask_edit()
        leaves={leaf for identifier in ids for leaf in self.descendant_layers(identifier)}
        if leaves:
            leaf=active if active in leaves else next(l.id for l in reversed(self.layers) if l.id in leaves)
            self.active_layer=next(i for i,l in enumerate(self.layers) if l.id==leaf)
        self._selected_nodes=ids;self.current_node=active;self._selected_layer_ids=leaves
        owned=[i for i,t in enumerate(self.text_objects) if t.get('layer_id')==active]
        self.selected_text=owned[-1] if len(ids)==1 and owned and self.editing_mask is None else -1
        self.textSelected.emit(self.selected_text);self.update()

    def set_selected_layers(self,ids,active_id=None):
        if self.groups:return self.set_selected_nodes(ids,active_id)
        super().set_selected_layers(ids,active_id)
        self._selected_nodes=set(self._selected_layer_ids);self.current_node=self.active.id

    def control_node(self):
        return self.node(getattr(self,'current_node',None)) if self.groups and getattr(self,'current_node',None) in self.selected_node_ids() else self.active

    def insertion_parent(self):
        node=self.control_node()
        return node.id if node.kind=='group' else self.parent_id(node.id)

    def can_insert(self,parent):
        if parent in self.groups and self.node_locked(self.groups[parent]):
            self.status.emit('Группа защищена: сначала отключите блокировку правок.');return False
        return True

    def attach_layer(self,identifier,parent):
        if not self.groups:return
        if parent not in self.groups:parent=None
        children=self.child_ids(parent)
        active=getattr(self,'current_node',None)
        index=children.index(active)+1 if active in children else len(children)
        children.insert(index,identifier)
        self.sync_groups()

    def node_locked(self,node,move=False):
        return any(g.locked or (move and g.position_locked) for g in [node]+self.ancestors(node.id))

    def node_visible(self,node):
        return node.visible and node.opacity>0 and all(g.visible and g.opacity>0 for g in self.ancestors(node.id))

    def can_edit(self,layer=None,move=False,erase=False):
        layer=layer or self.active
        control=self.control_node()
        if control.kind=='group' and not self.descendant_layers(control.id):
            self.status.emit('Группа пуста: добавьте в неё слой кнопкой «Добавить».');return False
        if any(g.locked or (move and g.position_locked) for g in self.ancestors(layer.id)):
            self.status.emit('Группа защищена: отключите её блокировку.');return False
        return super().can_edit(layer,move,erase)

    def set_selected_flag(self,key,value):
        if not self.groups:return super().set_selected_flag(key,value)
        from layer_actions import LABELS
        if key not in ('locked','position_locked','alpha_locked','color_label'):raise ValueError('Неизвестное свойство.')
        if key=='color_label' and value not in LABELS:raise ValueError('Неизвестная метка.')
        targets=[n for n in self.selected_nodes() if getattr(n,key)!=value and (key!='alpha_locked' or n.kind=='raster')]
        if not targets:return
        self.push_history()
        for node in targets:setattr(node,key,value)
        self.changed.emit();self.update()

    def set_selected_blend(self,mode):
        from blending import validate_mode
        mode=validate_mode(mode)
        targets=[node for node in self.selected_nodes() if node.blend_mode!=mode]
        if not targets:return
        self.push_history()
        for node in targets:node.blend_mode=mode
        self.changed.emit();self.update()

    def set_current_opacity(self,value):
        node=self.control_node()
        if node.kind!='group':return self.set_layer_opacity(self.active_layer,value)
        value=max(0.,min(1.,value/100))
        if node.opacity==value:return
        if not self._opacity_edit:self.push_history()
        node.opacity=value;self.modified.emit();self.changed.emit();self.update()

    def set_node_visible(self,identifier,visible):
        node=self.node(identifier)
        if node is None or node.visible==visible:return
        self.push_history();node.visible=visible;self.changed.emit();self.update()

    def toggle_group(self,identifier):
        if identifier not in self.groups:return
        self.groups[identifier].collapsed=not self.groups[identifier].collapsed
        if self.groups[identifier].collapsed:
            selected=self.selected_node_ids()
            hidden={node for node in selected if any(g.id==identifier for g in self.ancestors(node))}
            if hidden:self.set_selected_nodes((selected-hidden)|{identifier},identifier)
        self.changed.emit()

    def rename_node(self,identifier):
        from PySide6.QtWidgets import QInputDialog
        node=self.node(identifier)
        if node is None:return
        name,ok=QInputDialog.getText(self,'Название группы / слоя','Название:',text=node.name)
        if ok and name.strip() and name.strip()!=node.name:
            self.push_history();node.name=name.strip();self.changed.emit()

    def create_group(self,with_selection=True):
        self.sync_groups()
        if len(self.groups)>=MAX_GROUPS:raise ValueError('Максимум 256 групп.')
        selected=self.selected_node_ids() if with_selection else set()
        parents={self.parent_id(identifier) for identifier in selected}
        if len(parents)>1:
            self.status.emit('Для группировки выберите элементы одной папки.');return
        parent=next(iter(parents)) if parents else self.insertion_parent()
        if not self.can_insert(parent) or any(self.node_locked(self.node(identifier)) for identifier in selected):return
        siblings=self.child_ids(parent)
        moving=[identifier for identifier in siblings if identifier in selected]
        group=LayerGroup(name=f'Группа {len(self.groups)+1}',children=moving)
        groups=copy.deepcopy(self.groups);stack=list(self.layer_stack)
        target=groups[parent].children if parent else stack
        position=max((target.index(identifier) for identifier in moving),default=len(target)-1)+1
        target.insert(position,group.id)
        target[:]=[identifier for identifier in target if identifier not in selected]
        groups[group.id]=group
        validate_tree(groups,stack,{l.id for l in self.layers})
        self.push_history();self.groups,self.layer_stack=groups,stack
        self.sync_groups();self.set_selected_nodes({group.id},group.id)
        self.changed.emit();self.update()

    def ungroup_selected(self):
        targets=[identifier for identifier in self.selected_node_ids() if identifier in self.groups]
        if not targets:return
        if any(self.node_locked(self.groups[identifier]) for identifier in targets):
            self.status.emit('Сначала снимите защиту с группы.');return
        # Dissolving isolation/opacity changes the image; keep this explicit in UI/docs.
        self.push_history();selection=[]
        for identifier in targets:
            group=self.groups[identifier];siblings=self.child_ids(self.parent_id(identifier))
            index=siblings.index(identifier);siblings[index:index+1]=group.children
            selection.extend(group.children);del self.groups[identifier]
        self.sync_groups();self.set_selected_nodes(selection or {self.active.id})
        self.changed.emit();self.update()

    def move_nodes(self,ids,parent=None,before=None):
        self.sync_groups();ids=set(ids)
        if parent is not None and parent not in self.groups:raise ValueError('Группа назначения отсутствует.')
        if any(self.node(identifier) is None for identifier in ids):raise ValueError('Элемент отсутствует.')
        if not self.can_insert(parent) or any(self.node_locked(self.node(identifier)) for identifier in ids):return
        ids={identifier for identifier in ids if not any(g.id in ids for g in self.ancestors(identifier))}
        if not ids:return
        if parent in ids or (parent and any(g.id in ids for g in self.ancestors(parent))):
            self.status.emit('Нельзя переместить папку внутрь самой себя.');return
        ordered=[identifier for identifier,depth in self.tree_rows(include_collapsed=True) if identifier in ids]
        ordered.reverse() # UI top-to-bottom -> storage bottom-to-top.
        groups=copy.deepcopy(self.groups);stack=list(self.layer_stack)
        for children in [stack]+[g.children for g in groups.values()]:
            children[:]=[identifier for identifier in children if identifier not in ids]
        target=groups[parent].children if parent else stack
        position=target.index(before) if before in target else len(target)
        target[position:position]=ordered
        validate_tree(groups,stack,{l.id for l in self.layers})
        if stack==self.layer_stack and group_data(groups)==group_data(self.groups):return
        self.push_history();self.groups,self.layer_stack=groups,stack
        self.sync_groups();self.set_selected_nodes(ids)
        self.changed.emit();self.update()

    def drop_nodes(self,ids,target,mode):
        if target in ids:return
        if target is None:return self.move_nodes(ids,None,self.layer_stack[0] if self.layer_stack else None)
        if mode=='inside' and target in self.groups:
            self.move_nodes(ids,target)
            self.groups[target].collapsed=False;self.changed.emit();return
        parent=self.parent_id(target);siblings=self.child_ids(parent)
        index=siblings.index(target)+(1 if mode=='above' else 0)
        before=siblings[index] if index<len(siblings) else None
        self.move_nodes(ids,parent,before)

    def shift_selected_layers(self,direction):
        if not self.groups:return super().shift_selected_layers(direction)
        ids=self.selected_node_ids();parents={self.parent_id(identifier) for identifier in ids}
        if len(parents)!=1:self.status.emit('Для стрелок порядка выберите элементы одной папки.');return
        parent=next(iter(parents));old=list(self.child_ids(parent));order=list(old)
        indexes=range(len(order)-2,-1,-1) if direction>0 else range(1,len(order))
        step=1 if direction>0 else -1
        for i in indexes:
            if order[i] in ids and order[i+step] not in ids:order[i],order[i+step]=order[i+step],order[i]
        if order==old:return
        self.push_history();self.child_ids(parent)[:]=order;self.sync_groups();self.changed.emit();self.update()

    def duplicate_layer(self):
        if not self.groups:return super().duplicate_layer()
        from layers import Layer
        from PySide6.QtGui import QImage
        selected=self.selected_node_ids();targets=self.selected_layers()
        if any(not self.can_insert(self.parent_id(identifier)) for identifier in selected):return
        if (len(self.layers)+len(targets)+len(self.masks)+sum(1 for identifier in self.masks if identifier in selected or any(g.id in selected for g in self.ancestors(identifier))))*self.doc_size[0]*self.doc_size[1]+self.source_pixels()+sum(o["source"].width()*o["source"].height() for i,o in self.raster_objects.items() if i in {l.id for l in targets})>120_000_000:raise ValueError('Достигнут предел памяти слоёв.')
        new_groups=copy.deepcopy(self.groups);mapping={};new_layers=[]
        def clone(identifier):
            node=self.node(identifier)
            if node.kind=='group':
                new=copy.deepcopy(node);new.id=uuid.uuid4().hex;new.name+=' · копия'
                new.children=[clone(child) for child in node.children];new_groups[new.id]=new
            else:
                new=Layer(node.name+' · копия',QImage(node.image),node.visible,node.opacity,kind=node.kind,**node.flags());new_layers.append(new)
            mapping[identifier]=new.id;return new.id
        stack=list(self.layer_stack)
        for identifier in selected:
            new_id=clone(identifier);parent=self.parent_id(identifier)
            siblings=new_groups[parent].children if parent else stack
            siblings.insert(siblings.index(identifier)+1,new_id)
        validate_tree(new_groups,stack,{l.id for l in self.layers+new_layers})
        texts=[dict(copy.deepcopy(t),layer_id=mapping[t['layer_id']]) for t in self.text_objects if t.get('layer_id') in mapping]
        self.push_history();self.groups,self.layer_stack=new_groups,stack;self.layers.extend(new_layers);self.text_objects.extend(texts)
        for old,new in mapping.items():
            if old in self.raster_objects:self.remember_object(self.node(new),self.raster_objects[old])
            if old in self.masks:self.masks[new]=QImage(self.masks[old])
            if old in self.disabled_masks:self.disabled_masks.add(new)
        self.sync_groups();self.set_selected_nodes({mapping[identifier] for identifier in selected})
        self.changed.emit();self.update()

    def delete_layer(self):
        if len(self.layers)==1 and self.active.id in self.raster_objects:
            self.remove_selected_image();return
        if not self.groups:return super().delete_layer()
        ids=self.selected_node_ids();leaves=self.selected_layer_ids()
        if len(leaves)==len(self.layers):self.status.emit('Нельзя удалить все слои.');return
        targets=[self.node(identifier) for identifier in ids]+self.selected_layers()
        if any(self.node_locked(n) for n in targets):self.status.emit('Среди выбранных есть защищённая группа или слой.');return
        doomed=set(ids)
        for group in self.groups.values():
            if any(g.id in ids for g in self.ancestors(group.id)):doomed.add(group.id)
        self.push_history();self.layers=[l for l in self.layers if l.id not in leaves]
        self.text_objects=[t for t in self.text_objects if t.get('layer_id') not in leaves]
        self.groups={identifier:g for identifier,g in self.groups.items() if identifier not in doomed}
        for children in [self.layer_stack]+[g.children for g in self.groups.values()]:children[:]=[i for i in children if i not in doomed and i not in leaves]
        self.active_layer=min(self.active_layer,len(self.layers)-1)
        self.sync_groups();self.set_selected_nodes({self.active.id});self.changed.emit();self.update()

    def tree_rows(self,include_collapsed=False):
        self.sync_groups();rows=[]
        def visit(ids,depth):
            for identifier in reversed(ids):
                rows.append((identifier,depth))
                group=self.groups.get(identifier)
                if group and (include_collapsed or not group.collapsed):visit(group.children,depth+1)
        visit(self.layer_stack,0)
        return rows
