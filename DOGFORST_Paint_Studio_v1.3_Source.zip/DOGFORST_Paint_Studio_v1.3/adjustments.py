"""Tiled colour correction, deterministic filters and cancellable preview transactions."""
import copy,math,threading,uuid
from dataclasses import dataclass
import numpy as np
from scipy.ndimage import gaussian_filter
from PySide6.QtCore import QObject,QRunnable,Signal,QThreadPool,QTimer,QRectF
from PySide6.QtGui import QImage
from layers import Layer
from selection_tools import gray_array

DEFAULT_ADJUSTMENT=dict(brightness=0,contrast=0,gamma=100,saturation=0,hue=0,temperature=0,tint=0,
    grayscale=False,invert=False,sepia=False,effect='none',amount=8,strength=100)
EFFECTS={'none':('Без фильтра',0,100,8),'blur':('Гауссово размытие',0,30,8),
    'sharpen':('Резкость',0,200,70),'pixelate':('Пикселизация',1,100,16),
    'posterize':('Постеризация',2,32,6),'noise':('Зерно / шум',0,100,15),'vignette':('Виньетка',0,100,50)}
PRESETS={'Без коррекции':{},'Мягкий портрет':dict(contrast=-12,saturation=-8,temperature=8,gamma=108),
    'Тёплый свет':dict(temperature=25,saturation=10,brightness=4),'Холодный тон':dict(temperature=-25,tint=-5),
    'Чёрно-белый':dict(grayscale=True,contrast=12),'Сепия':dict(sepia=True,saturation=-15),
    'Выразительный':dict(contrast=22,saturation=20),'Негатив':dict(invert=True)}

def validate_adjustment(values):
    p=dict(DEFAULT_ADJUSTMENT,**values)
    limits={'brightness':(-100,100),'contrast':(-100,100),'gamma':(25,300),'saturation':(-100,100),
        'hue':(-180,180),'temperature':(-100,100),'tint':(-100,100),'strength':(0,100)}
    if p['effect'] not in EFFECTS:raise ValueError('Неизвестный фильтр.')
    limits['amount']=EFFECTS[p['effect']][1:3]
    for key,(lo,hi) in limits.items():
        if type(p[key]) is not int or not lo<=p[key]<=hi:raise ValueError('Некорректный параметр: '+key)
    for key in ('grayscale','invert','sepia'):
        if type(p[key]) is not bool:raise ValueError('Некорректный переключатель: '+key)
    return p

def pixels(image,writable=False):
    return np.frombuffer(image.bits() if writable else image.constBits(),np.uint8).reshape(image.height(),image.bytesPerLine())[:,:image.width()*4].reshape(image.height(),image.width(),4)

def hue_shift(rgb,degrees):
    hi=rgb.max(axis=2);lo=rgb.min(axis=2);delta=hi-lo;safe=np.maximum(delta,1e-8)
    r,g,b=rgb[:,:,0],rgb[:,:,1],rgb[:,:,2]
    h=np.where(hi==r,(g-b)/safe,np.where(hi==g,(b-r)/safe+2,(r-g)/safe+4));h=np.where(delta>1e-8,h/6,0)
    h=(h+degrees/360)%1;s=np.divide(delta,np.maximum(hi,1e-8));i=np.floor(h*6).astype(np.int32);f=h*6-i
    a=hi*(1-s);bb=hi*(1-f*s);c=hi*(1-(1-f)*s)
    return np.stack((np.choose(i%6,[hi,bb,a,a,c,hi]),np.choose(i%6,[c,hi,hi,bb,a,a]),np.choose(i%6,[a,a,c,hi,hi,bb])),axis=2)

def tone(rgb,p):
    rgb=np.clip((rgb-.5)*(2**(p['contrast']/50))+.5+p['brightness']/100,0,1)
    if p['gamma']!=100:rgb=np.power(rgb,100/p['gamma'])
    if p['hue']:rgb=hue_shift(rgb,p['hue'])
    luminance=rgb[:,:,0:1]*.2126+rgb[:,:,1:2]*.7152+rgb[:,:,2:3]*.0722
    rgb=np.clip(luminance+(rgb-luminance)*(1+p['saturation']/100),0,1)
    rgb=rgb+np.array([p['temperature']*.002,p['tint']*.002,-p['temperature']*.002],np.float32)
    rgb=np.clip(rgb,0,1)
    if p['grayscale']:
        gray=rgb[:,:,0:1]*.2126+rgb[:,:,1:2]*.7152+rgb[:,:,2:3]*.0722;rgb=np.repeat(gray,3,axis=2)
    if p['sepia']:rgb=np.clip(rgb@np.array([[.393,.349,.272],[.769,.686,.534],[.189,.168,.131]],np.float32),0,1)
    if p['invert']:rgb=1-rgb
    return rgb

@dataclass(frozen=True)
class AdjustmentInput:
    raw:object
    coverage:object=None
    bounds:object=None
    mask_only:bool=False


def render_adjustment(data,values,cancelled,progress=None,tile_width=512,tile_height=192):
    p=validate_adjustment(values)
    if cancelled.is_set():return None
    neutral=all(p[k]==DEFAULT_ADJUSTMENT[k] for k in DEFAULT_ADJUSTMENT if k not in ('amount','effect')) and p['effect']=='none'
    if neutral or p['strength']==0:return QImage(data.raw)
    original=data.raw.convertToFormat(QImage.Format.Format_RGBA8888);result=QImage(original)
    bounds=(data.bounds or QRectF(original.rect())).toAlignedRect().intersected(original.rect())
    if bounds.isEmpty():return QImage(data.raw)
    out=pixels(result,True);src=pixels(original);mask_image,mask=(gray_array(data.coverage) if data.coverage is not None else (None,None))
    effect=p['effect'];amount=p['amount'];sigma=amount if effect=='blur' else 1.2
    halo=math.ceil(sigma*3)+2 if effect in ('blur','sharpen') else amount+1 if effect=='pixelate' else 0
    total=math.ceil(bounds.width()/tile_width)*math.ceil(bounds.height()/tile_height);done=0;last_progress=-1
    for y in range(bounds.top(),bounds.bottom()+1,tile_height):
        h=min(tile_height,bounds.bottom()-y+1)
        for x in range(bounds.left(),bounds.right()+1,tile_width):
            if cancelled.is_set():return None
            w=min(tile_width,bounds.right()-x+1);x0=max(0,x-halo);y0=max(0,y-halo);x2=min(original.width(),x+w+halo);y2=min(original.height(),y+h+halo)
            patch=src[y0:y2,x0:x2];rgb=tone(patch[:,:,:3].astype(np.float32)/255,p);alpha=patch[:,:,3:4].astype(np.float32)/255
            iy=slice(y-y0,y-y0+h);ix=slice(x-x0,x-x0+w);before=src[y:y+h,x:x+w];after=rgb[iy,ix]
            if effect in ('blur','sharpen') and amount:
                filtered=np.empty_like(rgb)
                for channel in range(3):
                    if cancelled.is_set():return None
                    filtered[:,:,channel]=gaussian_filter(rgb[:,:,channel]*alpha[:,:,0],sigma,mode='nearest',truncate=3)
                weights=gaussian_filter(alpha[:,:,0],sigma,mode='nearest',truncate=3)[:,:,None]
                filtered=np.divide(filtered,np.maximum(weights,1e-8),out=np.zeros_like(filtered),where=weights>1e-8)[iy,ix]
                after=filtered if effect=='blur' else np.clip(after+(after-filtered)*(amount/100),0,1)
            elif effect=='pixelate':
                xx=np.clip((np.arange(x,x+w)//amount)*amount+amount//2,0,original.width()-1)-x0
                yy=np.clip((np.arange(y,y+h)//amount)*amount+amount//2,0,original.height()-1)-y0
                after=rgb[yy[:,None],xx[None,:]]
            elif effect=='posterize':after=np.round(after*(amount-1))/(amount-1)
            elif effect=='noise':
                yy,xx=np.mgrid[y:y+h,x:x+w];seed=xx.astype(np.uint32)*np.uint32(73856093)^yy.astype(np.uint32)*np.uint32(19349663)
                seed^=seed>>13;seed*=np.uint32(1274126177);seed^=seed>>16
                noise=(seed.astype(np.float32)/4294967295-.5)*(amount/100)
                after=np.clip(after+noise[:,:,None],0,1)
            elif effect=='vignette':
                yy,xx=np.mgrid[y:y+h,x:x+w];dx=(xx+.5-original.width()/2)/max(1,original.width()/2);dy=(yy+.5-original.height()/2)/max(1,original.height()/2)
                falloff=np.clip((dx*dx+dy*dy-.12)/1.5,0,1);after=after*(1-falloff[:,:,None]*(amount/100))
            if data.mask_only:
                gray=after[:,:,0:1]*.299+after[:,:,1:2]*.587+after[:,:,2:3]*.114;after=np.repeat(gray,3,axis=2)
            weight=np.full((h,w,1),p['strength']/100,np.float32)
            if mask is not None:weight*=mask[y:y+h,x:x+w,None]/255
            values=np.round(np.clip(before[:,:,:3]*(1-weight)+after*255*weight,0,255)).astype(np.uint8)
            # Alpha is preserved exactly; hidden RGB and excluded pixels are byte-identical.
            keep=(weight[:,:,0]==0)|(before[:,:,3]==0)
            values[keep]=before[:,:,:3][keep];out[y:y+h,x:x+w,:3]=values
            done+=1;percent=round(done*100/total)
            if progress is not None and percent//5!=last_progress:progress(percent);last_progress=percent//5
    return None if cancelled.is_set() else result.convertToFormat(data.raw.format())

class AdjustmentSignals(QObject):
    done=Signal(object,object,str)
    progress=Signal(object,int)
class AdjustmentJob(QRunnable):
    def __init__(self,session):
        super().__init__();self.uid=session.uid;self.version=session.version;self.data=session.data;self.parameters=copy.deepcopy(session.parameters);self.cancelled=threading.Event();self.signals=AdjustmentSignals()
    def run(self):
        try:self.signals.done.emit(self,render_adjustment(self.data,self.parameters,self.cancelled,lambda n:self.signals.progress.emit(self,n)),'')
        except Exception as error:self.signals.done.emit(self,None,'Недостаточно памяти для коррекции.' if isinstance(error,MemoryError) else str(error))
class AdjustmentSession:
    def __init__(self,node_id,mask_id,stamp,data):
        self.uid=uuid.uuid4().hex;self.node_id=node_id;self.mask_id=mask_id;self.stamp=stamp;self.data=data
        self.parameters=dict(DEFAULT_ADJUSTMENT);self.version=0;self.rendered_version=-1;self.result=None;self.error='';self.progress=0;self.show_original=False;self.apply_requested=False

class AdjustmentMixin:
    def init_adjustment(self):
        self.adjustment_session=None;self._adjustment_job=None
        self._adjustment_timer=QTimer(self);self._adjustment_timer.setSingleShot(True);self._adjustment_timer.setInterval(70);self._adjustment_timer.timeout.connect(self.launch_adjustment_job)
    def start_adjustment(self):
        if self.adjustment_session is not None:return True
        if self.drawing or self.fill_job is not None or self.wand_job is not None or self.gradient_session is not None or self.retouch_session is not None or self.selection_transform is not None or self._lasso_points:return False
        mask_id=self.editing_mask if self.editing_mask in self.masks else None
        if mask_id is None and (len(self.selected_node_ids())!=1 or self.control_node().kind=='group'):
            self.status.emit('Для коррекции выберите один слой или маску.');return False
        if not (self.can_edit_mask(mask_id) if mask_id else self.can_edit()):return False
        node=self.node(mask_id) if mask_id else self.active;raw=QImage(self.masks[mask_id]) if mask_id else self.raw_pixels(node)
        self.adjustment_session=AdjustmentSession(node.id,mask_id,self.selection_stamp(),AdjustmentInput(raw,self.selection_coverage() if self.selection else None,QRectF(self.selection) if self.selection else None,bool(mask_id)))
        self.adjustmentChanged.emit();self._adjustment_timer.start();self.update();return True
    def update_adjustment(self,**values):
        s=self.adjustment_session
        if s is None:return False
        p=validate_adjustment(dict(s.parameters,**values))
        if p==s.parameters:return True
        s.parameters=p;s.version+=1;s.error='';s.apply_requested=False;s.progress=0
        if self._adjustment_job:self._adjustment_job.cancelled.set()
        self._adjustment_timer.start();self.adjustmentChanged.emit();return True
    def show_adjustment_original(self,value):
        if self.adjustment_session:self.adjustment_session.show_original=bool(value);self.update()
    def launch_adjustment_job(self):
        s=self.adjustment_session
        if s is None or self._adjustment_job is not None or s.rendered_version==s.version:return
        job=AdjustmentJob(s);self._adjustment_job=job;job.signals.done.connect(self.finish_adjustment_job);job.signals.progress.connect(self.adjustment_progress);QThreadPool.globalInstance().start(job)
    def adjustment_progress(self,job,n):
        s=self.adjustment_session
        if s is not None and job.uid==s.uid and job.version==s.version:s.progress=n;self.adjustmentChanged.emit()
    def finish_adjustment_job(self,job,result,error):
        if job is not self._adjustment_job:return
        self._adjustment_job=None;s=self.adjustment_session
        if s is None:return
        if self.selection_stamp()!=s.stamp:self.cancel_adjustment();self.status.emit('Документ изменился: коррекция отменена.');return
        if job.uid!=s.uid or job.version!=s.version:self.launch_adjustment_job();return
        if error:s.error=error;s.apply_requested=False;self.status.emit(error)
        elif result is not None:s.result=result;s.rendered_version=s.version;s.progress=100;self.update()
        self.adjustmentChanged.emit()
        if not error and s.apply_requested:self.apply_adjustment()
    def cancel_adjustment(self):
        if self.adjustment_session is None:return False
        self.adjustment_session=None;self._adjustment_timer.stop()
        if self._adjustment_job:self._adjustment_job.cancelled.set()
        self.adjustmentChanged.emit();self.adjustmentFinished.emit(False);self.update();return True
    def apply_adjustment(self):
        s=self.adjustment_session
        if s is None:return False
        if self.selection_stamp()!=s.stamp or self.control_node().id!=s.node_id or self.editing_mask!=s.mask_id:
            self.cancel_adjustment();self.status.emit('Документ изменился: коррекция отменена.');return False
        if s.error:return False
        if s.result is None or s.rendered_version!=s.version:
            s.apply_requested=True;self._adjustment_timer.stop();self.launch_adjustment_job();self.adjustmentChanged.emit();return False
        self.adjustment_session=None;self._adjustment_timer.stop()
        if s.result!=s.data.raw:
            self.push_history()
            if s.mask_id:self.masks[s.mask_id]=QImage(s.result)
            else:
                node=self.node(s.node_id);node.image=QImage(s.result);node.kind='raster';self.text_objects=[t for t in self.text_objects if t.get('layer_id')!=s.node_id];self.selected_text=-1;self.textSelected.emit(-1)
            self.changed.emit()
        self.adjustmentChanged.emit();self.adjustmentFinished.emit(True);self.update();self.status.emit('Коррекция применена · Ctrl+Z — отменить');return True
    def adjustment_context(self):
        s=self.adjustment_session
        if s is None or s.result is None or s.show_original:return self.layers,self.text_objects,self.masks
        if s.mask_id:
            masks=dict(self.masks);masks[s.mask_id]=s.result;return self.layers,self.text_objects,masks
        layers=[Layer(l.name,QImage(s.result),l.visible,l.opacity,l.id,'raster',**l.flags()) if l.id==s.node_id else l for l in self.layers]
        return layers,[t for t in self.text_objects if t.get('layer_id')!=s.node_id],self.masks
