"""Bounded, validated preference palettes and MRU colours; independent of project format."""
import json
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QComboBox,QPushButton,QLabel,QInputDialog,QScrollArea,QFileDialog,QMessageBox
from PySide6.QtCore import QSaveFile,QIODevice
from widgets import ColorSwatch

DEFAULT_PALETTES=[dict(name='DOGFORST',colors=['#202020','#ffffff','#42b8cf','#526fdb','#9a65d6','#e37c93','#f1c27d']),dict(name='Спокойные',colors=['#33465a','#7e9c9a','#a8c7b4','#e8dfd0','#c4b6d0','#d1a3a1'])]

def validate_palettes(value):
    if not isinstance(value,list) or not 1<=len(value)<=32:raise ValueError('Допустимо от 1 до 32 палитр.')
    result=[];names=set()
    for entry in value:
        if not isinstance(entry,dict):raise ValueError('Неверная палитра.')
        name=entry.get('name');colors=entry.get('colors')
        if not isinstance(name,str) or not name.strip() or len(name)>60 or name.strip().casefold() in names:raise ValueError('Названия палитр должны быть разными и не длиннее 60 символов.')
        if not isinstance(colors,list) or len(colors)>64:raise ValueError('В палитре может быть до 64 цветов.')
        parsed=[]
        for color in colors:
            if not isinstance(color,str) or not QColor(color).isValid():raise ValueError('Некорректный цвет палитры.')
            c=QColor(color).name()
            if c not in parsed:parsed.append(c)
        names.add(name.strip().casefold());result.append(dict(name=name.strip(),colors=parsed))
    return result

class PaletteStore:
    def __init__(self,settings):
        self.settings=settings
        try:self.palettes=validate_palettes(json.loads(settings.value('colors/palettes_v1','null')))
        except (ValueError,TypeError):self.palettes=validate_palettes(DEFAULT_PALETTES)
        try:
            recent=json.loads(settings.value('colors/recent_v1','[]'))
            if not isinstance(recent,list):raise ValueError()
            self.recent=[]
            for value in recent[:24]:
                if isinstance(value,str) and QColor(value).isValid() and QColor(value).name() not in self.recent:self.recent.append(QColor(value).name())
        except (ValueError,TypeError):self.recent=[]
    def save(self):
        self.palettes=validate_palettes(self.palettes);self.settings.setValue('colors/palettes_v1',json.dumps(self.palettes,ensure_ascii=False));self.settings.setValue('colors/recent_v1',json.dumps(self.recent));self.settings.sync()
    def record(self,color):
        c=QColor(color)
        if not c.isValid():return
        value=c.name()
        if self.recent and self.recent[0]==value:return
        self.recent=[value]+[v for v in self.recent if v!=value];self.recent=self.recent[:24];self.save()
    def add_palette(self,name):
        candidate=validate_palettes(self.palettes+[dict(name=name,colors=[])]);self.palettes=candidate;self.save();return len(candidate)-1
    def rename(self,index,name):
        candidate=[dict(p) for p in self.palettes];candidate[index]=dict(candidate[index],name=name);self.palettes=validate_palettes(candidate);self.save()
    def delete(self,index):
        if len(self.palettes)<=1:raise ValueError('Нужно оставить хотя бы одну палитру.')
        del self.palettes[index];self.save()
    def add_color(self,index,color):
        c=QColor(color)
        if not c.isValid():raise ValueError('Некорректный цвет.')
        colors=self.palettes[index]['colors'];value=c.name()
        if value in colors:return
        if len(colors)>=64:raise ValueError('В палитре уже 64 цвета.')
        colors.append(value);self.save()
    def import_data(self,data):
        if not isinstance(data,dict) or data.get('format')!='dogforst-palettes' or data.get('version')!=1:raise ValueError('Это не файл палитр DOGFORST v1.')
        incoming=validate_palettes(data.get('palettes'));candidate=[dict(name=p['name'],colors=list(p['colors'])) for p in self.palettes]
        for p in incoming:
            existing={v['name'].casefold() for v in candidate};name=p['name'];suffix=2
            while name.casefold() in existing:name=p['name'][:50]+f' ({suffix})';suffix+=1
            candidate.append(dict(p,name=name))
        self.palettes=validate_palettes(candidate);self.save()

class PalettePanel(QWidget):
    def __init__(self,owner):
        super().__init__();self.owner=owner;self.store=PaletteStore(owner.settings);self.selected_color=None;root=QVBoxLayout(self)
        self.choice=QComboBox();self.choice.currentIndexChanged.connect(self.refresh_colors);root.addWidget(self.choice)
        row=QHBoxLayout()
        for text,fn in [('Создать',self.create),('Имя…',self.rename),('Удалить',self.delete)]:
            button=QPushButton(text);button.clicked.connect(fn);row.addWidget(button)
        root.addLayout(row);note=QLabel('Нажмите цвет для рисования. «+ Текущий» сохраняет выбранный цвет.');note.setWordWrap(True);root.addWidget(note)
        self.colors_widget=QWidget();self.colors=QGridLayout(self.colors_widget);self.colors.setContentsMargins(0,0,0,0);root.addWidget(self.colors_widget)
        row=QHBoxLayout();self.add=QPushButton('+ Текущий');self.add.clicked.connect(lambda:self.run(self.store.add_color,self.index(),owner.canvas.color));self.remove=QPushButton('Убрать цвет');self.remove.clicked.connect(self.remove_color);row.addWidget(self.add);row.addWidget(self.remove);root.addLayout(row)
        row=QHBoxLayout()
        for text,fn in [('Импорт…',self.import_file),('Экспорт…',self.export_file)]:
            button=QPushButton(text);button.clicked.connect(fn);row.addWidget(button)
        root.addLayout(row);root.addWidget(QLabel('Последние цвета'));self.recent_widget=QWidget();self.recent=QGridLayout(self.recent_widget);self.recent.setContentsMargins(0,0,0,0);root.addWidget(self.recent_widget);root.addStretch();self.refresh();owner.canvas.colorChanged.connect(self.record)
    def index(self):return max(0,self.choice.currentIndex())
    def run(self,fn,*args):
        try:fn(*args);self.refresh()
        except (ValueError,OSError) as e:QMessageBox.warning(self,'Палитры',str(e))
    def refresh(self):
        index=self.index();self.choice.blockSignals(True);self.choice.clear();self.choice.addItems([p['name'] for p in self.store.palettes]);self.choice.setCurrentIndex(min(index,len(self.store.palettes)-1));self.choice.blockSignals(False);self.refresh_colors();self.draw_grid(self.recent,self.store.recent)
    def draw_grid(self,grid,colors):
        while grid.count():
            item=grid.takeAt(0)
            if item.widget():item.widget().deleteLater()
        for i,value in enumerate(colors):
            button=ColorSwatch(value);button.accent=QColor(self.owner._theme_colors[5]);button.setChecked(QColor(value)==self.owner.canvas.color);button.clicked.connect(lambda checked=False,c=value:self.pick(c));grid.addWidget(button,i//7,i%7)
    def refresh_colors(self,*args):
        if self.choice.currentIndex()<0:return
        colors=self.store.palettes[self.index()]['colors'];self.draw_grid(self.colors,colors);self.remove.setEnabled(self.selected_color in colors);self.add.setEnabled(len(colors)<64)
    def pick(self,color):self.selected_color=color;self.owner.set_color(QColor(color));self.refresh_colors()
    def record(self,color):
        if not getattr(self.owner,"_color_previewing",False):self.store.record(color)
        self.selected_color=QColor(color).name();self.refresh_colors();self.draw_grid(self.recent,self.store.recent)
    def create(self):
        name,ok=QInputDialog.getText(self,'Новая палитра','Название:')
        if ok:
            try:index=self.store.add_palette(name);self.refresh();self.choice.setCurrentIndex(index)
            except ValueError as e:QMessageBox.warning(self,'Палитры',str(e))
    def rename(self):
        name,ok=QInputDialog.getText(self,'Название палитры','Название:',text=self.store.palettes[self.index()]['name'])
        if ok:self.run(self.store.rename,self.index(),name)
    def delete(self):self.run(self.store.delete,self.index())
    def remove_color(self):
        colors=self.store.palettes[self.index()]['colors']
        if self.selected_color in colors:colors.remove(self.selected_color);self.store.save();self.refresh_colors()
    def import_file(self):
        path,_=QFileDialog.getOpenFileName(self,'Импорт палитр','','Палитры DOGFORST (*.json)')
        if not path:return
        try:
            from pathlib import Path
            if Path(path).stat().st_size>1024*1024:raise ValueError('Файл палитры слишком большой: максимум 1 МиБ.')
            self.store.import_data(json.loads(Path(path).read_text(encoding='utf-8')));self.refresh()
        except (OSError,ValueError,UnicodeError) as e:QMessageBox.warning(self,'Палитры',str(e))
    def export_file(self):
        path,_=QFileDialog.getSaveFileName(self,'Экспорт всех палитр','DOGFORST_palettes.json','JSON (*.json)')
        if not path:return
        if not path.lower().endswith('.json'):path+='.json'
        output=QSaveFile(path)
        if not output.open(QIODevice.OpenModeFlag.WriteOnly):QMessageBox.warning(self,'Палитры',output.errorString());return
        payload=json.dumps(dict(format='dogforst-palettes',version=1,palettes=self.store.palettes),ensure_ascii=False,indent=2).encode('utf-8')
        if output.write(payload)!=len(payload) or not output.commit():output.cancelWriting();QMessageBox.warning(self,'Палитры','Не удалось сохранить палитры.')
