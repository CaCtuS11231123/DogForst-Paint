"""DOGFORST's own small folder glyph, drawn with Qt primitives."""
from PySide6.QtCore import Qt,QRectF
from PySide6.QtGui import QPixmap,QPainter,QPen,QColor,QIcon


def group_icon(collapsed,accent):
    pixmap=QPixmap(84,64);pixmap.fill(Qt.GlobalColor.transparent)
    painter=QPainter(pixmap);painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    color=QColor(accent);fill=QColor(color);fill.setAlpha(35)
    painter.setPen(QPen(color,3,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin))
    painter.setBrush(fill);painter.drawRoundedRect(QRectF(7,17,68,39),7,7)
    painter.drawLine(12,17,12,10);painter.drawLine(12,10,33,10);painter.drawLine(33,10,40,17)
    if not collapsed:painter.drawLine(16,29,66,29)
    else:painter.drawLine(22,29,22,44);painter.drawLine(22,44,36,44)
    painter.end();return QIcon(pixmap)
