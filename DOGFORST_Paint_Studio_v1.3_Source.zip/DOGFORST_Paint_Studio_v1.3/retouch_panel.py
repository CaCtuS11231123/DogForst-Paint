"""Live, tool-specific controls; unavailable controls are disabled, never fake."""
from PySide6.QtCore import Qt,QSignalBlocker
from PySide6.QtWidgets import QWidget,QDockWidget,QVBoxLayout,QFormLayout,QLabel,QSpinBox,QCheckBox,QPushButton,QProgressBar
from widgets import AnimatedSlider
from retouch import RETOUCH_TOOLS

class RetouchDock(QDockWidget):
    def __init__(self,owner):super().__init__('Ретушь и локальные инструменты',owner);self.owner=owner
    def closeEvent(self,event):self.owner.canvas.cancel_retouch();super().closeEvent(event)

class RetouchPanel(QWidget):
    def __init__(self,owner):
        super().__init__();self.owner=owner;self.c=owner.canvas;root=QVBoxLayout(self);self.heading=QLabel();root.addWidget(self.heading);form=QFormLayout();root.addLayout(form);self.fields={}
        for key,label,lo,hi,value in [('size','Размер',1,512,self.c.brush_size),('opacity','Непрозрачность',0,100,self.c.brush_opacity),('strength','Сила эффекта',0,100,self.c.retouch_options['strength']),('hardness','Жёсткость края',0,100,self.c.retouch_options['hardness'])]:
            spin=QSpinBox();spin.setRange(lo,hi);spin.setValue(value);spin.setSuffix(' px' if key=='size' else ' %');spin.valueChanged.connect(lambda v,k=key:self.change(k,v));form.addRow(label,spin);self.fields[key]=spin
        self.aligned=QCheckBox('Сохранять смещение штампа');self.aligned.setToolTip('Продолжать копирование с тем же смещением источника между штрихами');self.aligned.setChecked(self.c.retouch_options['aligned']);self.aligned.toggled.connect(lambda v:self.change('aligned',v));root.addWidget(self.aligned)
        self.source=QLabel();self.source.setWordWrap(True);root.addWidget(self.source);self.note=QLabel();self.note.setWordWrap(True);root.addWidget(self.note)
        info=QLabel('Работа идёт по выбранному слою или маске с учётом выделения. Сила накапливается при повторных проходах. Текст/фигура/фото становятся пикселями только после изменившего их штриха; Undo возвращает исходник.');info.setWordWrap(True);root.addWidget(info)
        self.progress=QProgressBar();self.progress.setRange(0,0);root.addWidget(self.progress);self.status=QLabel();self.status.setWordWrap(True);root.addWidget(self.status)
        self.cancel=QPushButton('Отменить обработку · Esc');self.cancel.clicked.connect(self.c.cancel_retouch);root.addWidget(self.cancel);root.addStretch();self.refresh()
    def change(self,key,value):
        if self.c.retouch_session is not None:return
        if key=='size':self.owner.size_spin.setValue(value)
        elif key=='opacity':self.owner.opacity_spin.setValue(value)
        else:self.c.retouch_options[key]=value;self.owner.settings.setValue('retouch/'+key,value)
        self.c.update_cursor();self.refresh()
    def refresh(self):
        tool=self.c.tool;s=self.c.retouch_session
        self.heading.setText(tool if tool in RETOUCH_TOOLS else 'Выберите инструмент ретуши')
        for key,widget in self.fields.items():
            value=self.c.brush_size if key=='size' else self.c.brush_opacity if key=='opacity' else self.c.retouch_options[key]
            with QSignalBlocker(widget):widget.setValue(value)
            widget.setEnabled(s is None)
        self.aligned.setEnabled(s is None and tool=='Штамп')
        with QSignalBlocker(self.aligned):self.aligned.setChecked(self.c.retouch_options['aligned'])
        notes={'Палец':'Начните на цветной области и потяните её в нужную сторону: пиксели смешиваются по движению кисти.', 'Размытие':'Локальное гауссово размытие. Мягкий край кисти оставляет плавный переход.', 'Резкость':'Локальная нерезкая маска повышает контраст деталей. Начинайте с небольшой силы.', 'Штамп':'Alt+нажатие выбирает источник на этом слое/маске. Затем рисуйте в месте копирования.', 'Осветление':'Осветляет цвета под кистью, сохраняя их прозрачность.', 'Затемнение':'Затемняет цвета под кистью, сохраняя их прозрачность.'}
        self.note.setText(notes.get(tool,''));anchor=self.c.clone_anchor
        self.source.setText(f'Источник штампа: X {anchor[1].x():.0f}, Y {anchor[1].y():.0f}' if tool=='Штамп' and anchor is not None else 'Штамп: источник ещё не выбран' if tool=='Штамп' else '')
        self.progress.setVisible(s is not None);self.cancel.setEnabled(s is not None)
        self.status.setText(f'Обработано точек: {s.processed}. В очереди: {len(s.points)}. Esc — отменить.' if s else 'Готово. Проведите инструментом по холсту.')
