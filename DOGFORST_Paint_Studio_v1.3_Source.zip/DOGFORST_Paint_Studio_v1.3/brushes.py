"""Distance-spaced feathered brush dabs and adjustable stroke stabilization."""
import math
from PySide6.QtCore import QPointF,QRectF
from PySide6.QtGui import QColor,QRadialGradient,QBrush


def stabilized_point(previous,target,strength):
    if strength<=0:return QPointF(target)
    distance=math.hypot(target.x()-previous.x(),target.y()-previous.y())
    alpha=1-math.exp(-distance/max(1.,strength*.3))
    return previous+(target-previous)*max(.08,alpha)


def paint_soft_segment(painter,a,b,size,color,hardness,remaining=0.,shape="round"):
    """Keep dab spacing independent of mouse event subdivision; carry to next segment."""
    radius=max(.5,size/2);spacing=max(.35,size*.12)
    length=math.hypot(b.x()-a.x(),b.y()-a.y())
    gradient=QRadialGradient(QPointF(0,0),radius)
    shade=QColor(color)
    # Compensate for overlapping dabs at 12% spacing.
    shade.setAlphaF(1-(1-shade.alphaF())**.24 if shade.alphaF()<1 else .72)
    gradient.setColorAt(0,shade);gradient.setColorAt(min(.98,max(0,hardness/100)),shade)
    edge=QColor(shade);edge.setAlpha(0);gradient.setColorAt(1,edge)
    from PySide6.QtCore import Qt
    painter.setPen(Qt.PenStyle.NoPen)
    distance=max(0.,remaining)
    if length==0:
        positions=[QPointF(a)]
    else:
        positions=[]
        while distance<=length:
            positions.append(a+(b-a)*(distance/length));distance+=spacing
    for point in positions:
        painter.save();painter.translate(point);painter.setBrush(QBrush(gradient))
        if shape=="square":
            if hardness>=100:painter.setBrush(QBrush(color))
            painter.drawRect(QRectF(-radius,-radius,2*radius,2*radius))
        else:painter.drawEllipse(QRectF(-radius,-radius,2*radius,2*radius))
        painter.restore()
    return spacing if length==0 else distance-length
