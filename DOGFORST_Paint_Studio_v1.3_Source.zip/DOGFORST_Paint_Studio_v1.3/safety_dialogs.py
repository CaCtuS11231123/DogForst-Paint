from datetime import datetime
from pathlib import Path
from PySide6.QtCore import Qt, QEventLoop
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QFormLayout, QCheckBox,
    QSpinBox, QLabel, QDialogButtonBox, QListWidget, QProgressBar, QPushButton)


class SaveProgressDialog(QDialog):
    """Cancel requests cancellation, but never destroys a still-running worker's UI."""
    def __init__(self, target, cancel, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Сохранение проекта')
        self.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.resize(480, 180)
        self.cancel_callback = cancel
        self.result_value = None
        self.error = None
        self.complete = False
        layout = QVBoxLayout(self)
        self.description = QLabel('Запись проекта…\n' + str(target))
        self.description.setWordWrap(True)
        layout.addWidget(self.description)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        layout.addWidget(self.progress)
        self.cancel_button = QPushButton('Отмена')
        self.cancel_button.clicked.connect(self.request_cancel)
        layout.addWidget(self.cancel_button)

    def update_progress(self, percent, text):
        self.progress.setValue(percent)
        self.progress.setToolTip(text)

    def request_cancel(self):
        if not self.complete:
            self.cancel_callback()
            self.cancel_button.setEnabled(False)
            self.cancel_button.setText('Отмена…')

    def reject(self):
        self.request_cancel()

    def closeEvent(self, event):
        if self.complete:
            event.accept()
        else:
            self.request_cancel()
            event.ignore()

    def finish(self, result, error):
        self.result_value, self.error = result, error
        self.complete = True
        self.accept()

    def run(self):
        loop = QEventLoop(self)
        self.finished.connect(loop.quit)
        self.show()
        if not self.complete:
            loop.exec()
        return self.result_value, self.error


class SafetySettingsDialog(QDialog):
    def __init__(self, enabled, minutes, backup_limit, root, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Автосохранение и резервные копии')
        self.resize(560, 280)
        layout = QFormLayout(self)
        hint = QLabel('Автосохранение создаёт отдельную копию восстановления.\n'
                      'Основной проект записывается только командой «Сохранить».')
        hint.setWordWrap(True)
        layout.addRow(hint)
        self.enabled = QCheckBox('Включить автосохранение')
        self.enabled.setChecked(enabled)
        self.minutes = QSpinBox()
        self.minutes.setRange(1, 60)
        self.minutes.setValue(minutes)
        self.minutes.setSuffix(' мин')
        self.backups = QSpinBox()
        self.backups.setRange(1, 50)
        self.backups.setValue(backup_limit)
        layout.addRow(self.enabled)
        layout.addRow('Интервал', self.minutes)
        layout.addRow('Предыдущих версий каждого проекта', self.backups)
        path = QLabel('Копии восстановления и журнал:\n' + str(root))
        path.setWordWrap(True)
        path.setTextInteractionFlags(path.textInteractionFlags() |
                                     Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addRow(path)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText('Применить')
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена')
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)


class ProjectCopiesDialog(QDialog):
    def __init__(self, records, parent=None, title='Восстановление проектов'):
        super().__init__(parent)
        self.records = records
        self.selected_record = None
        self.setWindowTitle(title)
        self.resize(670, 410)
        layout = QVBoxLayout(self)
        hint = QLabel('Выбранный проект откроется как несохранённая копия.\n'
                      'Исходный файл и копии останутся на месте до успешного сохранения.\n'
                      'Если последняя копия повреждена, выберите предыдущую строку.')
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.items = QListWidget()
        for record in records:
            try:
                when = datetime.fromisoformat(record.saved_at).astimezone().strftime('%d.%m.%Y %H:%M:%S')
            except (ValueError, TypeError):
                when = 'Дата неизвестна'
            name = Path(record.source).name if record.source else 'Без названия'
            self.items.addItem(f'{name} — {when}\n{record.source or "Несохранённый документ"}')
        self.items.setCurrentRow(0)
        layout.addWidget(self.items)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Open |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Open).setText('Восстановить копией')
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Позже')
        buttons.accepted.connect(self.choose)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def choose(self):
        row = self.items.currentRow()
        if 0 <= row < len(self.records):
            self.selected_record = self.records[row]
            self.accept()
