"""Read-only offline checks in background workers. No network, licensing or device IDs."""
import threading
from pathlib import Path
import sys
from PySide6.QtCore import QObject,QRunnable,Signal,QThreadPool
from PySide6.QtWidgets import QDialog,QVBoxLayout,QLabel,QPushButton,QFileDialog,QPlainTextEdit,QHBoxLayout
from integrity import verify_installation,verify_project_file

class CheckSignals(QObject):done=Signal(object,object,str)
class CheckJob(QRunnable):
    def __init__(self,fn,path):super().__init__();self.fn=fn;self.path=path;self.cancelled=threading.Event();self.signals=CheckSignals()
    def run(self):
        try:self.signals.done.emit(self,self.fn(self.path,self.cancelled),'')
        except Exception as e:self.signals.done.emit(self,None,str(e))

class SecurityDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent);self.setWindowTitle('Целостность файлов · DOGFORST');self.resize(650,480);self.job=None;root=QVBoxLayout(self)
        info=QLabel('Проверка SHA-256 обнаруживает изменённые или повреждённые файлы относительно проверочной карты. Она не является подписью издателя и не защищает от замены самой карты. Проверка работает без интернета.');info.setWordWrap(True);root.addWidget(info)
        row=QHBoxLayout();self.install=QPushButton('Проверить программу');self.project=QPushButton('Проверить проект…');self.cancel=QPushButton('Отменить проверку');row.addWidget(self.install);row.addWidget(self.project);row.addWidget(self.cancel);root.addLayout(row)
        self.output=QPlainTextEdit();self.output.setReadOnly(True);root.addWidget(self.output)
        self.install.clicked.connect(lambda:self.start(verify_installation,Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).parent));self.project.clicked.connect(self.choose_project);self.cancel.clicked.connect(self.cancel_check);self.cancel.setEnabled(False)
        close=QPushButton('Закрыть');close.clicked.connect(self.reject);root.addWidget(close)
    def choose_project(self):
        path,_=QFileDialog.getOpenFileName(self,'Проверить проект','','Проекты DOGFORST (*.mpaint)')
        if path:self.start(verify_project_file,path)
    def start(self,fn,path):
        if self.job:return
        self.output.setPlainText('Проверка: '+str(path));self.job=CheckJob(fn,path);self.job.signals.done.connect(self.finished_check)
        self.install.setEnabled(False);self.project.setEnabled(False);self.cancel.setEnabled(True);QThreadPool.globalInstance().start(self.job)
    def finished_check(self,job,result,error):
        if job is not self.job:return
        self.job=None;self.install.setEnabled(True);self.project.setEnabled(True);self.cancel.setEnabled(False)
        if error:self.output.appendPlainText('Проверка не завершена: '+error);return
        text=('Проверено файлов: '+str(result['checked'])+'\n')
        if not result.get('ok'):text+='Обнаружены изменения:\n'+'\n'.join(result.get('errors',[]))
        elif result.get('checksums') is False:text+='Старый проект без таблицы SHA-256. Ресурсы читаются; подлинность не подтверждена.'
        else:text+='Контрольные суммы совпали.'
        self.output.appendPlainText(text+'\nПодпись издателя: не используется в этой поставке.')
    def cancel_check(self):
        if self.job:self.job.cancelled.set()
    def reject(self):self.cancel_check();super().reject()
    def closeEvent(self,event):self.cancel_check();super().closeEvent(event)
