"""Editable layer glow. Render bounded expanded tiles so blur never leaves tile seams."""
import math
import numpy as np
from scipy.ndimage import gaussian_filter,maximum_filter
from PySide6.QtGui import QColor,QImage,QPainter

DEFAULT_GLOW=dict(enabled=True,color='#70caff',radius=18,spread=0,strength=100)

def validate_glow(value):
    if value is None:return None
    if not isinstance(value,dict) or set(value)-set(DEFAULT_GLOW):raise ValueError('Некорректные настройки свечения.')
    result=dict(DEFAULT_GLOW,**value)
    if not isinstance(result['enabled'],bool):raise ValueError('Некорректное состояние свечения.')
    if not isinstance(result['color'],str) or not QColor(result['color']).isValid():raise ValueError('Некорректный цвет свечения.')
    for key,lo,hi in [('radius',1,64),('spread',0,16),('strength',0,300)]:
        number=result[key]
        if isinstance(number,bool) or not isinstance(number,(int,float)) or not math.isfinite(number) or not lo<=number<=hi:raise ValueError('Недопустимый параметр свечения: '+key)
    return result

def active_glow(layer):
    value=getattr(layer,'glow',None)
    return value if value and value.get('enabled') and value.get('strength',0)>0 else None

def glow_margin(value):return math.ceil(value['radius'])+math.ceil(value['spread'])

def apply_glow(image,value):
    if not value or not value['enabled'] or value['strength']==0:return QImage(image)
    rgba=image.convertToFormat(QImage.Format.Format_RGBA8888)
    data=np.frombuffer(rgba.constBits(),dtype=np.uint8).reshape(rgba.height(),rgba.bytesPerLine())[:,:rgba.width()*4].reshape(rgba.height(),rgba.width(),4)
    alpha=data[:,:,3].astype(np.float32)/255
    if not alpha.any():return QImage(image)
    padding=math.ceil(value['spread'])
    if padding:
        alpha=np.pad(alpha,padding,mode='constant')
        alpha=maximum_filter(alpha,size=2*padding+1,mode='constant',cval=0)
    alpha=gaussian_filter(alpha,sigma=value['radius']/3,truncate=3,mode='constant',cval=0)
    if padding:alpha=alpha[padding:-padding,padding:-padding]
    color=QColor(value['color']);opacity=color.alphaF()*value['strength']/100
    pixels=np.empty((image.height(),image.width(),4),dtype=np.uint8)
    pixels[:,:,:3]=(color.red(),color.green(),color.blue());pixels[:,:,3]=np.round(np.clip(alpha*opacity,0,1)*255).astype(np.uint8)
    result=QImage(pixels.data,image.width(),image.height(),image.width()*4,QImage.Format.Format_RGBA8888).copy().convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
    p=QPainter(result)
    try:p.drawImage(0,0,image)
    finally:p.end()
    return result
