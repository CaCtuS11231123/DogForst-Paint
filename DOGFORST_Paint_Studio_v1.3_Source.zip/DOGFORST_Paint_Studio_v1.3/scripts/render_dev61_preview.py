"""Capture real Qt dialogs and canvas display with isolated temporary preferences."""
import sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QPointF
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
import app as module
from dialogs import ShapePicker,ShapeDialog
from shapes import DEFAULT_SHAPE
from brush_panel import BrushDialog
from release_notes import UpdatesDialog

def shot(widget,name):
    widget.show();QTest.qWait(150);assert widget.grab().save(str(ROOT/'reports'/name));widget.hide()

with tempfile.TemporaryDirectory() as temp:
    module.QSettings=lambda *args:QSettings(str(Path(temp)/'settings.ini'),QSettings.Format.IniFormat)
    app=QApplication([]);app.setStyle('Fusion');w=module.MainWindow();w.apply_theme('Dark',False)
    w.show();app.processEvents()
    picker=ShapePicker('Звезда',w);shot(picker,'dev61-shapes.png')
    parameters=ShapeDialog('Звезда',dict(DEFAULT_SHAPE,points=8,filled=True),w);shot(parameters,'dev61-shape-back.png')
    brush=BrushDialog(w.canvas,w);shot(brush,'dev61-brushes.png')
    brush.pick('Мягкая кисть',25);brush.size.setValue(35);shot(brush,'dev61-brush-settings.png')
    w.canvas.new_document(800,520);w.set_checker_style('dark');w.canvas.brush_size=40;w.canvas.brush_hardness=20
    w.canvas.color=QColor('#53b0ec');w.canvas._dab_remaining=0
    w.canvas._stroke(QPointF(80,140),QPointF(500,140));w.canvas.fit_canvas();shot(w,'dev61-dark-canvas.png')
    updates=UpdatesDialog(parent=w);shot(updates,'dev61-updates.png')
    w.dirty=False;w.close()
