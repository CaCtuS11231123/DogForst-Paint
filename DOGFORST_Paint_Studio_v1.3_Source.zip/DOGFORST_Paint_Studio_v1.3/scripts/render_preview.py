"""Generate real UI previews and an editable sample project (for QA)."""
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QPainter,QColor,QPen,QLinearGradient,QPainterPath
from PySide6.QtCore import QPointF,QRectF,Qt,QByteArray,QBuffer,QIODevice
from PySide6.QtTest import QTest
from app import MainWindow
from themes import ThemeDialog
def save_grab(widget,path):
    data=QByteArray();buffer=QBuffer(data)
    assert buffer.open(QIODevice.OpenModeFlag.WriteOnly)
    assert widget.grab().save(buffer,'PNG')
    buffer.close();Path(path).write_bytes(bytes(data))

app=QApplication([]);w=MainWindow();w.show();app.processEvents()
c=w.canvas;c.new_document(960,640)
p=QPainter(c.active.image);g=QLinearGradient(0,0,960,640);g.setColorAt(0,QColor('#0e2342'));g.setColorAt(1,QColor('#32214c'));p.fillRect(c.active.image.rect(),g);p.end();c.active.name='Глубина'
c.add_layer();p=QPainter(c.active.image);p.setRenderHint(QPainter.RenderHint.Antialiasing)
g=QLinearGradient(200,100,700,500);g.setColorAt(0,QColor('#72e5e0'));g.setColorAt(.5,QColor('#4f9afa'));g.setColorAt(1,QColor('#a18bfc'))
p.setBrush(g);p.setPen(Qt.PenStyle.NoPen);p.drawEllipse(QRectF(250,80,460,460))
p.setPen(QPen(QColor('#b3fcf1'),24,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap));path=QPainterPath(QPointF(150,400));path.cubicTo(380,200,480,600,800,250);p.drawPath(path);p.end();c.active.name='Свет и движение'
c.text_objects=[dict(text='CREATE YOUR OWN',x=255,y=270,font='Sans',size=35,bold=True,color='#10243c',rotation=0),dict(text='DOGFORST STUDIO',x=313,y=321,font='Sans',size=24,color='#10243c')]
c.save_project(str(ROOT/'examples'/'Demo.mpaint'))
w.refresh_layers();c.fit_canvas()
for name in ('Dark','Light','Neon','Soft'):
    w.apply_theme(name,False);QTest.qWait(200)
    save_grab(w,ROOT/'reports'/f'interface-{name.lower()}.png')
w.apply_theme('Dark',False)
d=ThemeDialog('Dark',w);d.show();QTest.qWait(200);save_grab(d,ROOT/'reports'/'themes.png');d.hide()
from dialogs import ShapeDialog,ShapePicker,ExportDialog,TextDialog
from shapes import DEFAULT_SHAPE
for name,dialog in [('shape-picker',ShapePicker(parent=w)),('shape-settings',ShapeDialog('Звезда',dict(DEFAULT_SHAPE,filled=True),w)),('export',ExportDialog(w))]:
    dialog.show();QTest.qWait(150);save_grab(dialog,ROOT/'reports'/f'{name}.png');dialog.hide()
# Show actual editable text with the inline inspector and on-canvas handles.
c.text_objects[0].update(color='#ffffff',stroke_color='#152949',stroke_width=2,italic=True)
w.set_tool('Текст');c.select_text(0);QTest.qWait(200);c.fit_canvas();QTest.qWait(100)
save_grab(w,ROOT/'reports'/'text-editing.png')
c.save_project(str(ROOT/'examples'/'Demo.mpaint'))
dialog=TextDialog(c.text_objects[0],w);dialog.show();QTest.qWait(150);save_grab(dialog,ROOT/'reports'/'text-dialog.png');dialog.hide()
w.dirty=False;w.close()
