"""Real Qt shape editing/glow previews and a vector project example."""
import sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,Qt,QPointF,QPoint,QEvent
from PySide6.QtGui import QColor,QMouseEvent
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
import app as module
from dialogs import ShapeDialog,ShapePicker
from shapes import DEFAULT_SHAPE
from glow_dialog import GlowDialog
from raster_objects import clone_object

def shot(w,name):w.show();QTest.qWait(140);assert w.grab().save(str(ROOT/'reports'/name))
def make(w,name,rect,options):
    c=w.canvas;w.set_tool(name);c.shape_options=dict(DEFAULT_SHAPE,**options);c._shape_configured=True
    a=c.screen_point(QPointF(rect[0],rect[1])).toPoint();b=c.screen_point(QPointF(rect[2],rect[3])).toPoint();QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=a);p=QPointF(b);c.mouseMoveEvent(QMouseEvent(QEvent.Type.MouseMove,p,p,Qt.MouseButton.NoButton,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier));QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=b)
with tempfile.TemporaryDirectory() as temp:
    module.QSettings=lambda *a:QSettings(str(Path(temp)/'settings.ini'),QSettings.Format.IniFormat)
    q=QApplication([]);q.setStyle('Fusion');w=module.MainWindow();w.show();q.processEvents();w.apply_theme('Dark',False);c=w.canvas;c.new_document(850,540);c.fit_canvas()
    make(w,'Эллипс',(130,140,430,390),dict(filled=True,fill='#73cadb',stroke='#152c42',stroke_width=12))
    make(w,'Звезда',(400,80,680,360),dict(filled=True,fill='#b997eb',stroke='#152c42',stroke_width=10,points=6,rotation=15))
    c.active.glow=dict(enabled=True,color='#c2a4ff',radius=28,spread=3,strength=150);c.changed.emit();w.refresh_layers();shot(w,'056-vector-workspace.png')
    obj=clone_object(c.raster_objects[c.active.id]);o=dict(obj['shape']['options'],width=obj['width'],height=obj['height'],rotation=obj['rotation']);d=ShapeDialog(obj['shape']['name'],o,w,placement=obj,opacity=100);d.back.hide();shot(d,'056-shape-editor.png');d.reject()
    g=GlowDialog(c.active,c.layer_image(c.active,False),c.doc_size,w);shot(g,'056-layer-glow.png');g.sample_mode.setCurrentIndex(1);g.sample_text.setText('Привет');g.preview.refresh();shot(g,'056-sample-glow.png');g.reject()
    picker=ShapePicker('Звезда',w);shot(picker,'056-shape-picker.png');picker.reject()
    c.save_project(str(ROOT/'examples/Editable_Shapes_056.mpaint'),backup=False);c.export_image(str(ROOT/'reports/056-vector-export.png'));w.dirty=False;w.close()
