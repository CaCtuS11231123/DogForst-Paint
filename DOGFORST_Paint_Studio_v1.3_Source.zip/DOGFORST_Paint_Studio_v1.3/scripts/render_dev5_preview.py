"""Actual Qt blend controls and examples; prior artwork stays untouched."""
import sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QByteArray,QBuffer,QIODevice,QRectF
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QColor,QPainter,QPen
from PySide6.QtTest import QTest
from app import MainWindow
from release_notes import UpdatesDialog
from compositor import render_image
from merge_dialog import MergePreviewDialog


def capture(widget,name):
    widget.show();QTest.qWait(120)
    data=QByteArray();buffer=QBuffer(data)
    assert buffer.open(QIODevice.OpenModeFlag.WriteOnly)
    assert widget.grab().save(buffer,'PNG')
    buffer.close();(ROOT/'reports'/name).write_bytes(bytes(data))


with tempfile.TemporaryDirectory(prefix='dogforst-dev5-preview-') as temp:
    QSettings.setDefaultFormat(QSettings.Format.IniFormat)
    QSettings.setPath(QSettings.Format.IniFormat,QSettings.Scope.UserScope,temp)
    app=QApplication([]);app.setStyle('Fusion')
    w=MainWindow();w.show();app.processEvents();c=w.canvas
    c.load_project(str(ROOT/'examples'/'Groups_Workflow.mpaint'))
    c.set_selected_nodes([c.layers[1].id]);c.add_layer();effect=c.active
    effect.name='Свет · Screen'
    p=QPainter(effect.image);p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(QPen(QColor('#78c9ed'),36));p.drawEllipse(QRectF(320,140,260,260));p.end()
    c.set_selected_blend('screen');effect.opacity=.64
    c.save_project(str(ROOT/'examples'/'Blend_Workflow.mpaint'),backup=False)
    c.export_image(str(ROOT/'reports'/'blend-export.png'))
    w.refresh_layers();w.text_dock.hide();w.apply_theme('Аврора',False);c.fit_canvas()
    capture(w,'blend-interface.png')
    w.layers_dock.setFloating(True);w.layers_dock.resize(470,620)
    capture(w.layers_dock,'blend-panel.png')
    w.blend_choice.showPopup();QTest.qWait(80);capture(w.blend_choice.view().window(),'blend-modes.png');w.blend_choice.hidePopup()
    w.layers_dock.hide()
    original_exec=MergePreviewDialog.exec
    def review(dialog):
        capture(dialog,'merge-blend-preview.png');dialog.hide();return 0
    MergePreviewDialog.exec=review
    try:c.merge_down()
    finally:MergePreviewDialog.exec=original_exec
    updates=UpdatesDialog(parent=w);capture(updates,'updates-dev5.png');updates.hide()
    w.dirty=False;w.close()
