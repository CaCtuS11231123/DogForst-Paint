"""Actual Qt gradient preview, palettes and applied example; temporary preferences."""
import sys,tempfile,time,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,Qt,QPointF,QRectF
from PySide6.QtGui import QPainter,QColor,QFont
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
import app as module
from layers import Layer,transparent_image
from selection_tools import polygon_mask
with tempfile.TemporaryDirectory() as temp:
    module.QSettings=lambda *a:QSettings(str(Path(temp)/'settings.ini'),QSettings.Format.IniFormat)
    q=QApplication([]);q.setStyle('Fusion');w=module.MainWindow();w.show();q.processEvents();w.apply_theme('Dark',False);c=w.canvas
    c.new_document(900,560);c.active.name='Ночной фон';c.active.image.fill(QColor('#152338'));c.add_layer();c.active.name='Открытка · градиент';c.fit_canvas();w.set_tool('Градиент')
    c.set_selection_mask(polygon_mask(c.doc_size,[QPointF(145,90),QPointF(755,90),QPointF(790,420),QPointF(110,420)]));c.start_gradient(QPointF(180,100),QPointF(690,400));c.update_gradient(stops=[(0.,'#ff58d4d3'),(.45,'#ff587add'),(1.,'#ffbc70cd')])
    deadline=time.monotonic()+8
    while c.gradient_session.rendered_version!=c.gradient_session.version and time.monotonic()<deadline:QTest.qWait(10)
    assert c.gradient_session.result is not None and not c.gradient_session.error
    QTest.qWait(150);assert w.grab().save(str(ROOT/'reports/dev10-gradient-preview.png'))
    w.gradient_dock.setFloating(True);w.gradient_dock.resize(540,950);QTest.qWait(100);assert w.gradient_dock.grab().save(str(ROOT/'reports/dev10-gradient-controls.png'));w.gradient_dock.setFloating(False)
    c.apply_gradient();c.cancel_selection();c.add_layer();c.active.name='Радиальный свет';c.start_gradient(QPointF(325,230),QPointF(540,230));c.update_gradient(kind='radial',stops=[(0.,'#b3ffe6b8'),(.45,'#4debb7e0'),(1.,'#00bca9ff')]);deadline=time.monotonic()+8
    while c.gradient_session.rendered_version!=c.gradient_session.version and time.monotonic()<deadline:QTest.qWait(10)
    c.apply_gradient();c.add_layer();c.active.name='Текст · DOGFORST';c.active.kind='text';c.text_objects.append(dict(layer_id=c.active.id,text='DOGFORST',x=225,y=195,size=64,font='Sans',bold=True,color='#ffffff'));c.changed.emit();c.fit_canvas();w.refresh_layers()
    c.save_project(str(ROOT/'examples/Gradient_Workflow.mpaint'),backup=False);c.export_image(str(ROOT/'reports/dev10-gradient-export.png'))
    panel=w.palette_panel;index=panel.store.add_palette('Цвета открытки')
    for value in ['#58d4d3','#587add','#bc70cd','#ffe6b8','#ffffff']:panel.store.add_color(index,value);w.set_color(QColor(value))
    panel.refresh();panel.choice.setCurrentIndex(index);w.palette_dock.show();w.palette_dock.raise_();QTest.qWait(150);assert w.grab().save(str(ROOT/'reports/dev10-palettes.png'))
    (ROOT/'examples/DOGFORST_palettes.json').write_text(json.dumps(dict(format='dogforst-palettes',version=1,palettes=panel.store.palettes),ensure_ascii=False,indent=2),encoding='utf-8')
    w.palette_dock.setFloating(True);w.palette_dock.resize(440,630);QTest.qWait(80);assert w.palette_dock.grab().save(str(ROOT/'reports/dev10-palette-controls.png'))
    w.dirty=False;w.close()
