"""Real Qt preview and editable group example; no changes to previous examples."""
import sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QByteArray,QBuffer,QIODevice
from PySide6.QtWidgets import QApplication,QInputDialog
from PySide6.QtTest import QTest
from app import MainWindow
from release_notes import UpdatesDialog


def capture(widget,name):
    widget.show();QTest.qWait(120)
    data=QByteArray();buffer=QBuffer(data)
    assert buffer.open(QIODevice.OpenModeFlag.WriteOnly)
    assert widget.grab().save(buffer,'PNG')
    buffer.close();(ROOT/'reports'/name).write_bytes(bytes(data))


with tempfile.TemporaryDirectory(prefix='dogforst-dev4-preview-') as temp:
    QSettings.setDefaultFormat(QSettings.Format.IniFormat)
    QSettings.setPath(QSettings.Format.IniFormat,QSettings.Scope.UserScope,temp)
    app=QApplication([]);app.setStyle('Fusion')
    w=MainWindow();w.show();app.processEvents();c=w.canvas
    c.load_project(str(ROOT/'examples'/'Demo.mpaint'))
    ids=[l.id for l in c.layers]
    c.set_selected_nodes(ids[2:]);c.create_group();typography=c.control_node().id
    c.groups[typography].name='Надписи';c.groups[typography].color_label='#6fba9a'
    c.set_selected_nodes([ids[1],typography]);c.create_group();art=c.control_node().id
    c.groups[art].name='Композиция';c.groups[art].color_label='#ad8ed0'
    c.set_current_opacity(88)
    c.layers[0].name='Защищённый фон';c.layers[0].position_locked=True
    c.save_project(str(ROOT/'examples'/'Groups_Workflow.mpaint'),backup=False)
    w.refresh_layers();w.text_dock.hide();w.apply_theme('Аврора',False);c.fit_canvas()
    capture(w,'groups-interface.png')
    # Expand the dock for a second view with all nested rows visible.
    w.layers_dock.setFloating(True);w.layers_dock.resize(470,620)
    w.layer_list.setMaximumHeight(360)
    capture(w.layers_dock,'groups-panel.png')
    c.toggle_group(typography);capture(w.layers_dock,'groups-collapsed.png')
    w.layers_dock.hide()
    dialog=UpdatesDialog(parent=w);capture(dialog,'updates-dev4.png');dialog.hide()
    w.dirty=False;w.close()
