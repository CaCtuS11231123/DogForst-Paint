"""Real Qt captures: glow, photo actions and disabled inputs; isolated preferences."""
import sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,Qt
from PySide6.QtGui import QImage,QColor
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
import app as module
from glow_dialog import GlowDialog
from dialogs import ExportDialog
from effects import DEFAULT_GLOW

def shot(widget,name):
    widget.show();QTest.qWait(170);assert widget.grab().save(str(ROOT/'reports'/name));widget.hide()

with tempfile.TemporaryDirectory() as temp:
    module.QSettings=lambda *a:QSettings(str(Path(temp)/'settings.ini'),QSettings.Format.IniFormat)
    app=QApplication([]);app.setStyle('Fusion');w=module.MainWindow();w.show();app.processEvents();w.apply_theme('Dark',False)
    c=w.canvas;c.new_document(800,500);c.active.name='Фон';c.active.image.fill(QColor('#142033'))
    c.import_object(QImage(str(ROOT/'assets/DOGFORST_Handdrawn.png')),'Картинка · DOGFORST')
    obj=dict(c.raster_objects[c.active.id]);obj.update(x=330.,y=35.,width=140.,height=140.);c.set_object(c.active,obj)
    c.add_layer();c.active.name='Текст · DOGFORST';c.active.kind='text'
    c.text_objects=[dict(text='DOGFORST',x=145,y=225,font='Segoe UI',size=74,bold=True,color='#ffffff',stroke_width=1,stroke_color='#70caff',layer_id=c.active.id)]
    c.active.glow=dict(DEFAULT_GLOW,radius=26,spread=2,strength=170,color='#4dc8ff');c.set_selected_nodes({c.active.id});c.selected_text=0;c.changed.emit()
    w.set_tool('Перемещение');w.text_dock.hide();c.fit_canvas();w.refresh_layers()
    c.save_project(str(ROOT/'examples/Glow_Workflow.mpaint'),backup=False);c.export_image(str(ROOT/'reports/dev71-glow-export.png'))
    shot(w,'dev71-main.png')
    dialog=GlowDialog(c.active,c.layer_image(c.active,False),c.doc_size,w);shot(dialog,'dev71-glow.png')
    dialog.enabled.setChecked(False);shot(dialog,'dev71-glow-disabled.png')
    export=ExportDialog(w);shot(export,'dev71-export-png-dark.png');export.format.setCurrentIndex(1);shot(export,'dev71-export-jpg-dark.png')
    w.apply_theme('Light',False);export=ExportDialog(w);shot(export,'dev71-export-png-light.png');export.format.setCurrentIndex(1);shot(export,'dev71-export-jpg-light.png')
    w.apply_theme('Dark',False);c.select_text(0);c.set_selected_flag('locked',True)
    w.text_dock.setFloating(True);w.text_dock.resize(490,760);shot(w.text_dock,'dev71-text-locked.png')
    w.dirty=False;w.close()
