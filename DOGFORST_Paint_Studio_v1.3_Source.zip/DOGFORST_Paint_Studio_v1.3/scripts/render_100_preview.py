"""Render real Qt views and a small editable project for the 1.00 release."""
import sys,tempfile,time,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QPointF,QRectF,Qt
from PySide6.QtGui import QPainter,QPen,QColor,QLinearGradient,QFont
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
import app as module
from layers import transparent_image
from security_dialog import SecurityDialog
from release_notes import UpdatesDialog

def shot(widget,name):
    widget.show();QTest.qWait(120);assert widget.grab().save(str(ROOT/'reports'/name))
def finish(c):
    c.finish_retouch();end=time.monotonic()+20
    while c.retouch_session and time.monotonic()<end:QTest.qWait(10)
    assert c.retouch_session is None

def specimen():
    image=transparent_image(900,540);p=QPainter(image);p.setRenderHint(QPainter.RenderHint.Antialiasing)
    gradient=QLinearGradient(0,0,900,540);gradient.setColorAt(0,QColor('#142d46'));gradient.setColorAt(1,QColor('#344054'));p.fillRect(image.rect(),gradient)
    p.setPen(Qt.PenStyle.NoPen)
    for i in range(9):
        p.setBrush(QColor('#81cfd2' if i%2 else '#a7a1ed'));x=100+i*81;p.drawEllipse(QRectF(x-22,160+math.sin(i*.9)*43,68,68))
    p.setPen(QColor('#eff6fc'));f=QFont('Sans',28);f.setBold(True);p.setFont(f);p.drawText(QPointF(68,88),'DOGFORST  /  1.00');f.setPixelSize(17);f.setBold(False);p.setFont(f);p.setPen(QColor('#b8c9df'));p.drawText(QPointF(70,124),'РЕТУШЬ  •  СЛОИ  •  ВАШИ ИДЕИ')
    p.setPen(QPen(QColor('#e9f0fa'),2));p.drawLine(72,326,825,326);p.setPen(QColor('#cedced'));p.drawText(QPointF(72,368),'Размытие  /  Палец  /  Штамп');p.drawText(QPointF(72,405),'Источник — Alt + нажатие. Отмена — Ctrl + Z.');p.end();return image

with tempfile.TemporaryDirectory() as tmp:
    module.QSettings=lambda *a:QSettings(str(Path(tmp)/'settings.ini'),QSettings.Format.IniFormat)
    q=QApplication([]);q.setStyle('Fusion');w=module.MainWindow();w.resize(1480,950);w.show();q.processEvents();w.apply_theme('Dark',False);c=w.canvas;c.new_document(900,540);c.import_object(specimen(),'Оригинал · дублируйте для ретуши');c.fit_canvas();w.refresh_layers()
    c.duplicate_layer();c.active.name='Ретушь · размытие и палец';w.set_tool('Размытие');c.brush_size=95;c.retouch_options.update(strength=65,hardness=60)
    assert c.start_retouch(QPointF(265,210));c.queue_retouch(QPointF(570,200));finish(c)
    w.set_tool('Палец');c.brush_size=62;assert c.start_retouch(QPointF(630,178));c.queue_retouch(QPointF(730,265));finish(c)
    c.add_layer();c.active.kind='text';c.active.name='Подпись · редактируемый текст';c.text_objects.append(dict(text='Собственный стиль. Свои инструменты.',x=70,y=453,size=20,color='#a9dfe6',layer_id=c.active.id));c.changed.emit();w.refresh_layers()
    c.save_project(str(ROOT/'examples/Retouch_Workflow_100.mpaint'),backup=False);c.export_image(str(ROOT/'reports/100-retouch-export.png'))
    c.set_selected_nodes({c.layers[2].id},c.layers[2].id);w.set_tool('Штамп');c.set_clone_source(QPointF(190,200));w.size_spin.setValue(c.brush_size);w.refresh_layers();w.retouch_panel.refresh();shot(w,'100-retouch-workspace.png')
    d=SecurityDialog(w);d.install.click();end=time.monotonic()+10
    while d.job and time.monotonic()<end:QTest.qWait(10)
    assert d.job is None and 'Контрольные суммы совпали' in d.output.toPlainText();shot(d,'100-integrity.png');d.reject()
    d=UpdatesDialog(parent=w);shot(d,'100-release-history.png');d.reject();w.dirty=False;w.close()
