"""Measure sparse brush tiles and opacity on a large document without GUI test assertions."""
import sys,tempfile,time,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QPointF
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication
import app as module
with tempfile.TemporaryDirectory() as temp:
    module.QSettings=lambda *a:QSettings(str(Path(temp)/'settings.ini'),QSettings.Format.IniFormat)
    q=QApplication([]);q.setStyle('Fusion');w=module.MainWindow();c=w.canvas;c.new_document(3200,2200);c.brush_size=512;c.brush_opacity=40;c.brush_stabilizer=0;c.color=QColor('red');c.drawing=True;c._stroke_history_started=False
    start=time.monotonic();c._stroke(QPointF(-300,1000),QPointF(-300,1000));c._stroke(QPointF(-300,1000),QPointF(3500,1000));c._stroke(QPointF(3500,1000),QPointF(-300,1000));elapsed=time.monotonic()-start;ink=c._ink_stroke
    assert abs(c.active.image.pixelColor(1600,1000).alpha()-102)<=1
    report=dict(canvas=[3200,2200],diameter=512,opacity=40,tiles=len(ink.tiles),ink_tile_bytes=sum(i.sizeInBytes() for i in ink.tiles.values()),full_canvas_bytes=c.active.image.sizeInBytes(),three_segments_seconds=round(elapsed,3),center_alpha=c.active.image.pixelColor(1600,1000).alpha(),platform='Linux, local measurement; not a Windows performance promise')
    assert report['ink_tile_bytes']<report['full_canvas_bytes'];(ROOT/'reports/benchmark-055-brush.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));c._ink_stroke=None;c.drawing=False;w.dirty=False;w.close()
