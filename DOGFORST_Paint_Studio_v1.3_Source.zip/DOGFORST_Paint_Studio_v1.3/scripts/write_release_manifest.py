"""Generate a reviewable SHA-256 manifest after code/build changes (not a signature)."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from release_notes import CURRENT_VERSION
from integrity import file_digest

def write_manifest(root,mode='source'):
    root=Path(root).resolve()
    if mode=='source':files=list(root.glob('*.py'))+list((root/'assets').rglob('*'))
    else:files=list(root.rglob('*'))
    files=sorted(p for p in files if p.is_file() and p.name!='release_integrity.json' and '__pycache__' not in p.parts)
    if mode=='source':critical=[p.relative_to(root).as_posix() for p in files]
    else:critical=[p.relative_to(root).as_posix() for p in files if p.parent==root or 'assets' in p.parts]
    value=dict(format='dogforst-release-sha256',schema=1,version=CURRENT_VERSION,mode=mode,critical=critical,files={p.relative_to(root).as_posix():dict(size=p.stat().st_size,sha256=file_digest(p)) for p in files})
    (root/'release_integrity.json').write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');return len(files)
if __name__=='__main__':
    root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT;mode='frozen' if len(sys.argv)>2 and sys.argv[2]=='frozen' else 'source';print(f'{write_manifest(root,mode)} files: {root}/release_integrity.json')
