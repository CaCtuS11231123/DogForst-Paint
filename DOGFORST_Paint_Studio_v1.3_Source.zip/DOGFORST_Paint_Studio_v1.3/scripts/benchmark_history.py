"""Separate-process Linux measurements. No Windows performance claim is made."""
import argparse
import gc
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time


def child(root, width, height, actions):
    sys.path.insert(0, str(Path(root).resolve()))
    import resource
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QPointF
    from PySide6.QtGui import QColor
    from canvas import PaintCanvas
    app = QApplication([])
    c = PaintCanvas()
    c.new_document(width, height)
    c.history.clear(); c.future.clear()
    c.brush_size = 12; c.color = QColor('#10cc77')
    gc.collect()
    before_rss = int(Path('/proc/self/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
    elapsed = []
    for i in range(actions):
        point = QPointF(20+(i*61) % (width-80), 20+(i*47) % (height-80))
        start = time.perf_counter()
        c.push_history(); c._stroke(point, point+QPointF(31,16)); c.changed.emit()
        if hasattr(c, 'commit_history'):
            c.commit_history(force=True)
        app.processEvents()
        elapsed.append((time.perf_counter()-start)*1000)
    retained = len(c.history)
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
    rss = int(Path('/proc/self/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
    final = hashlib.sha256(bytes(c.active.image.constBits())).hexdigest()
    if hasattr(c, 'history_engine'):
        stored = c.history_engine.statistics()['estimated_bytes']
    else:
        unique = {layer[1].cacheKey():layer[1].sizeInBytes()
                  for snapshot in c.history for layer in snapshot['layers']}
        stored = sum(unique.values())
    for _ in range(retained): c.undo()
    for _ in range(retained): c.redo()
    assert hashlib.sha256(bytes(c.active.image.constBits())).hexdigest() == final
    return dict(size=[width,height], actions=actions, retained=retained, initial_rss_bytes=before_rss,
        retained_rss_bytes=rss, peak_rss_bytes=peak, history_estimated_bytes=stored,
        median_action_ms=round(statistics.median(elapsed),3), max_action_ms=round(max(elapsed),3),
        image_sha256=final, undo_redo_roundtrip=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--child', action='store_true')
    parser.add_argument('--root')
    parser.add_argument('--baseline')
    parser.add_argument('--output')
    parser.add_argument('--width', type=int, default=2048)
    parser.add_argument('--height', type=int, default=2048)
    parser.add_argument('--actions', type=int, default=12)
    args = parser.parse_args()
    if args.child:
        print(json.dumps(child(args.root,args.width,args.height,args.actions)))
    else:
        result = dict(platform=sys.platform, python=sys.version.split()[0],
            note='Separate offscreen processes, small raster strokes on one initially transparent layer; time includes compaction, not window rendering.', cases=[])
        for width,height,actions in [(2048,2048,12),(3840,2160,6)]:
            case = dict(size=[width,height])
            for label,root in [('dev1',args.baseline),('dev2',Path(__file__).resolve().parents[1])]:
                command=[sys.executable,__file__,'--child','--root',str(root),'--width',str(width),'--height',str(height),'--actions',str(actions)]
                process=subprocess.run(command,check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                    env=dict(os.environ,QT_QPA_PLATFORM='offscreen'))
                case[label]=json.loads(process.stdout)
            assert case['dev1']['image_sha256']==case['dev2']['image_sha256']
            assert case['dev1']['retained']==case['dev2']['retained']
            result['cases'].append(case)
        Path(args.output).write_text(json.dumps(result,indent=2))
        print(json.dumps(result,indent=2))
