"""Repeatable UI heartbeat check for a soft selection on a large canvas."""
import sys,json,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QTimer,QPointF,QRectF
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
from PySide6.QtGui import QImage
import app as module
with tempfile.TemporaryDirectory() as temp:
    module.QSettings=lambda *a:QSettings(str(Path(temp)/'settings.ini'),QSettings.Format.IniFormat)
    q=QApplication([]);q.setStyle('Fusion');w=module.MainWindow();w.show();q.processEvents();c=w.canvas;c.new_document(3200,2200);c.selection=QRectF(0,0,3200,2200);mask=QImage(3200,2200,QImage.Format.Format_Grayscale8);mask.fill(128);c.selection_mask=mask
    ticks=[];timer=QTimer();timer.setInterval(10);timer.timeout.connect(lambda:ticks.append(time.monotonic()));timer.start()
    key=c.active.image.cacheKey();t=time.monotonic();assert c.start_gradient(QPointF(0,0),QPointF(3200,2200));c.update_gradient(kind='radial');deadline=t+30
    while time.monotonic()<deadline:
        s=c.gradient_session
        if s.error:raise RuntimeError(s.error)
        if s.rendered_version==s.version:break
        QTest.qWait(10)
    assert c.gradient_session.result is not None and c.active.image.cacheKey()==key
    elapsed=time.monotonic()-t;timer.stop();assert len(ticks)>=2
    report=dict(canvas=[3200,2200],soft_selection=True,preview_seconds=round(elapsed,3),ui_heartbeat_count=len(ticks),max_heartbeat_gap_ms=round(max((b-a for a,b in zip(ticks,ticks[1:])),default=0)*1000,1),original_model_unchanged=True,platform='Linux Qt offscreen; not a Windows performance guarantee')
    c.cancel_gradient();assert c.active.image.cacheKey()==key
    (ROOT/'reports/benchmark-gradients-dev10.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));w.dirty=False;w.close()
