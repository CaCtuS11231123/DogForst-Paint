"""Real Qt dialog snapshots for this development checkpoint."""
import sys
import uuid
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from PySide6.QtCore import QByteArray, QBuffer, QIODevice, QTimer
from PySide6.QtGui import QColor
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from app import MainWindow
from recovery import DocumentSnapshot
from safety_dialogs import SafetySettingsDialog, ProjectCopiesDialog, SaveProgressDialog
import project_manager


def save_grab(widget, path):
    widget.show()
    QTest.qWait(100)
    data = QByteArray()
    buffer = QBuffer(data)
    assert buffer.open(QIODevice.OpenModeFlag.WriteOnly)
    assert widget.grab().save(buffer, 'PNG')
    buffer.close()
    Path(path).write_bytes(bytes(data))
    widget.hide()


app = QApplication([])
window = MainWindow()
window.apply_theme('Dark', False)
window.show()
app.processEvents()
safety = window._safety
settings = SafetySettingsDialog(True, 2, 10, safety.root, window)
save_grab(settings, ROOT / 'reports' / 'safety-settings.png')
window.canvas.new_document(240, 160)
window.canvas.active.image.setPixelColor(20, 20, QColor('red'))
session = uuid.uuid4().hex
record = safety.store.write(DocumentSnapshot.capture(window.canvas), session, 1,
                            'Мои рисунки/Иллюстрация.mpaint')
recovery = ProjectCopiesDialog([record], window)
save_grab(recovery, ROOT / 'reports' / 'recovery-dialog.png')
versions = ProjectCopiesDialog([record], window, 'Предыдущие версии проекта')
save_grab(versions, ROOT / 'reports' / 'versions-dialog.png')
safety.store.discard_session(session)
release = threading.Event()
original = project_manager.png_bytes

def paused(image):
    release.wait(2)
    return original(image)

def capture_save_dialog():
    try:
        dialog = next(w for w in app.topLevelWidgets() if isinstance(w, SaveProgressDialog))
        save_grab(dialog, ROOT / 'reports' / 'save-progress.png')
    finally:
        release.set()

project_manager.png_bytes = paused
window.current_file = str(safety.root / 'Preview.mpaint')
QTimer.singleShot(40, capture_save_dialog)
try:
    assert window.save_project()
finally:
    release.set()
    project_manager.png_bytes = original
window.dirty = False
window.close()
