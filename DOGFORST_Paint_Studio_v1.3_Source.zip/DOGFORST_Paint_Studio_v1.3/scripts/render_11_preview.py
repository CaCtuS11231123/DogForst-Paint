"""Real Qt screenshots, correction comparison and a project with preserved original."""
import sys,time,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QPointF,QRectF,Qt
from PySide6.QtGui import QPainter,QColor,QLinearGradient,QPolygonF,QPen,QFont
from PySide6.QtWidgets import QApplication,QTabWidget
from PySide6.QtTest import QTest
import app as module
from layers import transparent_image
from adjustment_dialog import AdjustmentDialog
from release_notes import UpdatesDialog

def ready(c):
    deadline=time.monotonic()+20
    while c.adjustment_session and c.adjustment_session.rendered_version!=c.adjustment_session.version and time.monotonic()<deadline:QTest.qWait(10)
    assert c.adjustment_session and c.adjustment_session.rendered_version==c.adjustment_session.version and not c.adjustment_session.error

def shot(widget,name):widget.show();QTest.qWait(100);assert widget.grab().save(str(ROOT/'reports'/name))

def landscape():
    image=transparent_image(900,560);p=QPainter(image);p.setRenderHint(QPainter.RenderHint.Antialiasing);gradient=QLinearGradient(0,0,0,560);gradient.setColorAt(0,QColor('#708fc2'));gradient.setColorAt(.55,QColor('#d6bbac'));gradient.setColorAt(1,QColor('#537f9b'));p.fillRect(image.rect(),gradient);p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#f5ddad'));p.drawEllipse(QRectF(635,76,88,88))
    for color,points in [('#7a8caa',[(0,320),(105,205),(173,257),(328,105),(464,272),(610,180),(900,320)]),('#4a708c',[(0,390),(200,258),(320,325),(480,222),(660,365),(798,260),(900,375)])]:p.setBrush(QColor(color));p.drawPolygon(QPolygonF([QPointF(*pt) for pt in points+[(900,560),(0,560)]]))
    p.setBrush(QColor('#416a7b'));p.drawPolygon(QPolygonF([QPointF(0,390),QPointF(230,360),QPointF(565,560),QPointF(0,560)]));p.setPen(QPen(QColor('#aac9cf'),2))
    for i in range(18):p.drawLine(350+i*5,380+i*8,820-i*4,380+i*8)
    for x,y,h in [(76,359,127),(133,391,155),(230,413,112),(795,355,126),(846,385,183)]:
        p.setPen(QPen(QColor('#284c58'),5));p.drawLine(x,y,x,y-h)
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#315b63'));p.drawPolygon(QPolygonF([QPointF(x-32,y-18),QPointF(x,y-h),QPointF(x+32,y-18)]))
    p.setPen(QColor('#f4f0e8'));p.setFont(QFont('Sans',16));p.drawText(34,36,'DOGFORST  /  COLOUR STUDY');p.end();return image

with tempfile.TemporaryDirectory() as tmp:
    module.QSettings=lambda *a:QSettings(str(Path(tmp)/'settings.ini'),QSettings.Format.IniFormat)
    q=QApplication([]);q.setStyle('Fusion');w=module.MainWindow();w.show();q.processEvents();w.apply_theme('Dark',False);c=w.canvas;c.new_document(900,560);c.import_object(landscape(),'Оригинал · сохранён');c.export_image(str(ROOT/'reports/11-before.png'));original=c.active.id;c.duplicate_layer();c.active.name='Результат · цвет и виньетка';c.fit_canvas()
    assert c.start_adjustment();d=AdjustmentDialog(w);d.show();c.update_adjustment(temperature=24,contrast=12,saturation=15,gamma=110,effect='vignette',amount=40);ready(c);d.findChild(QTabWidget).setCurrentIndex(1);shot(d,'11-colour-dialog.png');d.findChild(QTabWidget).setCurrentIndex(2);d.background.setCurrentIndex(1);shot(d,'11-filters-dialog.png');c.apply_adjustment();d.deleteLater();c.node(original).visible=False;c.changed.emit();c.save_project(str(ROOT/'examples/Colour_Workflow_11.mpaint'),backup=False);c.export_image(str(ROOT/'reports/11-after.png'));w.refresh_layers();shot(w,'11-colour-workspace.png')
    d=UpdatesDialog(parent=w);shot(d,'11-updates.png');d.reject();w.dirty=False;w.close()
