"""Real background stroke, with Qt heartbeat and unmodified model during preview."""
import sys,time,json,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QPointF,QTimer,QRectF
from PySide6.QtGui import QPainter,QColor
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
import app as module
with tempfile.TemporaryDirectory() as tmp:
    module.QSettings=lambda *a:QSettings(str(Path(tmp)/'settings.ini'),QSettings.Format.IniFormat)
    q=QApplication([]);w=module.MainWindow();c=w.canvas;c.new_document(3000,2000);c.zoom=.3;p=QPainter(c.active.image);p.fillRect(300,300,1200,1000,QColor('#db6387'));p.fillRect(1500,300,1000,1000,QColor('#498ac2'));p.end();before=c.active.image.copy();c.commit_history(force=True);c.history.clear();c.future.clear();w.set_tool('Размытие');c.brush_size=300;c.retouch_options['strength']=65
    ticks=[];timer=QTimer();timer.setInterval(10);timer.timeout.connect(lambda:ticks.append(time.perf_counter()));timer.start();t=time.perf_counter();c.start_retouch(QPointF(1500,300));c.queue_retouch(QPointF(1500,1000));deadline=t+30
    while c._retouch_job is not None or c.retouch_session.points:
        assert time.perf_counter()<deadline;assert c.active.image==before;QTest.qWait(5)
    processed=c.retouch_session.processed;assert c.retouch_session.changes>0 and c.active.image==before;c.finish_retouch()
    while c.retouch_session is not None:assert time.perf_counter()<deadline;QTest.qWait(5)
    timer.stop();assert c.active.image!=before and len(c.history)==1
    report=dict(document=[3000,2000],diameter=300,processed_points=processed,seconds=round(time.perf_counter()-t,4),heartbeat_ticks=len(ticks),maximum_heartbeat_gap_ms=round(max([b-a for a,b in zip(ticks,ticks[1:])]+[0])*1000,2),original_unchanged_until_apply=True,one_undo=True,platform='Linux, Qt offscreen; measurement only, no Windows FPS claim')
    (ROOT/'reports/benchmark-100-retouch.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));w.dirty=False;w.close()
