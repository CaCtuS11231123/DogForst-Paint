"""Real Qt previews with temporary preferences and a separate editable texture example."""
import sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QPointF,Qt,QRectF
from PySide6.QtGui import QColor,QPainter,QPen,QImage
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
import app as module
from image_dialogs import PlacementDialog,ImportChoice
from brush_panel import BrushDialog
from layers import transparent_image
from release_notes import UpdatesDialog

def shot(widget,name):
    widget.show();QTest.qWait(180);assert widget.grab().save(str(ROOT/'reports'/name));widget.hide()

with tempfile.TemporaryDirectory() as temp:
    module.QSettings=lambda *args:QSettings(str(Path(temp)/'settings.ini'),QSettings.Format.IniFormat)
    app=QApplication([]);app.setStyle('Fusion');w=module.MainWindow();w.show();app.processEvents();w.apply_theme('Dark',False)
    c=w.canvas;c.load_project(str(ROOT/'examples/Blend_Workflow.mpaint'))
    # Procedural original pattern (not a supplied photo), placed as its own editable texture layer.
    texture=transparent_image(48,48);texture.fill(QColor('#eef6ff'));p=QPainter(texture)
    p.setPen(QPen(QColor('#53aacc'),3));p.drawLine(0,0,48,48);p.drawLine(-24,0,24,48);p.drawLine(24,0,72,48);p.end()
    c.import_object(texture,'Своя текстура · узор',True);obj=dict(c.raster_objects[c.active.id]);obj.update(x=120.,y=100.,width=520.,height=260.,rotation=-12.,tile_scale=75.)
    c.set_object(c.active,obj,opacity=.32,blend='screen');w.set_tool('Перемещение');w.refresh_layers();c.fit_canvas()
    c.save_project(str(ROOT/'examples/Texture_Workflow.mpaint'),backup=False)
    c.export_image(str(ROOT/'reports/dev7-texture-export.png'))
    shot(w,'dev7-layer-transform.png')
    placement=PlacementDialog(obj,c.doc_size,c.active,w);shot(placement,'dev7-image-settings.png')
    brush=BrushDialog(c,w);brush.pick('Кисть',None);brush.size.setValue(32);brush.color.color=QColor('#ee6994');brush.color.refresh();brush.outline_check.setChecked(True);brush.outline.setValue(3)
    shot(brush,'dev7-brush-editor.png')
    choice=ImportChoice(['Моя фотография.jpg'],w);shot(choice,'dev7-import-choice.png')
    updates=UpdatesDialog(parent=w);shot(updates,'dev7-updates.png')
    w.dirty=False;w.close()
