"""Capture real Qt clipping/selection controls and a v10 example, with temporary preferences."""
import sys,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,Qt,QPointF,QRectF
from PySide6.QtGui import QPainter,QColor,QLinearGradient,QPen
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
import app as module
from layers import transparent_image
from selection_tools import polygon_mask
from release_notes import UpdatesDialog

def shot(widget,name):
    widget.show();QTest.qWait(60)
    if isinstance(widget,module.MainWindow) and widget.canvas.tool in ('Лассо','Выделение','Волшебная палочка'):widget.show_selection_panel()
    QTest.qWait(180);assert widget.grab().save(str(ROOT/'reports'/name));
    if not isinstance(widget,module.MainWindow):widget.hide()

with tempfile.TemporaryDirectory() as temp:
    module.QSettings=lambda *a:QSettings(str(Path(temp)/'settings.ini'),QSettings.Format.IniFormat)
    app=QApplication([]);app.setQuitOnLastWindowClosed(False);app.setStyle('Fusion');w=module.MainWindow();w.show();app.processEvents();w.apply_theme('Dark',False);c=w.canvas
    c.load_project(str(ROOT/'examples/Glow_Workflow.mpaint'))
    base=next(l for l in c.layers if l.kind=='text');c.set_selected_nodes({base.id})
    pattern=transparent_image(160,80);p=QPainter(pattern);gradient=QLinearGradient(0,0,160,80)
    for at,color in [(0,'#57d9ef'),(.45,'#ae8cfa'),(1,'#fa85b4')]:gradient.setColorAt(at,QColor(color))
    p.fillRect(pattern.rect(),gradient);p.setPen(QPen(QColor(255,255,255,120),4));p.drawLine(0,60,160,5);p.end()
    c.import_object(pattern,'Текстура · обтравка',True);c.set_clipping(True);w.set_tool('Перемещение');c.fit_canvas();w.refresh_layers()
    c.save_project(str(ROOT/'examples/Clipping_Workflow.mpaint'),backup=False);c.export_image(str(ROOT/'reports/dev8-clipping-export.png'))
    shot(w,'dev8-clipping.png')
    c.set_selection_mask(polygon_mask(c.doc_size,[QPointF(110,190),QPointF(690,200),QPointF(620,360),QPointF(170,330)]))
    w.set_tool('Лассо');c.fit_canvas();shot(w,'dev8-polygon-selection.png')
    w.selection_dock.setFloating(True);w.selection_dock.resize(420,650);shot(w.selection_dock,'dev8-selection-controls.png');w.selection_dock.setFloating(False);w.selection_dock.hide()
    w.dirty=False;w.close();w=module.MainWindow();w.show();QTest.qWait(100);c=w.canvas
    c.new_document(640,420);c.active.image.fill(QColor('#e8f1fb'));p=QPainter(c.active.image);p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#6787e9'));p.drawEllipse(QRectF(160,80,250,250));p.setBrush(QColor('#ec8fc0'));p.drawRoundedRect(QRectF(345,170,150,140),20,20);p.end()
    w.set_tool('Волшебная палочка');c.select_wand(QPointF(40,40),Qt.KeyboardModifier.NoModifier)
    deadline=time.monotonic()+5
    while c.wand_job is not None and time.monotonic()<deadline:QTest.qWait(10)
    assert c.wand_job is None and c.selection_mask is not None
    c.fit_canvas();shot(w,'dev8-wand.png')
    updates=UpdatesDialog(parent=w);shot(updates,'dev8-updates.png');w.dirty=False;w.close()
