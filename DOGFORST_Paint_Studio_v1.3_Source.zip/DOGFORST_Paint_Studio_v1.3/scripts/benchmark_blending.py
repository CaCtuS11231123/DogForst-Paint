"""Small repeatable offscreen CPU composition benchmark, not a Windows FPS test."""
import sys,json,time,statistics,platform
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QColor,QPainter,QLinearGradient
from canvas import PaintCanvas
from layers import Layer,transparent_image

app=QApplication([]);results=[]
for size in [(1200,800),(2048,2048)]:
    c=PaintCanvas();c.new_document(*size);c.layers=[]
    for i in range(5):
        image=transparent_image(*size);p=QPainter(image);g=QLinearGradient(0,0,*size)
        g.setColorAt(0,QColor(20+i*30,80+i*20,170-i*20,140+i*20))
        g.setColorAt(1,QColor(180-i*20,90+i*20,40+i*20,220-i*20))
        p.fillRect(image.rect(),g);p.end();c.layers.append(Layer(f'Layer {i}',image))
    c.active_layer=4;c.sync_groups();c.history.clear();c.future.clear()
    for mode in ('normal','multiply','screen'):
        for layer in c.layers[1:]:layer.blend_mode=mode
        times=[]
        for _ in range(3):
            start=time.perf_counter();image=c.composite_image();times.append((time.perf_counter()-start)*1000)
            assert not image.isNull()
        results.append(dict(size=size,layers=5,upper_mode=mode,median_ms=round(statistics.median(times),2),max_ms=round(max(times),2)))
    c.deleteLater()
data=dict(platform=platform.system(),python=platform.python_version(),note='Three complete image compositions per case; includes result allocation, excludes window painting/export encoding and history.',results=results)
(ROOT/'reports'/'blend_benchmark.json').write_text(json.dumps(data,indent=2))
print(json.dumps(data,indent=2))
