"""Capture actual 0.55 Qt controls and create an applied brush example."""
import sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,Qt,QPointF,QPoint,QTimer
from PySide6.QtGui import QColor,QPainter,QFont,QMouseEvent
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
import app as module
from brush_panel import BrushDialog
from tool_settings import FillSettingsDialog

def shot(widget,name):
    widget.show();QTest.qWait(160);assert widget.grab().save(str(ROOT/'reports'/name))

def paint(c,points):
    QTest.mousePress(c,Qt.MouseButton.LeftButton,pos=QPoint(*points[0]))
    for p in points[1:]:
        from PySide6.QtCore import QEvent
        point=QPointF(*p);c.mouseMoveEvent(QMouseEvent(QEvent.Type.MouseMove,point,point,Qt.MouseButton.NoButton,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier))
    QTest.mouseRelease(c,Qt.MouseButton.LeftButton,pos=QPoint(*points[-1]))
with tempfile.TemporaryDirectory() as temp:
    module.QSettings=lambda *a:QSettings(str(Path(temp)/'settings.ini'),QSettings.Format.IniFormat)
    q=QApplication([]);q.setStyle('Fusion');w=module.MainWindow();w.show();q.processEvents();w.apply_theme('Dark',False);c=w.canvas
    c.new_document(780,480);c.pan=QPointF(35,65);c.zoom=1.;w.set_tool('Кисть');w.set_checker_style('dark');c.brush_stabilizer=0;c.brush_size=130;c.brush_opacity=42;c.color=QColor('#7acde0')
    paint(c,[(5,200),(160,200),(560,200),(160,200),(840,200)]);c.active.name='Один штрих · 42%'
    c.add_layer();c.active.name='Мягкая кисть';w.set_tool('Мягкая кисть');c.brush_size=150;c.brush_opacity=55;c.brush_hardness=15;c.color=QColor('#bd8fe5');paint(c,[(100,380),(300,330),(500,380),(740,350)])
    c.add_layer();c.active.name='Подписи';c.active.kind='text';c.text_objects.append(dict(layer_id=c.active.id,text='DOGFORST 0.55',x=90,y=40,size=44,font='Sans',bold=True,color='#e8f2ff'));c.changed.emit();c.fit_canvas();w.refresh_layers();shot(w,'055-brush-workspace.png')
    c.save_project(str(ROOT/'examples/Brush_Workspace_055.mpaint'),backup=False);c.export_image(str(ROOT/'reports/055-brush-export.png'))
    dialog=BrushDialog(c,w);dialog.pick('Кисть',None);dialog.spacing.setValue(12);dialog.flow.setValue(60);dialog.opacity.setValue(42);shot(dialog,'055-brush-settings.png');dialog.reject()
    fill=FillSettingsDialog(c,w);shot(fill,'055-fill-settings.png');fill.reject()
    w.layers_dock.setFloating(True);w.layers_dock.resize(440,640);shot(w.layers_dock,'055-layers-background.png');w.layers_dock.setFloating(False)
    menu=w.transparency_menu();menu.popup(QPoint(450,180));shot(menu,'055-transparency-menu.png');menu.close()
    menu=w.workspace_menu();menu.popup(QPoint(450,180));shot(menu,'055-workspace-menu.png');menu.close()
    w.panels_menu.popup(QPoint(450,180));shot(w.panels_menu,'055-panels-menu.png');w.panels_menu.close()
    w.restore_default_layout();w.dirty=False;w.close()
