"""Fail early when PyInstaller's installed bootloader is unavailable."""
import sys
from pathlib import Path

def main():
    try:
        import PyInstaller
        name='runw.exe' if sys.platform=='win32' else 'run'
        path=Path(PyInstaller.__file__).resolve().parent/'bootloader'/PyInstaller.PLATFORM/name
        if not path.is_file():
            print('PyInstaller bootloader is missing: '+str(path))
            print('Repair the installed build tool with:')
            print('"'+sys.executable+'" -m pip install --force-reinstall --no-cache-dir --no-deps --only-binary=:all: --index-url https://pypi.org/simple pyinstaller==6.22.3')
            print('If it disappears again, inspect your Windows Security protection history.');return 2
        print('PyInstaller bootloader found: '+str(path));return 0
    except Exception as error:print('Build environment check failed: '+str(error));return 2
if __name__=='__main__':sys.exit(main())
