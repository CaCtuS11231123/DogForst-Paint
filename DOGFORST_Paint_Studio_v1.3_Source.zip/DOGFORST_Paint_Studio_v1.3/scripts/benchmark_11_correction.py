"""One real 6 MP background correction with Qt heartbeat and immutable model."""
import sys,time,tempfile,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QTimer,QEventLoop
from PySide6.QtGui import QPainter,QColor,QLinearGradient
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
import app as module
with tempfile.TemporaryDirectory() as tmp:
    module.QSettings=lambda *a:QSettings(str(Path(tmp)/'settings.ini'),QSettings.Format.IniFormat)
    q=QApplication([]);w=module.MainWindow();c=w.canvas;c.new_document(3000,2000);p=QPainter(c.active.image);g=QLinearGradient(0,0,3000,2000);g.setColorAt(0,QColor('#6a8cba'));g.setColorAt(1,QColor('#dca76a'));p.fillRect(c.active.image.rect(),g);p.end();c.commit_history(force=True);c.history.clear();c.future.clear();before=c.active.image.copy();key=c.active.image.cacheKey();ticks=[];timer=QTimer();timer.setInterval(10);timer.timeout.connect(lambda:ticks.append(time.perf_counter()));timer.start();t=time.perf_counter();assert c.start_adjustment();c.update_adjustment(brightness=5,contrast=15,temperature=20,effect='blur',amount=5);deadline=t+45
    loop=QEventLoop();watchdog=QTimer();watchdog.setSingleShot(True);watchdog.setInterval(45000);watchdog.timeout.connect(loop.quit)
    def check_ready():
        assert c.active.image.cacheKey()==key
        s=c.adjustment_session
        if s is not None and s.rendered_version==s.version:loop.quit()
    c.adjustmentChanged.connect(check_ready);watchdog.start();loop.exec();watchdog.stop();c.adjustmentChanged.disconnect(check_ready)
    assert c.adjustment_session is not None and c.adjustment_session.rendered_version==c.adjustment_session.version
    preview_s=time.perf_counter()-t;assert c.active.image==before;c.apply_adjustment();assert c.active.image!=before and len(c.history)==1;timer.stop()
    report=dict(document=[3000,2000],preview_seconds=round(preview_s,4),apply_including_history_seconds=round(time.perf_counter()-t-preview_s,4),heartbeat_ticks=len(ticks),maximum_gap_ms=round(max([b-a for a,b in zip(ticks,ticks[1:])]+[0])*1000,2),model_unchanged_until_apply=True,one_undo=True,platform='Linux Qt offscreen; measurement, not a Windows FPS promise')
    (ROOT/'reports/benchmark-11-correction.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));w.dirty=False;w.close()
