"""Capture actual Qt widgets, with temporary preferences and no user documents."""
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from PySide6.QtCore import QSettings, QByteArray, QBuffer, QIODevice
from PySide6.QtWidgets import QApplication, QScrollArea
from PySide6.QtTest import QTest
from app import MainWindow
from release_notes import UpdatesDialog
from history_dialog import HistorySettingsDialog
from themes import ThemeDialog


def capture(widget, filename):
    widget.show()
    QTest.qWait(120)
    data = QByteArray()
    buffer = QBuffer(data)
    assert buffer.open(QIODevice.OpenModeFlag.WriteOnly)
    assert widget.grab().save(buffer, 'PNG')
    buffer.close()
    (ROOT / 'reports' / filename).write_bytes(bytes(data))


with tempfile.TemporaryDirectory(prefix='dogforst-preview-') as temporary:
    QSettings.setDefaultFormat(QSettings.Format.IniFormat)
    QSettings.setPath(QSettings.Format.IniFormat, QSettings.Scope.UserScope, temporary)
    app = QApplication([])
    app.setStyle('Fusion')
    window = MainWindow()
    window.apply_theme('Перламутр', False)
    window.show()
    app.processEvents()
    window.canvas.load_project(str(ROOT / 'examples' / 'Demo.mpaint'))
    window.refresh_layers()
    window.canvas.fit_canvas()
    capture(window, 'interface-pearl.png')
    updates = UpdatesDialog(parent=window)
    capture(updates, 'updates-dev2.png')
    updates.versions.setCurrentIndex(2)
    capture(updates, 'updates-v03.png')
    updates.hide()
    history = HistorySettingsDialog(35, 256, window)
    capture(history, 'history-settings.png')
    history.hide()
    themes = ThemeDialog('Перламутр', window)
    themes.show()
    app.processEvents()
    scroll = themes.findChild(QScrollArea)
    if scroll:
        scroll.verticalScrollBar().setValue(scroll.verticalScrollBar().maximum())
    capture(themes, 'themes-dev2.png')
    themes.hide()
    window.dirty = False
    window.close()
