"""Real mask/text/comfort controls and a separate editable v7 example."""
import sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QByteArray,QBuffer,QIODevice,QRectF,Qt
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QPainter,QColor,QPen
from PySide6.QtTest import QTest
from app import MainWindow
from themes import ThemeDialog
from release_notes import UpdatesDialog


def capture(widget,name):
    widget.show();QTest.qWait(120)
    data=QByteArray();buffer=QBuffer(data)
    assert buffer.open(QIODevice.OpenModeFlag.WriteOnly)
    assert widget.grab().save(buffer,'PNG')
    buffer.close();(ROOT/'reports'/name).write_bytes(bytes(data))


with tempfile.TemporaryDirectory(prefix='dogforst-dev6-preview-') as temp:
    QSettings.setDefaultFormat(QSettings.Format.IniFormat)
    QSettings.setPath(QSettings.Format.IniFormat,QSettings.Scope.UserScope,temp)
    app=QApplication([]);app.setStyle('Fusion');w=MainWindow();w.show();app.processEvents();c=w.canvas
    c.load_project(str(ROOT/'examples'/'Blend_Workflow.mpaint'))
    # Pick the coloured raster instead of a text object; keep background unlocked for all-layer testing.
    for layer in c.layers:layer.position_locked=False
    layer=next(layer for layer in c.layers if layer.name=='Свет и движение')
    c.set_selected_nodes([layer.id]);c.add_mask()
    painter=QPainter(c.masks[layer.id]);painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setPen(QPen(QColor('black'),44,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap))
    painter.drawLine(300,170,520,340);painter.end()
    c.save_project(str(ROOT/'examples'/'Mask_Workflow.mpaint'),backup=False)
    c.export_image(str(ROOT/'reports'/'mask-export.png'))
    w.apply_theme('Аврора',False);w.refresh_layers();w.text_dock.hide();w.show_mask_panel();c.fit_canvas()
    capture(w,'mask-interface.png')
    w.mask_dock.setFloating(True);w.mask_dock.resize(420,620);capture(w.mask_dock,'mask-panel.png');w.mask_dock.hide()
    dialog=ThemeDialog(w.theme_name,w);capture(dialog,'comfort-settings.png');dialog.hide()
    text=c.text_objects[1];c.select_text(1);w.text_dock.show();w.text_dock.setFloating(True);w.text_dock.resize(470,720)
    w.text_controls.outline_button.click()
    capture(w.text_dock,'outline-controls.png');w.text_dock.hide()
    updates=UpdatesDialog(parent=w);capture(updates,'updates-dev6.png');updates.hide()
    w.large_text=True;w.reduce_motion=True;w.high_contrast=True;w.ui_scale=1.2
    w.apply_theme('Soft',False);w.color_dock.show();w.color_dock.raise_()
    capture(w,'comfort-interface.png')
    w.dirty=False;w.close()
