"""Run the complete test suite with a fresh Qt process for each group."""

from pathlib import Path
import subprocess
import sys


SAVE_LIFECYCLE = ' or '.join((
    'test_previous_version_opens_as_copy_without_overwriting_current',
    'test_restoring_oldest_backup_survives_save_and_retention_cleanup',
    'test_manual_save_runs_in_background_and_keeps_newer_changes',
    'test_cancel_manual_save_keeps_original_and_unsaved_changes',
))


def main():
    root = Path(__file__).resolve().parents[1]
    tests = root / 'tests'
    modules = sorted(set(tests.rglob('test_*.py')) | set(tests.rglob('*_test.py')))
    if not modules:
        print('No test modules found.', file=sys.stderr)
        return 2
    safety = tests / 'test_safety.py'
    group_size = 4
    groups = []
    for offset in range(0, len(modules), group_size):
        group = [path for path in modules[offset:offset + group_size] if path != safety]
        if group:
            groups.append((', '.join(path.name for path in group), list(map(str, group))))
    # Keep repeated modal saves out of the long-lived recovery-test Qt process.
    if safety in modules:
        groups.extend((
            ('test_safety.py - recovery and storage', [str(safety), '-k', f'not ({SAVE_LIFECYCLE})']),
            ('test_safety.py - manual save lifecycle', [str(safety), '-k', SAVE_LIFECYCLE]),
        ))
    for label, args in groups:
        print('Test group: ' + label, flush=True)
        result = subprocess.run(
            [sys.executable, '-m', 'pytest', '-q', *args], cwd=root)
        if result.returncode:
            return result.returncode if result.returncode > 0 else 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
