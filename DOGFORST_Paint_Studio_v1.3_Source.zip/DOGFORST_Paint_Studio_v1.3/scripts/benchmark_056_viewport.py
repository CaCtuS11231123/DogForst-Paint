"""Compare full composite with a screen-resolution preview; never change project pixels."""
import sys,time,json,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QRectF
from PySide6.QtGui import QColor,QPainter
from PySide6.QtWidgets import QApplication
import app as module
from interactive_render import interactive_image
from effects import DEFAULT_GLOW
with tempfile.TemporaryDirectory() as temp:
    module.QSettings=lambda *a:QSettings(str(Path(temp)/'settings.ini'),QSettings.Format.IniFormat)
    q=QApplication([]);q.setStyle('Fusion');w=module.MainWindow();c=w.canvas;c.new_document(2400,1600);c.zoom=.35
    p=QPainter(c.active.image);p.setPen(QColor('#2f4465'));p.setBrush(QColor('#8ccfde'));p.drawRoundedRect(QRectF(400,300,1450,950),70,70);p.end();c.active.glow=dict(DEFAULT_GLOW,radius=45,spread=4);before=c.active.image.copy()
    t=time.perf_counter();full=c.composite_image();full_s=time.perf_counter()-t;t=time.perf_counter();proxy=interactive_image(c);proxy_s=time.perf_counter()-t
    assert c.active.image==before and full.size()==c.active.image.size() and proxy.width()<=1400 and proxy.height()<=1000
    report=dict(document=[2400,1600],proxy=[proxy.width(),proxy.height()],full_seconds=round(full_s,4),proxy_seconds=round(proxy_s,4),model_unchanged=True,platform='Linux Qt offscreen; not a Windows FPS guarantee')
    (ROOT/'reports/benchmark-056-view.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));w.dirty=False;w.close()
