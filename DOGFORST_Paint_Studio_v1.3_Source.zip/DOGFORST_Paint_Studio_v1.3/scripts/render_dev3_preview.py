"""Real Qt snapshots of the new release; isolated preferences and test artwork."""
import sys
import tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from PySide6.QtCore import QSettings,QByteArray,QBuffer,QIODevice,QRectF
from PySide6.QtWidgets import QApplication,QScrollArea
from PySide6.QtTest import QTest
from app import MainWindow
from themes import ThemeDialog
from release_notes import UpdatesDialog


def capture(widget,name):
    widget.show();QTest.qWait(120)
    data=QByteArray();buffer=QBuffer(data)
    assert buffer.open(QIODevice.OpenModeFlag.WriteOnly)
    assert widget.grab().save(buffer,'PNG')
    buffer.close();(ROOT/'reports'/name).write_bytes(bytes(data))


with tempfile.TemporaryDirectory(prefix='dogforst-preview-dev3-') as temp:
    QSettings.setDefaultFormat(QSettings.Format.IniFormat)
    QSettings.setPath(QSettings.Format.IniFormat,QSettings.Scope.UserScope,temp)
    app=QApplication([]);app.setStyle('Fusion')
    w=MainWindow();w.show();app.processEvents();c=w.canvas
    c.load_project(str(ROOT/'examples'/'Demo.mpaint'))
    c.layers[0].position_locked=True;c.layers[0].color_label='#719de0'
    c.layers[1].alpha_locked=True;c.layers[1].color_label='#ad8ed0'
    for layer in c.layers[2:]:layer.color_label='#6fba9a'
    c.set_selected_layers({layer.id for layer in c.layers[1:]},c.layers[1].id)
    c.save_project(str(ROOT/'examples'/'Layer_Workflow.mpaint'),backup=False)
    w.refresh_layers();w.text_dock.hide()
    w.apply_theme('Аврора',False);c.fit_canvas()
    capture(w,'interface-aurora.png')
    w.layer_list._insertion=1
    capture(w.layer_list,'layers-dev3.png');w.layer_list.clear_drag()
    c.selection=QRectF(240,70,480,480);w.set_tool('Выделение')
    capture(w,'selection-dev3.png')
    c.selection=None
    themes=ThemeDialog('Аврора',w);themes.show();app.processEvents()
    scroll=themes.findChild(QScrollArea)
    scroll.verticalScrollBar().setValue(scroll.verticalScrollBar().maximum())
    capture(themes,'themes-dev3.png');themes.hide()
    updates=UpdatesDialog(parent=w);capture(updates,'updates-dev3.png');updates.hide()
    w.dirty=False;w.close()
