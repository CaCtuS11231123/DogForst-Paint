"""Original vector shape library used by previews, icons and drawing."""
import math
from PySide6.QtCore import QRectF,QPointF,Qt
from PySide6.QtGui import QPainterPath,QTransform,QColor,QPen,QBrush

SHAPES=('Линия','Стрелка','Прямоугольник','Скруглённый','Эллипс','Треугольник',
        'Ромб','Пятиугольник','Шестиугольник','Звезда','Сердце','Облако речи',
        'Восьмиугольник','Трапеция','Параллелограмм','Прямоугольный треугольник',
        'Двойная стрелка','Кольцо','Полумесяц','Звезда 8 лучей')
DEFAULT_SHAPE=dict(stroke='#202020',fill='#72c6ff',filled=False,stroke_width=4,
                   rotation=0,shear=0,exact=False,width=240,height=160,dashed=False)


def shape_path(name,rect,points=5):
    r=rect.normalized();x,y,w,h=r.x(),r.y(),r.width(),r.height();p=QPainterPath()
    if name=='Линия':p.moveTo(rect.topLeft());p.lineTo(rect.bottomRight());return p
    if name=='Стрелка':
        a,b=rect.topLeft(),rect.bottomRight();v=b-a;length=math.hypot(v.x(),v.y())
        angle=math.atan2(v.y(),v.x());head=min(30.,length*.3)
        p.moveTo(a);p.lineTo(b)
        for sign in (-1,1):
            p.moveTo(b);p.lineTo(b-QPointF(math.cos(angle+sign*.55)*head,math.sin(angle+sign*.55)*head))
        return p
    if name=='Прямоугольник':p.addRect(r)
    elif name=='Скруглённый':p.addRoundedRect(r,min(w,h)*.18,min(w,h)*.18)
    elif name=='Эллипс':p.addEllipse(r)
    elif name=='Сердце':
        p.moveTo(x+w*.5,y+h);p.cubicTo(x-w*.35,y+h*.4,x+w*.05,y-h*.35,x+w*.5,y+h*.22)
        p.cubicTo(x+w*.95,y-h*.35,x+w*1.35,y+h*.4,x+w*.5,y+h);p.closeSubpath()
    elif name=='Облако речи':
        p.addRoundedRect(QRectF(x,y,w,h*.75),min(w,h)*.1,min(w,h)*.1)
        p.moveTo(x+w*.25,y+h*.7);p.lineTo(x+w*.23,y+h);p.lineTo(x+w*.5,y+h*.7);p.closeSubpath()
        p=p.simplified()
    elif name in ('Трапеция','Параллелограмм','Прямоугольный треугольник','Двойная стрелка'):
        coords={'Трапеция':[(.23,0),(.77,0),(1,1),(0,1)],
                'Параллелограмм':[(.25,0),(1,0),(.75,1),(0,1)],
                'Прямоугольный треугольник':[(0,0),(1,1),(0,1)],
                'Двойная стрелка':[(0,.5),(.25,0),(.25,.3),(.75,.3),(.75,0),(1,.5),(.75,1),(.75,.7),(.25,.7),(.25,1)]}[name]
        p.moveTo(x+coords[0][0]*w,y+coords[0][1]*h)
        for u,v in coords[1:]:p.lineTo(x+u*w,y+v*h)
        p.closeSubpath()
    elif name=='Кольцо':
        p.addEllipse(r);p.addEllipse(r.adjusted(w*.24,h*.24,-w*.24,-h*.24));p.setFillRule(Qt.FillRule.OddEvenFill)
    elif name=='Полумесяц':
        p.addEllipse(r);cut=QPainterPath();cut.addEllipse(r.translated(w*.32,-h*.12));p=p.subtracted(cut)
    elif name=='Крест':  # legacy rendering only; removed from the picker
        pts=[(.34,0),(.66,0),(.66,.34),(1,.34),(1,.66),(.66,.66),(.66,1),(.34,1),(.34,.66),(0,.66),(0,.34),(.34,.34)]
        p.moveTo(x+pts[0][0]*w,y+pts[0][1]*h)
        for u,v in pts[1:]:p.lineTo(x+u*w,y+v*h)
        p.closeSubpath()
    else:
        count={'Треугольник':3,'Ромб':4,'Пятиугольник':5,'Шестиугольник':6,'Восьмиугольник':8,'Звезда':max(3,min(24,int(points)))*2,'Звезда 8 лучей':16}.get(name,4)
        for i in range(count):
            radius=.43 if name in ('Звезда','Звезда 8 лучей') and i%2 else 1.
            angle=-math.pi/2+2*math.pi*i/count
            pt=QPointF(x+w/2+math.cos(angle)*w/2*radius,y+h/2+math.sin(angle)*h/2*radius)
            if i==0:p.moveTo(pt)
            else:p.lineTo(pt)
        p.closeSubpath()
    return p


def draw_shape(painter,name,rect,options,opacity=1.):
    rect=QRectF(rect)
    if name in ('Линия','Стрелка'):
        if options.get('flat_x'):rect.setWidth(0)
        if options.get('flat_y'):rect.setHeight(0)
    painter.save();painter.setRenderHint(painter.RenderHint.Antialiasing)
    center=rect.normalized().center()
    transform=QTransform().translate(center.x(),center.y()).rotate(float(options.get('rotation',0))).shear(float(options.get('shear',0))/100,0).translate(-center.x(),-center.y())
    painter.setTransform(transform,True)
    painter.setOpacity(painter.opacity()*opacity)
    painter.setPen(QPen(QColor(options['stroke']),float(options['stroke_width']),
        Qt.PenStyle.DashLine if options.get('dashed') else Qt.PenStyle.SolidLine,
        Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin))
    painter.setBrush(QBrush(QColor(options['fill'])) if options.get('filled') else Qt.BrushStyle.NoBrush)
    painter.drawPath(shape_path(name,rect,options.get('points',5)));painter.restore()
