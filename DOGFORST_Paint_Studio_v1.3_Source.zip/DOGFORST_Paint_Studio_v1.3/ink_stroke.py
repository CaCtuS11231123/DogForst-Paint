"""Sparse stroke tiles. Stroke opacity is applied once over the original pixels.

Only touched 256px tiles hold ink; neither off-canvas paths nor opacity need a
second full-canvas work image. Full source QImage uses Qt copy-on-write.
"""
import math
from PySide6.QtCore import Qt,QPointF,QRectF,QRect
from PySide6.QtGui import QImage,QColor,QPainter,QPen,QRadialGradient
from layers import transparent_image
from masks import apply_mask

PAINT_TOOLS=('Кисть','Мягкая кисть','Карандаш','Маркер','Ластик')

def clip_segment(a,b,rect):
    dx,dy=b.x()-a.x(),b.y()-a.y();lo,hi=0.,1.
    for p,q in [(-dx,a.x()-rect.left()),(dx,rect.right()-a.x()),(-dy,a.y()-rect.top()),(dy,rect.bottom()-a.y())]:
        if p==0:
            if q<0:return None
        else:
            t=q/p
            if p<0:lo=max(lo,t)
            else:hi=min(hi,t)
            if lo>hi:return None
    return lo,hi

class InkStroke:
    def __init__(self,canvas,mask=False):
        self.mask=mask;self.identifier=canvas.editing_mask if mask else canvas.active.id
        self.base=QImage(canvas.masks[self.identifier] if mask else canvas.active.image);self.tiles={};self.remaining=0.
        self.tool=canvas.tool;self.size=canvas.brush_size;self.hardness=min(35,canvas.brush_hardness) if self.tool=='Мягкая кисть' else canvas.brush_hardness
        self.shape=canvas.brush_shape;self.spacing=max(.35,self.size*canvas.brush_spacing/100);self.flow=canvas.brush_flow/100
        self.opacity=canvas.brush_opacity/100*(.35 if self.tool=='Маркер' else 1)
        self.color=QColor(canvas.color)
        if mask:
            g=255 if self.tool=='Ластик' else round(.299*self.color.red()+.587*self.color.green()+.114*self.color.blue());self.color=QColor(g,g,g)
        elif self.tool!='Ластик':self.opacity*=self.color.alphaF()
        else:self.color=QColor('white')
        self.color.setAlpha(255);self.alpha_locked=not mask and canvas.active.alpha_locked
        self.coverage=QImage(canvas.selection_mask) if canvas.selection_mask is not None else None
        self.selection=QRectF(canvas.selection) if canvas.selection else None
        self.smoothing=canvas.smoothing
    def segment(self,canvas,a,b):
        radius=self.size/2+2;expanded=QRectF(self.base.rect()).adjusted(-radius,-radius,radius,radius)
        clipped=clip_segment(a,b,expanded);length=math.hypot(b.x()-a.x(),b.y()-a.y());points=[]
        if length==0:
            if clipped:points=[QPointF(a)]
        elif clipped:
            first=max(self.remaining, self.remaining+max(0,math.ceil((clipped[0]*length-self.remaining)/self.spacing))*self.spacing)
            stop=min(length,clipped[1]*length);n=first
            while n<=stop+1e-8:points.append(a+(b-a)*(n/length));n+=self.spacing
        if length:self.remaining=(self.remaining-length)%self.spacing
        else:self.remaining=self.spacing
        touched={};continuous=self.tool in ('Карандаш','Маркер','Ластик')
        if continuous and clipped:
            aa=a+(b-a)*clipped[0];bb=a+(b-a)*clipped[1]
            bounds=QRectF(aa,bb).normalized().adjusted(-radius,-radius,radius,radius).toAlignedRect().intersected(self.base.rect())
            if self.selection:bounds=bounds.intersected(self.selection.toAlignedRect())
            for y in range(bounds.top()//256*256,bounds.bottom()+1,256):
                for x in range(bounds.left()//256*256,bounds.right()+1,256):
                    tile=QRectF(x,y,min(256,self.base.width()-x),min(256,self.base.height()-y)).adjusted(-radius,-radius,radius,radius)
                    if clip_segment(a,b,tile) is not None:touched[(x,y)]=None
        else:
            for point in points:
                bounds=QRectF(point.x()-radius,point.y()-radius,radius*2,radius*2).toAlignedRect().intersected(self.base.rect())
                if self.selection:bounds=bounds.intersected(self.selection.toAlignedRect())
                if bounds.isEmpty():continue
                for y in range(bounds.top()//256*256,bounds.bottom()+1,256):
                    for x in range(bounds.left()//256*256,bounds.right()+1,256):touched.setdefault((x,y),[]).append(point)
        if not touched:return
        destination=canvas.masks[self.identifier] if self.mask else canvas.active.image
        output=QPainter(destination)
        try:
            output.setCompositionMode(QPainter.CompositionMode.CompositionMode_Source)
            for (x,y),dabs in touched.items():
                rect=QRect(x,y,min(256,self.base.width()-x),min(256,self.base.height()-y))
                ink=self.tiles.get((x,y))
                if ink is None:ink=transparent_image(rect.width(),rect.height());self.tiles[(x,y)]=ink
                p=QPainter(ink);p.translate(-x,-y);p.setRenderHint(QPainter.RenderHint.Antialiasing,self.smoothing and self.tool!='Карандаш')
                if self.selection:p.setClipRect(self.selection)
                color=QColor(self.color);color.setAlphaF(self.flow)
                if continuous:
                    p.setPen(QPen(color,self.size,Qt.PenStyle.SolidLine,Qt.PenCapStyle.SquareCap if self.tool=='Карандаш' else Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin))
                    p.drawPoint(a) if a==b else p.drawLine(a,b)
                else:
                    p.setPen(Qt.PenStyle.NoPen)
                    for point in dabs:
                        r=self.size/2;shape=QRectF(point.x()-r,point.y()-r,self.size,self.size)
                        if self.hardness<100:
                            g=QRadialGradient(point,max(.5,r));g.setColorAt(0,color);g.setColorAt(min(.98,self.hardness/100),color);edge=QColor(color);edge.setAlpha(0);g.setColorAt(1,edge);p.setBrush(g)
                        else:p.setBrush(color)
                        p.drawRect(shape) if self.shape=='square' else p.drawEllipse(shape)
                p.end()
                layer=apply_mask(ink,self.coverage,rect) if self.coverage is not None else ink
                patch=self.base.copy(rect);paint=QPainter(patch);paint.setOpacity(self.opacity)
                paint.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationOut if self.tool=='Ластик' and not self.mask else QPainter.CompositionMode.CompositionMode_SourceAtop if self.alpha_locked else QPainter.CompositionMode.CompositionMode_SourceOver)
                paint.drawImage(0,0,layer);paint.end();output.drawImage(rect.topLeft(),patch)
        finally:output.end()

class InkStrokeMixin:
    def prepare_ink_segment(self,a,b,mask=False):
        if self.brush_opacity<=0 or (not mask and self.tool!='Ластик' and self.color.alpha()==0):return False
        radius=self.brush_size/2+2;bounds=QRectF(0,0,*self.doc_size)
        if self.selection:bounds=bounds.intersected(self.selection)
        if bounds.isEmpty() or clip_segment(a,b,bounds.adjusted(-radius,-radius,radius,radius)) is None:return False
        if self.drawing and not getattr(self,'_stroke_history_started',False):
            self.push_history();self._stroke_history_started=True
            if not mask and self.selection_mask is not None:self.rasterize_for_selection({self.active.id})
        return True
    def buffered_ink_segment(self,a,b,mask=False):
        if not self.prepare_ink_segment(a,b,mask):
            # Preserve phase across an off-canvas gap without allocating any tiles.
            if self._ink_stroke is not None:self._ink_stroke.segment(self,a,b)
            return
        if self._ink_stroke is None:self._ink_stroke=InkStroke(self,mask)
        self._ink_stroke.segment(self,a,b)
        if not self.drawing:self._ink_stroke=None
