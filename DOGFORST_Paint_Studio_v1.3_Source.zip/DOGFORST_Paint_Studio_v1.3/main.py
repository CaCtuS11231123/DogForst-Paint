import faulthandler
import json
import logging
from pathlib import Path
import sys
import traceback

from integrity import verify_installation


def run_editor(args, report=None):
    frozen = getattr(sys, 'frozen', False)
    root = Path(sys.executable).parent if frozen else Path(__file__).resolve().parent
    if '--verify-installation' in args:
        try:
            result = verify_installation(root)
            print(json.dumps(result, ensure_ascii=False))
            return 0 if result['ok'] else 2
        except Exception as error:
            print(str(error))
            return 2

    def stage(message):
        if report is not None:
            print(message, file=report, flush=True)

    smoke = report is not None or '--smoke-test' in args
    stage(f'Loading Qt. Python {sys.version.split()[0]}, platform {sys.platform}.')
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QApplication, QMessageBox

    stage('Creating QApplication.')
    app = QApplication(args)
    app.setOrganizationName("DOGFORST")
    app.setApplicationName("Paint Studio")
    app.setStyle("Fusion")
    integrity_notice = ''
    stage('Checking package integrity.')
    try:
        if frozen or (root / 'release_integrity.json').exists():
            result = verify_installation(root, critical_only=frozen and report is None)
            if not result['ok']:
                raise ValueError('\n'.join(result['errors'][:8]))
    except Exception as error:
        stage(f'Integrity check failed: {error}')
        if frozen:
            if not smoke:
                QMessageBox.critical(
                    None, 'Целостность программы',
                    'Распакуйте всю папку программы заново.\n\n' + str(error))
            return 2
        integrity_notice = 'Проверка исходников: ' + str(error)

    from diagnostics import application_data_directory, configure_logging, install_exception_hooks
    from release_notes import CURRENT_VERSION

    stage(f'Loading DOGFORST Paint Studio {CURRENT_VERSION}.')
    try:
        logger = configure_logging(application_data_directory() / 'logs', CURRENT_VERSION)
    except OSError:
        logger = logging.getLogger('dogforst')
        logger.addHandler(logging.StreamHandler())
        logger.exception('Could not create local diagnostics log')
    if report is not None:
        logger.addHandler(logging.StreamHandler(report))
    install_exception_hooks(logger)
    try:
        from app import MainWindow

        stage('Creating the editor window.')
        window = MainWindow()
        window.show()
    except Exception:
        logger.exception('Editor startup failed')
        if not smoke:
            QMessageBox.critical(
                None, 'Ошибка запуска DOGFORST',
                'Редактор не открылся. Запустите diagnose_windows.bat из папки программы, '
                'чтобы получить отчёт для разработчика.')
        raise

    def notify_error():
        if smoke:
            app.exit(1)
        else:
            QMessageBox.critical(
                window, 'Ошибка приложения',
                'Возникла внутренняя ошибка. Проверьте документ перед сохранением.\n'
                'Журнал доступен в меню «Справка → Открыть папку журналов».')

    install_exception_hooks(logger, notify_error)
    if integrity_notice:
        window.statusBar().showMessage(integrity_notice, 15000)
    if smoke:
        stage('Editor window shown. Entering Qt event loop.')

        def finish_check():
            stage('Startup OK. Editor initialized and event loop responded.')
            app.quit()

        QTimer.singleShot(350, finish_check)
    else:
        def open_start_screen():
            if window._safety:
                window._safety.offer_recovery(quiet=True)
            if not window.dirty:
                window.show_start_screen()

        QTimer.singleShot(0, open_start_screen)
    return app.exec()


def main():
    args = list(sys.argv)
    if '--diagnose-startup' not in args:
        return run_editor(args)
    index = args.index('--diagnose-startup')
    if index + 1 >= len(args):
        return 2
    path = Path(args[index + 1])
    del args[index:index + 2]
    with path.open('a', encoding='utf-8', buffering=1) as report:
        faulthandler.enable(file=report)
        try:
            return run_editor(args, report)
        except Exception:
            traceback.print_exc(file=report)
            return 1
        finally:
            faulthandler.disable()


if __name__ == "__main__":
    sys.exit(main())
