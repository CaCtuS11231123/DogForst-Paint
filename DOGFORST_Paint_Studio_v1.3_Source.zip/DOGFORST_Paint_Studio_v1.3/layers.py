import uuid
from PySide6.QtCore import Qt
from PySide6.QtGui import QImage

def transparent_image(width, height):
    image = QImage(width, height, QImage.Format.Format_ARGB32)
    if image.isNull():
        raise ValueError("Недостаточно памяти для создания холста.")
    image.fill(Qt.GlobalColor.transparent)
    return image


class Layer:
    def __init__(self, name, image, visible=True, opacity=1.0, layer_id=None, kind="raster",
                 locked=False, position_locked=False, alpha_locked=False, color_label='', blend_mode='normal',glow=None,clipped=False):
        self.id = layer_id or uuid.uuid4().hex
        self.kind = kind
        self.name = name
        self.image = image
        self.visible = visible
        self.opacity = opacity
        self.locked = locked
        self.position_locked = position_locked
        self.alpha_locked = alpha_locked
        self.color_label = color_label
        self.blend_mode = blend_mode
        from effects import validate_glow
        self.glow = validate_glow(glow)
        if not isinstance(clipped,bool):raise ValueError("Некорректная обтравка слоя.")
        self.clipped=clipped

    def flags(self):
        result={key: getattr(self, key) for key in ('locked','position_locked','alpha_locked','color_label','blend_mode')}
        if self.glow is not None:result['glow']=dict(self.glow)
        if self.clipped:result["clipped"]=True
        return result


