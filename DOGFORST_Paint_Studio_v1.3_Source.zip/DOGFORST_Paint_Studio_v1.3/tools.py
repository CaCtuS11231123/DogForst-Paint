"""Original DOGFORST line icons and tool-aware cursors; no external icon font."""
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import QPainterPath, QPixmap, QPainter, QPen, QColor, QIcon, QCursor, QPolygonF


def tool_pixmap(tool, size=32, color='#83bfff', line_width=1.8):
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.scale(size/32, size/32)
    p.setPen(QPen(QColor(color), line_width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    if tool in ('Кисти', 'Кисть', 'Карандаш', 'Маркер', 'Мягкая кисть', 'Пипетка'):
        p.drawLine(12,20,24,6); p.drawLine(16,23,28,9); p.drawLine(24,6,28,9)
        if tool == 'Пипетка':
            p.drawLine(19,7,27,15); p.drawLine(12,20,7,27); p.drawLine(16,23,7,27)
        elif tool == 'Карандаш':
            p.drawLine(12,20,9,27); p.drawLine(16,23,9,27)
        elif tool == 'Маркер':
            p.drawRect(7,23,10,4)
        else:
            p.drawEllipse(QRectF(5,21,10,7))
            if tool == 'Мягкая кисть':
                p.setPen(QPen(QColor(color), max(1,line_width), Qt.PenStyle.DotLine)); p.drawEllipse(QRectF(2,18,16,13))
    elif tool == 'Ластик':
        p.drawPolygon(QPolygonF([QPointF(5,21),QPointF(18,6),QPointF(28,15),QPointF(17,27),QPointF(11,27)]))
        p.drawLine(12,14,22,23)
    elif tool in ('Палец','Размытие','Резкость','Штамп','Осветление','Затемнение'):
        if tool=='Палец':
            p.drawRoundedRect(QRectF(11,4,8,19),4,4);p.drawPolyline(QPolygonF([QPointF(11,15),QPointF(5,13),QPointF(7,25),QPointF(16,29),QPointF(24,23),QPointF(24,14)]))
        elif tool=='Размытие':
            path=QPainterPath();path.moveTo(16,3);path.cubicTo(12,11,5,15,6,22);path.cubicTo(8,32,26,31,27,21);path.cubicTo(27,15,20,9,16,3);p.drawPath(path)
        elif tool=='Резкость':p.drawPolygon(QPolygonF([QPointF(16,3),QPointF(29,28),QPointF(3,28)]));p.drawLine(16,8,16,23)
        elif tool=='Штамп':p.drawRoundedRect(QRectF(11,3,10,15),4,4);p.drawRect(QRectF(5,19,22,8));p.drawLine(4,30,28,30)
        else:
            p.drawEllipse(QRectF(7,7,18,18))
            if tool=='Затемнение':p.drawArc(QRectF(10,7,12,18),-90*16,180*16);p.drawLine(16,8,16,24)
            else:
                for a,b in [(QPointF(16,1),QPointF(16,4)),(QPointF(16,28),QPointF(16,31)),(QPointF(1,16),QPointF(4,16)),(QPointF(28,16),QPointF(31,16))]:p.drawLine(a,b)
    elif tool == 'Градиент':
        p.drawRect(QRectF(4,6,24,20))
        for x in (8,12,16,20,24):p.drawLine(x,9,x,10+(x-4)//2)
        p.drawLine(6,25,26,8)
    elif tool == 'Заливка':
        p.drawPolygon(QPolygonF([QPointF(5,17),QPointF(16,6),QPointF(26,16),QPointF(15,27)]))
        p.drawLine(8,17,24,17); p.drawLine(11,5,17,11); p.drawEllipse(QRectF(25,23,4,6))
    elif tool == 'Фигуры':
        p.drawRect(QRectF(4,5,14,14));p.drawEllipse(QRectF(13,13,15,15))
    elif tool in __import__('shapes').SHAPES or tool=='Крест':
        from shapes import shape_path
        p.drawPath(shape_path(tool,QRectF(5,5,22,22)))
    elif tool == 'Прямоугольник': p.drawRoundedRect(QRectF(5,7,22,19),2,2)
    elif tool == 'Эллипс': p.drawEllipse(QRectF(4,7,24,19))
    elif tool == 'Линия': p.drawLine(5,26,27,6)
    elif tool == 'Выделение':
        p.setPen(QPen(QColor(color), max(1.5,line_width), Qt.PenStyle.DashLine)); p.drawRect(QRectF(5,5,22,22))
    elif tool=='Лассо':
        p.drawPolygon(QPolygonF([QPointF(6,9),QPointF(25,6),QPointF(28,22),QPointF(12,27),QPointF(6,9)]));p.drawEllipse(QRectF(3,6,6,6))
    elif tool=='Волшебная палочка':
        p.drawLine(6,27,23,10)
        for a,b in [(QPointF(23,2),QPointF(23,6)),(QPointF(28,7),QPointF(31,7)),(QPointF(15,7),QPointF(19,7)),(QPointF(27,12),QPointF(30,15))]:p.drawLine(a,b)
    elif tool == 'Текст':
        p.drawLine(6,6,26,6); p.drawLine(16,6,16,27); p.drawLine(11,27,21,27)
    elif tool == 'Перемещение':
        p.drawLine(16,4,16,28); p.drawLine(4,16,28,16)
        for pts in [((12,8),(16,4),(20,8)),((12,24),(16,28),(20,24)),((8,12),(4,16),(8,20)),((24,12),(28,16),(24,20))]:
            p.drawPolyline(QPolygonF([QPointF(*pt) for pt in pts]))
    p.end()
    return pix


def tool_icon(tool, color='#83bfff'):
    return QIcon(tool_pixmap(tool, 32, color))


def tool_cursor(tool, brush_size=8, zoom=1.0, dpr=1.0,shape="round"):
    if tool in ('Кисть','Карандаш','Маркер','Мягкая кисть','Ластик','Палец','Размытие','Резкость','Штамп','Осветление','Затемнение'):
        diameter = max(3, min(256, round(brush_size*zoom)))
        retouch=tool in ('Палец','Размытие','Резкость','Штамп','Осветление','Затемнение')
        side = diameter+(26 if retouch else 10)
        pix = QPixmap(round(side*dpr), round(side*dpr)); pix.setDevicePixelRatio(dpr)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(5,5,diameter,diameter)
        for color, width in [('#000000',3),('#ffffff',1)]:
            p.setPen(QPen(QColor(color),width))
            if tool == 'Ластик' or (shape=='square' and tool in ('Кисть','Мягкая кисть')): p.drawRect(rect)
            else: p.drawEllipse(rect)
        center=5+diameter/2;p.drawPoint(QPointF(center,center))
        if retouch:
            glyph=tool_pixmap(tool,16,'#000000',4.5);gp=QPainter(glyph);gp.drawPixmap(0,0,tool_pixmap(tool,16,'#ffffff',1.6));gp.end();p.drawPixmap(diameter+8,diameter+8,glyph)
        p.end()
        return QCursor(pix,round(center),round(center))
    if tool == 'Текст':
        pix=QPixmap(32,32);pix.fill(Qt.GlobalColor.transparent);p=QPainter(pix)
        for col,width in [('#000000',4),('#ffffff',1.5)]:
            p.setPen(QPen(QColor(col),width));p.drawLine(16,4,16,28);p.drawLine(11,4,21,4);p.drawLine(11,28,21,28)
        p.end();return QCursor(pix,16,16)
    pix = tool_pixmap(tool, 32, '#000000', 4.5)
    overlay = tool_pixmap(tool, 32, '#ffffff', 1.8)
    outline = QPainter(pix);outline.drawPixmap(0,0,overlay);outline.end()
    p = QPainter(pix); p.setPen(QPen(QColor('#101521'),3)); p.drawLine(1,5,9,5);p.drawLine(5,1,5,9)
    p.setPen(QPen(QColor('white'),1));p.drawLine(1,5,9,5);p.drawLine(5,1,5,9);p.end()
    return QCursor(pix,5,5)
