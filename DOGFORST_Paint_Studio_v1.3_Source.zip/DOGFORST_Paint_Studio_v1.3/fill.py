"""Connected colour fill in C-backed NumPy/SciPy operations, off the GUI thread."""
import threading
import numpy as np
from scipy import ndimage
from PySide6.QtCore import QObject, QRunnable, Signal
from PySide6.QtGui import QImage


def fill_image(image, x, y, color, tolerance, opacity, cancelled=None, bounds=None, selection=None):
    rgba = image.convertToFormat(QImage.Format.Format_RGBA8888)
    w, h = rgba.width(), rgba.height()
    if not (0 <= x < w and 0 <= y < h):
        return None
    pixels = np.frombuffer(rgba.constBits(), dtype=np.uint8).reshape(h, rgba.bytesPerLine())[:, :w*4].reshape(h,w,4)
    if bounds is not None:
        left, top, right, bottom = bounds
        left,top,right,bottom = max(0,left),max(0,top),min(w,right),min(h,bottom)
        if not (left <= x < right and top <= y < bottom):
            return None
    replacement = np.array([color.red(), color.green(), color.blue(), round(color.alpha()*opacity/100)], dtype=np.uint8)
    if np.array_equal(pixels[y,x], replacement):
        return None
    target = pixels[y,x].astype(np.int16)
    mask = np.ones((h,w), dtype=bool)
    # One channel at a time avoids a full h*w*4 int16 temporary.
    for channel in range(4):
        if cancelled and cancelled.is_set():
            return None
        mask &= np.abs(pixels[:,:,channel].astype(np.int16)-target[channel]) <= tolerance
    if target[3] == 0:
        # Fully transparent pixels have no visible RGB color.
        mask |= pixels[:, :, 3] == 0
    if bounds is not None:
        mask[:top] = False; mask[bottom:] = False
        mask[:, :left] = False; mask[:, right:] = False
    if selection is not None:
        from selection_tools import gray_array
        keep,coverage=gray_array(selection);mask&=coverage>0
        if not mask[y,x]:return None
    labels, _ = ndimage.label(mask)  # 4-connected, matching the original fill.
    if cancelled and cancelled.is_set():
        return None
    region = labels == labels[y,x]
    output = pixels.copy()
    output[region] = replacement
    result=QImage(output.data, w, h, w*4, QImage.Format.Format_RGBA8888).copy().convertToFormat(QImage.Format.Format_ARGB32)
    if selection is not None:
        from selection_tools import blend_selection
        result=blend_selection(image,result,selection)
    return result


class FillSignals(QObject):
    done = Signal(object, str)


class FillJob(QRunnable):
    def __init__(self, image, x, y, color, tolerance, opacity, bounds=None,selection=None):
        super().__init__()
        self.args = (image, x, y, color, tolerance, opacity)
        self.bounds = bounds
        self.selection=QImage(selection) if selection is not None else None
        self.cancelled = threading.Event()
        self.signals = FillSignals()

    def run(self):
        try:
            result = fill_image(*self.args, cancelled=self.cancelled, bounds=self.bounds,selection=self.selection)
            self.signals.done.emit(result, "")
        except Exception as error:
            self.signals.done.emit(None, "Недостаточно памяти для заливки." if isinstance(error,MemoryError) else str(error) or type(error).__name__)
