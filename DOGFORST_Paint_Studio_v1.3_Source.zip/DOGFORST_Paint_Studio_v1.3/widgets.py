from PySide6.QtCore import Qt, QVariantAnimation, QEasingCurve, QRectF, Signal
from PySide6.QtGui import QColor, QPainter, QPen, QPalette, QIcon
from PySide6.QtWidgets import QToolButton, QSlider, QStylePainter, QStyleOptionSlider, QStyle


class AnimatedToolButton(QToolButton):
    doubleClicked=Signal()
    def mouseDoubleClickEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton:
            self.doubleClicked.emit();event.accept();return
        super().mouseDoubleClickEvent(event)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.accent = QColor('#79baff')
        self.progress = 0.
        self.hovered = False
        self.animation = QVariantAnimation(self)
        self.animation.setDuration(220)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.animation.valueChanged.connect(self._frame)
        self.toggled.connect(self._animate)

    def _frame(self, value):
        self.progress = float(value); self.update()

    def _animate(self, *_):
        if getattr(self.window(),'reduce_motion',False):
            self.animation.stop();self._frame(1. if self.isChecked() else .35 if self.hovered else 0.);return
        self.animation.stop(); self.animation.setStartValue(self.progress)
        self.animation.setEndValue(1. if self.isChecked() else .35 if self.hovered else 0.)
        self.animation.start()

    def enterEvent(self, event):
        self.hovered = True; self._animate(); super().enterEvent(event)

    def leaveEvent(self, event):
        self.hovered = False; self._animate(); super().leaveEvent(event)

    def paintEvent(self, event):
        # Fixed paint geometry: hover/checked never change a layout or border width.
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing)
        window=self.window();colors=getattr(window,'_theme_colors',None)
        base=QColor(colors[4]) if colors else self.palette().color(QPalette.ColorRole.Button)
        foreground=QColor(colors[1]) if colors else self.palette().color(QPalette.ColorRole.ButtonText)
        if not self.isEnabled():base=QColor('#161c26');foreground=QColor('#aab6c8')
        p.setBrush(base);p.setPen(QPen(QColor(colors[3]) if colors else QColor('#52617a'),1))
        rect=QRectF(self.rect()).adjusted(1,1,-1,-1);p.drawRoundedRect(rect,10,10)
        tint=QColor(self.accent);tint.setAlpha(round(65*self.progress)+(20 if self.isDown() else 0) if self.isEnabled() else 0)
        p.setBrush(tint);border=QColor(self.accent);border.setAlpha(round(255*self.progress) if self.isEnabled() else 0);p.setPen(QPen(border,1.5));p.drawRoundedRect(rect,10,10)
        size=self.iconSize();x=(self.width()-size.width())//2
        self.icon().paint(p,x,8,size.width(),size.height(),Qt.AlignmentFlag.AlignCenter,QIcon.Mode.Normal if self.isEnabled() else QIcon.Mode.Disabled)
        font=p.font();font.setPixelSize(round(12*getattr(window,'ui_scale',1.)));p.setFont(font);p.setPen(foreground)
        text=p.fontMetrics().elidedText(self.text(),Qt.TextElideMode.ElideRight,self.width()-10)
        p.drawText(QRectF(5,self.height()-25,self.width()-10,21),Qt.AlignmentFlag.AlignCenter,text)
        p.end()


class ColorSwatch(AnimatedToolButton):
    def __init__(self, color, parent=None):
        super().__init__(parent); self.color = QColor(color); self.setCheckable(True)
        self.setToolTip(self.color.name().upper()); self.setFixedSize(27,32)

    def paintEvent(self, event):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        if not self.isEnabled():p.fillRect(self.rect(),QColor('#161c26'))
        p.setBrush(self.color if self.isEnabled() else QColor('#66748a')); p.setPen(QPen(QColor('#8492a6'),1))
        p.drawRoundedRect(QRectF(self.rect()).adjusted(5,6,-5,-6),5,5)
        accent = QColor(self.accent); accent.setAlpha(round(255*self.progress) if self.isEnabled() else 0)
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(QPen(accent,2))
        p.drawRoundedRect(QRectF(self.rect()).adjusted(1,2,-1,-2),8,8);p.end()


class AnimatedSlider(QSlider):
    """Animate paint position only; the actual numeric value changes immediately."""
    def __init__(self, orientation, parent=None):
        super().__init__(orientation, parent); self.visual_value = float(self.value())
        self.animation = QVariantAnimation(self); self.animation.setDuration(75)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.animation.valueChanged.connect(self._frame)
        self.valueChanged.connect(self._animate)

    def _frame(self, value):
        self.visual_value = float(value); self.update()

    def _animate(self, value):
        if getattr(self.window(),'reduce_motion',False):
            self.animation.stop();self._frame(value);return
        self.animation.stop(); self.animation.setStartValue(self.visual_value)
        self.animation.setEndValue(float(value)); self.animation.start()

    def paintEvent(self, event):
        painter = QStylePainter(self); option = QStyleOptionSlider(); self.initStyleOption(option)
        option.subControls = QStyle.SubControl.SC_SliderGroove | QStyle.SubControl.SC_SliderHandle
        option.sliderPosition = round(self.visual_value)
        painter.drawComplexControl(QStyle.ComplexControl.CC_Slider, option)
