# Рисованный знак DOGFORST

Новый самостоятельный рисунок создан встроенной генерацией изображений.
Он не копирует фирменные знаки других редакторов.

Основной ресурс: `assets/DOGFORST_Handdrawn.png` — прозрачный PNG 1254×1254.
На его основе технически подготовлен ICO с размерами 16/24/32/48/64/128/256.
Прежняя иконка: `assets/DOGFORST_Icon_original.ico`.
PNG используется в шапке, ICO — в окне и спецификации PyInstaller.

Промпт:

> Use case: logo-brand. Create a single original hand-drawn application icon for DOGFORST Paint Studio, a creative painting app. No text, no letters. A playful but premium sketch of a paintbrush laying a swooping blue and violet paint stroke into a compact rounded diamond-like crystal mark. Visible pen outlines in deep near-black, slightly imperfect hand-inked contours and subtle colored-pencil hatch marks. Cyan, cornflower blue, lavender with one small warm white sparkle. Strong silhouette legible at 48px, centered on genuinely transparent background, no square background, no mockup, no watermark, no existing product logos. An actual illustrated emblem, not a glossy 3D app tile. Large emblem filling 80% of square canvas.
