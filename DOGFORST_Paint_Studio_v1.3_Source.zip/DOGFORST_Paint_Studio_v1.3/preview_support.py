"""Neutral transparency previews, independent of document pixels."""
from PySide6.QtCore import QRectF
from PySide6.QtGui import QImage,QPainter,QBrush,QColor

def paint_checker(painter,rect,style='light'):
    base,accent=('#323744','#242936') if style=='dark' else ('#ffffff','#dce3ed')
    tile=QImage(16,16,QImage.Format.Format_RGB32);tile.fill(QColor(base));p=QPainter(tile);p.fillRect(0,0,8,8,QColor(accent));p.fillRect(8,8,8,8,QColor(accent));p.end();painter.fillRect(rect,QBrush(tile))
