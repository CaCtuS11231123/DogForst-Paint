"""Real editors with shared controls, previews and explicit Apply/Cancel."""
from PySide6.QtCore import Qt,Signal,QRectF,QSize
from PySide6.QtGui import QColor,QPainter,QFont,QIcon,QPixmap
from PySide6.QtWidgets import (QWidget,QDialog,QVBoxLayout,QHBoxLayout,QFormLayout,QGridLayout,
    QPushButton,QLabel,QTextEdit,QFontComboBox,QSpinBox,QDoubleSpinBox,QCheckBox,QComboBox,
    QDialogButtonBox,QScrollArea,QToolButton,QSizePolicy,QStackedWidget,QSlider,QSplitter)
from text_model import draw_text,text_geometry
from shapes import SHAPES,DEFAULT_SHAPE,draw_shape


class ColorButton(QPushButton):
    colorChanged=Signal()
    def __init__(self,color,label='Цвет',parent=None):
        super().__init__(label,parent);self.color=QColor(color);self.clicked.connect(self.choose);self.refresh()
    def refresh(self):
        self.setStyleSheet(f'QPushButton:enabled {{background:{self.color.name()};color:{"#101722" if self.color.lightness()>145 else "white"};border:1px solid #8392a9;padding:7px;border-radius:7px;}} QPushButton:disabled {{background:#161c26;color:#aab6c8;border:1px solid #445166;padding:7px;border-radius:7px;}}')
    def choose(self):
        from PySide6.QtWidgets import QColorDialog
        original=QColor(self.color);owner=self.parentWidget()
        while owner is not None and not hasattr(owner,'canvas'):owner=owner.parentWidget()
        text_original=None;text_index=-1;dirty_original=owner.dirty if owner is not None else False;revision_original=owner._safety.revision if owner is not None and owner._safety else None
        if owner is not None:
            import copy
            text_index=owner.canvas.selected_text
            if owner.text_controls.isAncestorOf(self) and 0<=text_index<len(owner.canvas.text_objects):text_original=copy.deepcopy(owner.canvas.text_objects[text_index])
            owner._text_edit_timer.stop();owner.end_text_history_group();owner._color_picker_active=True
        dialog=QColorDialog(self.color,self);dialog.setWindowTitle('Выбрать цвет');dialog.setOption(QColorDialog.ColorDialogOption.DontUseNativeDialog,True)
        def preview(color):
            if color.isValid() and color!=self.color:self.color=QColor(color);self.refresh();self.colorChanged.emit()
        dialog.currentColorChanged.connect(preview)
        result=dialog.exec()
        preview(dialog.currentColor() if result==QDialog.DialogCode.Accepted else original)
        if owner is not None:
            restore_text=text_original is not None and (result!=QDialog.DialogCode.Accepted or dialog.currentColor()==original)
            if restore_text:
                item=owner.canvas.text_objects[text_index];item.clear();item.update(text_original);owner.canvas.changed.emit();owner.canvas.textSelected.emit(text_index);owner.canvas.update()
            owner._color_picker_active=False;owner.end_text_history_group()
            if restore_text:
                owner.dirty=dirty_original
                if owner._safety is not None and revision_original is not None:owner._safety.revision=revision_original
                owner.update_title()
        dialog.deleteLater()


def spin(minimum,maximum,value,suffix=''):
    w=QSpinBox();w.setRange(minimum,maximum);w.setValue(round(value));w.setSuffix(suffix);return w


def geometry_spin(lo,hi,value):
    w=QDoubleSpinBox();w.setRange(lo,hi);w.setDecimals(1);w.setValue(value);w.setSuffix(' px');return w


class TextControls(QWidget):
    edited=Signal(dict)
    def __init__(self,item,parent=None,preview_font=False):
        super().__init__(parent);self.base=dict(item);self.loading=False
        form=QFormLayout(self);form.setSpacing(8);form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows);form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.content=QTextEdit();self.content.setAcceptRichText(False);self.content.setMinimumHeight(90);self.content.setMaximumHeight(160)
        self.content.setPlaceholderText('Введите текст…');form.addRow(self.content)
        self.font=QFontComboBox();self.font.setMinimumWidth(100);self.font.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Fixed);form.addRow('Шрифт',self.font)
        self.font.setToolTip('Введите часть названия, чтобы найти установленный шрифт.')
        self.font_preview = TextPreview(item) if preview_font else None
        if self.font_preview is not None:
            self.font_preview.setMinimumSize(0, 84)
            self.font_preview.setMaximumHeight(95)
            form.addRow(self.font_preview)
        self.size=spin(1,1600,32,' px');form.addRow('Размер текста',self.size)
        row=QHBoxLayout();self.bold=QCheckBox('Жирный');self.italic=QCheckBox('Курсив');row.addWidget(self.bold);row.addWidget(self.italic);form.addRow(row)
        self.color=ColorButton('#202020','Цвет текста');form.addRow(self.color)
        self.stroke=ColorButton('#000000','Цвет обводки');self.stroke_width=spin(0,60,0,' px')
        self.outline_button=QPushButton('Обводка');self.outline_button.setCheckable(True)
        self.outline_button.setToolTip('Нажмите: сразу появится обводка 4 px, затем можно изменить цвет и толщину.')
        self._outline_last=4;form.addRow(self.outline_button)
        self.outline_panel=QWidget();row=QHBoxLayout(self.outline_panel);row.setContentsMargins(0,0,0,0)
        row.addWidget(self.stroke);row.addWidget(self.stroke_width);form.addRow(self.outline_panel)
        self.outline_button.clicked.connect(self.toggle_outline)
        self.stroke_width.valueChanged.connect(self.sync_outline)
        self.width_scale=spin(20,500,100,' %');form.addRow('Ширина букв',self.width_scale)
        self.rotation=spin(-180,180,0,'°');form.addRow('Поворот',self.rotation)
        self.align=QComboBox();self.align.addItems(['По левому краю','По центру','По правому краю']);form.addRow('Выравнивание',self.align)
        self.spacing=spin(-10,100,0,' px');form.addRow('Между буквами',self.spacing)
        self.line_spacing=spin(50,300,115,' %');form.addRow('Между строками',self.line_spacing)
        self.background=QCheckBox('Подложка текста');self.background_color=ColorButton('#ffffff','Цвет подложки')
        row=QHBoxLayout();row.addWidget(self.background);row.addWidget(self.background_color);form.addRow(row)
        self.set_item(item)
        self.content.textChanged.connect(self.emit_values);self.font.currentFontChanged.connect(self.emit_values)
        for w in (self.size,self.stroke_width,self.width_scale,self.rotation,self.spacing,self.line_spacing):w.valueChanged.connect(self.emit_values)
        for w in (self.bold,self.italic,self.background):w.toggled.connect(self.emit_values)
        for w in (self.color,self.stroke,self.background_color):w.colorChanged.connect(self.emit_values)
        self.align.currentIndexChanged.connect(self.emit_values)
        self.background.toggled.connect(self.background_color.setEnabled)
        self.background_color.setToolTip("Сначала включите подложку текста, затем выберите её цвет.")
    def set_item(self,item):
        if item.get('layer_id')!=self.base.get('layer_id'):self._outline_last=4
        self.loading=True;self.base=dict(item)
        # Preserve caret and scroll when only geometry is changing on the canvas.
        if self.content.toPlainText()!=str(item.get('text','')):self.content.setPlainText(str(item.get('text','')))
        self.font.setCurrentFont(QFont(str(item.get('font','Segoe UI'))))
        for widget,key,default in [(self.size,'size',32),(self.stroke_width,'stroke_width',0),
             (self.rotation,'rotation',0),(self.spacing,'letter_spacing',0)]:widget.setValue(round(float(item.get(key,default))))
        self.width_scale.setValue(round(float(item.get('width_scale',1))*100));self.line_spacing.setValue(round(float(item.get('line_spacing',1.15))*100))
        self.bold.setChecked(bool(item.get('bold',False)));self.italic.setChecked(bool(item.get('italic',False)))
        self.background.setChecked(bool(item.get('background_enabled',False)));self.background_color.setEnabled(self.background.isChecked())
        self.align.setCurrentIndex({'left':0,'center':1,'right':2}.get(item.get('align','left'),0))
        for button,key,default in [(self.color,'color','#202020'),(self.stroke,'stroke_color','#000000'),(self.background_color,'background','#ffffff')]:
            button.color=QColor(item.get(key,default));button.refresh()
        self.sync_outline(self.stroke_width.value())
        self.loading=False
        self.update_font_preview(self.values())
    def toggle_outline(self,enabled):
        if self.loading:return
        self.stroke_width.setValue(self._outline_last if enabled else 0)
    def sync_outline(self,value):
        if value>0:self._outline_last=value
        self.outline_button.setChecked(value>0);self.outline_panel.setVisible(value>0)
    def values(self):
        return dict(self.base,text=self.content.toPlainText(),font=self.font.currentFont().family(),size=self.size.value(),
            bold=self.bold.isChecked(),italic=self.italic.isChecked(),color=self.color.color.name(),
            stroke_color=self.stroke.color.name(),stroke_width=self.stroke_width.value(),width_scale=self.width_scale.value()/100,
            rotation=self.rotation.value(),letter_spacing=self.spacing.value(),line_spacing=self.line_spacing.value()/100,
            align=('left','center','right')[self.align.currentIndex()],background_enabled=self.background.isChecked(),background=self.background_color.color.name())
    def update_font_preview(self, values):
        if self.font_preview is not None:
            sample = values['text'].splitlines()
            self.font_preview.set_item(dict(values, text=sample[0][:65] if sample else 'Привет · Aa Бб 123'))

    def emit_values(self,*_):
        if not self.loading:
            values = self.values()
            self.update_font_preview(values)
            self.edited.emit(values)


class TextPreview(QWidget):
    def __init__(self,item):super().__init__();self.item=dict(item);self.setMinimumSize(320,145)
    def set_item(self,item):self.item=dict(item);self.update()
    def paintEvent(self,event):
        p=QPainter(self);p.fillRect(self.rect(),QColor('#e8edf5'))
        item=dict(self.item,x=0,y=0,rotation=0)
        _,rect=text_geometry(item);width=rect.width()*float(item.get('width_scale',1));height=rect.height()
        scale=min((self.width()-28)/max(1,width),(self.height()-28)/max(1,height),1.5)
        p.translate((self.width()-width*scale)/2-rect.x()*scale,(self.height()-height*scale)/2-rect.y()*scale)
        p.scale(scale,scale);draw_text(p,item);p.end()


class TextDialog(QDialog):
    def __init__(self,item,parent=None):
        super().__init__(parent);self.setWindowTitle('Текст · DOGFORST');self.resize(760,650)
        root=QVBoxLayout(self);root.addWidget(QLabel('Текст остаётся редактируемым. На холсте потяните угловую ручку для размера.'))
        row=QHBoxLayout();self.controls=TextControls(item);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(self.controls)
        self.preview=TextPreview(item);row.addWidget(scroll,1);row.addWidget(self.preview,1);root.addLayout(row,1)
        self.controls.edited.connect(self.preview.set_item)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText('Применить');buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена')
        buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);root.addWidget(buttons)
    def values(self):return self.controls.values()


class ShapePreview(QWidget):
    def __init__(self,name,options):super().__init__();self.name=name;self.options=options;self.zoom=100;self.background='light';self.setMinimumSize(320,300)
    def paintEvent(self,event):
        from preview_support import paint_checker
        from shapes import shape_path
        from PySide6.QtGui import QTransform
        p=QPainter(self);paint_checker(p,self.rect(),self.background)
        w,h=self.options.get('width',240),self.options.get('height',160);rect=QRectF(0,0,w,h);center=rect.center()
        t=QTransform().translate(center.x(),center.y()).rotate(self.options.get('rotation',0)).shear(self.options.get('shear',0)/100,0).translate(-center.x(),-center.y())
        bounds=t.map(shape_path(self.name,rect,self.options.get('points',5))).boundingRect();margin=self.options.get('stroke_width',4)/2*(1+abs(self.options.get('shear',0))/100)+5;bounds=bounds.adjusted(-margin,-margin,margin,margin)
        factor=min((self.width()-30)/max(1,bounds.width()),(self.height()-30)/max(1,bounds.height()))*self.zoom/100
        p.translate(self.width()/2-bounds.center().x()*factor,self.height()/2-bounds.center().y()*factor);p.scale(factor,factor);draw_shape(p,self.name,rect,self.options);p.end()


class ShapePicker(QDialog):
    def __init__(self,current='Прямоугольник',parent=None):
        super().__init__(parent);self.setWindowTitle('Фигуры · DOGFORST');self.selected=current;self.resize(650,680)
        root=QVBoxLayout(self);root.addWidget(QLabel('Выберите фигуру — затем откроются её параметры.'))
        panel=QWidget();grid=QGridLayout(panel);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(panel);root.addWidget(scroll,1)
        from widgets import AnimatedToolButton
        for i,name in enumerate(SHAPES):
            pix=QPixmap(96,80);pix.fill(Qt.GlobalColor.transparent);p=QPainter(pix)
            draw_shape(p,name,QRectF(20,12,56,56),dict(DEFAULT_SHAPE,stroke='#80baff',stroke_width=2.5));p.end()
            b=AnimatedToolButton();b.setText(name);b.setIcon(QIcon(pix));b.setIconSize(QSize(96,80));b.setFixedSize(140,124)
            b.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
            b.setCheckable(True);b.setChecked(name==current)
            b.clicked.connect(lambda checked=False,n=name:self.pick(n));grid.addWidget(b,i//4,i%4)
        cancel=QPushButton('← Назад к инструментам');cancel.clicked.connect(self.reject);root.addWidget(cancel)
    def pick(self,name):self.selected=name;self.accept()


class ShapeDialog(QDialog):
    Back = 2
    def __init__(self,name,options,parent=None,placement=None,opacity=100):
        super().__init__(parent);self.placement=placement;self.name=name;self.setWindowTitle(f'{name} · параметры');self.resize(940,720)
        root=QVBoxLayout(self);split=QSplitter();root.addWidget(split,1);controls=QWidget();form=QFormLayout(controls);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(controls);split.addWidget(scroll)
        self.outline=ColorButton(options['stroke'],'Цвет контура');self.fill=ColorButton(options['fill'],'Цвет фона / заливки')
        self.filled=QCheckBox('Заливать фигуру');self.filled.setChecked(options['filled'] if name not in ('Линия','Стрелка') else False);self.filled.setEnabled(name not in ('Линия','Стрелка'))
        self.width=spin(1,200,options['stroke_width'],' px');self.rotation=spin(-180,180,options.get('rotation',0),'°')
        self.shear=spin(-100,100,options.get('shear',0),' %');self.exact=QCheckBox('Точный размер вместо протягивания')
        self.exact.setChecked(options.get('exact',False));self.w=geometry_spin(1,24000,options.get('width',240));self.h=geometry_spin(1,24000,options.get('height',160))
        self.points=spin(3,24,options.get('points',5));form.addRow('Лучи звезды',self.points);self.points.setEnabled(name=='Звезда')
        self.dashed=QCheckBox('Пунктирный контур');self.dashed.setChecked(options.get('dashed',False))
        for label,widget in [('Контур',self.outline),('Толщина',self.width),('',self.filled),('Заливка',self.fill),('Поворот',self.rotation),('Наклон / курсив',self.shear),('',self.dashed),('',self.exact),('Ширина',self.w),('Высота',self.h)]:form.addRow(label,widget)
        self.fill.setEnabled(self.filled.isChecked());self.filled.toggled.connect(self.fill.setEnabled)
        self.w.setEnabled(self.exact.isChecked());self.h.setEnabled(self.exact.isChecked());self.exact.toggled.connect(self.w.setEnabled);self.exact.toggled.connect(self.h.setEnabled)
        if placement is not None:
            self.rotation.setRange(-36000,36000);self.rotation.setValue(round(placement['rotation']))
            self.exact.setChecked(True);self.exact.hide();self.x=geometry_spin(-100000,100000,placement['x']);self.y=geometry_spin(-100000,100000,placement['y']);form.insertRow(0,'X',self.x);form.insertRow(1,'Y',self.y)
            self.object_opacity=spin(0,100,opacity,' %');form.addRow('Непрозрачность слоя',self.object_opacity)
        self.preview=ShapePreview(name,self.values());side=QWidget();side_layout=QVBoxLayout(side);side_layout.addWidget(self.preview,1);self.preview_zoom=QSlider(Qt.Orientation.Horizontal);self.preview_zoom.setRange(25,200);self.preview_zoom.setValue(100);side_layout.addWidget(QLabel('Масштаб примера — размер фигуры не меняется'));side_layout.addWidget(self.preview_zoom)
        self.preview_background=QComboBox();self.preview_background.addItems(['Светлая шахматка','Тёмная шахматка']);side_layout.addWidget(self.preview_background);split.addWidget(side);split.setSizes([430,450])
        self.preview_zoom.valueChanged.connect(lambda v:(setattr(self.preview,'zoom',v),self.preview.update()));self.preview_background.currentIndexChanged.connect(lambda i:(setattr(self.preview,'background','dark' if i else 'light'),self.preview.update()))
        for w in (self.width,self.rotation,self.shear,self.w,self.h,self.points):w.valueChanged.connect(self.update_preview)
        for w in (self.filled,self.exact,self.dashed):w.toggled.connect(self.update_preview)
        for w in (self.outline,self.fill):w.colorChanged.connect(self.update_preview)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
        self.back=buttons.addButton('← Назад к фигурам',QDialogButtonBox.ButtonRole.ActionRole);self.back.clicked.connect(lambda:self.done(self.Back))
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText('Применить' if placement is not None else 'Рисовать');buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена')
        buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);root.addWidget(buttons)
    def values(self):return dict(stroke=self.outline.color.name(),fill=self.fill.color.name(),filled=self.filled.isChecked(),stroke_width=self.width.value(),rotation=self.rotation.value(),shear=self.shear.value(),exact=self.exact.isChecked(),width=self.w.value(),height=self.h.value(),dashed=self.dashed.isChecked(),points=self.points.value())
    def object_values(self):
        from shape_objects import shape_source
        from raster_objects import clone_object
        obj=clone_object(self.placement);options=self.values();source,recipe=shape_source(self.name,options)
        
        for key,dimension in [('flat_x',self.w.value()),('flat_y',self.h.value())]:
            if dimension<=1:recipe['options'][key]=obj['shape']['options'].get(key,False)
        obj.update(source=source,shape=recipe,x=self.x.value(),y=self.y.value(),width=float(self.w.value()),height=float(self.h.value()),rotation=float(self.rotation.value()));return obj
    def update_preview(self,*_):self.preview.options=self.values();self.preview.update()


class ExportDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent);self.setWindowTitle('Экспорт изображения');self.setMinimumWidth(410)
        form=QFormLayout(self);form.addRow(QLabel('Выберите формат. Затем укажите, куда сохранить изображение.'))
        self.format=QComboBox();self.format.addItems(['PNG — прозрачность, без потерь','JPG — небольшой размер','BMP — растровое изображение','WEBP — современный формат'])
        self.quality=spin(1,100,95,' %');self.background=ColorButton('#ffffff','Фон для JPG / BMP')
        form.addRow('Формат',self.format);form.addRow('Качество JPG / WEBP',self.quality);form.addRow(self.background)
        self.format.currentIndexChanged.connect(self.sync);self.sync()
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText('Сохранить…');buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена')
        buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);form.addRow(buttons)
    def sync(self,*_):
        quality=self.format.currentIndex() in (1,3);self.quality.setEnabled(quality);self.background.setEnabled(self.format.currentIndex() in (1,2))
        self.quality.setToolTip('Качество сжатия выбранного формата.' if quality else 'Для PNG и BMP качество сжатия здесь не настраивается.')
        self.background.setToolTip('Фон для форматов без прозрачности.' if self.background.isEnabled() else 'Этот формат сохраняет прозрачность; подложка не требуется.')
    @property
    def extension(self):return ('png','jpg','bmp','webp')[self.format.currentIndex()]
