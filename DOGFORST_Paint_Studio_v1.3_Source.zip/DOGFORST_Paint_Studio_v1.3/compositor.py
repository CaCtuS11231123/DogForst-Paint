"""Blend document tiles on transparent RGBA, never against the workspace checkerboard.

Each layer's pixels and editable texts form one source before applying its mode.
Normal groups isolate children with blend modes; other all-normal legacy paths
retain the existing direct rendering. Nested temporary buffers remain bounded.
"""
from PySide6.QtCore import QRect,QRectF,QSize,Qt
from PySide6.QtGui import QPainter,QImage
from layers import transparent_image
from text_model import draw_text
from blending import composition_mode
from effects import active_glow,apply_glow,glow_margin
from clipping import clip_image

TILE=256


def paint_tiles(painter,layers,groups,stack,texts,size,region=None,preview=None,masks=None,disabled_masks=()):
    masks=masks or {};active_masks=set(masks)-set(disabled_masks)
    mapping={layer.id:layer for layer in layers};owned={}
    for text in texts:owned.setdefault(text.get('layer_id'),[]).append(text)
    bounds=QRect(0,0,*size)
    clip=bounds if region is None else region.toAlignedRect().intersected(bounds)
    if clip.isEmpty():return
    stack=stack if groups else [layer.id for layer in layers]
    special={}
    def contains_blend(identifier):
        if identifier not in special:
            node=groups.get(identifier) or mapping[identifier]
            children=[contains_blend(child) for child in node.children] if identifier in groups else []
            special[identifier]=getattr(node,'clipped',False) or identifier in active_masks or active_glow(node) is not None or node.blend_mode!='normal' or any(children)
        return special[identifier]
    for identifier in stack:contains_blend(identifier)

    def buffer(tile):
        image=transparent_image(tile.width(),tile.height()).convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
        target=QPainter(image);target.translate(-tile.x(),-tile.y());target.setClipRect(QRectF(tile))
        return image,target

    def raw_layer(target,node):
        target.drawImage(0,0,node.image)
        if preview is not None and preview[0]==node.id:preview[1](target)
        for text in owned.get(node.id,[]):draw_text(target,text)

    def source_for(identifier,tile,styles=True):
        node=groups.get(identifier) or mapping[identifier]
        value=active_glow(node) if styles else None
        margin=glow_margin(value) if value else 0
        expanded=tile.adjusted(-margin,-margin,margin,margin)
        source,local=buffer(expanded)
        try:
            if identifier in groups:nodes(local,node.children,expanded)
            else:raw_layer(local,node)
        finally:local.end()
        if identifier in active_masks:
            from masks import apply_mask
            source=apply_mask(source,masks[identifier],expanded)
        if value:source=apply_glow(source,value).copy(margin,margin,tile.width(),tile.height())
        return source

    def nodes(target,ids,tile):
        base=None;base_alpha=None
        for identifier in ids:
            node=groups.get(identifier) or mapping[identifier]
            clipped=getattr(node,'clipped',False)
            if not clipped:base=identifier;base_alpha=None
            if not node.visible or node.opacity<=0:continue
            if clipped and base is None:continue
            if identifier in groups and node.opacity==1 and not special[identifier]:
                nodes(target,node.children,tile);continue
            direct=(identifier not in groups and not clipped and not active_glow(node) and node.blend_mode=='normal' and
                    (node.opacity==1 or not owned.get(identifier)) and identifier not in active_masks and not (preview is not None and preview[0]==identifier))
            if direct:
                target.save();target.setOpacity(node.opacity);raw_layer(target,node);target.restore();continue
            source=source_for(identifier,tile)
            if clipped:
                bottom=groups.get(base) or mapping[base]
                if not bottom.visible or bottom.opacity<=0:continue
                if base_alpha is None:base_alpha=source_for(base,tile,False)
                source=clip_image(source,base_alpha,bottom.opacity)
            opacity=node.opacity
            if node.blend_mode=='add' and opacity!=1:
                faded,local=buffer(tile)
                try:local.setOpacity(opacity);local.drawImage(tile.x(),tile.y(),source)
                finally:local.end()
                source=faded;opacity=1.
            target.save()
            try:
                target.setOpacity(opacity);target.setCompositionMode(composition_mode(node.blend_mode))
                target.drawImage(tile.x(),tile.y(),source)
            finally:target.restore()

    # Stable document-aligned tile boundaries across full exports and partial repaints.
    left=clip.left()//TILE*TILE;top=clip.top()//TILE*TILE
    for y in range(top,clip.bottom()+1,TILE):
        for x in range(left,clip.right()+1,TILE):
            tile=QRect(x,y,min(TILE,size[0]-x),min(TILE,size[1]-y))
            result,local=buffer(tile)
            try:
                nodes(local,stack,tile)
                for text in owned.get(None,[]):draw_text(local,text)
            finally:local.end()
            painter.drawImage(x,y,result)


def render_image(size,layers,groups,stack,texts,max_size=None,masks=None,disabled_masks=()):
    """Composition for previews/merge, with optional bounded final preview size."""
    from group_render import paint_stack
    target=QSize(*size)
    if max_size is not None:target.scale(QSize(*max_size),Qt.AspectRatioMode.KeepAspectRatio)
    target.setWidth(max(1,target.width()));target.setHeight(max(1,target.height()))
    image=transparent_image(target.width(),target.height())
    painter=QPainter(image)
    try:
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform,True)
        painter.scale(target.width()/size[0],target.height()/size[1])
        paint_stack(painter,layers,groups,stack,texts,size,masks=masks,disabled_masks=disabled_masks)
    finally:painter.end()
    return image
