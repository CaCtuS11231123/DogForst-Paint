"""Review a real before/after when rasterizing blend-dependent layers."""
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QDialogButtonBox


class MergePreviewDialog(QDialog):
    def __init__(self,before,after,parent=None):
        super().__init__(parent);self.setWindowTitle('Объединение слоёв с наложением')
        self.resize(850,470);root=QVBoxLayout(self)
        note=QLabel('Выбранные слои и их эффекты будут объединены в один обычный растровый слой. '
                    'Взаимодействие с нижними слоями может измениться. Сравните результат перед применением; Ctrl+Z возвращает исходные слои.')
        note.setWordWrap(True);root.addWidget(note)
        row=QHBoxLayout()
        for title,image in [('До объединения',before),('После объединения',after)]:
            column=QVBoxLayout();column.addWidget(QLabel(title))
            view=QLabel();view.setAlignment(Qt.AlignmentFlag.AlignCenter)
            view.setStyleSheet('background:#dfe4ed;border-radius:8px;padding:6px;')
            view.setPixmap(QPixmap.fromImage(image));column.addWidget(view,1);row.addLayout(column,1)
        root.addLayout(row,1)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText('Объединить')
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Оставить слои')
        buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);root.addWidget(buttons)
