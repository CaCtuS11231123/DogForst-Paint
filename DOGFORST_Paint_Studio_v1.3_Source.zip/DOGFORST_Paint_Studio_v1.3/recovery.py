"""Immutable GUI snapshots and crash recovery generations. No QWidget access."""
import copy
import json
import logging
import re
import time
import uuid
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from PySide6.QtGui import QImage
from PySide6.QtCore import QLockFile
from layers import Layer, transparent_image
from project_manager import save_project, read_project
from storage import atomic_bytes, check_cancelled

LOG = logging.getLogger('dogforst')


@dataclass(frozen=True)
class DocumentSnapshot:
    size: tuple
    layers: tuple
    active_layer: int
    texts: tuple
    groups: tuple = ()
    layer_stack: tuple = ()
    masks: tuple = ()
    disabled_masks: tuple = ()
    raster_objects: tuple = ()

    @classmethod
    def capture(cls, canvas):
        canvas.sync_groups();canvas.sync_masks();canvas.sync_raster_objects()
        # QImage's implicit sharing detaches future GUI writes from this snapshot.
        layers = tuple(Layer(l.name, QImage(l.image), l.visible, l.opacity, l.id, l.kind, **l.flags())
                       for l in canvas.layers)
        texts = copy.deepcopy(canvas.text_objects)
        known = {layer.id for layer in layers}
        layers = list(layers)
        for text in texts:
            if text.get('layer_id') not in known:
                layer = Layer('Текст · ' + str(text.get('text',''))[:22],
                              transparent_image(*canvas.doc_size), kind='text')
                layers.append(layer)
                text['layer_id'] = layer.id
                known.add(layer.id)
        from groups import group_data
        stack=list(canvas.layer_stack)
        stack.extend(l.id for l in layers if l.id not in {old.id for old in canvas.layers})
        return cls(tuple(canvas.doc_size),tuple(layers),canvas.active_layer,tuple(texts),
                   tuple(copy.deepcopy(group_data(canvas.groups))),tuple(stack),
                   tuple((i,QImage(image)) for i,image in canvas.masks.items()),tuple(canvas.disabled_masks),tuple((i,dict(copy.deepcopy({k:v for k,v in o.items() if k!='source'}),source=QImage(o['source']))) for i,o in canvas.raster_objects.items()))


@dataclass(frozen=True)
class RecoveryRecord:
    path: Path
    session: str
    revision: int
    source: str | None
    saved_at: str


class RecoveryStore:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def session_directory(self, session):
        if not re.fullmatch(r'[a-f0-9]{32}', session):
            raise ValueError('Некорректный идентификатор восстановления.')
        path = self.root / session
        if not path.resolve().is_relative_to(self.root):
            raise ValueError('Каталог восстановления находится вне хранилища.')
        return path

    def write(self, snapshot, session, revision, source=None, cancelled=None, progress=None):
        directory = self.session_directory(session)
        filename = f'{time.time_ns():020d}-{uuid.uuid4().hex}.mpaint'
        target = directory / filename
        source = str(source) if source else None
        saved_at = datetime.now(timezone.utc).isoformat()
        check_cancelled(cancelled)
        save_project(target, snapshot.size, snapshot.layers, snapshot.active_layer,
                     list(snapshot.texts), backup=False, cancelled=cancelled, progress=progress,
                     groups=list(snapshot.groups),layer_stack=list(snapshot.layer_stack) or None,
                     masks=dict(snapshot.masks),disabled_masks=snapshot.disabled_masks,raster_objects=dict(snapshot.raster_objects))
        # A complete project is recoverable even if the process dies before metadata commit.
        metadata = dict(version=1, session=session, revision=revision, source=source,
                        saved_at=saved_at)
        try:
            atomic_bytes(target.with_suffix('.json'),
                         json.dumps(metadata, ensure_ascii=False, allow_nan=False).encode('utf-8'))
        except OSError:
            LOG.exception('Recovery project saved; metadata could not be committed')
        record = RecoveryRecord(target, session, revision, source, saved_at)
        self._prune(session, keep=2)
        return record

    def _prune(self, session, keep):
        files = sorted(self.session_directory(session).glob('*.mpaint'), reverse=True)
        for old in files[keep:]:
            self.remove(RecoveryRecord(old, session, -1, None, ''))

    def remove(self, record):
        path = Path(record.path)
        directory = self.session_directory(record.session)
        if path.parent != directory or not path.resolve().is_relative_to(self.root):
            raise ValueError('Нельзя удалить файл вне хранилища восстановления.')
        path.unlink(missing_ok=True)
        path.with_suffix('.json').unlink(missing_ok=True)
        try:
            directory.rmdir()
        except OSError:
            pass  # A worker may still be writing a new generation here.

    def discard_session(self, session):
        directory = self.session_directory(session)
        if not directory.exists():
            return
        for path in list(directory.glob('*.mpaint')):
            self.remove(RecoveryRecord(path, session, -1, None, ''))

    def candidates(self):
        """List all complete generations. Full image validation occurs before restoring."""
        records = []
        for directory in self.root.iterdir():
            if not directory.is_dir() or not re.fullmatch(r'[a-f0-9]{32}', directory.name):
                continue
            if not directory.resolve().is_relative_to(self.root):
                continue
            lock = QLockFile(str(directory / '.lock'))
            lock.setStaleLockTime(0)
            if not lock.tryLock(0):
                continue
            lock.unlock()
            for path in directory.glob('*.mpaint'):
                if not path.resolve().is_relative_to(self.root):
                    continue
                try:
                    with zipfile.ZipFile(path) as archive:
                        info = archive.getinfo('project.json')
                        if info.file_size > 4_000_000:
                            continue
                        manifest = json.loads(archive.read(info))
                        if not isinstance(manifest, dict) or not manifest.get('layers'):
                            continue
                    metadata = {}
                    meta = path.with_suffix('.json')
                    if meta.exists() and meta.stat().st_size < 16_000:
                        try:
                            metadata = json.loads(meta.read_text(encoding='utf-8'))
                            if not isinstance(metadata, dict):
                                metadata = {}
                        except (OSError, ValueError):
                            metadata = {}
                    records.append(RecoveryRecord(path, directory.name,
                        int(metadata.get('revision', -1)), metadata.get('source') if isinstance(metadata.get('source'),str) else None,
                        str(metadata.get('saved_at') or datetime.fromtimestamp(
                            path.stat().st_mtime, timezone.utc).isoformat())))
                except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile):
                    LOG.warning('Skipped incomplete recovery generation: %s', path.name)
        return sorted(records, key=lambda r: r.path.name, reverse=True)

    def read(self, record):
        return read_project(record.path)
