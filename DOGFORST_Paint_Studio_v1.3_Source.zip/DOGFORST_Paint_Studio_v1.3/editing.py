"""Canvas interaction: editable text, transform handles, selections and layer actions."""
import math
from PySide6.QtCore import Qt,QPointF,QRectF
from PySide6.QtGui import QPainter,QColor,QPen,QImage,QPolygonF
from PySide6.QtWidgets import QApplication,QDialog,QMessageBox,QMenu
from layers import Layer,transparent_image
from masks import mask_image,apply_mask
from text_model import text_geometry,text_transform,draw_text
from shapes import SHAPES,DEFAULT_SHAPE
from dialogs import TextDialog
from retouch import RETOUCH_TOOLS
from selection_tools import rect_mask,combine_masks,blend_selection,selected_pixels,moved_pixels


class CanvasEditingMixin:
    def ensure_text_layers(self):
        known={layer.id for layer in self.layers}
        for item in self.text_objects:
            if item.get('layer_id') not in known:
                layer=Layer('Текст · '+str(item.get('text',''))[:22],transparent_image(*self.doc_size),kind='text')
                self.layers.append(layer);item['layer_id']=layer.id;known.add(layer.id)

    def text_layer(self,item):
        return next((layer for layer in self.layers if layer.id==item.get('layer_id')),None)

    def select_text(self,index):
        self.selected_text=index
        if 0<=index<len(self.text_objects):
            layer=self.text_layer(self.text_objects[index])
            if layer:
                self.active_layer=self.layers.index(layer)
                if layer.id not in self.selected_layer_ids():self.set_selected_layers({layer.id},layer.id)
        self.textSelected.emit(index);self.changed.emit();self.update()

    def text_handles(self,item):
        _,r=text_geometry(item);transform=text_transform(item)
        points={'size':r.bottomRight(),'width':QPointF(r.right(),r.center().y()),
                'rotate':QPointF(r.center().x(),r.top()-24/max(.1,self.zoom))}
        return {key:self.screen_point(transform.map(pt)) for key,pt in points.items()}

    def selection_handles(self):
        if not self.selection or self.selection_mask is not None:return {}
        r=self.selection
        if min(r.width(),r.height())*self.zoom < 24:
            return {}
        return {key:self.screen_point(point) for key,point in {
            'tl':r.topLeft(),'tm':QPointF(r.center().x(),r.top()),'tr':r.topRight(),
            'mr':QPointF(r.right(),r.center().y()),'br':r.bottomRight(),
            'bm':QPointF(r.center().x(),r.bottom()),'bl':r.bottomLeft(),'ml':QPointF(r.left(),r.center().y())}.items()}

    def handle_at(self,point,handles):
        nearest=min(handles,key=lambda key:(point-handles[key]).manhattanLength(),default=None)
        return nearest if nearest and (point-handles[nearest]).manhattanLength()<=11 else None

    def paint_overlays(self,painter):
        self.paint_retouch_overlay(painter)
        if self.adjustment_session is not None:return
        if self.retouch_session is not None:return
        if self.gradient_session is not None:self.paint_gradient(painter);return
        if self.selection_transform is not None:self.paint_selection_transform(painter);return
        painter.save();painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        if self.selection and self.selection_mask is None:
            a=self.screen_point(self.selection.topLeft());b=self.screen_point(self.selection.bottomRight());rect=QRectF(a,b).normalized()
            painter.fillRect(rect,QColor(80,169,255,22))
            painter.setPen(QPen(QColor('#ffffff'),2));painter.drawRect(rect)
            pen=QPen(QColor('#1671d4'),1.3,Qt.PenStyle.DashLine);pen.setDashOffset(self._marquee_phase);painter.setPen(pen);painter.drawRect(rect)
            if self.tool in ('Выделение','Перемещение'):
                self._paint_handles(painter,self.selection_handles())
            self._overlay_label(painter,rect.bottomLeft()+QPointF(0,23),f'{round(self.selection.width())} × {round(self.selection.height())} px · перенос внутри · Esc — снять')
        if 0<=self.selected_text<len(self.text_objects):
            item=self.text_objects[self.selected_text];layer=self.text_layer(item)
            if layer and not layer.visible:painter.restore();return
            _,rect=text_geometry(item);transform=text_transform(item)
            polygon=QPolygonF([self.screen_point(transform.map(pt)) for pt in (rect.topLeft(),rect.topRight(),rect.bottomRight(),rect.bottomLeft())])
            painter.setBrush(Qt.BrushStyle.NoBrush);painter.setPen(QPen(QColor('#151f32'),3));painter.drawPolygon(polygon)
            painter.setPen(QPen(QColor('#83ceff'),1));painter.drawPolygon(polygon)
            handles=self.text_handles(item);self._paint_handles(painter,handles)
            painter.setPen(QPen(QColor('#63baff'),1));painter.drawLine(handles['rotate'],self.screen_point(transform.map(QPointF(rect.center().x(),rect.top()))))
            self._overlay_label(painter,polygon.boundingRect().bottomLeft()+QPointF(0,23),f"{item.get('size',32)} px · {item.get('rotation',0):.0f}° · угол: размер · справа: ширина · круг: поворот")
        self.selection_overlay(painter)
        self.paint_object_overlay(painter)
        painter.restore()

    def _paint_handles(self,painter,handles):
        for key,point in handles.items():
            rect=QRectF(point.x()-5,point.y()-5,10,10);painter.setPen(QPen(QColor('#101827'),3));painter.setBrush(QColor('#ffffff'))
            if key=='rotate':painter.drawEllipse(rect)
            else:painter.drawRect(rect)
            painter.setPen(QPen(QColor('#237dcc'),1))
            if key=='rotate':painter.drawEllipse(rect)
            else:painter.drawRect(rect)

    def _overlay_label(self,painter,point,text):
        width=painter.fontMetrics().horizontalAdvance(text)+14
        x=max(4,min(point.x(),self.width()-width-4));y=max(18,min(point.y(),self.height()-8))
        r=QRectF(x,y-17,width,23);painter.setPen(Qt.PenStyle.NoPen);painter.setBrush(QColor('#142239'));painter.drawRoundedRect(r,5,5)
        painter.setPen(QColor('#eaf5ff'));painter.drawText(QPointF(x+7,y),text)

    def edit_text_dialog(self,index=None,pos=None):
        old=self.text_objects[index] if index is not None and 0<=index<len(self.text_objects) else None
        base=old or dict(text='',x=(pos.x() if pos else 30),y=(pos.y() if pos else 30),font='Segoe UI',size=48,
                         color=self.color.name(),bold=False,italic=False,rotation=0,stroke_width=0,width_scale=1)
        if old is not None and not self.can_edit(self.text_layer(old)):return
        if old is None and not self.can_insert(self.insertion_parent()):return
        dialog=TextDialog(base,self.window())
        if dialog.exec()!=QDialog.DialogCode.Accepted:return
        item=dialog.values()
        if not item['text'].strip():return
        if old is None:
            if (len(self.layers)+len(self.masks)+1)*self.doc_size[0]*self.doc_size[1]+self.source_pixels()>120_000_000:
                QMessageBox.warning(self,'Текст','Недостаточно бюджета памяти для нового слоя.');return
            layer=Layer('Текст · '+item['text'][:22],transparent_image(*self.doc_size),kind='text')
            parent=self.insertion_parent()
            self.push_history();self.layers.append(layer);item['layer_id']=layer.id;self.text_objects.append(item)
            self.attach_layer(layer.id,parent)
            self.select_text(len(self.text_objects)-1)
        else:
            self.push_history();old.update(item);self.select_text(index)
        self.changed.emit();self.update()

    def _begin_move(self,pos):
        ids={layer.id for layer in self.layers} if self.move_all_layers else {layer.id for layer in self.layers if self.node_visible(layer)} if self.move_all_visible else self.selected_layer_ids()
        if self.editing_mask in self.masks:ids=set()
        ids={layer.id for layer in self.layers if layer.id in ids and not self.node_locked(layer,move=True)}
        if not ids:self.status.emit('Нет доступных для перемещения слоёв: проверьте блокировки.')
        self._move_objects={i:dict(o,source=QImage(o['source'])) for i,o in self.raster_objects.items() if i in ids}
        self._move_coverage=QImage(self.selection_mask) if self.selection_mask is not None and not (self.move_all_visible or self.move_all_layers) else None
        self._move_layers=[(layer,self.raw_pixels(layer) if self._move_coverage is not None else QImage(layer.image)) for layer in self.layers if layer.id in ids]
        self._move_rect=QRectF(self.selection) if self.selection and not (self.move_all_visible or self.move_all_layers) else None
        mask_ids=set(ids)&set(self.masks)
        for identifier in self.groups:
            descendants=set(self.descendant_layers(identifier))
            if identifier in self.masks and descendants and descendants<=ids:mask_ids.add(identifier)
        self._move_masks=[(identifier,QImage(self.masks[identifier])) for identifier in mask_ids]
        skipped=len(self.layers)-len(ids) if (self.move_all_visible or self.move_all_layers) else len(self.selected_layer_ids())-len(ids)
        if skipped:self.status.emit(f'Перемещается слоёв: {len(ids)}. Пропущено скрытых/защищённых: {skipped}. Проверьте «Положение» и «Правки» у нужных слоёв.')
        self._move_texts=[] if self._move_coverage is not None else [(i,dict(item)) for i,item in enumerate(self.text_objects)
            if item.get('layer_id') in ids and (not self._move_rect or self._move_rect.contains(text_transform(item).map(text_geometry(item)[1].center())))]
        self._interaction='move';self._interaction_start=QPointF(pos);self._move_recorded=False
        self.drawing=True

    def _move_to(self,pos):
        delta=pos-self._interaction_start
        if delta.isNull() or not self._move_layers:return
        if not self._move_recorded:
            self.push_history();self._move_recorded=True
            if self._move_coverage is not None:self.rasterize_for_selection({layer.id for layer,_ in self._move_layers})
        for layer,source in self._move_layers:
            if layer.id in self._move_objects and not self._move_rect:
                from raster_objects import render_object
                obj=dict(self._move_objects[layer.id]);obj['x']+=delta.x();obj['y']+=delta.y();layer.image=render_object(obj,self.doc_size);self.remember_object(layer,obj);continue
            if self._move_coverage is not None:image=moved_pixels(source,self._move_coverage,delta)
            elif self._move_rect:
                image=QImage(source);p=QPainter(image);p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Clear)
                p.fillRect(self._move_rect,Qt.GlobalColor.transparent);p.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceOver)
                p.drawImage(self._move_rect.topLeft()+delta,source.copy(self._move_rect.toAlignedRect()));p.end()
            else:
                image=transparent_image(*self.doc_size);p=QPainter(image);p.drawImage(delta,source);p.end()
            if layer.id in self._move_objects and not self._move_rect:
                from raster_objects import render_object
                obj=dict(self._move_objects[layer.id]);obj['x']+=delta.x();obj['y']+=delta.y()
                image=render_object(obj,self.doc_size);layer.image=image;self.remember_object(layer,obj)
            else:layer.image=image
        for identifier,source in self._move_masks:
            image=mask_image(self.doc_size);p=QPainter(image)
            if self._move_coverage is not None:
                p.end();image=moved_pixels(source,self._move_coverage,delta,True);p=QPainter(image)
            elif self._move_rect:
                p.drawImage(0,0,source);p.fillRect(self._move_rect,QColor('white'))
                p.drawImage(self._move_rect.topLeft()+delta,source.copy(self._move_rect.toAlignedRect()))
            else:p.drawImage(delta,source)
            p.end();self.masks[identifier]=image
        for i,original in self._move_texts:
            self.text_objects[i]['x']=original.get('x',0)+delta.x();self.text_objects[i]['y']=original.get('y',0)+delta.y()
        if self._move_rect:
            self.selection=self._move_rect.translated(delta)
            if self._move_coverage is not None:
                image=rect_mask(self.doc_size,None);p=QPainter(image);p.drawImage(delta,self._move_coverage);p.end();self.selection_mask=image;self._selection_overlay_key=None
        self.update()

    def mousePressEvent(self,event):
        if self.fill_job is not None or self.wand_job is not None:return
        self.setFocus();pos=self.doc_point(event.position())
        if event.button()==Qt.MouseButton.MiddleButton or (event.button()==Qt.MouseButton.LeftButton and self._space_down):
            self._panning=True;self._pan_mouse=event.position();self.setCursor(Qt.CursorShape.ClosedHandCursor);return
        if self.adjustment_session is not None:return
        if self.retouch_session is not None:return
        if self.gradient_session is not None:
            if event.button()==Qt.MouseButton.LeftButton:self.gradient_press(event.position(),pos)
            return
        if self.selection_transform is not None:
            if event.button()==Qt.MouseButton.LeftButton:self.selection_transform_press(event.position(),pos)
            return
        if event.button()!=Qt.MouseButton.LeftButton:return
        if self.tool in RETOUCH_TOOLS:
            if self.tool=='Штамп' and event.modifiers()&Qt.KeyboardModifier.AltModifier:self.set_clone_source(pos)
            else:self.start_retouch(pos)
            return
        if self.tool=='Градиент':
            if QRectF(0,0,*self.doc_size).contains(pos) and self.start_gradient(pos):self.gradient_session.drag='b'
            return
        if self.tool=='Лассо':self.lasso_click(pos,event.modifiers());return
        if self.tool=='Волшебная палочка':self.select_wand(pos,event.modifiers());return
        if self.tool=='Перемещение' and (self.move_all_visible or self.move_all_layers):
            self.select_text(-1);self._begin_move(pos);return
        if self.editing_mask in self.masks:
            if self.tool=='Заливка':self.start_mask_fill(int(pos.x()),int(pos.y()));return
            if self.tool in ('Кисть','Карандаш','Маркер','Мягкая кисть','Ластик'):
                if not self.can_edit_mask():return
                self._selection_work=None;self._dab_remaining=0.;self._ink_stroke=None;self._stroke_history_started=False;self._interaction='mask';self.drawing=True;self.last=QPointF(pos)
                self.mask_stroke(pos,pos);self.update();return
        if self.tool in ('Текст','Перемещение') and 0<=self.selected_text<len(self.text_objects):
            hit=self.handle_at(event.position(),self.text_handles(self.text_objects[self.selected_text]))
            if hit:
                if not self.can_edit(self.text_layer(self.text_objects[self.selected_text]),move=True):return
                self.push_history();self._interaction='text_'+hit;self._original_text=dict(self.text_objects[self.selected_text])
                self._interaction_start=QPointF(pos);self.drawing=True;return
        if self.tool=='Перемещение' and not self.auto_select_layer and not self.editing_mask and not self.selection:
            handle=self.handle_at(event.position(),self.object_handles())
            if handle:self.begin_object_drag(handle,pos)
            else:self._begin_move(pos)
            return
        if self.tool=='Пипетка':
            x,y=int(pos.x()),int(pos.y())
            if 0<=x<self.doc_size[0] and 0<=y<self.doc_size[1]:self.color=self.composite_image().pixelColor(x,y);self.colorChanged.emit(self.color)
            return
        if self.tool in ('Текст','Перемещение'):
            hit=self._text_hit(pos) if self.tool=='Текст' or self.auto_select_layer else -1
            if hit>=0:
                self.select_text(hit)
                if self.tool=='Перемещение':
                    self.selection=None;self._begin_move(pos)
                else:
                    if not self.can_edit(self.text_layer(self.text_objects[hit]),move=True):return
                    self._interaction='text_move';self._original_text=dict(self.text_objects[hit]);self._interaction_start=QPointF(pos)
                    self._move_recorded=False;self.drawing=True
                return
            if self.tool=='Текст':self.select_text(-1);self.edit_text_dialog(None,pos);return
        if self.tool in ('Выделение','Перемещение') and self.selection and (self.tool=='Перемещение' or self.effective_selection_mode(event.modifiers())=='replace'):
            hit=self.handle_at(event.position(),self.selection_handles())
            if hit:
                self.push_history();self._interaction='selection_'+hit;self._original_selection=QRectF(self.selection);self.drawing=True;return
            if self.selection_contains(pos):self._begin_move(pos);return
        if self.tool=='Заливка':self.flood_fill(int(pos.x()),int(pos.y()));return
        if self.tool=='Выделение':
            self._selection_before=self.selection_coverage() if self.selection else None;self._rectangle_mode=self.effective_selection_mode(event.modifiers())
            self.push_history();self._interaction='select';self.start=pos;self.selection=None;self.drawing=True;self.update();return
        if self.tool=='Перемещение':
            self.select_text(-1)
            if self.auto_select_layer and len(self.selected_layer_ids()) == 1:
                x,y=int(pos.x()),int(pos.y())
                if 0<=x<self.doc_size[0] and 0<=y<self.doc_size[1]:
                    for i in reversed(range(len(self.layers))):
                        layer=self.layers[i]
                        if self.node_visible(layer) and layer.image.pixelColor(x,y).alpha()>0:
                            self.set_active_layer(i);break
            self._begin_move(pos);return
        if not QRectF(0,0,*self.doc_size).contains(pos) and self.tool not in ('Кисть','Карандаш','Маркер','Мягкая кисть','Ластик',*SHAPES):return
        if self.tool in SHAPES and self.control_node().kind=='group':
            if self.selection is not None or not self.can_insert(self.control_node().id):return
        elif not self.can_edit(erase=self.tool == "Ластик"):return
        self.selected_text=-1;self.textSelected.emit(-1)
        self._selection_work=None
        self._dab_remaining=0.;self._outlined_path=None
        self._ink_stroke=None;self._stroke_history_started=False
        if self.tool in SHAPES:
            self.push_history()
            if self.selection_mask is not None:self.rasterize_for_selection({self.active.id})
        self._interaction='draw';self.drawing=True;self.start=pos;self.last=pos;self.preview=pos
        if self.tool not in SHAPES:self._stroke(pos,pos)
        elif self.shape_options.get('exact'):
            self.preview=pos+QPointF(self.shape_options['width'],self.shape_options['height'])
        self.update()

    def mouseMoveEvent(self,event):
        if getattr(self,'_panning',False):
            self.pan+=event.position()-self._pan_mouse;self._pan_mouse=event.position();self.update();return
        pos=self.doc_point(event.position())
        if self.adjustment_session is not None:return
        if self.retouch_session is not None:self.queue_retouch(pos);return
        if self.gradient_session is not None:self.gradient_move(pos,event.modifiers());return
        if self.selection_transform is not None:self.selection_transform_move(event.position(),pos,event.modifiers());return
        if self.tool=='Лассо' and self._lasso_points:self._lasso_hover=QPointF(pos);self.update();return
        if not self.drawing:
            object_handle=self.handle_at(event.position(),self.object_handles())
            if object_handle:self.setCursor(Qt.CursorShape.CrossCursor if object_handle=='rotate' else Qt.CursorShape.SizeFDiagCursor);return
            handle=None
            if self.tool in ('Текст','Перемещение') and 0<=self.selected_text<len(self.text_objects):handle=self.handle_at(event.position(),self.text_handles(self.text_objects[self.selected_text]))
            if handle:self.setCursor(Qt.CursorShape.SizeHorCursor if handle=='width' else Qt.CursorShape.SizeFDiagCursor if handle=='size' else Qt.CursorShape.CrossCursor)
            elif self.tool in ('Выделение','Перемещение') and self.selection and self.handle_at(event.position(),self.selection_handles()):self.setCursor(Qt.CursorShape.SizeFDiagCursor)
            else:self.update_cursor()
            return
        mode=self._interaction
        if mode.startswith('object_'):
            self.drag_object(mode.split('_',1)[1],pos,event.modifiers());return
        if mode=='mask':
            if pos!=self.last:
                from brushes import stabilized_point
                target=stabilized_point(self.last,pos,self.brush_stabilizer) if self.tool in ('Кисть','Мягкая кисть','Маркер') and not getattr(self,'_releasing_stroke',False) else pos
                self.mask_stroke(self.last,target);self.last=QPointF(target)
            self.update();return
        if mode.startswith('text_'):
            item=self.text_objects[self.selected_text];old=self._original_text
            if mode=='text_move':
                delta=pos-self._interaction_start
                if not delta.isNull() and not self._move_recorded:self.push_history();self._move_recorded=True
                item['x']=old.get('x',0)+delta.x();item['y']=old.get('y',0)+delta.y()
            elif mode=='text_rotate':
                origin=QPointF(old.get('x',0),old.get('y',0));a=self._interaction_start-origin;b=pos-origin
                angle=old.get('rotation',0)+math.degrees(math.atan2(b.y(),b.x())-math.atan2(a.y(),a.x()))
                if event.modifiers()&Qt.KeyboardModifier.ShiftModifier:angle=round(angle/15)*15
                item['rotation']=round((angle+180)%360-180)
                self.status.emit(f"Поворот текста: {item['rotation']}° · Shift — шаг 15°")
            else:
                local=text_transform(old).inverted()[0].map(pos);_,r=text_geometry(old)
                if mode=='text_width':item['width_scale']=max(.2,min(5.,old.get('width_scale',1)*(local.x()-r.left())/max(1,r.width())))
                else:
                    ratio=math.hypot(local.x(),local.y())/max(1.,math.hypot(r.right(),r.bottom()))
                    item['size']=max(1,min(1600,round(old.get('size',32)*ratio)))
            self.textSelected.emit(self.selected_text);self.update();return
        if mode=='move':
            if event.modifiers()&Qt.KeyboardModifier.ShiftModifier:
                delta=pos-self._interaction_start
                pos=QPointF(pos.x(),self._interaction_start.y()) if abs(delta.x())>abs(delta.y()) else QPointF(self._interaction_start.x(),pos.y())
            self._move_to(pos);return
        if mode.startswith('selection_'):
            key=mode.split('_')[1];r=QRectF(self._original_selection)
            if 'l' in key:r.setLeft(pos.x())
            if 'r' in key:r.setRight(pos.x())
            if 't' in key:r.setTop(pos.y())
            if 'b' in key:r.setBottom(pos.y())
            self.selection=r.normalized().intersected(QRectF(0,0,*self.doc_size));self.update();return
        if mode=='select':
            self.selection=QRectF(self.start,pos).normalized().intersected(QRectF(0,0,*self.doc_size));self.update();return
        if self.tool in SHAPES:
            if self.shape_options.get('exact'):pos=self.start+QPointF(self.shape_options['width'],self.shape_options['height'])
            elif event.modifiers()&Qt.KeyboardModifier.ShiftModifier:
                delta=pos-self.start;side=max(abs(delta.x()),abs(delta.y()));pos=self.start+QPointF(math.copysign(side,delta.x()),math.copysign(side,delta.y()))
            self.preview=pos
        elif pos!=self.last:
            from brushes import stabilized_point
            target=stabilized_point(self.last,pos,self.brush_stabilizer) if self.tool in ('Кисть','Мягкая кисть','Маркер') and not getattr(self,'_releasing_stroke',False) else pos
            self._stroke(self.last,target);self.last=target
        self.update()

    def mouseReleaseEvent(self,event):
        if getattr(self,'_panning',False):self._panning=False;self.update_cursor();return
        if self.retouch_session is not None:
            if event.button()==Qt.MouseButton.LeftButton:self.queue_retouch(self.doc_point(event.position()));self.finish_retouch()
            return
        if self.gradient_session is not None:
            if event.button()==Qt.MouseButton.LeftButton:
                self.gradient_move(self.doc_point(event.position()),event.modifiers());self.gradient_session.drag=None
            return
        if self.selection_transform is not None:
            if event.button()==Qt.MouseButton.LeftButton:
                self.selection_transform_move(event.position(),self.doc_point(event.position()),event.modifiers());self.selection_transform.drag=None
            return
        if event.button()!=Qt.MouseButton.LeftButton or not self.drawing:return
        self._releasing_stroke=True
        try:self.mouseMoveEvent(event)
        finally:self._releasing_stroke=False
        if self._interaction=='select' and (self._rectangle_mode!='replace'):
            self.set_selection_mask(rect_mask(self.doc_size,self.selection),self._rectangle_mode,record=False,before=self._selection_before)
        if self._interaction=='draw' and self.tool in SHAPES:
            if not self.create_shape(self.tool,QRectF(self.start,self.preview),self.shape_options):
                p=QPainter(self.active.image);self._draw_shape(p,self.tool,QRectF(self.start,self.preview));p.end()
        if self.selection and (self.selection.width()<1 or self.selection.height()<1):self.selection=None
        self.drawing=False;self.preview=None;self._interaction='';self._outlined_path=None;self._outlined_base=None;self._selection_work=None;self._ink_stroke=None
        if getattr(self,'_created_shape',False):self._created_shape=False;self.shapeCreated.emit()
        if self.selected_text>=0:self.textSelected.emit(self.selected_text)
        self.changed.emit();self.update()

    def mouseDoubleClickEvent(self,event):
        if self.adjustment_session is not None or self.retouch_session is not None or self.selection_transform is not None or self.gradient_session is not None:return
        if self.tool=='Лассо':self.finish_lasso();return
        if self.tool in ('Текст','Перемещение'):
            hit=self._text_hit(self.doc_point(event.position()))
            if hit>=0 and (self.tool=='Текст' or self.auto_select_layer or self.text_objects[hit].get('layer_id') in self.selected_layer_ids()):self.drawing=False;self.edit_text_dialog(hit);return
        if not QRectF(0,0,*self.doc_size).contains(self.doc_point(event.position())):
            self.workspaceMenuRequested.emit(event.globalPosition().toPoint());return
        if self.tool=='Перемещение' and not self.selection and not self.editing_mask and len(self.selected_node_ids())==1:
            from raster_objects import object_transform
            obj=self.object_for_layer()
            if obj is not None and QRectF(0,0,obj['width'],obj['height']).contains(object_transform(obj).inverted()[0].map(self.doc_point(event.position()))):
                self.drawing=False;self._interaction='';self.objectEditRequested.emit();return
        super().mouseDoubleClickEvent(event)

    def keyPressEvent(self,event):
        if self.adjustment_session is not None:
            if event.key()==Qt.Key.Key_Escape or (event.key()==Qt.Key.Key_Z and event.modifiers()&Qt.KeyboardModifier.ControlModifier):self.cancel_adjustment()
            elif event.key() in (Qt.Key.Key_Enter,Qt.Key.Key_Return):self.apply_adjustment()
            return
        if self.retouch_session is not None:
            if event.key()==Qt.Key.Key_Escape or (event.key()==Qt.Key.Key_Z and event.modifiers()&Qt.KeyboardModifier.ControlModifier):self.cancel_retouch();return
            if event.key() in (Qt.Key.Key_Enter,Qt.Key.Key_Return):self.finish_retouch();return
            if event.key()==Qt.Key.Key_Space:self._space_down=True;self.setCursor(Qt.CursorShape.OpenHandCursor)
            return
        if self.gradient_session is not None:
            if event.key() in (Qt.Key.Key_Enter,Qt.Key.Key_Return):self.apply_gradient();return
            if event.key()==Qt.Key.Key_Escape or (event.key()==Qt.Key.Key_Z and event.modifiers()&Qt.KeyboardModifier.ControlModifier):self.cancel_gradient();return
            if event.key()==Qt.Key.Key_Space:self._space_down=True;self.setCursor(Qt.CursorShape.OpenHandCursor)
            return
        if self.selection_transform is not None:
            if event.key() in (Qt.Key.Key_Enter,Qt.Key.Key_Return):self.apply_selection_transform();return
            if event.key()==Qt.Key.Key_Escape or (event.key()==Qt.Key.Key_Z and event.modifiers()&Qt.KeyboardModifier.ControlModifier):self.cancel_selection_transform();return
            if event.key()==Qt.Key.Key_Space:self._space_down=True;self.setCursor(Qt.CursorShape.OpenHandCursor);return
            if event.key() in (Qt.Key.Key_Left,Qt.Key.Key_Right,Qt.Key.Key_Up,Qt.Key.Key_Down):
                amount=10 if event.modifiers()&Qt.KeyboardModifier.ShiftModifier else 1;p=self.selection_transform.parameters
                dx,dy={Qt.Key.Key_Left:(-amount,0),Qt.Key.Key_Right:(amount,0),Qt.Key.Key_Up:(0,-amount),Qt.Key.Key_Down:(0,amount)}[event.key()]
                self.update_selection_transform(x=max(-100000,min(100000,p['x']+dx)),y=max(-100000,min(100000,p['y']+dy)));return
            return
        if self._lasso_points:
            if event.key() in (Qt.Key.Key_Enter,Qt.Key.Key_Return):self.finish_lasso();return
            if event.key() in (Qt.Key.Key_Backspace,Qt.Key.Key_Delete):self._lasso_points.pop();self.selectionStateChanged.emit();self.update();return
        if event.key() in (Qt.Key.Key_Delete,Qt.Key.Key_Backspace) and self.selection_mask is not None:
            self.erase_selected_pixels();return
        if event.key()==Qt.Key.Key_Escape and self.cancel_object_drag():return
        if self.editing_mask in self.masks and event.key() in (Qt.Key.Key_Delete,Qt.Key.Key_Backspace):
            self.fill_mask(0,True);return
        if event.key()==Qt.Key.Key_Space and not event.isAutoRepeat():self._space_down=True;self.setCursor(Qt.CursorShape.OpenHandCursor);return
        if event.key() in (Qt.Key.Key_Left,Qt.Key.Key_Right,Qt.Key.Key_Up,Qt.Key.Key_Down):
            amount=10 if event.modifiers()&Qt.KeyboardModifier.ShiftModifier else 1
            delta={Qt.Key.Key_Left:QPointF(-amount,0),Qt.Key.Key_Right:QPointF(amount,0),Qt.Key.Key_Up:QPointF(0,-amount),Qt.Key.Key_Down:QPointF(0,amount)}[event.key()]
            self.move_selected_by(delta)
            if self.selected_text>=0:self.textSelected.emit(self.selected_text)
            self.changed.emit();self.update();return
        if event.key() in (Qt.Key.Key_Delete,Qt.Key.Key_Backspace) and 0<=self.selected_text<len(self.text_objects):
            index=self.selected_text;layer=self.text_layer(self.text_objects[index])
            if not self.can_edit(layer):return
            self.push_history();del self.text_objects[index]
            if layer and layer.kind=='text' and not any(t.get('layer_id')==layer.id for t in self.text_objects):
                # Keep any raster marks a user may have added to the same layer.
                if layer.image==transparent_image(*self.doc_size):
                    self.layers.remove(layer)
                    if not self.layers:self.layers=[Layer('Слой 1',transparent_image(*self.doc_size))]
            self.active_layer=min(self.active_layer,len(self.layers)-1);self.selected_text=-1;self.textSelected.emit(-1);self.changed.emit();self.update();return
        self._base_keyPressEvent(event)

    def contextMenuEvent(self,event):
        if self.adjustment_session is not None:self.cancel_adjustment();return
        if self.retouch_session is not None:self.cancel_retouch();return
        if self.gradient_session is not None:
            menu=QMenu(self);menu.addAction("Применить градиент",self.apply_gradient);menu.addAction("Отменить градиент",self.cancel_gradient);menu.exec(event.globalPos());return
        if self.selection_transform is not None:
            menu=QMenu(self);menu.addAction('Применить трансформацию',self.apply_selection_transform);menu.addAction('Отменить трансформацию',self.cancel_selection_transform);menu.exec(event.globalPos());return
        menu=QMenu(self)
        action=menu.addAction('Снять выделение · Esc / Ctrl+D',self.cancel_selection)
        action.setEnabled(self.selection is not None or self._interaction=='select')
        action=menu.addAction('Вернуть последнее выделение · Ctrl+Shift+D',self.reselect)
        action.setEnabled(self.last_selection is not None)
        menu.addAction('Выделить всё · Ctrl+A',self.select_all)
        menu.exec(event.globalPos())

    def keyReleaseEvent(self,event):
        if event.key()==Qt.Key.Key_Space and not event.isAutoRepeat():self._space_down=False;self.update_cursor();return
        super().keyReleaseEvent(event)

    def select_all(self):
        target=QRectF(0,0,*self.doc_size)
        if self.selection == target:return
        self.push_history();self.selection=target;self.selected_text=-1
        self.textSelected.emit(-1);self.changed.emit();self.update()

    def cancel_selection(self):
        selecting=self._interaction == 'select' or self._interaction.startswith('selection_')
        if self.selection is not None:
            self.last_selection=QRectF(self.selection)
            if not selecting and not self.drawing:self.push_history()
        if selecting or self._interaction == 'move':
            self.drawing=False;self.preview=None;self._interaction='';self._outlined_path=None;self._outlined_base=None;self._selection_work=None;self._ink_stroke=None
        self.selection=None;self.selected_text=-1;self.textSelected.emit(-1)
        self.changed.emit();self.update();self.status.emit('Выделение снято · Ctrl+Shift+D — вернуть рамку')

    def reselect(self):
        if self.last_selection is None:return
        target=self.last_selection.intersected(QRectF(0,0,*self.doc_size))
        if target.isEmpty() or target==self.selection:return
        self.push_history();self.selection=QRectF(target);self.changed.emit();self.update()


    def layer_image(self,layer,include_effects=True):
        image=QImage(layer.image)
        if layer.id in self.masks and layer.id not in self.disabled_masks:image=image.convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
        p=QPainter(image)
        for text in self.text_objects:
            if text.get('layer_id')==layer.id:draw_text(p,text)
        p.end()
        if layer.id in self.masks and layer.id not in self.disabled_masks:image=apply_mask(image,self.masks[layer.id])
        if include_effects:
            from effects import apply_glow
            image=apply_glow(image,layer.glow)
        if include_effects:image=self.layer_clipping(image,layer)
        return image

    def merge_down(self):
        self.stop_mask_edit()
        if self.control_node().kind=='group':
            self.status.emit('Для объединения выберите слой внутри группы.');return
        if self.active_layer==0:return
        top=self.active;bottom=self.layers[self.active_layer-1]
        if self.parent_id(top.id)!=self.parent_id(bottom.id):
            self.status.emit('Объединять с нижним можно внутри одной группы.');return
        if not self.can_edit(top) or not self.can_edit(bottom) or bottom.alpha_locked:return
        clipping=any(getattr(self.node(i),'clipped',False) for i in self.child_ids(self.parent_id(top.id)))
        if clipping or top.blend_mode!='normal' or bottom.blend_mode!='normal':
            import copy
            from compositor import render_image
            from merge_dialog import MergePreviewDialog
            ids={top.id,bottom.id};remaining=[t for t in self.text_objects if t.get('layer_id') not in ids]
            if clipping:
                pair=[Layer(l.name,self.layer_image(l),l.visible,l.opacity,l.id,blend_mode=l.blend_mode) for l in (bottom,top)]
                image=render_image(self.doc_size,pair,{},[bottom.id,top.id],[])
            else:image=render_image(self.doc_size,[bottom,top],{},[bottom.id,top.id],
                               [t for t in self.text_objects if t.get('layer_id') in ids],masks={i:m for i,m in self.masks.items() if i in ids},disabled_masks=self.disabled_masks)
            flags=dict(bottom.flags(),blend_mode='normal',glow=None,clipped=False)
            merged=Layer(bottom.name+' + '+top.name,image,layer_id=bottom.id,**flags)
            candidate=list(self.layers);candidate[self.active_layer-1:self.active_layer+1]=[merged]
            groups=copy.deepcopy(self.groups);stack=[identifier for identifier in self.layer_stack if identifier!=top.id]
            for group in groups.values():group.children=[identifier for identifier in group.children if identifier!=top.id]
            before=render_image(self.doc_size,self.layers,self.groups,self.layer_stack,self.text_objects,(390,300),masks=self.masks,disabled_masks=self.disabled_masks)
            after=render_image(self.doc_size,candidate,groups,stack,remaining,(390,300),masks={i:m for i,m in self.masks.items() if i not in ids},disabled_masks=self.disabled_masks)
            if MergePreviewDialog(before,after,self.window()).exec()!=QDialog.DialogCode.Accepted:return
            self.push_history();self.text_objects=remaining
            self.layers[self.active_layer-1:self.active_layer+1]=[merged]
        else:
            image=transparent_image(*self.doc_size).convertToFormat(QImage.Format.Format_ARGB32_Premultiplied);p=QPainter(image)
            for layer in (bottom,top):
                if layer.visible:p.setOpacity(layer.opacity);p.drawImage(0,0,self.layer_image(layer))
            p.end();self.push_history();ids={top.id,bottom.id}
            self.text_objects=[t for t in self.text_objects if t.get('layer_id') not in ids]
            self.layers[self.active_layer-1:self.active_layer+1]=[Layer(bottom.name+' + '+top.name,image,layer_id=bottom.id,**dict(bottom.flags(),glow=None))]
        for identifier in ids:self.masks.pop(identifier,None);self.disabled_masks.discard(identifier)
        self.active_layer-=1;self.selected_text=-1;self.textSelected.emit(-1);self.changed.emit();self.update()

    def paste_image(self,image,name='Вставленный слой'):
        if self.editing_mask in self.masks:return self.paste_mask_image(image)
        parent=self.insertion_parent()
        if not self.can_insert(parent):return
        if image.isNull():return
        if (len(self.layers)+len(self.masks)+1)*self.doc_size[0]*self.doc_size[1]+self.source_pixels()>120_000_000:raise ValueError('Достигнут предел памяти слоёв.')
        target=transparent_image(*self.doc_size);p=QPainter(target);p.drawImage(self.selection.topLeft() if self.selection_mask is not None else QPointF(),image);p.end()
        self.push_history();self.layers.insert(self.active_layer+1,Layer(name,target));self.active_layer+=1;self.selected_text=-1
        self.attach_layer(self.active.id,parent);self.set_selected_layers({self.active.id},self.active.id)
        self.changed.emit();self.update()

    def copy_selection(self):
        image=QImage(self.masks[self.editing_mask]) if self.editing_mask in self.masks else self.layer_image(self.active)
        if self.selection_mask is not None:image=selected_pixels(image,self.selection_mask)
        if self.selection:image=image.copy(self.selection.toAlignedRect())
        QApplication.clipboard().setImage(image)

    def cut_selection(self):
        if self.selection_mask is not None:self.erase_selected_pixels(True);return
        if self.editing_mask in self.masks:
            self.copy_selection();self.fill_mask(0,True);return
        if not self.can_edit(erase=True):return
        self.copy_selection();self.push_history();p=QPainter(self.active.image);p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Clear)
        p.fillRect(self.selection or QRectF(0,0,*self.doc_size),Qt.GlobalColor.transparent);p.end()
        self.text_objects=[t for t in self.text_objects if not (t.get('layer_id')==self.active.id and
            (not self.selection or self.selection.contains(text_transform(t).map(text_geometry(t)[1].center()))))]
        self.selected_text=-1;self.textSelected.emit(-1);self.changed.emit();self.update()

    def crop_selection(self):
        if not self.selection:return
        r=self.selection.toAlignedRect().intersected(QRectF(0,0,*self.doc_size).toRect())
        if r.isEmpty():return
        self.push_history()
        for layer in self.layers:layer.image=layer.image.copy(r)
        for item in self.text_objects:item['x']=item.get('x',0)-r.x();item['y']=item.get('y',0)-r.y()
        self.transform_masks((r.width(),r.height()),crop=r)
        for identifier,obj in self.raster_objects.items():obj["x"]-=r.x();obj["y"]-=r.y()
        self.reset_object_keys()
        self.doc_size=(r.width(),r.height());self.selection=None;self.fit_canvas();self.changed.emit();self.update()

    def apply_filter(self,name):
        if self.editing_mask in self.masks:
            if name=='invert':self.invert_mask()
            else:self.status.emit('Маска уже состоит из оттенков серого.')
            return
        if not self.can_edit():return
        import numpy as np
        original=self.raw_pixels(self.active) if self.selection_mask is not None else QImage(self.active.image)
        source=original.convertToFormat(QImage.Format.Format_RGBA8888)
        pixels=np.frombuffer(source.constBits(),dtype=np.uint8).reshape(source.height(),source.bytesPerLine())[:,:source.width()*4].reshape(source.height(),source.width(),4).copy()
        r=self.selection.toAlignedRect().intersected(source.rect()) if self.selection else source.rect()
        view=pixels[r.top():r.bottom()+1,r.left():r.right()+1,:3]
        if name=='invert':view[:]=255-view
        else:view[:]=np.round(view.astype(float)@np.array([.299,.587,.114]))[:,:,None].astype(np.uint8)
        self.push_history()
        if self.selection_mask is not None:self.rasterize_for_selection({self.active.id})
        self.active.image=QImage(pixels.data,source.width(),source.height(),source.width()*4,QImage.Format.Format_RGBA8888).copy().convertToFormat(QImage.Format.Format_ARGB32)
        if self.selection_mask is not None:self.active.image=blend_selection(original,self.active.image,self.selection_mask,self.selection)
        if not self.selection:
            for text in self.text_objects:
                if text.get('layer_id')==self.active.id:
                    for key in ('color','stroke_color','background'):
                        color=QColor(text.get(key,'#202020'));rgb=[color.red(),color.green(),color.blue()]
                        text[key]=QColor(*([255-v for v in rgb] if name=='invert' else [round(sum(a*b for a,b in zip(rgb,(.299,.587,.114))))]*3)).name()
        self.changed.emit();self.update()
