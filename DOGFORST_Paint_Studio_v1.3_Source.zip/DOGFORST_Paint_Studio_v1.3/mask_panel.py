"""Explicit mask target, thumbnail and reversible controls for beginners."""
from PySide6.QtCore import Qt,QSignalBlocker
from PySide6.QtGui import QPixmap,QColor
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QCheckBox


class MaskPanel(QWidget):
    def __init__(self,owner):
        super().__init__();self.owner=owner;self.canvas=owner.canvas
        layout=QVBoxLayout(self)
        self.title=QLabel();self.title.setWordWrap(True);layout.addWidget(self.title)
        self.preview=QLabel();self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter);self.preview.setMinimumHeight(85);layout.addWidget(self.preview)
        self.hint=QLabel('Белый показывает, чёрный скрывает, серый делает полупрозрачным.');self.hint.setWordWrap(True);layout.addWidget(self.hint)
        self.add=QPushButton('Добавить белую маску');self.add.clicked.connect(lambda:owner.run_canvas_action(self.canvas.add_mask));layout.addWidget(self.add)
        self.enabled=QCheckBox('Маска включена');self.enabled.toggled.connect(self.canvas.set_mask_enabled);layout.addWidget(self.enabled)
        self.edit=QCheckBox('Рисовать по маске');self.edit.toggled.connect(self.edit_target);layout.addWidget(self.edit)
        self.only=QCheckBox('Показать саму маску');self.only.toggled.connect(self.show_only);layout.addWidget(self.only)
        row=QHBoxLayout();self.black=QPushButton('Чёрная кисть');self.white=QPushButton('Белая кисть')
        self.black.clicked.connect(lambda:self.paint_color('black'));self.white.clicked.connect(lambda:self.paint_color('white'))
        row.addWidget(self.black);row.addWidget(self.white);layout.addLayout(row)
        self.invert=QPushButton('Инвертировать маску');self.invert.clicked.connect(self.canvas.invert_mask);layout.addWidget(self.invert)
        self.apply=QPushButton('Применить маску (растр)');self.apply.setToolTip('Запечь в пиксели отдельного слоя. Его текст станет растровым. Ctrl+Z возвращает исходное.')
        self.apply.clicked.connect(lambda:owner.run_canvas_action(self.canvas.apply_current_mask));layout.addWidget(self.apply)
        self.remove=QPushButton('Удалить маску · вернуть исходное');self.remove.clicked.connect(self.canvas.delete_mask);layout.addWidget(self.remove)
        layout.addStretch(1);self.canvas.changed.connect(self.refresh);self.refresh()

    def edit_target(self,enabled):
        if enabled:self.owner.set_tool('Кисть');self.canvas.start_mask_edit()
        else:self.canvas.stop_mask_edit();self.canvas.changed.emit();self.canvas.update()

    def show_only(self,value):
        if value and self.canvas.editing_mask is None:self.edit_target(True)
        self.canvas.show_mask=bool(value and self.canvas.editing_mask in self.canvas.masks);self.canvas.update()

    def paint_color(self,color):
        if self.canvas.editing_mask!=self.canvas.control_node().id:self.edit_target(True)
        if self.canvas.editing_mask is not None:self.owner.set_color(QColor(color))

    def refresh(self):
        node=self.canvas.control_node();exists=node.id in self.canvas.masks
        editable=not self.canvas.node_locked(node)
        self.title.setText(('Маска: ' if exists else 'Нет маски: ')+node.name)
        self.add.setEnabled(not exists and editable)
        self.enabled.setEnabled(exists)
        self.edit.setEnabled(exists and editable);self.only.setEnabled(exists and editable)
        for widget in (self.black,self.white,self.invert,self.remove):widget.setEnabled(exists and editable)
        self.apply.setEnabled(exists and editable and node.kind!='group' and node.id not in self.canvas.disabled_masks)
        for widget,value in [(self.enabled,exists and node.id not in self.canvas.disabled_masks),(self.edit,self.canvas.editing_mask==node.id),(self.only,self.canvas.show_mask and self.canvas.editing_mask==node.id)]:
            with QSignalBlocker(widget):widget.setChecked(value)
        if exists:
            self.preview.setPixmap(QPixmap.fromImage(self.canvas.masks[node.id].scaled(160,90,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)))
        else:self.preview.clear()
        self.hint.setText('Маска выключена. Включите её, чтобы увидеть результат на рисунке.' if node.id in self.canvas.disabled_masks else
                          'Слой или папка защищены: снимите блокировку «Правки».' if not editable else
                          'Белый показывает, чёрный скрывает, серый делает полупрозрачным. Рисунок не стирается.')
