import sys
import json
import zipfile
import io
import copy
from pathlib import Path

from PySide6.QtCore import Qt, QPointF, QRectF, Signal, QByteArray, QBuffer, QIODevice
from PySide6.QtGui import (
    QAction, QColor, QImage, QPainter, QPen, QBrush, QFont, QKeySequence
)
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFileDialog, QColorDialog,
    QInputDialog, QMessageBox, QToolBar, QSpinBox, QLabel, QComboBox, QLineEdit, QFontDialog,
    QListWidget, QListWidgetItem, QDockWidget, QSlider, QPushButton,
    QHBoxLayout, QVBoxLayout, QFormLayout, QDoubleSpinBox, QCheckBox,
    QToolButton, QDialog, QTextEdit, QDialogButtonBox, QFontComboBox
)

from layers import Layer, transparent_image
from clipping import ClippingMixin
from selection_transform import SelectionTransformMixin
from gradients import GradientMixin
from ink_stroke import InkStrokeMixin
from shape_objects import ShapeObjectsMixin
from layer_merge import LayerMergeMixin
from retouch import RetouchMixin,RETOUCH_TOOLS
from adjustments import AdjustmentMixin
from selection_tools import SelectionMixin,blend_selection,selected_pixels,moved_pixels
from raster_objects import RasterObjectsMixin,clone_object
from project_manager import save_project, read_project
from tools import tool_cursor
from PySide6.QtCore import QThreadPool
from PySide6.QtWidgets import QProgressDialog
from PySide6.QtGui import QTransform
from fill import FillJob
from history import HistoryEngine
from masks import MaskActionsMixin,apply_mask
from layer_actions import LayerActionsMixin
from groups import GroupActionsMixin, group_data, read_groups
from group_render import paint_stack
from blending import requires_composite
from editing import CanvasEditingMixin
from text_model import draw_text, text_geometry, text_transform
from shapes import SHAPES, DEFAULT_SHAPE, draw_shape
from PySide6.QtCore import QTimer, QSaveFile, QPoint

APP_NAME = "DOGFORST Paint Studio"

class PaintCanvas(AdjustmentMixin, RetouchMixin, LayerMergeMixin, ShapeObjectsMixin, InkStrokeMixin, GradientMixin, SelectionTransformMixin, SelectionMixin, ClippingMixin, RasterObjectsMixin, MaskActionsMixin, GroupActionsMixin, LayerActionsMixin, CanvasEditingMixin, QWidget):
    TOOLS = [
        "Кисть", "Карандаш", "Маркер", "Мягкая кисть", "Ластик",
        "Линия", "Прямоугольник", "Эллипс", "Текст", "Пипетка",
        *RETOUCH_TOOLS, "Заливка", "Градиент", "Выделение", "Лассо", "Волшебная палочка", "Перемещение", *[s for s in SHAPES if s not in ("Линия","Прямоугольник","Эллипс")]
    ]

    adjustmentChanged=Signal()
    adjustmentFinished=Signal(bool)
    retouchChanged=Signal()
    shapeCreated=Signal()
    objectEditRequested=Signal()
    workspaceMenuRequested=Signal(QPoint)
    gradientChanged=Signal()
    selectionTransformChanged=Signal()
    selectionStateChanged=Signal()
    textSelected = Signal(int)
    historyRestored = Signal()
    historyChanged = Signal()
    changed = Signal()
    modified = Signal()
    status = Signal(str)
    colorChanged = Signal(QColor)

    def __init__(self):
        super().__init__()
        self.doc_size = (1200, 800)
        self.raster_objects={};self._object_keys={};self._candidate_key=None;self._candidate_object=None;self._interactive_images={}
        self.layers = [Layer("Слой 1", transparent_image(*self.doc_size))]
        self.active_layer = 0
        self.groups = {}
        self.layer_stack = [self.layers[0].id]
        self._selected_nodes = {self.layers[0].id}
        self.current_node = self.layers[0].id
        self.changed.connect(self.sync_groups)
        self.masks={};self.disabled_masks=set();self.editing_mask=None;self.show_mask=False;self._before_mask_color=None
        self.changed.connect(self.sync_masks)
        self.changed.connect(self.sync_raster_objects)
        self.tool = "Кисть"
        self.color = QColor("#202020")
        self.brush_shape = "round"
        self.brush_outline = 0
        self.brush_outline_color = QColor("#17263f")
        self._outlined_path = None
        self.brush_hardness = 100
        self.brush_stabilizer = 18
        self.checker_style = "light"
        self.brush_spacing=12;self.brush_flow=100;self._ink_stroke=None;self._stroke_history_started=False
        self.brush_size = 8
        self.brush_opacity = 100
        self.fill_tolerance = 24
        self.zoom = 0.8
        self.pan = QPointF(25, 25)
        self.smoothing = True
        self.drawing = False
        self.start = QPointF()
        self.last = QPointF()
        self.preview = None
        self.selection = None
        self.init_selections()
        self.init_selection_transform()
        self.init_gradient()
        self.init_retouch()
        self.init_adjustment()
        self.last_selection = None;self.last_selection_mask=None;self.clear_transient_selection()
        self.selection_start = None
        self.selection_move_start = None
        self.selection_image = None
        self.selection_offset = QPointF()
        self.max_history = 35
        self.history_engine = HistoryEngine(self.max_history)
        self.history = self.history_engine.undo_view
        self.future = self.history_engine.redo_view
        self._history_group_active = False
        self._restoring_history = False
        self.changed.connect(self.schedule_history_commit)
        self.fill_job = None
        self.workspace_color = QColor("#121722")
        self.workspace_brush = None
        self._opacity_edit = False
        # Text stays vector/editable until rasterized by export.
        self.text_objects = []
        self.history_engine.current_state=self.snapshot
        self.selected_text = -1
        self.text_drag_offset = QPointF()
        self._text_dragging = False
        self.shape_options = dict(DEFAULT_SHAPE)
        self.auto_select_layer = False
        self.move_all_visible = False
        self.move_all_layers = False
        self._space_down = False
        self._interaction = ''
        self._marquee_phase = 0
        self.show_checkerboard = True
        self._marquee_timer = QTimer(self)
        self._marquee_timer.setInterval(80)
        self._marquee_timer.timeout.connect(self._animate_marquee)
        self._marquee_timer.start()
        self.setMinimumSize(500, 350)
        self.setAcceptDrops(True)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    @property
    def active(self):
        return self.layers[self.active_layer]

    def doc_point(self, point):
        return QPointF((point.x() - self.pan.x()) / self.zoom,
                       (point.y() - self.pan.y()) / self.zoom)

    def screen_point(self, point):
        return QPointF(self.pan.x() + point.x() * self.zoom,
                       self.pan.y() + point.y() * self.zoom)

    def dragEnterEvent(self,event):
        window=self.window()
        if window is not self and hasattr(window,"import_paths"):window.dragEnterEvent(event)
        else:event.ignore()

    def dropEvent(self,event):
        window=self.window()
        if window is not self and hasattr(window,"import_paths"):window.dropEvent(event)
        else:event.ignore()

    def snapshot(self):
        self.sync_groups();self.sync_masks();self.sync_raster_objects()
        return {
            "doc_size": self.doc_size,
            "raster_objects": {identifier:clone_object(obj) for identifier,obj in self.raster_objects.items()},
            "active_layer": self.active_layer,
            "layers": [
                (layer.name, QImage(layer.image), layer.visible, layer.opacity, layer.id, layer.kind)
                for layer in self.layers
            ],
            "selection": QRectF(self.selection) if self.selection else None,
            "selection_mask":QImage(self.selection_mask) if self.selection_mask is not None else None,
            "text_objects": copy.deepcopy(self.text_objects),
            "selected_text": self.selected_text,
            "layer_flags": {layer.id: layer.flags() for layer in self.layers},
            "selected_layers": sorted(self.selected_layer_ids()),
            "groups": group_data(self.groups),
            "layer_stack": list(self.layer_stack),
            "selected_nodes": list(self.selected_node_ids()),
            "current_node": self.control_node().id,
            "masks": {identifier:QImage(image) for identifier,image in self.masks.items()},
            "disabled_masks": list(self.disabled_masks),"editing_mask": self.editing_mask,
            "mask_color":self.color.name(QColor.NameFormat.HexArgb) if self.editing_mask else None,
            "before_mask_color":self._before_mask_color.name(QColor.NameFormat.HexArgb) if self._before_mask_color is not None else None,
        }

    def restore(self, snap):
        self.cancel_pending_preview()
        self._ink_stroke=None;self._interactive_images={}
        self.stop_mask_edit()
        self.raster_objects={i:clone_object(o) for i,o in snap.get("raster_objects",{}).items()}
        self.doc_size = snap["doc_size"]
        self.active_layer = snap["active_layer"]
        self.layers = [
            Layer(name, QImage(image), visible, opacity, layer_id, kind)
            for name, image, visible, opacity, layer_id, kind in snap["layers"]
        ]
        for layer in self.layers:
            for key,value in snap.get("layer_flags",{}).get(layer.id,{}).items():
                setattr(layer,key,value)
        self.groups,self.layer_stack=read_groups(snap.get('groups',[]),snap.get('layer_stack',[l.id for l in self.layers]),{l.id for l in self.layers})
        self._selected_nodes=set(snap.get('selected_nodes',[]));self.current_node=snap.get('current_node')
        self.masks={identifier:QImage(image) for identifier,image in snap.get("masks",{}).items()}
        self.disabled_masks=set(snap.get("disabled_masks",[]));self.editing_mask=snap.get("editing_mask");self.show_mask=False
        if self.editing_mask in self.masks:
            self._before_mask_color=QColor(snap.get("before_mask_color") or self.color.name());self.color=QColor(snap.get("mask_color") or "#000000");self.colorChanged.emit(self.color)
        self._selected_layer_ids = set(snap.get("selected_layers",[self.layers[self.active_layer].id]))
        self.active_layer = max(0, min(self.active_layer, len(self.layers) - 1))
        self.selection = QRectF(snap["selection"]) if snap["selection"] else None
        self.selection_mask=QImage(snap["selection_mask"]) if snap.get("selection_mask") is not None else None
        self._selection_overlay_key=None;self.clear_transient_selection()
        self.text_objects = [dict(item) for item in snap.get("text_objects", [])]
        self.selected_text = int(snap.get("selected_text", -1))
        self.reset_object_keys()
        self.drawing = False
        self.preview = None
        self.selection_image = None
        self._text_dragging = False
        self.textSelected.emit(self.selected_text)
        self.modified.emit()
        self.changed.emit()
        self.update()

    def push_history(self, mark_modified=True):
        self.cancel_pending_preview()
        self._history_group_active = False
        self.history_engine.max_steps = self.max_history
        self.history_engine.begin(self.snapshot())
        if mark_modified:
            self.modified.emit()
        QTimer.singleShot(0, self.commit_history)

    def schedule_history_commit(self):
        if self.history_engine.pending is not None:
            QTimer.singleShot(0, self.commit_history)

    def commit_history(self, force=False):
        if self._restoring_history or self.history_engine.pending is None:
            return
        if not force and (self.drawing or self._opacity_edit or self._history_group_active):
            return
        self.history_engine.commit(self.snapshot())
        self.historyChanged.emit()

    def undo(self):
        if self.cancel_pending_preview():return
        result = self.history_engine.undo(self.snapshot())
        if result is not None:
            self._restore_history_result(result)
            self.status.emit('Отмена действия')

    def redo(self):
        if self.drawing:self.status.emit("Завершите текущий штрих или перемещение перед повтором.");return
        if self.cancel_pending_preview():return
        result = self.history_engine.redo(self.snapshot())
        if result is not None:
            self._restore_history_result(result)
            self.status.emit('Повтор действия')

    def _restore_history_result(self, result):
        self._restoring_history = True
        try:
            self._history_group_active = False
            self.historyRestored.emit()
            self.restore(result)
        finally:
            self._restoring_history = False

    def set_zoom(self, value, anchor=None):
        anchor = anchor or QPointF(self.width() / 2, self.height() / 2)
        value = max(0.1, min(5.0, value))
        doc_anchor = self.doc_point(anchor)
        self.zoom = value
        self.update_cursor()
        self.pan = QPointF(anchor.x() - doc_anchor.x() * value,
                           anchor.y() - doc_anchor.y() * value)
        self.update()
        self.status.emit(f"Масштаб: {round(self.zoom * 100)}%")

    def update_cursor(self):
        self.setCursor(tool_cursor(self.tool, self.brush_size, self.zoom, self.devicePixelRatioF(),self.brush_shape))

    def fit_canvas(self):
        if not self.doc_size[0] or not self.doc_size[1]:
            return
        margin = 60
        self.zoom = max(0.1, min(2.0, min(
            (self.width() - margin) / self.doc_size[0],
            (self.height() - margin) / self.doc_size[1]
        )))
        self.update_cursor()
        self.pan = QPointF(
            (self.width() - self.doc_size[0] * self.zoom) / 2,
            (self.height() - self.doc_size[1] * self.zoom) / 2
        )
        self.update()
        self.status.emit(f"Масштаб: {round(self.zoom * 100)}%")

    def new_document(self, width=1200, height=800):
        if width*height > 60_000_000:
            raise ValueError("Максимум 60 млн пикселей на холст.")
        new_layer = Layer("Слой 1", transparent_image(width, height))
        self.push_history()
        self.doc_size = (width, height)
        self.clear_masks()
        self.raster_objects={};self._object_keys={};self._candidate_key=None;self._candidate_object=None;self._interactive_images={}
        self.layers = [new_layer]
        self.groups={};self.layer_stack=[self.layers[0].id];self._selected_nodes={self.layers[0].id};self.current_node=self.layers[0].id
        self.active_layer = 0
        self.selection = None
        self.text_objects = []
        self.selected_text = -1
        self.textSelected.emit(-1)
        self.last_selection = None;self.last_selection_mask=None;self.clear_transient_selection()
        self.fit_canvas()
        self.changed.emit()
        self.update()

    def add_layer(self):
        parent=self.insertion_parent()
        if not self.can_insert(parent):return
        if (len(self.layers)+len(self.masks)+1)*self.doc_size[0]*self.doc_size[1]+self.source_pixels()>120_000_000:
            QMessageBox.warning(self, APP_NAME, "Достигнут предел памяти слоёв (120 млн пикселей).")
            return
        self.push_history()
        self.layers.insert(self.active_layer + 1,
                           Layer(f"Слой {len(self.layers) + 1}",
                                 transparent_image(*self.doc_size)))
        self.active_layer += 1
        self.attach_layer(self.active.id,parent)
        self.set_selected_layers({self.active.id},self.active.id)
        self.changed.emit()
        self.update()

    def rename_layer(self, index):
        if not 0 <= index < len(self.layers):
            return
        name, ok = QInputDialog.getText(
            self, "Переименовать слой", "Название слоя:",
            text=self.layers[index].name
        )
        if ok and name.strip():
            self.push_history()
            self.layers[index].name = name.strip()
            self.changed.emit()

    def set_active_layer(self, index):
        self.cancel_pending_preview()
        if 0 <= index < len(self.layers):
            if self.editing_mask!=self.layers[index].id:self.stop_mask_edit()
            self.active_layer = index
            self._selected_layer_ids = {self.active.id}
            self._selected_nodes={self.active.id};self.current_node=self.active.id
            owned = [i for i,t in enumerate(self.text_objects) if t.get('layer_id') == self.active.id]
            self.selected_text = owned[-1] if owned else -1
            self.textSelected.emit(self.selected_text)
            self.update()

    def set_layer_visible(self, index, visible):
        if 0 <= index < len(self.layers):
            if self.layers[index].visible != visible:
                self.push_history()
                self.layers[index].visible = visible
                self.changed.emit()
                self.update()

    def begin_opacity_edit(self):
        self.push_history()
        self._opacity_edit = True

    def end_opacity_edit(self):
        self._opacity_edit = False
        self.changed.emit()

    def set_layer_opacity(self, index, value):
        if 0 <= index < len(self.layers):
            value = max(0., min(1., value / 100.0))
            if value != self.layers[index].opacity:
                if not self._opacity_edit:
                    self.push_history()
                self.layers[index].opacity = value
                self.modified.emit()
                self.update()

    def load_image(self, filename):
        from raster_objects import read_image
        image = read_image(filename)
        if image.isNull():
            raise ValueError("Не удалось открыть изображение.")
        if image.width()*image.height() > 60_000_000:
            raise ValueError("Изображение превышает 60 млн пикселей.")
        self.push_history()
        self.doc_size = (image.width(), image.height())
        self.clear_masks()
        self.raster_objects={};self._object_keys={};self._candidate_key=None;self._candidate_object=None;self._interactive_images={}
        self.layers = [Layer("Изображение", image.convertToFormat(
            QImage.Format.Format_ARGB32))]
        self.groups={};self.layer_stack=[self.layers[0].id];self._selected_nodes={self.layers[0].id};self.current_node=self.layers[0].id
        self.active_layer = 0
        from raster_objects import DEFAULTS
        self.remember_object(self.layers[0],dict(DEFAULTS,source=QImage(image),width=float(image.width()),height=float(image.height())))
        self.selection = None
        self.text_objects = []
        self.selected_text = -1
        self.textSelected.emit(-1)
        self.last_selection = None;self.last_selection_mask=None;self.clear_transient_selection()
        self.fit_canvas()
        self.changed.emit()
        self.update()

    def save_project(self, filename, **options):
        self.ensure_text_layers()
        self.sync_groups();self.sync_raster_objects()
        return save_project(filename, self.doc_size, self.layers, self.active_layer, self.text_objects,
                            groups=group_data(self.groups),layer_stack=list(self.layer_stack),
                            masks=self.masks,disabled_masks=self.disabled_masks,raster_objects=self.raster_objects,**options)

    def load_project(self, filename):
        self.apply_loaded_project(read_project(filename))

    def apply_loaded_project(self, project):
        size, layers, active, texts = project
        self.push_history()
        self.clear_masks()
        self.raster_objects={};self._object_keys={};self._candidate_key=None;self._candidate_object=None;self._interactive_images={}
        self.doc_size, self.layers, self.active_layer = size, layers, active
        self.masks={identifier:QImage(image) for identifier,image in getattr(project,"masks",{}).items()}
        self.disabled_masks=set(getattr(project,"disabled_masks",()))
        self.raster_objects={i:clone_object(o) for i,o in getattr(project,"raster_objects",{}).items()};self.reset_object_keys()
        self.groups=copy.deepcopy(getattr(project,"groups",{}));self.layer_stack=list(getattr(project,"layer_stack",[l.id for l in layers]))
        self._selected_nodes={self.active.id};self.current_node=self.active.id
        self.text_objects, self.selected_text = texts, -1
        self.ensure_text_layers()
        collapsed=[group for group in self.ancestors(self.active.id) if group.collapsed]
        if collapsed:
            self._selected_nodes={collapsed[-1].id};self.current_node=collapsed[-1].id
        self.textSelected.emit(-1)
        self.selection = None
        self.clear_transient_selection()
        self.last_selection = None;self.last_selection_mask=None;self.clear_transient_selection()
        self.fit_canvas()
        self.changed.emit()
        self.update()

    def _draw_text_objects(self, painter, include_selection=False, layer_id=None):
        for item in self.text_objects:
            if item.get('layer_id') == layer_id:
                draw_text(painter, item)


    def _text_hit(self, pos):
        # Follow visual layer order, including visibility and opacity.
        candidates = []
        for layer in self.layers:
            if self.node_visible(layer):
                candidates.extend(i for i,t in enumerate(self.text_objects) if t.get('layer_id') == layer.id)
        candidates.extend(i for i,t in enumerate(self.text_objects) if not t.get('layer_id'))
        for index in reversed(candidates):
            item = self.text_objects[index]
            local = text_transform(item).inverted()[0].map(pos)
            if text_geometry(item)[1].adjusted(-4,-4,4,4).contains(local):
                return index
        return -1


    def composite_image(self,include_transform_preview=False):
        if include_transform_preview and (self.selection_transform is not None or self.gradient_session is not None or self.retouch_session is not None or self.adjustment_session is not None):
            from compositor import render_image
            layers,texts,masks=self.preview_context()
            return render_image(self.doc_size,layers,self.groups,self.layer_stack,texts,masks=masks,disabled_masks=self.disabled_masks)
        result = transparent_image(*self.doc_size)
        painter = QPainter(result)
        if self.masks or self.groups or requires_composite(self.layers,self.groups,self.text_objects):
            try:paint_stack(painter,self.layers,self.groups,self.layer_stack,self.text_objects,self.doc_size,masks=self.masks,disabled_masks=self.disabled_masks)
            finally:painter.end()
            return result
        for layer in self.layers:
            if layer.visible:
                painter.setOpacity(layer.opacity)
                painter.drawImage(0, 0, layer.image)
                self._draw_text_objects(painter, layer_id=layer.id)
        painter.setOpacity(1.0)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        self._draw_text_objects(painter, False)
        painter.end()
        return result

    def export_image(self, filename, quality=95, background="#ffffff"):
        image = self.composite_image()
        if Path(filename).suffix.lower() in (".jpg", ".jpeg", ".bmp"):
            rgb = QImage(image.size(), QImage.Format.Format_RGB32)
            rgb.fill(QColor(background))
            painter = QPainter(rgb)
            painter.drawImage(0, 0, image)
            painter.end()
            image = rgb
        suffix = Path(filename).suffix.lower().lstrip(".")
        image_format = "JPEG" if suffix in ("jpg", "jpeg") else suffix.upper()
        if image_format not in ("PNG", "JPEG", "BMP", "WEBP"):
            image_format = "PNG"
        output = QSaveFile(str(filename))
        if not output.open(QIODevice.OpenModeFlag.WriteOnly):
            raise ValueError(output.errorString())
        if not image.save(output, image_format, quality):
            output.cancelWriting()
            raise ValueError(f"Не удалось записать {image_format}.")
        if not output.commit():
            raise ValueError(output.errorString())

    fillColorUsed = Signal(QColor)

    def flood_fill(self, x, y):
        if self.editing_mask in self.masks:return self.start_mask_fill(x,y)
        self._fill_mask_id=None
        if not self.can_edit():return
        if self.fill_job is not None:
            return
        if not (0 <= x < self.doc_size[0] and 0 <= y < self.doc_size[1]):
            return
        self._fill_rasterize=self.selection_mask is not None
        source=self.raw_pixels(self.active) if self._fill_rasterize else QImage(self.active.image)
        self._fill_layer = self.active
        self._fill_key = self.active.image.cacheKey()
        rect = self.selection.toAlignedRect() if self.selection else None
        bounds = (rect.left(),rect.top(),rect.right()+1,rect.bottom()+1) if rect else None
        self.fill_job = FillJob(source, x, y, QColor(self.color),
                                self.fill_tolerance, self.brush_opacity, bounds,selection=self.selection_mask)
        self.fill_dialog = QProgressDialog("Заливка…", "Отмена", 0, 0, self.window())
        self.fill_dialog.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.fill_dialog.setMinimumDuration(150)
        self.fill_dialog.canceled.connect(self.fill_job.cancelled.set)
        self.fill_job.signals.done.connect(self._finish_fill)
        self.fill_dialog.show()
        QThreadPool.globalInstance().start(self.fill_job)

    def _finish_fill(self, result, error):
        job = self.fill_job
        self.fill_dialog.canceled.disconnect()
        self.fill_dialog.close()
        self.fill_dialog.deleteLater()
        self.fill_job = None
        mask_id=getattr(self,'_fill_mask_id',None)
        if mask_id is not None:
            self._fill_mask_id=None
            if error:QMessageBox.warning(self,APP_NAME,'Заливка маски не выполнена: '+error)
            elif result is not None and not job.cancelled.is_set() and mask_id in self.masks and self.masks[mask_id].cacheKey()==self._fill_key and self.can_edit_mask(mask_id):
                self.push_history();self.masks[mask_id]=result;self.changed.emit();self.update()
            return
        if error:
            QMessageBox.warning(self, APP_NAME, "Заливка не выполнена: " + error)
        elif result is not None and not job.cancelled.is_set():
            if self._fill_layer in self.layers and self._fill_layer.image.cacheKey() == self._fill_key:
                if not self.can_edit(self._fill_layer):return
                self.push_history()
                if getattr(self,"_fill_rasterize",False):self.rasterize_for_selection({self._fill_layer.id})
                if self._fill_layer.alpha_locked:
                    result = self.preserve_alpha(self._fill_layer.image,result)
                self._fill_layer.image = result
                self.changed.emit()
                self.update()
                self.fillColorUsed.emit(job.args[3])
                self.status.emit("Заливка завершена")

    def _stroke(self,a,b):
        if not self.can_edit(erase=self.tool=="Ластик"):return
        if self.brush_outline>0 and self.tool!='Ластик':
            if self.prepare_ink_segment(a,b):return self.masked_stroke(a,b,self._stroke_raw)
            return
        return self.buffered_ink_segment(a,b)

    def _stroke_raw(self, a, b):
        if not self.can_edit(erase=self.tool == "Ластик"):return
        if self.tool in ('Кисть','Карандаш','Маркер','Мягкая кисть') and self.brush_outline>0:
            self._outlined_stroke(a,b);return
        painter = QPainter(self.active.image)
        if self.active.alpha_locked:
            painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceAtop)
        if self.selection:
            painter.setClipRect(self.selection)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, self.smoothing)
        color = QColor(self.color)
        color.setAlpha(int(color.alpha() * self.brush_opacity / 100))
        size = self.brush_size
        if self.tool == "Ластик":
            painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationOut)
            color = QColor(0, 0, 0, color.alpha())
        elif self.tool == "Маркер":
            color.setAlpha(int(color.alpha() * 0.35))
        pen = QPen(color, size, Qt.PenStyle.SolidLine,
                   Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        if self.tool == "Карандаш":
            pen.setCapStyle(Qt.PenCapStyle.SquareCap)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        painter.setPen(pen)
        if self.tool == "Мягкая кисть" or (self.tool=='Кисть' and (self.brush_hardness<100 or self.brush_shape=="square")):
            from brushes import paint_soft_segment
            hardness=min(self.brush_hardness,35) if self.tool=='Мягкая кисть' else self.brush_hardness
            self._dab_remaining=paint_soft_segment(painter,a,b,size,color,hardness,getattr(self,'_dab_remaining',0.),self.brush_shape)
        else:painter.drawPoint(a) if a == b else painter.drawLine(a, b)
        painter.end()

    def _outlined_stroke(self,a,b):
        from PySide6.QtGui import QPainterPath
        if self._outlined_path is None or getattr(self,'_outlined_layer',None)!=self.active.id:
            self._outlined_layer=self.active.id;self._outlined_base=QImage(self.active.image)
            self._outlined_path=QPainterPath(a)
        self._outlined_path.lineTo(b if a!=b else b+QPointF(.001,0))
        radius=self.brush_size/2+3
        bounds=self._outlined_path.boundingRect().adjusted(-radius,-radius,radius,radius).intersected(QRectF(0,0,*self.doc_size))
        p=QPainter(self.active.image);p.setRenderHint(QPainter.RenderHint.Antialiasing,True)
        p.setClipRect(bounds)
        if self.selection:p.setClipRect(self.selection,Qt.ClipOperation.IntersectClip)
        p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Source);p.drawImage(0,0,self._outlined_base)
        p.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceAtop if self.active.alpha_locked else QPainter.CompositionMode.CompositionMode_SourceOver)
        color=QColor(self.color);outline=QColor(self.brush_outline_color)
        cap=Qt.PenCapStyle.SquareCap if self.brush_shape=='square' else Qt.PenCapStyle.RoundCap
        join=Qt.PenJoinStyle.MiterJoin if self.brush_shape=='square' else Qt.PenJoinStyle.RoundJoin
        rect=bounds.toAlignedRect();tile=transparent_image(max(1,rect.width()),max(1,rect.height()))
        local=QPainter(tile);local.setRenderHint(QPainter.RenderHint.Antialiasing,True);local.translate(-rect.x(),-rect.y())
        local.setPen(QPen(outline,self.brush_size,Qt.PenStyle.SolidLine,cap,join));local.drawPath(self._outlined_path)
        local.setPen(QPen(color,max(1,self.brush_size-self.brush_outline*2),Qt.PenStyle.SolidLine,cap,join));local.drawPath(self._outlined_path);local.end()
        p.setOpacity(self.brush_opacity/100*(.35 if self.tool=='Маркер' else 1));p.drawImage(rect.topLeft(),tile);p.end()


    def _draw_shape(self,painter,tool,rect):
        if self.selection_mask is None:return self._draw_shape_raw(painter,tool,rect)
        from shapes import shape_path
        options=self.shape_options;center=rect.normalized().center()
        transform=QTransform().translate(center.x(),center.y()).rotate(float(options.get('rotation',0))).shear(float(options.get('shear',0))/100,0).translate(-center.x(),-center.y())
        radius=max(self.brush_size,float(options.get('stroke_width',4)))+3
        bounds=transform.map(shape_path(tool,rect,options.get('points',5))).boundingRect().adjusted(-radius,-radius,radius,radius).intersected(self.selection).intersected(QRectF(0,0,*self.doc_size))
        if painter.hasClipping():bounds=bounds.intersected(painter.clipBoundingRect())
        region=bounds.toAlignedRect()
        if region.isEmpty():return
        patch=transparent_image(region.width(),region.height());p=QPainter(patch);p.translate(-region.x(),-region.y());self._draw_shape_raw(p,tool,rect,True);p.end()
        patch=apply_mask(patch,self.selection_mask,region);painter.save()
        if self.active.alpha_locked:painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceAtop)
        painter.drawImage(region.topLeft(),patch);painter.restore()

    def _draw_shape_raw(self, painter, tool, rect,ignore_alpha=False):
        painter.save()
        if self.selection:
            painter.setClipRect(self.selection, Qt.ClipOperation.IntersectClip)
        if self.active.alpha_locked and not ignore_alpha:
            painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceAtop)
        options = dict(self.shape_options)
        if not getattr(self, '_shape_configured', False):
            options.update(stroke=self.color.name(), stroke_width=self.brush_size)
        draw_shape(painter, tool, rect, options, self.brush_opacity/100)
        painter.restore()


    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), self.workspace_brush if self.workspace_brush is not None else self.workspace_color)
        canvas_rect = QRectF(self.pan.x(), self.pan.y(),
                             self.doc_size[0] * self.zoom,
                             self.doc_size[1] * self.zoom)
        if not event.region().intersects(canvas_rect.toAlignedRect()):
            self.paint_overlays(painter)
            painter.end()
            return
        painter.fillRect(canvas_rect, QColor("#ffffff"))
        if self.show_checkerboard:
            base,accent=('#343842','#272b34') if self.checker_style=='dark' else ('#ffffff','#e2e6ed')
            tile = QImage(16,16,QImage.Format.Format_RGB32);tile.fill(QColor(base))
            tp=QPainter(tile);tp.fillRect(0,0,8,8,QColor(accent));tp.fillRect(8,8,8,8,QColor(accent));tp.end()
            painter.fillRect(canvas_rect,QBrush(tile))
        painter.save()
        painter.translate(self.pan)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        painter.scale(self.zoom, self.zoom)
        painter.setClipRect(QRectF(0, 0, *self.doc_size))
        shape_preview=(self.active.id,lambda target:self._draw_shape(target,self.tool,QRectF(self.start,self.preview))) if self.drawing and self.preview is not None and self.tool in SHAPES else None
        from interactive_render import interactive_image
        proxy=interactive_image(self,shape_preview,self.preview_context() if self.retouch_session is not None else None) if (self.drawing or self.retouch_session is not None) and not self.show_mask else None
        if proxy is not None:
            painter.drawImage(QRectF(0,0,*self.doc_size),proxy)
        elif self.selection_transform is not None or self.gradient_session is not None or self.retouch_session is not None or self.adjustment_session is not None:
            layers,texts,masks=self.preview_context()
            if self.show_mask and self.editing_mask in masks:painter.drawImage(0,0,masks[self.editing_mask])
            else:
                region=QRectF(self.doc_point(event.rect().topLeft()),self.doc_point(event.rect().bottomRight())).adjusted(-2,-2,2,2)
                paint_stack(painter,layers,self.groups,self.layer_stack,texts,self.doc_size,region,masks=masks,disabled_masks=self.disabled_masks)
        elif self.show_mask and self.editing_mask in self.masks:
            painter.drawImage(0,0,self.masks[self.editing_mask])
        elif shape_preview is not None or self.masks or self.groups or requires_composite(self.layers,self.groups,self.text_objects):
            region=self.doc_point(event.rect().topLeft())
            region=QRectF(region,self.doc_point(event.rect().bottomRight())).adjusted(-2,-2,2,2)
            paint_stack(painter,self.layers,self.groups,self.layer_stack,self.text_objects,self.doc_size,region,shape_preview,masks=self.masks,disabled_masks=self.disabled_masks)
        else:
            for layer in self.layers:
                if layer.visible:
                    painter.setOpacity(layer.opacity)
                    painter.drawImage(0, 0, layer.image)
                    self._draw_text_objects(painter, layer_id=layer.id)
            painter.setOpacity(1.0)
            painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
            self._draw_text_objects(painter, include_selection=True)
        painter.restore()
        self.paint_overlays(painter)
        painter.end()


    def wheelEvent(self, event):
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
            self.set_zoom(self.zoom * factor, event.position())
            event.accept()
        else:
            super().wheelEvent(event)

    def _base_keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.cancel_selection()
        elif event.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            if self.tool == "Текст" and 0 <= self.selected_text < len(self.text_objects):
                self.push_history()
                del self.text_objects[self.selected_text]
                self.selected_text = -1
            elif self.selection:
                if not self.can_edit(erase=True):return
                self.push_history()
                painter = QPainter(self.active.image)
                painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_Clear)
                painter.fillRect(self.selection, Qt.GlobalColor.transparent)
                painter.end()
            else:
                return
            self.changed.emit();self.update()
        else:
            QWidget.keyPressEvent(self, event)


    def _animate_marquee(self):
        if self.selection:
            self._marquee_phase = (self._marquee_phase+1)%12
            self.update()
