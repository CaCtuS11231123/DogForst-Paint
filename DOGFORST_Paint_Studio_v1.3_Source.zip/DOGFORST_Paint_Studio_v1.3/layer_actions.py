"""Layer selection, safe bulk commands and edit permissions; UI-independent."""
import copy
from PySide6.QtCore import QPointF
from PySide6.QtGui import QImage
from layers import Layer

LABELS = {'': 'Без метки', '#719de0': 'Голубая', '#ad8ed0': 'Лиловая',
          '#6fba9a': 'Зелёная', '#dda16d': 'Оранжевая', '#d77f96': 'Розовая'}


class LayerActionsMixin:
    def selected_layer_ids(self):
        known = {layer.id for layer in self.layers}
        selected = set(getattr(self, '_selected_layer_ids', ())) & known
        # Direct API callers may change active_layer; always keep it in selection.
        if self.active.id not in selected:
            selected = {self.active.id}
        return selected

    def selected_layers(self):
        ids = self.selected_layer_ids()
        return [layer for layer in self.layers if layer.id in ids]

    def set_selected_layers(self, ids, active_id=None):
        self.cancel_pending_preview()
        known = {layer.id for layer in self.layers}
        ids = set(ids) & known
        if not ids:
            ids = {self.active.id}
        active_id = active_id if active_id in ids else next(l.id for l in reversed(self.layers) if l.id in ids)
        self.active_layer = next(i for i,l in enumerate(self.layers) if l.id == active_id)
        self._selected_layer_ids = ids
        texts = [i for i,t in enumerate(self.text_objects) if t.get('layer_id') == active_id]
        self.selected_text = texts[-1] if len(ids) == 1 and texts else -1
        self.textSelected.emit(self.selected_text)
        self.update()

    def can_edit(self, layer=None, move=False, erase=False):
        layer = layer or self.active
        if layer.locked:
            self.status.emit('Слой защищён: отключите «Правки» в панели слоёв.')
            return False
        if move and layer.position_locked:
            self.status.emit('Положение слоя заблокировано.')
            return False
        if erase and layer.alpha_locked:
            self.status.emit('Прозрачность защищена: стирание недоступно.')
            return False
        return True

    def set_selected_flag(self, key, value):
        if key not in ('locked','position_locked','alpha_locked','color_label'):
            raise ValueError('Неизвестное свойство слоя.')
        if key == 'color_label' and value not in LABELS:
            raise ValueError('Неизвестная цветовая метка.')
        targets = [l for l in self.selected_layers() if getattr(l,key) != value and
                   (key != 'alpha_locked' or l.kind != 'text')]
        if not targets:
            return
        self.push_history()
        for layer in targets:
            setattr(layer,key,value)
        self.changed.emit(); self.update()

    def reorder_layers(self, top_to_bottom):
        old = [l.id for l in reversed(self.layers)]
        if len(top_to_bottom) != len(old) or set(top_to_bottom) != set(old):
            raise ValueError('Некорректный порядок слоёв.')
        if old == list(top_to_bottom):
            return
        ids = self.selected_layer_ids(); active = self.active.id
        self.push_history()
        mapping = {layer.id:layer for layer in self.layers}
        self.layers = [mapping[identifier] for identifier in reversed(top_to_bottom)]
        self.set_selected_layers(ids, active)
        self.changed.emit(); self.update()

    def shift_selected_layers(self, direction):
        ids = self.selected_layer_ids()
        order = list(self.layers)
        indexes = range(len(order)-2,-1,-1) if direction > 0 else range(1,len(order))
        step = 1 if direction > 0 else -1
        for i in indexes:
            if order[i].id in ids and order[i+step].id not in ids:
                order[i], order[i+step] = order[i+step], order[i]
        self.reorder_layers([l.id for l in reversed(order)])

    def duplicate_layer(self):
        targets = self.selected_layers()
        if (len(self.layers)+len(targets)+len(self.masks)+sum(l.id in self.masks for l in targets))*self.doc_size[0]*self.doc_size[1]+self.source_pixels()+sum(o["source"].width()*o["source"].height() for i,o in self.raster_objects.items() if i in {l.id for l in targets})>120_000_000:
            raise ValueError('Достигнут предел памяти слоёв.')
        clones = {l.id:Layer(l.name+' · копия',QImage(l.image),l.visible,l.opacity,
                            kind=l.kind,**l.flags()) for l in targets}
        texts = [dict(copy.deepcopy(t),layer_id=clones[t['layer_id']].id)
                 for t in self.text_objects if t.get('layer_id') in clones]
        self.push_history()
        order = []
        for layer in self.layers:
            order.append(layer)
            if layer.id in clones:
                order.append(clones[layer.id])
        active = clones[self.active.id].id
        self.layers = order; self.text_objects.extend(texts)
        for old,new in clones.items():
            if old in self.raster_objects:self.remember_object(new,self.raster_objects[old])
            if old in self.masks:self.masks[new.id]=QImage(self.masks[old])
            if old in self.disabled_masks:self.disabled_masks.add(new.id)
        self.set_selected_layers({l.id for l in clones.values()},active)
        self.changed.emit(); self.update()

    def delete_layer(self):
        if len(self.layers)==1 and self.active.id in self.raster_objects:
            self.remove_selected_image();return
        targets = self.selected_layers()
        if any(l.locked for l in targets):
            self.status.emit('Среди выбранных слоёв есть защищённые. Сначала отключите «Правки».')
            return
        if len(targets) == len(self.layers):
            self.status.emit('Нельзя удалить все слои: оставьте хотя бы один.')
            return
        ids = {l.id for l in targets}; old_index = self.active_layer
        self.push_history()
        self.layers = [l for l in self.layers if l.id not in ids]
        self.text_objects = [t for t in self.text_objects if t.get('layer_id') not in ids]
        self.active_layer = min(old_index,len(self.layers)-1)
        self.set_selected_layers({self.active.id})
        self.changed.emit(); self.update()

    def move_selected_by(self, delta):
        self._begin_move(QPointF())
        self._move_to(delta)
        self.drawing = False; self._interaction = ''
        self.changed.emit(); self.update()

    def preserve_alpha(self, before, result):
        import numpy as np
        a=before.convertToFormat(QImage.Format.Format_RGBA8888)
        b=result.convertToFormat(QImage.Format.Format_RGBA8888)
        alpha=np.frombuffer(a.constBits(),dtype=np.uint8).reshape(a.height(),a.bytesPerLine())[:,3:a.width()*4:4]
        out=np.frombuffer(b.bits(),dtype=np.uint8).reshape(b.height(),b.bytesPerLine())
        out[:,3:b.width()*4:4]=alpha
        del out
        return b.convertToFormat(QImage.Format.Format_ARGB32)
