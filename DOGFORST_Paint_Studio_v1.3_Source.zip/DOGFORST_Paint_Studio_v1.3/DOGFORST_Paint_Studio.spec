# Build on the target operating system; Windows EXE must be built on Windows.
import sys
from pathlib import Path
root = Path(SPECPATH)
a = Analysis([str(root / 'main.py')], pathex=[str(root)],
    binaries=[], datas=[(str(root / 'assets'), 'assets')],
    hiddenimports=['scipy.ndimage'],
    hookspath=[], hooksconfig={}, runtime_hooks=[],
    excludes=['matplotlib','pandas','IPython','pytest','tkinter','PySide6.QtWebEngineCore',
              'PySide6.QtWebEngineWidgets','PySide6.QtQml','PySide6.QtQuick'], noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='DOGFORST_Paint_Studio',
    debug=False, bootloader_ignore_signals=False, strip=False, upx=False,
    console=False, version=str(root / 'version_info.txt') if sys.platform=='win32' else None, icon=str(root / 'assets' / 'DOGFORST_Icon.ico') if sys.platform=='win32' else None)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='DOGFORST_Paint_Studio')
