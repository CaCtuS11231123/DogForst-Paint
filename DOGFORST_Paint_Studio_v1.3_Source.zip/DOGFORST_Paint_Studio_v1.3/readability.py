"""User-controlled interface preferences, without medical protection claims."""
from PySide6.QtGui import QColor

THEME_NOTICE = ('Темы и настройки комфорта не являются медицинскими средствами и не гарантируют защиту зрения. '
                'Разработчики DOGFORST Paint Studio не несут ответственности за возможный вред здоровью, связанный с использованием тем оформления. '
                'Это информационное уведомление, а не медицинская рекомендация.')


def readable_colors(colors,contrast=False):
    if not contrast:return tuple(colors)
    if QColor(colors[0]).lightness()<128:
        return ('#171b22','#ffffff','#10151b','#445568','#202a36','#9bd7ff','#1a202a')
    return ('#f3f2ec','#101820','#e3e6e9','#b1c8db','#ffffff','#135b9a','#d7dee4')
