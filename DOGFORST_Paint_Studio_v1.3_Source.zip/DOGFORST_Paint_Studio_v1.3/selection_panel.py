"""Selection modes, wand sampling and explicit actions; unavailable settings are disabled."""
from PySide6.QtCore import QSignalBlocker
from PySide6.QtWidgets import QWidget,QVBoxLayout,QFormLayout,QComboBox,QSpinBox,QCheckBox,QPushButton,QLabel

class SelectionPanel(QWidget):
    def __init__(self,window):
        super().__init__();self.owner=window;c=window.canvas;root=QVBoxLayout(self);form=QFormLayout();root.addLayout(form)
        self.mode=QComboBox()
        for label,key in [('Новое выделение','replace'),('Добавить область','add'),('Вычесть область','subtract'),('Пересечение','intersect')]:self.mode.addItem(label,key)
        self.mode.currentIndexChanged.connect(lambda _:setattr(c,'selection_mode',self.mode.currentData()));form.addRow('Режим',self.mode)
        self.tolerance=QSpinBox();self.tolerance.setRange(0,255);self.tolerance.setValue(c.wand_tolerance);self.tolerance.valueChanged.connect(lambda v:setattr(c,'wand_tolerance',v));form.addRow('Допуск палочки',self.tolerance)
        self.connected=QCheckBox('Только смежная область');self.connected.setChecked(True);self.connected.toggled.connect(lambda v:setattr(c,'wand_connected',v));root.addWidget(self.connected)
        self.merged=QCheckBox('Образец со всех видимых слоёв');self.merged.toggled.connect(lambda v:setattr(c,'wand_merged',v));root.addWidget(self.merged)
        self.feather=QSpinBox();self.feather.setRange(1,64);self.feather.setValue(6);self.feather.setSuffix(' px');form.addRow('Растушёвка',self.feather)
        self.apply_feather=QPushButton('Растушевать границу');self.apply_feather.clicked.connect(lambda:window.run_canvas_action(c.feather_selection,self.feather.value()));root.addWidget(self.apply_feather)
        self.transform=QPushButton('Размер / поворот выделения…');self.transform.clicked.connect(lambda:window.run_canvas_action(c.start_selection_transform));root.addWidget(self.transform)
        for label,fn in [('Инвертировать',c.invert_selection),('Выделить всё',c.select_all),('Снять выделение · Esc',c.cancel_selection),('Вернуть последнее',c.reselect)]:
            button=QPushButton(label)
            if label=='Вернуть последнее':self.restore_button=button
            if label=='Снять выделение · Esc':self.clear_button=button
            button.clicked.connect(lambda checked=False,f=fn:window.run_canvas_action(f));root.addWidget(button)
        note=QLabel('Shift — добавить · Alt — вычесть\nShift+Alt — пересечение\n\nЛассо: точки мышью, Enter или двойное нажатие замыкает контур. Backspace убирает точку, Esc отменяет построение.\n\nПодсвеченная область ограничивает пиксельные правки. Размер/поворот: Ctrl+T или кнопка выше. Enter применяет, Esc отменяет предпросмотр.');note.setWordWrap(True);root.addWidget(note);root.addStretch()
        self.refresh()
    def refresh(self):
        c=self.owner.canvas
        self.transform.setEnabled(c.selection is not None and c.wand_job is None and not c.drawing)
        self.restore_button.setEnabled(c.last_selection is not None);self.clear_button.setEnabled(c.selection is not None or bool(c._lasso_points) or c.wand_job is not None)
        wand=c.tool=='Волшебная палочка'
        for control in (self.tolerance,self.connected,self.merged):control.setEnabled(wand)
        for control in (self.feather,self.apply_feather):control.setEnabled(c.selection is not None and c.wand_job is None)
        with QSignalBlocker(self.mode):self.mode.setCurrentIndex(self.mode.findData(c.selection_mode))
