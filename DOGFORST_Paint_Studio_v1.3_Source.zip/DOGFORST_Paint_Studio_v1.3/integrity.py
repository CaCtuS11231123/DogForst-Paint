"""Offline integrity checks, not DRM or cryptographic publisher authentication.

SHA-256 detects changed bytes against a supplied manifest. A person able to replace
both files and this unsigned manifest can bypass it; signing is a separate stage.
"""
import hashlib,json,re,stat
from pathlib import Path,PurePosixPath

class IntegrityError(ValueError):pass

def strict_json(value):
    def pairs(items):
        result={}
        for key,value in items:
            if key in result:raise IntegrityError('Повторяющийся ключ JSON: '+str(key))
            result[key]=value
        return result
    def constant(value):raise IntegrityError('Недопустимое число JSON: '+value)
    return json.loads(value,object_pairs_hook=pairs,parse_constant=constant)

def safe_relative(name):
    if not isinstance(name,str) or not name or len(name)>500 or '\\' in name or '\x00' in name or ':' in name or name.startswith('/') or any(p in ('','.','..') for p in name.split('/')):raise IntegrityError('Недопустимый путь в проверочной карте.')
    return name

def archive_preflight(archive):
    infos=archive.infolist()
    names=[i.filename for i in infos]
    if len(names)!=len(set(names)):raise IntegrityError('В архиве повторяются имена файлов.')
    if len(infos)>4096:raise IntegrityError('В проекте слишком много ресурсов.')
    if sum(i.file_size for i in infos)>520_000_000:raise IntegrityError('Распакованные данные проекта превышают безопасный предел.')
    for i in infos:
        # ZipInfo.filename can be normalized on Windows; preserve the raw ZIP name.
        raw_name=getattr(i,'orig_filename',i.filename)
        safe_relative(raw_name.rstrip('/') if i.is_dir() else raw_name)
        name=i.filename.rstrip('/') if i.is_dir() else i.filename;safe_relative(name)
        if i.flag_bits&1:raise IntegrityError('Зашифрованные ресурсы проекта не поддерживаются.')
        if stat.S_ISLNK(i.external_attr>>16):raise IntegrityError('Символические ссылки в проекте не поддерживаются.')

def checksum_table(manifest):
    value=manifest.get('checksums')
    if value is None:return None
    if not isinstance(value,dict) or not value or len(value)>4096:raise IntegrityError('Некорректная таблица SHA-256 проекта.')
    for name,digest in value.items():
        safe_relative(name)
        if not isinstance(digest,str) or not re.fullmatch('[0-9a-f]{64}',digest):raise IntegrityError('Некорректная контрольная сумма проекта.')
    return value

def check_payload(table,name,data):
    if table is None:return
    if name not in table or hashlib.sha256(data).hexdigest()!=table[name]:raise IntegrityError('Ресурс проекта изменён или повреждён: '+name)

def file_digest(path,cancelled=None):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        while True:
            if cancelled is not None and cancelled.is_set():raise IntegrityError('Проверка отменена.')
            block=stream.read(1024*1024)
            if not block:break
            h.update(block)
    return h.hexdigest()

def verify_installation(root,cancelled=None,critical_only=False):
    root=Path(root).resolve();path=root/'release_integrity.json'
    if not path.is_file() or path.stat().st_size>2_000_000:raise IntegrityError('Проверочная карта поставки отсутствует или слишком велика.')
    manifest=strict_json(path.read_text(encoding='utf-8'))
    if not isinstance(manifest,dict) or manifest.get('format')!='dogforst-release-sha256' or manifest.get('schema')!=1 or manifest.get('mode') not in ('source','frozen'):raise IntegrityError('Некорректная проверочная карта поставки.')
    files=manifest.get('files');critical=manifest.get('critical')
    if not isinstance(files,dict) or not 1<=len(files)<=4096 or not isinstance(critical,list) or not critical or any(n not in files for n in critical):raise IntegrityError('Некорректный список проверяемых файлов.')
    result=dict(version=manifest.get('version'),mode=manifest['mode'],checked=0,errors=[],publisher_signature=False)
    for name,entry in files.items():
        safe_relative(name)
        if not isinstance(entry,dict) or type(entry.get('size')) is not int or not 0<=entry['size']<=2_000_000_000 or not isinstance(entry.get('sha256'),str) or not re.fullmatch('[0-9a-f]{64}',entry['sha256']):raise IntegrityError('Некорректное описание проверяемого файла.')
        if critical_only and name not in critical:continue
        target=(root/name).resolve()
        if not target.is_relative_to(root):raise IntegrityError('Файл выходит за пределы папки программы.')
        if not target.is_file():result['errors'].append(name+': отсутствует')
        elif target.stat().st_size!=entry['size'] or file_digest(target,cancelled)!=entry['sha256']:result['errors'].append(name+': изменён')
        result['checked']+=1
    result['ok']=not result['errors'];return result

def verify_project_file(path,cancelled=None):
    import zipfile
    with zipfile.ZipFile(path) as archive:
        archive_preflight(archive)
        if archive.getinfo('project.json').file_size>4_000_000:raise IntegrityError('Слишком большое описание проекта.')
        manifest=strict_json(archive.read('project.json'))
        if not isinstance(manifest,dict) or type(manifest.get('version')) is not int or manifest['version'] not in range(1,12) or not isinstance(manifest.get('layers'),list) or not manifest['layers']:raise IntegrityError('Некорректное описание проекта.')
        table=checksum_table(manifest)
        resources=[v['path'] for v in manifest.get('layers',[])]+[v['path'] for v in manifest.get('masks',[])]+[v['path'] for v in manifest.get('raster_objects',[])]
        for name in resources:
            safe_relative(name)
            if table is not None and name not in table:raise IntegrityError('Нет контрольной суммы ресурса: '+name)
            h=hashlib.sha256()
            with archive.open(name) as stream:
                while True:
                    if cancelled is not None and cancelled.is_set():raise IntegrityError('Проверка отменена.')
                    block=stream.read(1024*1024)
                    if not block:break
                    h.update(block)
            if table is not None and h.hexdigest()!=table[name]:raise IntegrityError('Ресурс проекта изменён или повреждён: '+name)
        return dict(ok=True,checked=len(resources),checksums=table is not None,version=manifest.get('version'),publisher_signature=False)
