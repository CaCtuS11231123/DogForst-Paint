@echo off
setlocal DisableDelayedExpansion
set "REPORT=%TEMP%\DOGFORST-startup-%RANDOM%-%RANDOM%.txt"
set "RESULT=2"
> "%REPORT%" echo DOGFORST Paint Studio startup check
if not exist "%~dp0DOGFORST_Paint_Studio.exe" (
  >> "%REPORT%" echo ERROR: DOGFORST_Paint_Studio.exe is missing.
  goto show
)
if not exist "%~dp0_internal\." (
  >> "%REPORT%" echo ERROR: _internal is missing. Extract the whole ZIP before running.
  goto show
)
if not exist "%~dp0release_integrity.json" (
  >> "%REPORT%" echo ERROR: release_integrity.json is missing. Extract the whole ZIP.
  goto show
)
start "" /wait "%~dp0DOGFORST_Paint_Studio.exe" --diagnose-startup "%REPORT%"
set "RESULT=%ERRORLEVEL%"
:show
>> "%REPORT%" echo Windows process exit code: %RESULT%
type "%REPORT%"
echo.
echo Report saved to "%REPORT%"
pause
exit /b %RESULT%
