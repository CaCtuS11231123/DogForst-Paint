"""Viewport-sized drawing preview. Project pixels/export always stay full resolution."""
import copy
from PySide6.QtCore import Qt,QRectF
from PySide6.QtGui import QImage,QPainter
from layers import Layer
from compositor import render_image

def interactive_image(canvas,preview=None,context=None):
    input_layers,input_texts,input_masks=context if context is not None else (canvas.layers,canvas.text_objects,canvas.masks)
    factor=min(1.,1400/canvas.doc_size[0],1000/canvas.doc_size[1],max(.1,canvas.zoom)*canvas.devicePixelRatioF())
    if factor>=.999:return None
    size=(max(1,round(canvas.doc_size[0]*factor)),max(1,round(canvas.doc_size[1]*factor)))
    cache=getattr(canvas,'_interactive_images',{});new={}
    def small(key,image):
        stamp=(image.cacheKey(),size);entry=cache.get(key)
        result=entry[1] if entry and entry[0]==stamp else image.scaled(*size,Qt.AspectRatioMode.IgnoreAspectRatio,Qt.TransformationMode.SmoothTransformation)
        new[key]=(stamp,result);return result
    def glow(value):
        if value is None:return None
        return dict(value,radius=max(1.,value['radius']*factor),spread=value['spread']*factor)
    layers=[]
    for layer in input_layers:
        image=small(layer.id,layer.image)
        if preview is not None and preview[0]==layer.id:
            image=QImage(image);p=QPainter(image);p.scale(factor,factor);preview[1](p);p.end()
        flags=layer.flags();flags['glow']=glow(flags.get('glow'));layers.append(Layer(layer.name,image,layer.visible,layer.opacity,layer.id,layer.kind,**flags))
    masks={i:small('@mask/'+i,m) for i,m in input_masks.items()};texts=copy.deepcopy(input_texts)
    for t in texts:
        for key in ('x','y','size','stroke_width','letter_spacing'):
            if key in t:t[key]*=factor
    groups=copy.deepcopy(canvas.groups)
    for g in groups.values():
        if getattr(g,'glow',None):g.glow=glow(g.glow)
    canvas._interactive_images=new
    return render_image(size,layers,groups,canvas.layer_stack,texts,masks=masks,disabled_masks=canvas.disabled_masks)
