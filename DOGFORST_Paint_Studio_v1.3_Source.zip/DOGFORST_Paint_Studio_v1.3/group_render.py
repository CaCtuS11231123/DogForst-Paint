"""Isolated group opacity, in bounded tiles instead of full canvases per group."""
from PySide6.QtCore import QRect, QRectF
from PySide6.QtGui import QPainter, QImage
from layers import transparent_image
from text_model import draw_text

TILE = 256


def paint_stack(painter, layers, groups, stack, texts, size, region=None,preview=None,masks=None,disabled_masks=()):
    from blending import requires_composite
    if (set(masks or {})-set(disabled_masks)) or preview is not None or requires_composite(layers,groups,texts):
        from compositor import paint_tiles
        return paint_tiles(painter,layers,groups,stack,texts,size,region,preview,masks,disabled_masks)
    if not groups:stack=[layer.id for layer in layers]
    mapping={layer.id:layer for layer in layers}
    owned={}
    for text in texts:owned.setdefault(text.get('layer_id'),[]).append(text)
    bounds=QRect(0,0,*size)
    region=bounds if region is None else region.toAlignedRect().intersected(bounds)

    def nodes(target,ids,clip):
        for identifier in ids:
            node=groups.get(identifier) or mapping[identifier]
            if not node.visible or node.opacity<=0:continue
            if identifier not in groups:
                target.save();target.setOpacity(target.opacity()*node.opacity)
                target.drawImage(0,0,node.image)
                for text in owned.get(identifier,[]):draw_text(target,text)
                target.restore()
            elif node.opacity==1:
                nodes(target,node.children,clip)
            else:
                # Each nested buffer is at most 256x256 (roughly 256 KiB).
                for y in range(clip.top(),clip.bottom()+1,TILE):
                    for x in range(clip.left(),clip.right()+1,TILE):
                        tile=QRect(x,y,min(TILE,clip.right()-x+1),min(TILE,clip.bottom()-y+1))
                        image=transparent_image(tile.width(),tile.height()).convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
                        local=QPainter(image)
                        try:
                            local.translate(-x,-y);local.setClipRect(QRectF(tile))
                            nodes(local,node.children,tile)
                        finally:local.end()
                        target.save();target.setOpacity(target.opacity()*node.opacity)
                        target.drawImage(x,y,image);target.restore()
    nodes(painter,stack,region)
    for text in owned.get(None,[]):draw_text(painter,text)
