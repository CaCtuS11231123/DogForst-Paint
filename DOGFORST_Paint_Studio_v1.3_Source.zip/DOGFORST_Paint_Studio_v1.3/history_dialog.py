from PySide6.QtWidgets import QDialog, QFormLayout, QSpinBox, QLabel, QDialogButtonBox


class HistorySettingsDialog(QDialog):
    def __init__(self, steps, megabytes, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Память и история действий')
        self.resize(540, 270)
        form = QFormLayout(self)
        note = QLabel('Небольшие правки хранятся сжатыми участками. Изменение лимитов может удалить самые старые доступные шаги, но не меняет рисунок. Последнее действие сохраняется даже если оно одно превышает бюджет.')
        note.setWordWrap(True)
        form.addRow(note)
        self.steps = QSpinBox(); self.steps.setRange(5, 200); self.steps.setValue(steps)
        self.memory = QSpinBox(); self.memory.setRange(32, 1024); self.memory.setValue(megabytes); self.memory.setSuffix(' МиБ')
        form.addRow('Максимум шагов', self.steps)
        form.addRow('Бюджет сохранённой истории', self.memory)
        extra=QLabel('Это не лимит всей памяти программы. Активный документ, снимок текущего действия и фоновые задачи используют дополнительную память.');extra.setWordWrap(True);form.addRow(extra)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText('Применить')
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена')
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        form.addRow(buttons)


def setting_integer(settings,key,default,minimum,maximum):
    try:return max(minimum,min(maximum,int(settings.value(key,default))))
    except (ValueError,TypeError):return default
