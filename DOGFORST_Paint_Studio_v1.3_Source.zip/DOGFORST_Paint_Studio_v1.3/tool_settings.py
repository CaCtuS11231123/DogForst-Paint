"""Settings for flood fill. Controls map directly to the existing fill engine."""
from PySide6.QtWidgets import QDialog,QVBoxLayout,QFormLayout,QSpinBox,QLabel,QDialogButtonBox,QPushButton
from PySide6.QtGui import QColor
from dialogs import ColorButton
class FillSettingsDialog(QDialog):
    def __init__(self,canvas,parent=None):
        super().__init__(parent);self.setWindowTitle('Параметры заливки');self.resize(390,240);root=QVBoxLayout(self);form=QFormLayout();root.addLayout(form)
        current = QColor(canvas.color)
        remembered = QColor(getattr(canvas, 'last_fill_color', QColor()))
        self.color = ColorButton(remembered if remembered.isValid() and not canvas.editing_mask else current,
                                 'Редактировать цвет…')
        form.addRow('Цвет заливки', self.color)
        use_current = QPushButton('Использовать текущий цвет')
        use_current.clicked.connect(lambda: self.set_color(current))
        form.addRow(use_current)
        self.tolerance=QSpinBox();self.tolerance.setRange(0,255);self.tolerance.setValue(canvas.fill_tolerance);form.addRow('Допуск похожих цветов',self.tolerance)
        self.opacity=QSpinBox();self.opacity.setRange(0,100);self.opacity.setSuffix(' %');self.opacity.setValue(canvas.brush_opacity);form.addRow('Непрозрачность',self.opacity)
        note=QLabel('Допуск 0 заменяет только одинаковый цвет. Более высокий допуск включает похожие оттенки. Выделение ограничивает заливку; на маске цвет переводится в серый. Изменение настроек не заливает холст.');note.setWordWrap(True);root.addWidget(note)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);root.addWidget(buttons)

    def set_color(self, color):
        self.color.color = QColor(color)
        self.color.refresh()
