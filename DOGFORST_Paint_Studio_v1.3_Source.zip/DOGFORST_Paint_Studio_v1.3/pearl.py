"""Slow workspace/accent colour motion; document pixels and global QSS stay untouched."""
import math
import time
from PySide6.QtCore import QObject, QTimer, QEvent, QRectF
from PySide6.QtGui import QColor, QBrush, QLinearGradient, QRegion
from PySide6.QtWidgets import QApplication

PEARL_NAME = 'Перламутр'
PALETTE = ('#9bb8c4', '#b3a7c6', '#9bbfb3', '#a1b0cd')
AURORA_NAME = 'Аврора'
AURORA_PALETTE = ('#87bfb7','#98b4d0','#b1a0c7','#8bbab4')
DYNAMIC_THEMES = {PEARL_NAME:PALETTE,AURORA_NAME:AURORA_PALETTE}


def blend(a, b, fraction):
    a, b = QColor(a), QColor(b)
    return QColor(*[round(x+(y-x)*fraction) for x,y in zip(a.getRgb()[:3], b.getRgb()[:3])])


def accent_at(seconds, palette=PALETTE):
    position = (seconds % 60) / 15
    index = int(position)
    fraction = position-index
    fraction = fraction*fraction*(3-2*fraction)
    return blend(palette[index], palette[(index+1)%4], fraction)


class PearlAnimator(QObject):
    def __init__(self, window):
        super().__init__(window)
        self.window = window
        self.selected, self.motion = False, True
        self.name = PEARL_NAME
        self.seconds = 0.
        self.last_clock = None
        self.timer = QTimer(self)
        self.timer.setInterval(100)
        self.timer.timeout.connect(self.tick)
        window.installEventFilter(self)

    def set_theme(self, name, motion=True):
        self.name = name
        self.selected, self.motion = name in DYNAMIC_THEMES, bool(motion)
        self.last_clock = None
        if self.selected:
            self.paint_frame()
        else:
            self.window.canvas.workspace_brush = None
        self.synchronize()

    def eventFilter(self, watched, event):
        if event.type() in (QEvent.Type.Show, QEvent.Type.Hide, QEvent.Type.WindowStateChange):
            QTimer.singleShot(0, self.synchronize)
        elif event.type() == QEvent.Type.Resize and self.selected:
            QTimer.singleShot(0, self.paint_frame)
        return False

    def synchronize(self):
        run = self.selected and self.motion and self.window.isVisible() and not self.window.isMinimized()
        if run:
            if not self.timer.isActive():
                self.last_clock = None
                self.timer.start()
        else:
            self.timer.stop()
            self.last_clock = None

    def tick(self):
        if not self.selected or not self.motion:
            return
        if not self.window.isVisible() or self.window.isMinimized():
            self.synchronize()
            return
        now = time.monotonic()
        if self.last_clock is not None:
            self.seconds += min(.25, max(0., now-self.last_clock))
        self.last_clock = now
        self.paint_frame()

    def paint_frame(self):
        if not self.selected:
            return
        canvas = self.window.canvas
        palette = DYNAMIC_THEMES[self.name]
        accent = accent_at(self.seconds,palette)
        other = accent_at(self.seconds+21,palette)
        gradient = QLinearGradient(0, 0, max(1, canvas.width()), max(1, canvas.height()))
        if self.name == AURORA_NAME:
            gradient.setColorAt(0, blend('#15262d', accent, .22))
            gradient.setColorAt(.48, QColor('#202a36'))
            gradient.setColorAt(1, blend('#272236', other, .22))
        else:
            gradient.setColorAt(0, blend('#18212b', accent, .12))
            gradient.setColorAt(.5, QColor('#202832'))
            gradient.setColorAt(1, blend('#1d202c', other, .12))
        canvas.workspace_brush = QBrush(gradient)
        # Repaint workspace margins, not the painted document on every timer tick.
        document = QRectF(canvas.pan.x(), canvas.pan.y(), canvas.doc_size[0]*canvas.zoom,
                          canvas.doc_size[1]*canvas.zoom).toAlignedRect()
        margins = QRegion(canvas.rect()).subtracted(QRegion(document))
        if not margins.isEmpty():
            canvas.update(margins)
        for button in list(getattr(self.window, 'tool_buttons', {}).values()) + list(getattr(self.window, 'swatch_buttons', [])):
            if button.accent != accent:
                button.accent = QColor(accent)
                button.update()
